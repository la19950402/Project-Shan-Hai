# Phase 15.5.49 — Phase 7 legendary/display-team DOM contract

## Base
- Based on `project-root-phase15.5.48-phase7-mainentry-dom-contract.zip`

## Goal
- Continue Phase 7 without touching boot/auth chain.
- Tighten DOM contracts for legendary admin/student panels and display-team editor.
- Reduce silent failures caused by missing DOM nodes.

## Files changed
- `js/main.entry.js`
- `js/core/state.js`

## What changed

### 1. Added main-entry DOM contract helpers
New helpers in `js/main.entry.js`:
- `getLegendaryAdminDom()`
- `getLegendaryStudentDom()`
- `getDisplayTeamDom()`

They all use `buildElementContract(...)` and report into both:
- `currentState.*DomContract`
- `window.__BOOT_DIAG.*DomContract`

### 2. Legendary admin panel now uses DOM contract
Updated:
- `loadLegendaryAdmin()`
- `publishLegendary()`

Covered ids:
- `legendaryAdminModal`
- `legendaryAddModal`
- `laActiveList`
- `laSelectId`
- `laPoints`
- `laReqAttr`
- `laReqCount`

### 3. Student legendary panel now uses DOM contract
Updated:
- `loadActiveLegendariesForStudent()`

Covered ids:
- `stuLegendaryList`
- `teacherSpeechText`
- `teacherAvatar`

### 4. Display team editor now uses DOM contract
Updated:
- `openDisplayTeamEditor()`
- `toggleDisplayTeamItem()`

Covered ids:
- `displayTeamModal`
- `dtGrid`
- `dtCountDisplay`

## State additions
Added to `currentState`:
- `legendaryAdminDomContract`
- `legendaryStudentDomContract`
- `displayTeamDomContract`

## Validation
- `node --check js/main.entry.js`
- `node --check js/core/state.js`
- Verified required ids exist in `index.html`
- Reviewed new helper scope and call sites for runtime-reference regressions

## Risk profile
- Low risk
- No changes to boot/auth entry chain
- No changes to Firebase auth/login flow
- No changes to canonical façade names used by HTML
