# 高風險檢查與即時修補（phase15.5.21）

## 這次先修掉的會報錯區

1. **BOSS 開戰前缺少核心依賴防呆**
   - `buildBattleTeamForStudent` 若初始化不完整，原本會直接進入後續流程。
   - 已補成明確提示並中止。

2. **BOSS 選角確認按鈕找不到時會靜默失敗**
   - `confirmBattleSelection()` 原本 `if (!btn) return;`。
   - 已改成明確提示。

3. **Boss 狀態檢查在 studentData 缺失時可能留下舊狀態**
   - 已補成直接清空 `currentBattleBoss` 並隱藏區塊。

4. **進入戰鬥場前若 Boss 或出戰成員不存在，原本可能在後續 DOM/資料流程炸掉**
   - `prepareBattleArena()` 已補防呆。

5. **題目渲染缺少關鍵 DOM / 題目資料時會直接 TypeError**
   - `renderQuizQuestion()` 已補：
     - 題目不存在
     - 問題文字區不存在
     - 選項容器不存在
     - 選項為空

6. **作答按鈕 index 對不上時會直接讀 `undefined.style`**
   - `selectQuizOption()` 已補 `selectedBtn` 檢查。

7. **多個 modal 說明面板直接抓 DOM 沒 null guard**
   - 已補：
     - `showImageModal()`
     - `showStatusInfo()`
     - `showAttrInfo()`
     - `showHackerAlert()`

8. **每日挑戰倒數元件缺件時會直接報錯**
   - `updateDailyQuestTimer()` 已補 `studentView / btn / timerText` 檢查。

## 仍屬高風險、但這輪先只記錄的區域

1. **專案仍保留大量平行入口鏈**
   - `bootstrap-entry.*` / `main.entry.*` 副本很多。
   - 目前啟用的是 `bossrepairclean2`，但包內仍有多份歷史入口。
   - 未來建議收斂成單一正式入口。

2. **主入口檔體積過大、責任過重**
   - `main.entry.bossrepairclean2.js` 仍承載大量 UI、學生端、老師端、商城、題庫、批量、戰鬥邏輯。
   - 高風險原因：任何一處小改動都可能影響 boot 與全域掛載。

3. **大量舊式 DOM 直取仍存在**
   - 雖然這輪先修了最容易炸的幾段，但整體專案仍有很多 `document.getElementById(...).xxx` 直取。
   - 建議逐步收斂成小型 view helpers。

4. **BOSS / 題庫資料格式相容邏輯仍混在 battle 模組內**
   - 目前先以可運作為主。
   - 後續應拆成 `quiz-normalizer` / `battle-boss-service` 類型的邏輯層。

5. **Firestore 路徑與權限仍有技術債**
   - `quiz_bank` 同時承擔題庫與 Boss 設定文件。
   - 後續建議將 `_BATTLE_TOWER_BOSS_` 移出題庫集合。

## 建議的未來改善順序

1. 先保持這版只修可用性，不再疊加新需求。
2. 收斂單一正式入口。
3. 把 `renderQuizQuestion()`、`prepareBattleArena()`、`checkBattleTowerStatus()` 這類高頻流程抽成較小函式。
4. 補一輪 smoke test：登入 / 每日挑戰 / 討伐 Boss / 老師端題庫 / 批量模式。
