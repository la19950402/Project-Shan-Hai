# phase15.5.37 debuff-clear-fix report

## 問題
老師面板的「清除全部狀態」會顯示成功，但學生的負面狀態實際上沒有被清除。

## 根因
真正的壞點不在 `teacher-actions.js` 的 `forceDebuff('Healthy')`。

`forceDebuff('Healthy')` 已正確把：
- `data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 }`
- `data.debuffs_timestamp = null`

送進 `saveToDB()`。

但是 `saveToDB()` 在 admin 路徑最後會呼叫：
- `syncStudentMirrorForSerial()`
- `mergeStudentRecords(primary, secondary, serial)`

而 `mergeStudentRecords()` 原本對 debuffs 的合併規則是：

```js
merged.debuffs[k] = Math.max(Number(base.debuffs?.[k]) || 0, Number(other.debuffs?.[k]) || 0);
merged.debuffs_timestamp = Math.max(Number(base.debuffs_timestamp) || 0, Number(other.debuffs_timestamp) || 0) || null;
```

這會導致：
- 新資料明明把 `Poison` 清成 `0`
- 舊鏡像資料如果還是 `1`
- 合併後又被 `Math.max(0, 1)` 拉回 `1`

所以表面上看起來就是「有保存，但狀態不會真正消失」。

## 最小修補
只改 canonical active chain：
- `js/main.entry.js`

改法：
- debuff state 不再用 `Math.max` 合併
- 若 primary 具有明確 debuff state，就以 primary 為準
- 只有 primary 沒有 debuff state 時，才退回 secondary

## 驗證
- `node --check js/main.entry.js` 通過
- 針對 bug 情境驗證：
  - primary = 清除後 0
  - secondary = 舊值 1
  - 舊規則結果：仍是 1
  - 新規則結果：正確為 0

## 影響範圍
這個修補會直接改善：
- 老師面板清除負面狀態
- 任何需要把 debuff stack 從大於 0 改成 0 的保存流程
- debuffs_timestamp 清空後又被舊鏡像時間戳拉回來的問題
