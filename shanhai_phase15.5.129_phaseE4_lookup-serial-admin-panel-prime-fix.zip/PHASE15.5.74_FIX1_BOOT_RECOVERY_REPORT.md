# Phase 15.5.74 Fix1 — Boot recovery, cache alignment, and next-step plan

## 1) 本次排查結論
這一包「打不開」的主因不是 Firebase 規則，也不是單一業務流程，而是 **active main entry 在抽 helper 後留下了 boot 級依賴缺口**。

最關鍵的 blocking root cause 有兩類：

### A. `main.entry.js` 缺少仍被 active chain 直接使用的 helper
在 `js/main.entry.js` 中，以下 helper 在舊版存在、在目前 active chain 仍被直接使用，但已被不完整抽離後遺失：

- `getContentProfile()`
- `isCatProfile()`
- `getCatBossVisualByType()`
- `getProfileAttributeInfo()`
- `getProfileDebuffInfo()`
- `getProfileLabels()`
- `getProfileFlags()`

修補後位置：
- `js/main.entry.js:244`
- `js/main.entry.js:257`
- `js/main.entry.js:274`
- `js/main.entry.js:285`
- `js/main.entry.js:290`
- `js/main.entry.js:295`
- `js/main.entry.js:299`

這些 helper 並不是只有互動時才會用到；在 active module 掛載時就已透過依賴注入傳進：
- `teacherActionsApi`
- `batchApi`
- `battleApi`
- `shopApi`
- `quizApi`
- `studentApi`

也就是說，若上述 helper 不存在，`main.entry.js` 在初始化模組時就可能直接拋出 `ReferenceError`，屬於 **boot 級故障**。

### B. `quiz-battle-config-utils` 已抽出，但 `main.entry.js` 沒有補 import
`PHASE15.5.70` 已說明 battle/quiz 的設定 helper 被抽到：
- `js/core/quiz-battle-config-utils.js`

但 active `js/main.entry.js` 當時沒有補完整 import，導致 wrapper 仍會呼叫未定義的 `*Core` 名稱。

本次補入：
- `normalizeQuizGradeTokenCore`
- `isQuizEnabledCore`
- `quizMatchesStudentGradeCore`
- `getStudentGradeInfoCore`
- `getBattleAudienceOptionsCore`
- `normalizeBossDiceCountCore`
- `normalizeBattleTowerDocCore`
- `getBattleBossConfigForAudienceCore`
- `getBattleBossConfigForStudentCore`
- `getBattleMonStageCore`
- `getBattleMonDiceCountCore`
- `getBattleStageLabelCore`

修補後位置：
- `js/main.entry.js:24`

這一類問題未必一進首頁就爆，但 battle/quiz/student 流程會不穩，屬於 **高優先 latent blocker**。

---

## 2) 本次實際修補內容

### 修補 1：補回 `main.entry.js` 遺失 helper
已在 canonical active chain 補回必要 helper，且沒有改動外部 API 名稱。

檔案：
- `js/main.entry.js`

### 修補 2：補齊 `quiz-battle-config-utils` import
將 `main.entry.js` wrapper 所需的 `*Core` helper 補齊 import。

檔案：
- `js/main.entry.js`

### 修補 3：避免 `Chart` CDN 失敗時在掛載階段直接炸掉
學生模組掛載原本直接傳裸 `Chart`，若 CDN 沒進來，可能在注入階段就丟 `ReferenceError`。

本次改為：
- `const ChartLib = window.Chart || globalThis.Chart || null;`
- 注入 `Chart: ChartLib`
- 在 `student.js` 的 `renderRadarChartRaw()` 補 `typeof Chart !== 'function'` guard

修補後位置：
- `js/main.entry.js:7242`
- `js/main.entry.js:7245`
- `js/modules/student.js`（雷達圖建立前 guard）

### 修補 4：battle 模組補齊 `getDailyResetAnchor` 依賴
`battle.js` 內部有呼叫 `getDailyResetAnchor`，但 deps destructure 未取出，屬於後續功能爆點。

檔案：
- `js/modules/battle.js`

### 修補 5：battle 模組重複局部變數收斂
`battle.js` 內部重複 `const arenaEls` 會增加維護風險，本次改成不同名稱，避免同方法內重覆局部宣告。

檔案：
- `js/modules/battle.js`

### 修補 6：NFC 建立改為 `window.NDEFReader`
將裸 `new NDEFReader()` 改為 `new window.NDEFReader()`，避免環境判定和靜態檢查混亂。

檔案：
- `js/main.entry.js`
- `js/modules/zones.js`

### 修補 7：active chain cache busting / build tag 對齊
為了避免修好後仍混吃舊快取，已將 active chain 版本識別統一成：
- `phase15phase74fix1`

已更新：
- `index.html:2241`
- `js/bootstrap-entry.js:1`
- `js/main.entry.js:1-24`
- `js/core/api-surface.js:1`
- `js/core/profile-visual-utils.js:1`
- active modules 內部 import query
- `js/ENTRY_CHAIN_MANIFEST.json:72-74`
- `js/main.entry.js:25` 的 `BUILD_TAG`

---

## 3) 本次驗證方式

### 已完成
1. canonical active chain 與本次修補檔案全部重新 `node --check`
2. active chain 重新做靜態交叉檢查
3. `tsc --checkJs` 再掃一次，已清掉本次關鍵類型：
   - 缺失 helper 名稱
   - 缺失 battle helper core 名稱
   - `Chart` 掛載階段裸引用
   - `NDEFReader` 裸引用
   - `battle.js` 同方法內重複局部變數
   - `getDailyResetAnchor` battle 依賴遺漏

### 目前仍無法在此容器內完整驗證的項目
因容器內瀏覽器策略限制與外網限制，這一輪無法做真正的 Firebase + CDN + DOM 全互動 smoke test，因此下面幾項仍需你在實際部署環境驗證：
- 首頁 boot 面板是否消失
- 登入是否正常
- 老師端查卡序 → 進學生頁
- 手動加分 / 移除狀態
- 題庫管理
- BOSS 挑戰
- 商城管理

---

## 4) 建議的立即 smoke test（按順序執行）

### A. Boot / Login gate
1. 開首頁
2. 確認沒有永遠停在 boot panel
3. Console 不應再出現：
   - `getProfileLabels is not defined`
   - `isCatProfile is not defined`
   - `getContentProfile is not defined`
   - `ReferenceError: Chart is not defined`
4. `typeof window.App` 應為 `object`
5. `typeof window.App?.bindAuthControls` 應為 `function`
6. 可正常登入

### B. 老師端高風險鏈
1. 查卡序
2. 進學生頁
3. 手動加分
4. 移除狀態
5. 補發 / 寫入 NFC（若設備支援）

### C. 學生端與共享資料鏈
1. 學生頁可開
2. 商城展示區可載入
3. 每日歷練可進
4. BOSS 可讀到資料並顯示
5. 排行榜可開
6. 專區可開

---

## 5) 後續優化方向與可執行計畫
以下不是重寫，而是遵守既定原則的 **穩定優先路線圖**。

## Phase A — 立即穩定（1~2 輪）
目標：先把 boot / login / teacher / boss / quiz / shop 的主鏈驗到穩。

### A1. 建立正式 smoke test 清單與回歸表
輸出物：
- `SMOKE_TEST_PHASE15.5.74_FIX1.md`

內容至少包含：
- boot
- login
- teacher lookup
- teacher add score
- teacher remove debuff
- batch mode
- quiz bank
- boss
- shop admin
- ranking
- zones

執行方式：
- 每輪修補都逐項打勾
- 每項記錄「成功 / 失敗 / console error / 復現步驟 / 涉及檔案」

### A2. 將 boot blockers 與 latent blockers 分開管理
輸出物：
- `ACTIVE_CHAIN_BLOCKERS.md`

分類：
- P0 boot blockers：會讓頁面打不開
- P1 flow blockers：登入後高機率爆
- P2 latent blockers：只在特定流程爆

### A3. 實機確認 CDN / Firebase 外部依賴
要檢查：
- `chart.js` 是否可載入
- Firebase CDN module 是否正常
- 部署站點是否 HTTPS / 可用 Web NFC

執行標準：
- 若外部 script 或 CDN 曾失敗，要建立 fallback 策略，不要再讓裸全域直接參與 boot

---

## Phase B — 主鏈減重，但只做低風險抽離（2~4 輪）
目標：把 `main.entry.js` 持續變薄，但每輪只抽純 helper，不碰老師保存鏈。

### B1. 把 profile/content helper 正式抽成獨立 core 模組
建議新增：
- `js/core/content-profile-runtime.js`

抽離對象：
- `getContentProfile`
- `isCatProfile`
- `getCatBossVisualByType`
- `getProfileAttributeInfo`
- `getProfileDebuffInfo`
- `getProfileLabels`
- `getProfileFlags`

做法：
- 先建立 core 模組
- `main.entry.js` 保留同名 wrapper
- wrapper 只轉呼叫 core
- 不改外部注入 API

完成標準：
- `main.entry.js` 行數下降
- 對外呼叫點不變
- boot / student / battle / shop / teacher smoke test 全過

### B2. 將 `main.entry.js` 的學生商城展示區 helper 抽到 student/shop shared helper
候選抽離：
- `normalizeStudentShopMode`
- `resolveStudentShopCardFooter`
- `normalizeStudentShopItem`
- `renderStudentShopShowcaseCards`

限制：
- 本階段不要碰購買交易
- 只處理展示與純資料正規化

### B3. 把 UI/DOM contract 查找再集中
目前建議新增：
- `js/core/dom-helpers.js` 或 `js/core/view-dom-contracts.js`

先抽：
- 純 `getXxxDom()` 類 helper
- 純 `pickElementsById` 類流程

不要先抽：
- teacher save chain
- battle execution chain
- auth boot chain

---

## Phase C — 老師端保存鏈強化（高優先功能穩定）
目標：你最在意的「老師幫學生加分、移除狀態一定要穩」。

### C1. 建立 teacher flow 專用驗證腳本與檢查表
檢查點：
- 查卡序後 `currentState.studentData`
- 查卡序後 `currentState.currentUid`
- `prepareActionFromButton()`
- `commitAction()`
- `forceDebuff()`
- `saveToDB()`
- 寫入後 UI 回填

### C2. teacher-actions.js 做第二輪依賴顯式化
原則：
- 繼續消除隱性 `App.*` / `this.*`
- 改成 injected deps / local wrapper
- 每次只收斂 1~2 個 helper 類群

### C3. 對學生 target hydration 做統一入口
建議集中：
- `resolveTeacherTargetStudent()`
- `hydrateTeacherTargetState()`

避免：
- lookup / panel open / action commit 各自拼裝 target state

---

## Phase D — 題庫 / BOSS / 商城 的共享資料鏈整理
目標：降低資料格式混雜造成的互相影響。

### D1. 題庫資料格式正規化集中化
建議新增：
- `js/core/quiz-record-normalizers.js`

集中：
- 題目欄位兼容
- 正確答案兼容
- options/choices/selections 兼容
- grade / audience 對應

### D2. BOSS tower doc schema 固化
輸出物：
- `BATTLE_TOWER_SCHEMA.md`

明確欄位：
- `audiences.default`
- `audiences.grade4`
- `audiences.grade5`
- `audiences.support`
- `bossDiceCount`
- `gatekeeperQuizId`

### D3. 商城學生端模式正式化
目前已經有：
- `preview`
- `request_only`
- `direct`
- `admin_only`

下一步要做的是：
1. schema 文件化
2. 老師端商品欄位 UI 對應
3. request flow 的資料模型
4. direct flow 的扣幣/扣庫存交易設計

注意：
- 這一塊只能在 teacher save chain 穩定後再做

---

## Phase E — 可觀測性與部署穩定
目標：避免下一次再出現「其實是混版 / 快取污染」。

### E1. 建立單一版本號策略
規範：
- `index.html` module src query
- `bootstrap-entry.js` 的 `BOOT_ID`
- `main.entry.js` 的 `BUILD_TAG`
- active chain import query
- `ENTRY_CHAIN_MANIFEST.json`

每次 release 一律同號同步更新。

### E2. 建立 boot diagnostics 固定輸出
固定記錄：
- active build tag
- active boot id
- module import version tag
- window.App ready state
- login controls bound state

### E3. 增加 deploy checklist
部署前固定檢查：
1. hard reload
2. 清 service worker / cache（若有）
3. 看 boot panel
4. 看 console 第一屏
5. 看 `window.__BOOT_DIAG`
6. 測登入

---

## 6) 目前建議的實作優先順序
1. 先部署本次 `fix1`
2. 先驗 boot / login / teacher / quiz / boss / shop / ranking / zones smoke test
3. 若 smoke test 過，再做 `content-profile-runtime` 抽離
4. 之後再做 teacher target/save chain 第二輪收斂
5. 最後才考慮學生商城 request/direct 交易流與更深的效能優化

---

## 7) 本次修補原則是否符合交接策略
是，原因如下：
- 只改 canonical active chain
- 沒有新增新的入口副本
- 沒有擴大全域暴露面
- 先修 boot blocker，再談優化
- 再額外補 cache 對齊，避免混版
- 沒有回退到大改 HTML / 大改 UI 結構

