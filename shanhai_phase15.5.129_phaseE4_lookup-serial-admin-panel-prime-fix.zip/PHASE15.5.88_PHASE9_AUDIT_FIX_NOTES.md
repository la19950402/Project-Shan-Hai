# PHASE 15.5.88 — Phase 9 Audit Fix: Battle Session + Daily Result Guard

## 本輪目標
在 phase15.5.87 的基礎上，針對共用 `quizSession` 的老風險做回掃，優先修掉「語法沒錯、但舊 session 狀態干擾新流程」這種高信心 bug。

## 這次檢查到的主因

### 1. BOSS / battle 進題目前沒有走 `beginQuizSession('battle')`
Daily challenge 已經引入了：
- `quizSession.aborted`
- `quizSession.answerPending`
- `quizSession.resultShown`
- `quizSession.sessionToken`
- `quizSession.advanceTimerId`

但 battle 在 `confirmBattleSelection()` 仍只是手動塞：
- `quizSession.mode = 'battle'`
- `quizSession.questions = [qD]`
- `quizSession.currentIndex = 0`
- `quizSession.score = 0`

這表示如果上一輪 daily / quiz 關閉時留下：
- `aborted = true`
- `answerPending = true`
- `resultShown = true`

新的 battle session 仍可能被舊狀態干擾，造成「能選出戰，但題目不一定能正常起來」或答題互動怪異。

### 2. Battle 答題沒有防重入
Battle 模式的答案按鈕直接走 `App.handleBattleQuizAnswer(...)`，之前沒有：
- `answerPending` guard
- 同題按鈕 disable
- session token 比對

所以快速連點或雙擊時，理論上可能重複觸發：
- `prepareBattleArena()`
- 或答錯後的保存流程

### 3. Daily result DOM 缺失時，只 alert 但不 abort session
`showQuizResult()` 在找不到 `quizScoreText / quizResultDesc` 時，先前只會 alert 然後 return。
這會留下半殘的 quiz session 狀態，後面再重啟 quiz / battle 時，比較容易出現 stale state 問題。

## 本輪修正

### A. battle 正式改走 `beginQuizSession('battle')`
檔案：
- `js/modules/battle.js`
- `js/main.entry.js`

作法：
- 在 `createBattleModule(...)` 注入 `beginQuizSession`
- `confirmBattleSelection()` 啟動 battle 題目時，先呼叫 `beginQuizSession('battle')`
- 若 helper 不可用，才退回最小手動 reset

效果：
- battle 會跟 daily 使用同一套 session 清理規則
- 舊的 `aborted / answerPending / resultShown` 不再殘留影響 battle

### B. battle 答題增加防重入
檔案：
- `js/modules/battle.js`

作法：
- `handleBattleQuizAnswer()` 開頭增加：
  - `quizSession.aborted` guard
  - `quizSession.answerPending` guard
  - `expectedToken` 驗證
- 點答後先 disable 所有答題按鈕
- finally 中把 `answerPending` 歸零

效果：
- 快速連點不會重複受理 battle 答案
- battle arena / save 路徑不會因雙擊重複進入

### C. result DOM 缺失時直接 abort session
檔案：
- `js/main.entry.js`

作法：
- `showQuizResult()` 找不到結算 DOM 時，先 `abortQuizSession('result_missing_dom')` 再 alert

效果：
- 避免留下半殘的結果態 session
- 降低後續 battle / daily 被舊 session 汙染的機率

## 驗證
- `node --check js/main.entry.js`
- `node --check js/modules/battle.js`
- 全部 `js/**/*.js` 再跑一輪 syntax check
- 結果：0 個語法錯誤

## 版本
- query tag: `phase15phase88phase9auditfix`
- build tag: `v15.5.88-phase9-audit-fix-battle-session-and-result-guard-20260315`
