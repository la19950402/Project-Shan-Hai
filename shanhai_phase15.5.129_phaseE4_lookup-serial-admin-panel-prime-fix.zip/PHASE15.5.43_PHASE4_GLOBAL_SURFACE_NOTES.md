# Phase 15.5.43 — Phase 4 Global Surface Convergence (Round 1)

## 基底
- 實際可用基底：`project-root-phase15.5.41-phase2-teacher-target-context.zip`
- 說明：容器內未找到先前口頭提到的 `15.5.42` 壓縮檔，因此本輪以目前可讀取的最新基底繼續推進，並避免回退已知穩定鏈。

## 本輪目標
在不破壞 `window.App / window.UI` 舊相容層的前提下，收斂第一批非必要全域：
1. 將鑄造入口收回 `App` façade
2. 將 `ShanHaiSystem` 改為 debug-only 最小只讀物件
3. 同步更新 surface policy 與 HTML 呼叫點

## 修改檔案
- `index.html`
- `js/main.entry.js`
- `js/core/global-bridge.js`
- `js/core/api-surface.js`

## 修改重點
### 1. 鑄造入口改由 `App.forceOpenCardForge(...)` 統一進入
- `index.html` 的鑄造按鈕從 `window.forceOpenCardForge(event)` 改為 `App.forceOpenCardForge(event)`
- `js/main.entry.js` 的按鈕 click fallback 同步改走 `this.forceOpenCardForge(evt)`
- `js/main.entry.js` 在 façade 掛載完成後，正式補上 `App.forceOpenCardForge = (...args) => forceOpenCardForge(...args)`

### 2. 停止在正常 runtime 暴露 `window.forceOpenCardForge`
- `js/core/global-bridge.js` 的 `exposeLegacyGlobals()` 現在會主動刪除 `root.forceOpenCardForge`
- 這代表鑄造入口的主路徑正式收回 `App` façade，降低全域旁路入口

### 3. `ShanHaiSystem` 改為 debug-only，且縮成最小只讀摘要
- `buildSystemNamespace()` 不再暴露 `App/UI/currentState/db/auth/storage` 等大範圍內部物件
- 改為只輸出：
  - `version`
  - `buildTag`
  - `splitBridgeEnabled`
  - `facade` 摘要
  - `surface` 摘要
  - `dev.clearAssetUrlCache`
- `exposeLegacyGlobals()` 只有在 debug/dev/test 條件成立時才會掛 `window.ShanHaiSystem`

### 4. Legacy global policy 同步收斂
`js/core/api-surface.js`
- `LEGACY_GLOBAL_POLICY.required` 從 `['App','UI','forceOpenCardForge','ShanHaiSystem']`
  改為 `['App','UI']`
- `ShanHaiSystem` 與 `__clearAssetUrlCache` 改列為 `debugOnly`
- `forceOpenCardForge` 改納入 `App` surface transitional 監控

## 為什麼這樣修
- 舊 HTML 仍大量依賴 `window.App / window.UI`，本輪不能硬拔
- `window.forceOpenCardForge` 是可先安全收回的旁路入口，因為 active chain 已可統一改走 `App` façade
- `window.ShanHaiSystem` 過去暴露太多內部狀態，會鼓勵外部直接依賴內部實作；改成 debug-only 最小摘要能降低耦合風險

## 驗證
### 語法檢查
- `node --check js/core/api-surface.js`
- `node --check js/core/global-bridge.js`
- `node --check js/main.entry.js`

### 靜態檢查
- active HTML / main entry 已無 `window.forceOpenCardForge` 依賴
- `App.forceOpenCardForge` 已掛上
- legacy global required 已收斂為 `App/UI`
- `ShanHaiSystem` 僅在 debug 條件才暴露

## 本輪刻意沒動
- `window.App / window.UI` 相容層
- 老師端保存邏輯
- 題庫 / BOSS 業務邏輯
- 歷史副本與 archive 檔案

## 下一步建議
第五階段可接著做：
1. 讓 surface policy 與 HTML 入口監控更完整
2. 盤點 `App` 上仍屬於 transitional 的方法，區分哪些可以再收斂、哪些仍需保留
