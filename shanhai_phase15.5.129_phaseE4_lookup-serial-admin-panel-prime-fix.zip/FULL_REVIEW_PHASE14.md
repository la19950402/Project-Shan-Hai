# Phase 14 全面檢查報告

## 已執行的檢查

1. `js/` 目錄所有 `.js` 檔做 `node --check` 語法檢查：**通過**。
2. 掃描所有 ES module `import`：**本地相對路徑皆存在**。
3. 檢查 `index.html` 的 `App.xxx()` 事件呼叫：**大多數可在 `main.js` 或 façade 清單中對應到**。
4. 檢查 `debug-flags.js`：**預設 `enabled = false`，boot panel / fallback login / global boot error capture 只在 dev/test/debugRequested 啟用**。
5. 檢查 `app-facade.js`：**已集中定義模組化 API 掛載規則**。

## 主要發現

### A. 可用性 / 低階語法
- 本輪未發現新的 `Unexpected token` 類語法錯。
- 本地相對 import 路徑無缺失。
- `main.js` 仍引用版本參數 `?v=phase14facade1`，本身可用。

### B. 相容層收斂程度
- 雖然已新增 `js/core/app-facade.js`，但 `main.js` 內仍存在大量直接 `App.xxx = ...` 或 `App.xxx = function() {}` 的 legacy 掛載。
- 特別是學習扶助 / 科展專區、卡片鍛造 fallback、部分診斷與工具類功能仍直接留在 `main.js`。
- 這代表 façade **已建立，但尚未完全成為唯一掛載入口**。

### C. Debug / fallback
- `debug-flags.js` 設計合理，prod 預設不會顯示 boot panel，也不會自動啟用 fallback login。
- 但 `bootStatusPanel` DOM 仍常駐於 `index.html`，只是由 JS 在 prod 隱藏，屬於可接受的保守做法。

### D. 快取版本參數一致性
- 部分 Phase 13 模組檔內 import 仍保留 `?v=phase13modules1`，雖然不會直接造成壞掉，但會增加快取版本辨識的混亂。
- 建議下一輪統一版本參數命名，例如全部改為 `phase14facade1` 或抽成單一 build tag。

## 目前判定

### 可以判定為穩定的項目
- 模組語法完整。
- façade 與 debug flags 可正常存在。
- 目前**不建議立刻導入 HTML partials**。

### 尚未完全收尾的項目
1. `main.js` 仍過大，且留有大量 legacy 直接掛載。
2. `window.forceOpenCardForge` 仍是全域 escape hatch。
3. 專區（support/science）功能仍高度集中於 `main.js`，未完全收束到 façade / service 層。
4. 版本參數命名未統一。

## 對 HTML partials 的評估

**暫不建議現在導入。**

原因：
- `main.js` 仍高度依賴固定 `id` / `getElementById` / `innerHTML`。
- façade 雖已建立，但 legacy 綁定尚未完全收斂。
- 此時切 HTML partials，最容易引發 DOM 載入順序與元素不存在問題。

## 建議下一步（優先順序）

1. **收斂 façade 成唯一掛載入口**
   - 把 `main.js` 內剩餘的 direct `App.xxx = ...` 盤點成清單。
   - 能模組化的搬進模組；不能搬的至少透過 `app-facade.js` 統一暴露。

2. **統一版本參數 / build tag**
   - 避免 `phase13modules1`、`phase14facade1` 混雜。

3. **整理全域 escape hatch**
   - 例如 `window.forceOpenCardForge`，保留但標記為唯一例外。

4. **做一次人工回歸測試清單**
   - 老師登入
   - 掃描學生
   - 手動加分
   - 批量模式
   - Boss 挑戰與結算
   - 商城
   - 題庫
   - 排行榜
   - 學習扶助 / 科展專區

在以上 4 點完成前，HTML partials 仍不建議啟動。
