# PHASE15.5.77 Performance Phase 2 - Ranking Summary Fallback

## 修改重點
- `js/main.entry.js`
  - 新增 `leaderboard_public` collection 常數。
  - 新增排行榜摘要 helper：
    - `getRankingDisplayItems()`
    - `getRankingLegendaryPoints()`
    - `buildLeaderboardSummaryData()`
    - `normalizeLeaderboardSummaryRecord()`
    - `loadLeaderboardSummary()`
    - `syncLeaderboardSummaryForSerial()`
    - `backfillLeaderboardSummaryEntries()`
  - `warmRankingCache()` 改為：
    1. 優先讀 `leaderboard_public` 的 top-N 摘要。
    2. 若摘要不存在或讀取失敗，再 fallback 舊的 full scan `students`。
    3. fallback 後會背景回寫 top 30 摘要，讓下一次排行榜可以直接走輕量路徑。
  - `renderRankingRows()` 改為可同時渲染：
    - 舊版完整學生文件
    - 新版 `leaderboard_public` 摘要文件
  - `syncStudentMirrorForSerial()`、`saveToDB()`、匿名初始化建檔流程，新增非阻斷式 leaderboard summary 同步。
- `js/modules/ranking.js`
  - 改成優先使用 main entry 注入的 ranking cache/render helper。
  - 保留舊 full scan fallback，避免注入鏈意外斷掉時排行榜完全失效。
- `index.html`
- `js/bootstrap-entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/modules/shop.js`
  - active chain 版本識別同步推進至 `phase15phase77perfphase2ranking`。

## 為什麼這樣修
這一輪的目標不是一次重寫排行榜，而是先把最重的讀取模式換掉：

舊路徑：
- 開排行榜 -> `getDocs(collection(db, COLLECTION_NAME))`
- 全量抓回 students
- 前端排序
- 切前 30

新路徑：
- 開排行榜 -> 優先查 `leaderboard_public`
- 只取 top 30 摘要
- 無資料或失敗時才回退 full scan
- 第一次回退後，順手把前 30 名摘要批次寫回去

這樣做的好處：
- 不需要一次就把整個資料模型重構完成。
- 現有環境沒有 `leaderboard_public` 也不會立刻壞掉。
- 只要排行榜開過一次、或學生資料有保存過，summary 就會開始長出來。
- 之後排行榜越來越容易走輕量查詢，而不是一直全掃 students。

## 驗證方式
- `node --check js/main.entry.js`
- `node --check js/modules/ranking.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 再跑一輪 `node --check`
- 結果：`syntax_errors 0`

## 風險說明
- `leaderboard_public` 目前是低風險導入版，依賴前端同步與 fallback backfill 漸進建立資料。
- 若 Firestore Rules 尚未允許管理端寫入 `leaderboard_public`，摘要同步會降級為 warning，不會阻斷原本 students/student_pages 儲存鏈。
- 這一輪沒有碰排行榜 UI 結構，也沒有改老師端保存主鏈。

## 部署後優先驗證
1. 首頁可正常 boot
2. 登入正常
3. 第一次打開排行榜：
   - 仍可顯示（就算 summary 還沒建完）
4. 第二次打開排行榜：
   - 應優先吃 `leaderboard_public`
   - 體感應比第一次更快
5. console 不應出現新的 boot blocker

## 下一輪建議
- 第三輪改 BOSS / 題庫：
  - 先做題池索引摘要
  - 停止 battle 路徑每次全掃 `quiz_bank`
