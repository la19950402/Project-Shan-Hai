# Phase 15.5.6 Hotfix

本輪收斂目標：商城與題庫流程穩定化。

重點：
- 商城購買/商品儲存/刪除/贈禮加入 busy guard 與 try/catch
- 題庫載入/新增/修改/刪除/啟用切換加入 busy guard 與錯誤提示
- state.js 新增 shop/quiz 作業旗標
- 版本參數統一為 phase15hotfix6
