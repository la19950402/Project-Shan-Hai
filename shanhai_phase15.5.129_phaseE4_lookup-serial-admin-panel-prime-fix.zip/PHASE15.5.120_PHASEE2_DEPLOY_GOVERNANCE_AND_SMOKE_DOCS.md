# PHASE15.5.120 — Phase E-2 Deploy Governance / Smoke Docs + Deep Check

## 本輪目標
在不變更 canonical active chain、不修改 boot/version chain、也不再拆業務邏輯的前提下，補齊 **deploy governance / smoke docs**，讓 active chain 的部署前檢查、部署後驗收、以及 rollback 路徑形成可執行、可驗證的治理層。

## 本輪實作

### 1) 新增部署治理文件
新增：
- `DEPLOY_CHECKLIST.md`
- `SMOKE_TEST_ACTIVE_CHAIN.md`

內容涵蓋：
- canonical active chain 與固定 `BOOT_ID / BUILD_TAG`
- deploy 前腳本檢查順序
- deploy 後 smoke test 執行順序
- rollback / archive 參考規則
- 最小必跑案例與記錄要求

### 2) 新增 deploy governance 深檢
新增：
- `scripts/deep-check-phasee-deploy-governance.mjs`

檢查內容：
- `DEPLOY_CHECKLIST.md` 是否包含 active chain、build tag、腳本順序與 rollback 規則
- `SMOKE_TEST_ACTIVE_CHAIN.md` 是否包含 boot / login / save / battle / shop / collection / forge / batch/auth 等手動 smoke 路徑
- manifests 是否已記錄 deploy / smoke docs 的治理註記

### 3) manifests 補 deploy governance 註記
已更新：
- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/MODULE_VARIANT_MANIFEST.json`

更新方向：
- notes / riskNotes 明確補入 `DEPLOY_CHECKLIST.md` 與 `SMOKE_TEST_ACTIVE_CHAIN.md`
- 讓 archive governance 之後的部署治理不只存在於外部報告，也留在 active manifests 的治理脈絡裡

## 量化結果
- `DEPLOY_CHECKLIST.md`：**99 行**
- `SMOKE_TEST_ACTIVE_CHAIN.md`：**88 行**
- `scripts/deep-check-phasee-deploy-governance.mjs`：**87 行**
- deploy checklist 腳本引用數：**12**
- smoke sections：**8**
- 最小必跑案例：**8**

## active chain 狀態
- `BOOT_ID`：`phase15phase103fix15battlebossconfigsplit`
- `BUILD_TAG`：`v15.5.103-fix15-battle-boss-config-split-20260316`
- canonical active chain：
  - `js/bootstrap-entry.js`
  - `js/main.entry.js`
  - `js/core/app-facade.js`
  - `js/core/api-surface.js`

本輪 **未變更** active runtime 邏輯與 boot/version chain。

## 驗證結果
通過：
- `scripts/validate-active-chain.mjs`
- `scripts/deep-check-active-flow.mjs`
- `scripts/deep-check-phasec-collection-boundaries.mjs`
- `scripts/deep-check-phasec-evolution-boundaries.mjs`
- `scripts/deep-check-phasec-collection-editor-boundaries.mjs`
- `scripts/deep-check-phasec-forge-actioncard-boundaries.mjs`
- `scripts/deep-check-phasec-save-hub-boundaries.mjs`
- `scripts/deep-check-phased-auth-legacy-deps.mjs`
- `scripts/deep-check-phased-student-legacy-deps.mjs`
- `scripts/deep-check-phased-legacy-reaudit.mjs`
- `scripts/deep-check-phasee-archive-governance.mjs`
- `scripts/deep-check-phasee-deploy-governance.mjs`

## 目前階段判定
- **Phase A**：完成
- **Phase B**：完成
- **Phase C**：完成
- **Phase D**：完成
- **Phase E-1（archive / variant governance）**：完成
- **Phase E-2（deploy governance / smoke docs）**：完成

目前專案已正式進入 **最終治理收尾期**，active runtime、archive 邊界、deploy/smoke 順序都已形成可驗證治理層。

## 剩餘工作與後續規劃

### Phase E-3：Firestore Rules alignment
下一輪最合理：
- 依 canonical active path 與實際 collection/doc 使用情況，整理 Firestore Rules 對照
- 明確標記哪些 collection scope 已可確認
- 標記哪些 scope 仍需人工確認
- 形成 rules alignment report

### Phase E-4：final release governance re-audit
最後一輪建議：
- 對 active chain / manifests / archive / deploy docs / rules notes 再做一次總盤
- 確認沒有 phase 間文件失配
- 形成最終可交接的執行版報告

## 本輪結論
這輪的價值不是再減少主入口行數，而是把部署治理從「口頭流程」變成「文件 + 腳本 + manifest 註記」三層一致。之後不論是部署、交接、re-audit 或 rollback，都會以 canonical active chain 與這兩份 deploy/smoke 文件為唯一操作基準。
