# 第一次全域收斂（最保險版本）

這一輪只做最低風險整理，不直接移除 `window.App` / `window.UI`。

## 這次實作內容

1. 新增 `js/core/global-bridge.js`
   - 集中管理剩餘必要全域橋接
   - 將 `forceOpenCardForge`、`ShanHaiSystem`、`__clearAssetUrlCache` 的暴露集中處理

2. `__clearAssetUrlCache` 不再在 `main.js` 直接掛成全域
   - 改為本地函式 `__clearAssetUrlCache()`
   - 正式環境預設不暴露到 `window`
   - 仍可由 `window.ShanHaiSystem.dev.clearAssetUrlCache()` 使用
   - 只有 dev / test / debug 模式才掛回 `window.__clearAssetUrlCache`

3. `forceOpenCardForge` 改為 bridge 建立
   - HTML 既有 `onclick="return window.forceOpenCardForge(event);"` 保持不變
   - 但全域函式的建立邏輯從 `main.js` 抽離到 `global-bridge.js`

4. `window.ShanHaiSystem` 改為經由 `buildSystemNamespace()` 組裝
   - 將 dev helper 收斂到 `ShanHaiSystem.dev`

## 為什麼這是最保險的第一刀

- 不動 `window.App` / `window.UI`
- 不改 HTML 結構
- 不改既有 `onclick`
- 不動老師端 / Boss / 批量 / 商城 / 題庫業務規則
- 只集中剩餘必要全域入口與 debug helper

## 這一輪後的剩餘全域

### 必要相容層
- `window.App`
- `window.UI`

### 過渡保留
- `window.forceOpenCardForge`
- `window.ShanHaiSystem`

### 條件式 debug
- `window.__clearAssetUrlCache`（僅 dev/test/debug 模式）
