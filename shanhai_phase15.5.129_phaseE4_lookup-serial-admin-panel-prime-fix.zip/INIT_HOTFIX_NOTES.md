# Phase 15.5.8 Init Guard Hotfix

本輪只修初始化鏈防呆，不更動業務邏輯。

## 修正內容
- `setupEventListeners()` 內未防呆 DOM 綁定改為 null-safe：
  - `scanNfcBtn`
  - `submitRegBtn`
  - `submitRegAndWriteBtn`
  - `writeNfcLinkBtn`
- `usbScannerInput.focus()` 改為 null-safe
- 全局 click handler 內的 `classList.contains()` 讀取改為 null-safe
- `onAuthStateChanged` callback 加上完整 `try/catch`
- admin snapshot callback 的 `dashboardView/adminView` 判斷改為 null-safe
- 版本字串統一為 `phase15inithotfix2`

## 目標
避免因缺少單一 DOM 元素、焦點操作失敗、或 auth callback 例外導致整體初始化中斷，表現為「登入按鈕沒反應」。
