# PHASE15.5.93 FIX5 — Student Load Unification

## 本輪目標
把老師端「查卡序 -> 載入學生 -> snapshot 回來 -> UI 更新」鏈路往單一路徑收斂，降低：

- 查學生時的重複綁定與重複 UI 變動
- 已經顯示同一位學生時再次查詢造成的無效重 render
- 學生載入上下文不明，後續難以追查的問題

## 實際修改

### 1. `lookupByCardSeq()` 改成 defer selection
檔案：`js/main.entry.js`

- 查卡序時，`lookupTeacherTargetBySerial()` 現在以 `deferSelection: true` 先回傳已解析的學生資料
- 不再在 lookup 階段先行綁定 `currentUid/studentData`、再進 `loadStudentData()` 做第二次完整綁定
- 真正的顯示與綁定改由 `loadStudentData()` 接手

### 2. `lookupTeacherTargetBySerial()` 支援 defer selection
檔案：`js/modules/teacher-actions.js`

新增行為：

- `options.deferSelection === true` 時：
  - 只做資料讀取、舊 pending action 清理、teacher target context 同步
  - 不立即更新學生面板、不立即寫 active studentData
- 保留原本非 defer 模式的行為，避免影響其他老師端流程

### 3. `loadStudentData()` 補齊載入上下文與同目標 guard
檔案：`js/modules/student.js`

新增：

- `normalizeSerialLike()`
- `studentLoadMode`
- `studentLoadRequestedUid`
- `studentLoadRequestedAt`
- `studentLoadActiveSerial`

新增邏輯：

- 如果 admin 端已經正在顯示同一位學生，而且 `preloadedData` 與上次 render signature 相同：
  - 不再做多餘的 preloaded render
  - 只保留 snapshot rebind 與 target context 同步
- `docRef` 改成優先使用標準化後的 `requestedSerial`
- 載入成功、snapshot 缺失、snapshot error 時，會正確更新：
  - `studentHydrationPending`
  - `studentHydrationError`
  - `studentLoadActiveSerial`

### 4. 深度檢查腳本補強
檔案：`scripts/deep-check-active-flow.mjs`

新增檢查：

- lookup 是否有 `deferSelection: true`
- teacher-actions 是否真的支援 defer selection
- student same-target rebind guard 是否存在
- student load context fields 是否已正式加入 state
- docRef 是否使用標準化 serial

## 本輪版本
- `BOOT_ID`: `phase15phase93fix5studentloadunify`
- `BUILD_TAG`: `v15.5.93-fix5-student-load-unification-20260315`

## 驗證結果

### Syntax
- `find js -name '*.js' | xargs node --check`：通過

### Active chain
- `node scripts/validate-active-chain.mjs`：通過

### Deep check
- `node scripts/deep-check-active-flow.mjs`：通過

## 本輪完成後的判讀
這一輪已把查卡序與載入學生之間最明顯的「雙階段綁定」收斂掉一層，並補齊了學生載入上下文狀態。

但仍未完全結案的點：

- `main.entry.js` 仍偏大
- `main.entry.js` 內仍有 21 個 `getDocs(...)`
- 老師端查卡序與學生載入雖已更接近單一路徑，但仍未完全抽成獨立服務層

## 建議部署後優先回測
1. 用同一卡序連續查兩次，確認第二次不再有明顯重刷
2. 快速切兩位學生，確認不會回跳前一位
3. 查學生後立即做老師端操作，確認 target context 正常
4. 學生不存在、網路失敗時，確認 hydration error 能被記錄
