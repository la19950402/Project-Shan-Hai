# Phase 15.5.29 - Risk Reduction Phase 5

## 本輪目標
- 不新增全域變數
- 將 active module variants 收回 canonical 檔名
- 逐步消除高風險 `this.*` helper 寫法

## 已完成
1. battle / shop / quiz / zones 的 active 實作已收回 canonical 檔名。
2. main entry 現在直接載入 `battle.js` / `shop.js` / `quiz.js` / `zones.js`。
3. battle 模組改用 injected `getDailyResetAnchor`，不再依賴 `this.getDailyResetAnchor`。
4. shop 模組將 busy helpers 收斂為 module-local closures，並以 injected deps 取代部分跨模組 `this.*` helper。
5. quiz 模組將 `setQuizBusy` / `isQuizBusy` 收斂為 module-local closures，降低 façade 遺漏時的崩壞風險。

## 下一步
- 繼續將 shop / battle 中剩餘的跨模組 `this.*` helper 逐步改成 injected deps。
- 針對 zones 模組補共享 DOM query helper，降低 runtime 直取風險。
- 開始清點可以安全刪除的 archived variants（不在本輪執行刪除）。
