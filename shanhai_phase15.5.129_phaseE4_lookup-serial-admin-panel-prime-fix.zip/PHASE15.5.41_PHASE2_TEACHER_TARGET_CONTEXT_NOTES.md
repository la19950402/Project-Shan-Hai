# Phase 15.5.41 — Phase 2 Teacher Target Context

## 修改重點

這一階段落實「老師端 target context 固化」，目標是讓以下鏈路使用一致的 target：

- 查卡序 → 進學生頁
- 老師手動加分（prepare / commit）
- 狀態調整（forceDebuff）
- 鑄造道具卡（open / start forge）
- 管理員補發

## 這次修改的檔案

- `js/core/state.js`
- `js/modules/teacher-actions.js`
- `js/main.entry.js`
- `js/modules/student.js`
- `js/core/global-bridge.js`

## 這次怎麼修

### 1. 在 `currentState` 補正式的 `teacherTargetContext`
新增欄位：

- `serial`
- `currentUid`
- `studentName`
- `source`
- `action`
- `hydrated`
- `hasStudentData`
- `activeToken`
- `lastResolvedAt`
- `lastLookupAt`
- `lastHydratedAt`
- `lastSavedAt`
- `lastError`

並補上 `teacherActionSubmitting: false` 的預設值。

### 2. 在 `teacher-actions.js` 建立 context 同步與診斷 helper
新增：

- `getTeacherTargetContextBase()`
- `normalizeTeacherTargetData()`
- `syncTeacherTargetContext()`
- `syncTeacherTargetDiagnostics()`
- `getTeacherTargetContext()`
- `clearTeacherTargetContext()`
- `diagnoseTeacherTarget()`

### 3. `hydrateTeacherTargetData()` 改成會優先吃 context serial
`resolveTeacherTargetSerial()` 現在會依序看：

- explicit serial
- data.card_seq / data.serial
- `teacherTargetContext.serial/currentUid`
- `currentState.studentData`
- `currentState.currentUid`

所以當 `studentData` 一時缺失時，老師端操作仍可用 context 重新 hydrate 正確學生。

### 4. `prepareAction()` / `commitAction()` 固定同一個 target serial
- `prepareAction()` 會把 `targetSerial` / `targetName` 存進 `currentState.pendingAction`
- `commitAction()` 會優先使用 `pendingAction.targetSerial` 重新 hydrate 與保存

這樣可避免 preview 開啟後 target 被切走，導致加分落到錯學生。

### 5. Forge 與 Debuff 操作同步使用 target context
- `openCardForge()` / `startCardForge()` 會同步 `teacherTargetContext`
- `pendingForgeData` 補入 `targetSerial` / `targetName`
- `forceDebuff()`、死亡重置、老師補發都會在 hydrate/save 前後同步 context

### 6. 查卡序與 admin snapshot 會回補 context
- `lookupByCardSeq()`：查到、查無、查詢錯誤都會更新 `teacherTargetContext`
- `student.js` 的 admin `loadStudentData()` snapshot 成功/失敗也會更新 context
- `global-bridge` 的 `forceOpenCardForge` 會先同步一次 context 再委派

## 為什麼這樣修

目前老師端不穩的核心不是單一按鈕，而是：

- target serial 來源分散
- `currentState.studentData` 可能暫時缺失
- 查卡序、snapshot、preview、保存之間沒有同一份固定 target context

這次先把「誰是目前操作對象」固定成一份 context，再讓各操作共用，能降低：

- 明明剛查到學生，後續操作卻說沒載入學生
- preview 後 target 被切走，commit 寫到錯學生
- forge / debuff / compensation 跟查卡序不同步

## 驗證方式

已完成：

- `node --check js/core/state.js`
- `node --check js/core/global-bridge.js`
- `node --check js/modules/student.js`
- `node --check js/modules/teacher-actions.js`
- `node --check js/main.entry.js`

## 建議後續 smoke test

1. 老師端查卡序後，直接手動加分 → 確認加到正確學生
2. 開啟 preview 後，不切換 target，直接 confirm → 確認寫回同一卡序
3. 狀態調整（附加 / 清除）→ 確認落到正確學生
4. 開啟 forge → 確認不再隨機出現「需要先載入學生狀態」
5. 查詢失敗後再重新查成功 → 確認 context 會更新
