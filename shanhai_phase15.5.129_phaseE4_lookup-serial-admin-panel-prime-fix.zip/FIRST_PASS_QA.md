# 第一次修整自查

## 已完成
- [x] 新增 `js/core/global-bridge.js`
- [x] `__clearAssetUrlCache` 改成本地函式，不再預設直接暴露為全域
- [x] `window.forceOpenCardForge` 的建立邏輯抽出 `main.js`
- [x] `window.ShanHaiSystem` 改成經由 `buildSystemNamespace()` 組裝
- [x] `index.html` 與 `main.js` 版本參數同步到 `phase15hotfix7`

## 語法檢查
- [x] `js/main.js`
- [x] `js/core/global-bridge.js`
- [x] `js/core/app-facade.js`
- [x] `js/core/debug-flags.js`
- [x] `js/core/state.js`
- [x] `js/core/ui.js`
- [x] `js/modules/auth.js`
- [x] `js/modules/student.js`
- [x] `js/modules/teacher-actions.js`
- [x] `js/modules/batch.js`
- [x] `js/modules/battle.js`
- [x] `js/modules/shop.js`
- [x] `js/modules/quiz.js`
- [x] `js/modules/ranking.js`
- [x] `js/modules/content-profile.js`
- [x] `js/modules/zones.js`

## 風險提醒
- `window.forceOpenCardForge` 仍保留，因為 HTML 仍直接呼叫它；這是刻意保守相容
- `window.ShanHaiSystem` 仍保留，用於系統診斷與開發資訊收集
- 這一輪沒有移除 `window.App` / `window.UI`，避免破壞舊 `onclick`
