# Phase 15.5.47 — Phase 7 shop / zones DOM contract 擴充

## 本輪目標
延續 phase15.5.46 的 DOM contract / safe helper 建立，將高風險面板進一步納管到：
- `js/modules/shop.js`
- `js/modules/zones.js`

本輪維持低風險原則：
- 不碰 `bootstrap-entry.js`
- 不碰 `main.entry.js`
- 不碰 `auth.js`
- 不改舊 HTML 結構
- 不新增業務全域變數

## 這次修改的重點

### 1. `currentState` 補上 DOM contract 診斷欄位
新增：
- `shopDomContract`
- `supportZoneDomContract`
- `scienceZoneDomContract`

格式統一為：
- `checkedAt`
- `missing`
- `ok`

### 2. `shop.js` 導入 DOM contract
新增 `getShopDomElements()`，統一盤點與取得：
- 商城主畫面容器
- 商城管理 modal / list / form
- gift pane 欄位與目標資訊
- tab 按鈕與 pane

並同步寫入：
- `currentState.shopDomContract`
- `window.__BOOT_DIAG.shopDomContract`

同時把 `shop.js` 內所有 `document.getElementById(...)` 清為 0，改走 `getShopDomElements()`。

### 3. `zones.js` 導入 support / science DOM contract
新增：
- `getSupportZoneDom()`
- `getScienceZoneDom()`
- `syncZoneDomDiagnostics()`

統一納管：
- modal
- student select
- selected meta
- attendance / status / note
- performance tag 容器
- today record summary
- url display
- batch status / facet / auto check-in

並同步寫入：
- `currentState.supportZoneDomContract`
- `currentState.scienceZoneDomContract`
- `window.__BOOT_DIAG.supportZoneDomContract`
- `window.__BOOT_DIAG.scienceZoneDomContract`

同時把 `zones.js` 內所有 `document.getElementById(...)` 清為 0，改走 zone DOM getters。

## 驗證

### 語法檢查
- `node --check js/core/dom-contract.js`
- `node --check js/core/state.js`
- `node --check js/modules/shop.js`
- `node --check js/modules/zones.js`

### DOM id 對表
已逐一比對 `index.html`，本輪新增 contract 使用到的 id：
- shop: 全數存在
- support zone: 全數存在
- science zone: 全數存在

### 靜態盤查
- `shop.js` 的 `getElementById(...)` 使用數：`0`
- `zones.js` 的 `getElementById(...)` 使用數：`0`

## 風險控制
本輪只做 DOM 取得與診斷層收斂，沒有改：
- 啟動入口鏈
- 登入鏈
- 老師端保存鏈
- 題庫 / BOSS 業務邏輯

## 產物
- `project-root-phase15.5.47-phase7-shop-zones-dom-contract.zip`
