# Phase 15.5.39 - Low-Risk Stability Hardening (Stage 1)

## 本階段目標
先修補不改業務流程、但能直接提升穩定性與診斷能力的低風險缺漏：

1. 補齊鑄造道具卡按鈕的真實 DOM 掛點
2. 修正 façade surface 缺件警告不會正確觸發的問題
3. 將 index.html 目前直接使用的 App 入口納入 surface policy 監控

## 修改檔案
- `index.html`
- `js/core/api-surface.js`

## 修改內容
### 1. 鑄造按鈕 DOM 掛點補齊
在 `index.html` 補上：
- `id="cfStartBtn"`
- `id="cfCancelBtn"`

讓 `js/modules/teacher-actions.js` 內的 `setForgeButtonsDisabled()` 能真正抓到按鈕並控制 disabled 狀態，避免鑄造過程中重複點擊或取消流程失控。

### 2. façade 缺件警告修正
`js/core/api-surface.js` 原本 `logSurfaceWarnings()` 檢查的是：
- `inventory.app.missing`
- `inventory.ui.missing`

但實際 inventory 結構是：
- `inventory.app.required.missing`
- `inventory.app.transitional.missing`
- `inventory.ui.required.missing`

本次改為檢查正確路徑，讓掛載缺漏不再悶著不報。

### 3. 將 index.html 直接使用的 App 入口納管
新增 `INDEX_HTML_DIRECT_APP_METHODS`，把目前 HTML 直接呼叫、但不在原 policy 內的 App 方法納入 `APP_GLOBAL_SURFACE_POLICY.transitional`。

這樣後續若 refactor 漏掛這些入口，surface inventory 會更早報警，不會靜悄悄失效。

## 本階段刻意不做的事
- 不改登入流程
- 不改老師端保存鏈
- 不改題庫業務邏輯
- 不移除 `window.App` / `window.UI`
- 不碰歷史副本與非 canonical active chain

## 驗證
已完成：
- `node --check js/core/api-surface.js`
- `node --check js/modules/teacher-actions.js`
- `node --check js/main.entry.js`
- 驗證 `index.html` 已存在 `cfStartBtn` / `cfCancelBtn`
- 驗證 `index.html` 直接使用的 `App.xxx()` 入口，對照 surface policy 後 **missing count = 0**

## 結論
這一階段屬於「接線層與診斷層」修補，不改外觀、不動主流程，但能降低：
- 鑄造流程按鈕失控
- façade 漏掛不報警
- HTML 直接入口未納管導致之後 refactor 漏掛

適合作為優化計畫的第一階段低風險修補基底。
