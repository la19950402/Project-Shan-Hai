# PHASE15.5.100 FIX12 — Quiz Pool Routing Split

## 本輪重點
- 將 `quiz pool` 的 audience key、summary payload、summary 讀取、ID 回補、summary backfill、背景 refresh、student preload/fallback 全數移入 `js/modules/quiz.js`
- `js/main.entry.js` 只保留薄委派，不再直接做 `quiz_bank` 的 active query / full scan / summary 組裝
- 保留 daily / battle 現有呼叫面，透過 `App.warmStudentQuizPool()` 等委派進 `quizApi`

## 主要修改檔案
- `js/modules/quiz.js`
- `js/main.entry.js`
- `scripts/deep-check-active-flow.mjs`
- `scripts/validate-active-chain.mjs`
- `js/bootstrap-entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- `index.html`

## 版本
- `BOOT_ID`: `phase15phase100fix12quizpoolsplit`
- `BUILD_TAG`: `v15.5.100-fix12-quiz-pool-routing-split-20260315`

## 驗證結果
- `find js -name '*.js' -print0 | xargs -0 -n1 node --check`：通過
- `node scripts/validate-active-chain.mjs`：通過
- `node scripts/deep-check-active-flow.mjs`：通過

## 收斂成果
- `main.entry.js` 內 `getDocs(...)`：**14 → 8**
- `main.entry.js` 已不再直接包含：
  - `warmStudentQuizPool` 的 active query / full scan fallback
  - `quiz_pool_public` summary doc 讀取與 payload backfill
  - `quiz pool` audience normalization / candidate shuffle / ID hydrate
- `quiz` 模組現在接手：
  - `normalizeQuizPoolAudienceKey`
  - `getQuizPoolAudienceKeyForStudent`
  - `buildQuizPoolQuestionSummary`
  - `normalizeQuizPoolSummaryRecord`
  - `buildQuizPoolAudiencePayloads`
  - `loadQuizPoolAudienceDoc`
  - `loadQuizQuestionsByIds`
  - `backfillQuizPoolSummaryEntries`
  - `syncQuizPoolSummaryFromQuizBank`
  - `scheduleQuizPoolSummaryRefresh`
  - `warmStudentQuizPool`

## 目前判讀
- 這輪已把 `daily / battle / quiz pool` 共用的題池預熱與 summary fallback 主線從主入口外移一大段
- active chain 與 deep-check 未發現衝突或漏接
- 下一輪最值得收的是 `battle.js` 內仍直接對 `quiz_bank` 做的 random gatekeeper / boss config 讀取路徑
