# PHASE15.5.78 PERFORMANCE PHASE3 QUIZ POOL SUMMARY FALLBACK NOTES

## 本輪目標
第三輪聚焦在 BOSS / 每日歷練的題庫載入性能。
核心方向不是再讓前端每次直接全掃 `quiz_bank`，而是改成：

1. 優先讀取 `quiz_pool_public` 題池索引文件
2. 只抓少量候選題目的 `quiz_bank/{id}` 文件
3. 沒有索引或索引失敗時，才 fallback 舊路徑
4. fallback 後非阻斷回填題池索引，讓下一次變快

---

## 這次實際修改

### 1. 新增題池索引集合路徑
在 active chain 新增：
- `quiz_pool_public`

用途：
- 儲存 `default / support / grade1~grade6` 的題池索引 doc
- 每份 doc 只保存：
  - `question_ids`
  - `question_count`
  - `sample_questions`
  - `updated_at`

這樣首頁 / 學生頁 / BOSS 不需要再一開始掃整個 `quiz_bank`。

### 2. `warmStudentQuizPool()` 改成優先走索引
原本：
- 直接 query / full scan `quiz_bank`

現在：
- 先依學生 audience key（`support` / `gradeX` / `default`）讀取 `quiz_pool_public/{audienceKey}`
- 只挑少量題目 id
- 再逐題讀取需要的 question doc
- 如果題池不足，才 fallback

這會直接改善：
- 每日歷練
- 學生端題池 warm
- battle gatekeeper random 題目抽取

### 3. BOSS 隨機題改成先吃 warm pool
`js/modules/battle.js`
- `pickRandomGatekeeperQuestion()` 現在會先呼叫 `warmStudentQuizPool(...)`
- 先從 audience 對應的小題池抽題
- 只有題池失敗時才退回舊的 full scan

### 4. 題庫管理異動後自動刷新題池索引
以下操作成功後都會排程刷新 `quiz_pool_public`：
- `saveNewQuiz()`
- `saveEditedQuiz()`
- `deleteQuiz()`
- `toggleQuizActive()`
- `batchSetQuizActive()`
- `batchDeleteSelectedQuizzes()`

這樣不需要等下一次慢路徑 fallback 才重建題池。

### 5. 快取與 audience 分流
新增 state：
- `studentQuizPoolCacheByAudience`
- `studentQuizPoolLoadedAtByAudience`
- `studentQuizPoolPromiseByAudience`
- `quizPoolSummarySyncPromise`
- `quizPoolSummarySyncedAt`
- `quizPoolSummaryLastError`
- `quizPoolSummaryRefreshTimer`

這讓不同 audience 的題池快取不會互相覆蓋。

### 6. legacy 題庫保底
考慮到舊資料可能沒有 `isActive === true`，本輪也補了保底：
- 若 active query 命中太少，會再做 full scan
- 避免因 legacy 題目欄位不完整而把可用題目漏掉

---

## 修改檔案
- `js/main.entry.js`
- `js/modules/battle.js`
- `js/core/state.js`
- `index.html`
- `js/bootstrap-entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- active chain import query tags（canonical `js/core/*.js`, `js/modules/*.js`）

---

## 版本同步
- Active query tag: `phase15phase78perfphase3quizpool`
- Build tag: `v15.5.78-performance-phase3-quiz-pool-summary-fallback-20260315`

---

## 驗證
### 靜態驗證
- `node --check js/main.entry.js`
- `node --check js/modules/battle.js`
- `node --check js/core/state.js`
- 全部 `js/**/*.js` 語法檢查通過
- 結果：`syntax_errors = 0`

### 本輪預期效益
1. 學生端每日歷練不再預設掃整個題庫
2. BOSS 隨機守門題先走小題池
3. 題庫更新後索引會跟著刷新
4. 後續為題圖/題目摘要做進一步優化時，已有穩定入口

---

## 仍未處理（下一輪候選）
1. 題圖正式展示鏈（battle / quiz render 題目圖片 DOM）
2. `quiz_pool_public` 若要完全避免逐題 `getDoc`，可再演進成嵌入式 compact question summary
3. BOSS 指定題後台 UI 仍偏向全量讀題庫，之後可再改成先讀 summary preview
4. 若要再加速，可把題池索引的維護轉到後端/Cloud Function

---

## 建議部署後優先驗證
1. 首頁正常開啟
2. 登入正常
3. 每日歷練首次點擊能正常進入題目
4. 第二次再開每日歷練/BOSS，體感應比全掃版穩定
5. 題庫新增/修改/上下架後，再開歷練/BOSS 不應長時間卡在題庫讀取
6. console 不應新增 boot blocker
