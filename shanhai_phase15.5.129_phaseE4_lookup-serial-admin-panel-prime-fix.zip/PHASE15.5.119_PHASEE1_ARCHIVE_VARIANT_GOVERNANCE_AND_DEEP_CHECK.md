# PHASE15.5.119 — Phase E-1 Archive / Variant Governance + Deep Check

## 本輪目標
在不變更 canonical active chain、不中斷既有驗證的前提下，將 inactive entry/core/module variants 與 backup scratch files 從 `js/` 主工作區移出，建立可回溯、可驗證的 archive 治理邊界。

## 本輪實作

### 1) inactive variants 移出 active workspace
已將歷史 variants 從 `js/` 移至 `archive/variants/`，保留原本的相對結構：
- entry variants → `archive/variants/js/bootstrap-entry.*.js`、`archive/variants/js/main.entry.*.js`
- core variants → `archive/variants/js/core/*`
- module variants → `archive/variants/js/modules/*`

### 2) backup / scratch files 移出 active workspace
已將以下 backup / scratch 類檔案移至 `archive/backups/`：
- `js/main.entry.js.bak`
- `js/main.entry.js.pre1552bak`
- `js/main.entry.rewritten.js`

### 3) manifests 更新
已更新：
- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/MODULE_VARIANT_MANIFEST.json`

調整內容：
- archived paths 全部改指向 `archive/variants/...`
- notes / riskNotes 更新為 archive governance 現況
- active chain 與 active runtime modules 維持 canonical 不變

### 4) archive 治理文件
新增：
- `archive/README.md`
- `ARCHIVE_VARIANT_GOVERNANCE.md`

用途：
- 明確規範 archive/variants 與 archive/backups 的用途
- 明確定義「修 active 先、archive 只做 rollback/forensics」

### 5) 新增深檢
新增：
- `scripts/deep-check-phasee-archive-governance.mjs`

檢查內容：
- archived manifest paths 是否都已指向 `archive/variants/`
- manifest 記載的 archived files 是否實際存在
- active files 是否誤進 archive
- `js/` 主工作區是否還殘留 suffixed inactive variants
- `js/` 主工作區是否還殘留 `.bak` / rewritten scratch files

## 量化結果
- archived entry files：**31**
- archived core variants：**11**
- archived module variants：**25**
- `archive/variants/` 實際檔案數：**56**
- `archive/backups/` 實際檔案數：**3**
- `js/` 工作區 variant leak：**0**
- `js/` 工作區 backup leak：**0**

## active chain 狀態
- `BOOT_ID`：`phase15phase103fix15battlebossconfigsplit`
- `BUILD_TAG`：`v15.5.103-fix15-battle-boss-config-split-20260316`
- canonical active chain：
  - `js/bootstrap-entry.js`
  - `js/main.entry.js`
  - `js/core/app-facade.js`
  - `js/core/api-surface.js`

本輪**未變更** boot/version chain。

## 驗證結果
通過：
- `scripts/validate-active-chain.mjs`
- `scripts/deep-check-active-flow.mjs`
- `scripts/deep-check-phasec-collection-boundaries.mjs`
- `scripts/deep-check-phasec-evolution-boundaries.mjs`
- `scripts/deep-check-phasec-collection-editor-boundaries.mjs`
- `scripts/deep-check-phasec-forge-actioncard-boundaries.mjs`
- `scripts/deep-check-phasec-save-hub-boundaries.mjs`
- `scripts/deep-check-phased-auth-legacy-deps.mjs`
- `scripts/deep-check-phased-student-legacy-deps.mjs`
- `scripts/deep-check-phased-legacy-reaudit.mjs`
- `scripts/deep-check-phasee-archive-governance.mjs`

## 目前階段判定
- **Phase A**：完成
- **Phase B**：完成
- **Phase C**：完成
- **Phase D**：完成
- **Phase E-1**：完成

目前專案已正式進入 **治理收尾期**，active workspace 已從歷史 variants 干擾中脫離。

## 剩餘工作與後續規劃

### Phase E-2：deploy governance / smoke docs
建議下一輪完成：
- `DEPLOY_CHECKLIST.md`
- `SMOKE_TEST_ACTIVE_CHAIN.md`
- active chain deploy 前後檢查順序文件化
- 將現有 deep-check 腳本與 smoke 順序整理成單一執行指引

### Phase E-3：Firestore Rules alignment
再下一輪建議完成：
- 依 canonical active path 與實際 collection/doc 使用情況，整理 Firestore Rules 對照
- 標記仍需人工確認的 collection scope
- 補一份 rules alignment report

### Phase E-4：final release governance re-audit
最後可做：
- 對 active chain / manifests / archive / deploy docs / rules notes 再做一次總盤
- 形成可交接的最終執行版報告

## 本輪結論
這輪的價值不是再拆功能，而是把「active runtime」與「historical rollback assets」真正分區。之後 grep、修正、review、交接都會以 canonical active chain 為主，不再被 `js/` 目錄中的歷史 variants 干擾。
