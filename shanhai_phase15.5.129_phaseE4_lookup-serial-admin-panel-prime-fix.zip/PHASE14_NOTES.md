
# Phase 14 收尾整併

## 本輪重點
- 新增 `js/core/app-facade.js`，集中管理 `window.App` / `window.UI` 的相容層掛載。
- 新增 `js/core/debug-flags.js`，將 debug 預設關閉，僅在 dev/test 條件下開啟 boot panel、fallback login、boot error capture。
- `main.js` 不再逐條散落掛載模組 API，而是透過 `mountAppFacade(...)` 統一掛載。
- `index.html` 的 boot 狀態面板保留，但預設僅在 dev/test 顯示。

## Façade 集中化
- `mountAppFacade({ App, UI, apis, debugFlags })`
- `exposeGlobalFacade({ App, UI })`
- 盤點列表集中在 `APP_FACADE_METHODS`

## Debug 策略
- `DEBUG_FLAGS.enabled = false`
- `showBootPanel` / `enableFallbackLogin` / `captureGlobalBootErrors` 僅在 dev/test 或顯式 debug 查詢參數下啟用
- 相關區塊保留 `@debug-removable:*` 標記

## HTML partials 評估
目前建議 **暫緩導入**。
理由：
1. 雖然核心模組已拆出，但 `main.js` 仍有大量直接 `getElementById` / `innerHTML` / 固定 id 依賴。
2. 相容層剛完成收斂，應先以此基線進行 1~2 輪回歸測試，再考慮切 HTML。
3. 若現在導入 partials，最容易引入「DOM 先後順序 / 事件掛載時機 / HTML id 契約」相關退化。

建議下一步：先做 API 清單凍結與回歸測試，再評估是否進行 partials proof-of-concept。
