# Stage 2 — Prevalidation Quiz Pool Health Dry-Run

## Goal
Add an admin-side dry-run checker for `quiz_pool_public` so the project can validate summary health **before** changing runtime logic or repairing data.

This stage does **not** modify student quiz behavior. It only adds:
- summary health inspection
- reusable dry-run output
- global console helpers for diagnosis

## Files changed
- `js/modules/quiz.js`

## What was added

### 1. `inspectQuizQuestionsByIds(ids, options)`
A new internal helper that:
- loads each `quiz_bank/{id}` doc by ID
- separates results into:
  - playable rows
  - missing IDs
  - invalid IDs
  - invalid reason counts
  - fetch failures
- reuses the same validation rules already used by stage 1 diagnostics

This keeps diagnostics reusable for both normal summary-by-id loading and dry-run health audit.

### 2. `auditQuizPoolSummaryHealth(options)`
A new admin-only dry-run checker that can:
- audit one audience (`default`, `grade3`, `support`, etc.)
- or audit all summary docs under `quiz_pool_public`

For each audience, it reports:
- whether the summary exists
- `question_count`
- `question_ids` count
- playable resolved question count
- missing doc count
- invalid doc count
- invalid reason counts
- fetch failure count
- whether sample IDs are outside summary IDs
- health score
- issue list

### 3. Global console helpers
Added these helpers in browser console:

```js
await __auditQuizPoolSummaryHealth()
await __auditQuizPoolSummaryHealth('default')
await __auditQuizPoolSummaryHealth('grade3')
await __auditQuizPoolSummaryHealth('support')
```

Also available:

```js
__getQuizPoolHealthAudit()
__printQuizPoolHealthAudit()
__printQuizPoolHealthAudit('default')
```

## Issue types reported
The dry-run can now flag these conditions:
- `missing-summary`
- `summary-count-mismatch`
- `fetch-failures`
- `missing-question-docs`
- `invalid-question-docs`
- `all-summary-ids-unusable`
- `sample-not-in-question-ids`

## Why this stage is useful
This directly answers the current symptom:
- UI can show quiz count
- but student cannot actually load usable questions

With this dry-run, the next test can clearly distinguish whether the real problem is:
1. summary exists but points to missing docs
2. summary points to inactive/invalid quiz docs
3. sample entries are out of sync
4. summary count itself is stale
5. fetch/read failures are happening even before content validation

## Notes
- Admin runtime is required for the full dry-run.
- If run outside admin runtime, it returns `admin-required` and does not mutate data.
- No Firestore writes are performed in this stage.
