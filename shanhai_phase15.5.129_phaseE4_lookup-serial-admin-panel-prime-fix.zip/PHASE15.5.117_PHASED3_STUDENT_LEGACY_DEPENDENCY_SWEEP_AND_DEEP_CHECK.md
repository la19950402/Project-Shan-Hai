# Phase 15.5.117 — Phase D-3：student legacy dependency sweep + 深度檢查

## 這輪完成了什麼

這輪不是再拆 Firestore 資料鏈，而是延續 Phase D 的目標，回掃 `js/modules/student.js` 內還殘留的 legacy DOM 依賴，讓 student 模組和前一輪的 auth 模組一樣，改成走顯式注入與 DOM contract。

本輪完成：

- `student.js` 新增顯式注入：
  - `documentRef`
  - `getStudentDisplayDom`
  - `getStudentIdentityDom`
  - `getStudentViewDom`
  - `getStudentShopStatusDom`
- `student.js` 不再直接使用：
  - `document.createElement(...)`
  - 內建的 `document` default root 查詢
  - 自己在模組內拼 student/shop/view DOM 小宇宙
- `main.entry.js` 新增並掛載 student 專用 DOM contract：
  - `getStudentDisplayDom(prefix)`
  - `getStudentIdentityDom()`
  - `getStudentViewDom()`
  - `getStudentShopStatusDom()`
- `student.js` 內相關流程已改走 reader contract：
  - `readStudentDisplayDom(...)`
  - `readStudentIdentityDom()`
  - `readStudentViewDom()`
  - `readStudentShopStatusDom()`
- 新增深檢：
  - `scripts/deep-check-phased-student-legacy-deps.mjs`

## 量化結果

### 行數
- `js/main.entry.js`：**5484 → 5553**
- `js/modules/student.js`：**903 → 919**

這輪主入口行數上升是正常的，原因不是把舊邏輯搬回主入口，而是補上了 **student DOM contract helper**，讓模組不再偷吃全域 `document`。

### student 模組 legacy 依賴收斂
- `student.js` 內 `document.createElement(...)`：**1 → 0**
- `student.js` 內 direct `document.getElementById(...)`：**維持 0**
- `student.js` 內 direct `document.querySelectorAll(...)`：**維持 0**
- `student.js` 內 `readStudent*Dom(...)` reader：**0 → 5**
- `main.entry.js` 內 student DOM helper：**0 → 4**

### 主入口資料責任
- 主入口 `getDoc / getDocs / setDoc`：維持 **0 / 0 / 0**
- `main_saveToDB_count`：維持 **8**

## 驗證結果

### 語法檢查
- `node --check js/modules/student.js`：通過
- `node --check js/main.entry.js`：通過

### Active chain / 深度檢查
- `scripts/validate-active-chain.mjs`：通過
- `scripts/deep-check-active-flow.mjs`：通過
- `scripts/deep-check-phasec-collection-boundaries.mjs`：通過
- `scripts/deep-check-phasec-evolution-boundaries.mjs`：通過
- `scripts/deep-check-phasec-collection-editor-boundaries.mjs`：通過
- `scripts/deep-check-phasec-forge-actioncard-boundaries.mjs`：通過
- `scripts/deep-check-phasec-save-hub-boundaries.mjs`：通過
- `scripts/deep-check-phased-auth-legacy-deps.mjs`：通過
- `scripts/deep-check-phased-student-legacy-deps.mjs`：通過

### canonical active chain
- `BOOT_ID`：`phase15phase103fix15battlebossconfigsplit`
- `BUILD_TAG`：`v15.5.103-fix15-battle-boss-config-split-20260316`
- **本輪未變更 boot/version chain**

## 目前階段判定

### 已完成
- **Phase A**：student / token / mirror / save / card scan 主鏈收斂完成
- **Phase B**：主入口直接查詢收斂完成
- **Phase C**：collection / evolution / forge / save hub 收斂完成
- **Phase D-2**：auth legacy dependency sweep 完成
- **Phase D-3**：student legacy dependency sweep 完成

### 目前位置
現在專案已正式進入：

**Phase D 後段 / Phase E 前置治理期**

也就是說，目前主問題已經不再是：
- 主入口還有多少直接 Firestore 讀寫
- student 模組還有多少直接 DOM 隱性依賴

現在真正剩下的是：
- `batch.js` 若要與現況完全對齊，仍值得補一次實際版回掃確認
- archive 歷史副本仍多，維護辨識成本高
- deploy governance / smoke checklist 還沒正式收尾
- Firestore Rules 還沒依照現行 canonical 路徑做最後整理

## 下一步建議順序

### Phase D-4（建議）
做一次 **legacy sweep re-audit**：
- 重新盤 `batch / auth / student` 三個模組的實際狀態
- 對照 deep-check 腳本與實檔，補齊任何「腳本通過但實作仍偏舊」的落差

### Phase E-1
處理 **archive / variant 治理**：
- 建立 archive 結構
- 搬移停用 variant
- 降低 grep 混淆與誤修舊檔風險

### Phase E-2
處理 **deploy governance**：
- 補 `DEPLOY_CHECKLIST.md`
- 補 `SMOKE_TEST_ACTIVE_CHAIN.md`
- 固化 active chain 釋出版流程

### Phase E-3
處理 **Firestore Rules 收尾**：
- 對照現行 `students / student_pages / public summary / token` 路徑
- 清理已不再使用或風險高的舊規則邊界

## 這輪結論

這輪的本質不是再減少 `main.entry.js` 的資料責任，而是把 `student.js` 從「模組化外表、仍藏全域 document 依賴」的狀態，再往真正顯式依賴推進一步。

現在可以比較明確地說：

**Phase D 的 student 模組收斂已完成，專案可以開始從『模組責任收斂』轉向『治理與收尾』。**
