# Phase 14.2：Student façade merge

- 將 `App.refreshStudentIdentityLabels` 併入 `js/modules/student.js`
- 將 façade 的 `studentApp` 掛載清單加入 `refreshStudentIdentityLabels`
- 從 `main.js` 移除最後一個 direct `App.xxx = ...` 的 legacy 掛載
- 統一版本參數為 `phase14cleanup2`
- 更新 build tag 為 `v14.2-student-facade-merge-20260313`

## 影響
- 舊呼叫 `App.refreshStudentIdentityLabels(...)` 仍可用
- 主檔不再直接掛載這個方法，改由 app-facade 集中管理
- 不改 HTML、不改資料結構、不改業務邏輯
