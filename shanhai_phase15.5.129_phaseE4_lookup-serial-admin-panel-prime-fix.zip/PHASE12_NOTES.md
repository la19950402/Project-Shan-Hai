# Phase 12：拆分 battle

本階段以 **保守重構** 為原則，將 battle 相關邏輯從 `js/main.js` 抽出為 `js/modules/battle.js`，並維持舊 HTML 與 `window.App` 呼叫方式相容。

## 本次拆出內容
- Boss 挑戰流程
- 戰塔狀態檢查 / 刷新
- 中午重置判定與教師手動重置
- 戰鬥結算
- 管理端 Boss 設定 / 發布 / 清除

## battle.js 對外 API
- `startBattleChallenge`
- `selectBattleMon`
- `confirmBattleSelection`
- `handleBattleQuizAnswer`
- `prepareBattleArena`
- `rollDice`
- `showBattleSettlement`
- `backToBattleResult`
- `closeBattleArenaAndRefresh`
- `endBattle`
- `checkBattleTowerStatus`
- `updateBattleTowerStatus`
- `resetDailyAndBattleChallenges`
- `populateBattleQuizOptions`
- `updateBattleTowerAdminAudienceView`
- `openBattleTowerSetup`
- `publishBattleBoss`
- `clearBattleBoss`

## 相容層
在 `main.js` 中，battle API 會掛回 `App`：

```js
App.startBattleChallenge = battleApi.startBattleChallenge.bind(App);
App.selectBattleMon = battleApi.selectBattleMon.bind(App);
App.confirmBattleSelection = battleApi.confirmBattleSelection.bind(App);
App.handleBattleQuizAnswer = battleApi.handleBattleQuizAnswer.bind(App);
App.prepareBattleArena = battleApi.prepareBattleArena.bind(App);
App.rollDice = battleApi.rollDice.bind(App);
App.showBattleSettlement = battleApi.showBattleSettlement.bind(App);
App.backToBattleResult = battleApi.backToBattleResult.bind(App);
App.closeBattleArenaAndRefresh = battleApi.closeBattleArenaAndRefresh.bind(App);
App.endBattle = battleApi.endBattle.bind(App);
App.checkBattleTowerStatus = battleApi.checkBattleTowerStatus.bind(App);
App.updateBattleTowerStatus = battleApi.updateBattleTowerStatus.bind(App);
App.resetDailyAndBattleChallenges = battleApi.resetDailyAndBattleChallenges.bind(App);
App.populateBattleQuizOptions = battleApi.populateBattleQuizOptions.bind(App);
App.updateBattleTowerAdminAudienceView = battleApi.updateBattleTowerAdminAudienceView.bind(App);
App.openBattleTowerSetup = battleApi.openBattleTowerSetup.bind(App);
App.publishBattleBoss = battleApi.publishBattleBoss.bind(App);
App.clearBattleBoss = battleApi.clearBattleBoss.bind(App);
```

## 這次順手保留的穩定修補
- 老師端手動加分按鈕維持 B 方案：`data-* + App.prepareActionFromButton(this)`
- `teacher-actions.js` 已加入 `prepareActionFromButton`
- `index.html` 載入版本改為 `phase12battle1`

## 已知仍保留在主檔的 battle 相關輔助方法
以下 helper 仍保留在 `main.js`，由 battle 模組透過 `this` 或依賴注入使用：
- `buildBattleRewardEventId`
- `getBattleRewardDisplay`
- `resolveBattleRecordBase`
- `buildBattleOutcomeRecord`
- `settleRewardViaServer`
- `saveToDB`
- `applyDataMigration`

這是刻意保守處理，以避免過度拆分造成 Boss 結算與戰塔邏輯退化。


補充：`App.attackBoss` 已作為 `startBattleChallenge` 的相容別名掛回。
