# 程式待辦清單（詳細版）

## A. 阻斷級穩定性

### A-1 初始化與登入
- [ ] 用實際瀏覽器跑一次 `index.html`，確認沒有 syntax / reference / module import error
- [ ] 驗證管理端登入、學生匿名登入、登出都可正常運作
- [ ] 驗證 `file://`、`http://localhost`、正式 HTTPS 三種環境的差異提示
- [ ] 檢查 `onAuthStateChanged` 在登入/登出切換時不會殘留舊畫面

### A-2 學生資料讀取
- [ ] 驗證老師端連續查詢兩位學生，後查者不會被前查者的舊 listener 覆蓋
- [ ] 驗證查無學生時，面板會清空而不是殘留上一位
- [ ] 驗證學生端 token/hash/serial 三種入口都能正確載入
- [ ] 檢查學生資料讀取失敗時，畫面與提示一致

### A-3 老師端操作
- [ ] 驗證手動加分：按鈕 → 預覽彈窗 → commit → 資料落地
- [ ] 驗證手動加分失敗時，不會把 pendingAction 清掉
- [ ] 驗證 debuff / 恢復 healthy / 死亡重置都會真正保存
- [ ] 驗證鑄卡流程在重複點擊時不會重複送出

### A-4 批量模式
- [ ] 驗證切換學生前會先保存上一位
- [ ] 驗證退出批量模式前會先保存當前學生
- [ ] 驗證保存失敗時不會靜默丟資料
- [ ] 驗證每位學生的連擊額外獎勵仍然獨立計算

### A-5 Battle / Boss
- [ ] 驗證守門員答題失敗後，挑戰消耗與戰鬥紀錄會落地
- [ ] 驗證 Boss 勝利後，金幣 / 經驗 / 戰鬥紀錄都會保存
- [ ] 驗證隔日中午重置後重新挑戰，不會被 eventId 誤判成重複獎勵
- [ ] 驗證結算後戰塔狀態會立即刷新

## B. 全域收斂

### B-1 相容層凍結
- [ ] 盤點 `window.App` 目前對外暴露方法，標註「必留 / 過渡 / 可移除」
- [ ] 盤點 `window.UI` 對外暴露方法，縮到只剩通用 UI 能力
- [ ] 建立 façade API 凍結清單，避免後續改名破壞 HTML `onclick`

### B-2 剩餘全域移除順序
- [x] `window.__clearAssetUrlCache` 改為條件式 debug 全域
- [x] `window.forceOpenCardForge` 建立邏輯搬到 bridge
- [ ] 評估 `window.forceOpenCardForge` 是否可改成 `App.openCardForge` + `data-action`
- [ ] 評估 `window.ShanHaiSystem` 是否可只保留 diagnostics / dev namespace
- [ ] 確認沒有其他新模組再偷偷新增 `window.*`

### B-3 state 收斂
- [ ] 盤點 `currentState` 欄位，區分：核心狀態 / 僅 UI 狀態 / 一次性流程旗標
- [ ] 將可模組內封裝的 busy flags 往模組內收，而不是都堆到 `currentState`
- [ ] 建立 state schema 註記，避免不同模組任意擴寫欄位

## C. 共用 Service 層

### C-1 資料保存
- [ ] 將 `saveToDB`、學生鏡像同步、battle outcome save、shop save 整理成 service
- [ ] 對保存流程建立統一錯誤格式
- [ ] 對保存流程建立統一忙碌狀態/重入保護

### C-2 獎勵結算
- [ ] 將 `buildRewardEventId` / `settleRewardViaServer` / reward 去重規則整理成 reward service
- [ ] 明確定義哪些流程使用本地保存、哪些流程依賴 Cloud Function
- [ ] 檢查所有 eventId 是否都帶有正確的時間/場次維度

### C-3 圖片 / Storage
- [ ] 將資產 URL cache、storage 圖片 hydrate、placeholder 流程整理成 asset service
- [ ] 建立 cache 清除與版本失效策略
- [ ] 檢查直接 URL 與 storage path 混用時的分支

## D. DOM 契約整理

### D-1 DOM 清單
- [ ] 建立所有關鍵 `id` 的契約表（login、admin panel、battle、batch、shop、quiz、zones）
- [ ] 標註哪些 `id` 屬於不可動契約
- [ ] 標註哪些 `innerHTML` 片段仍包含 inline `onclick`

### D-2 事件綁定
- [ ] 將重複綁定風險高的事件改成 once binding 或委派
- [ ] 盤點 `setupEventListeners()` 剩餘責任，持續往模組內拆
- [ ] 逐步減少 inline `onclick`，但只在回歸穩定後進行

## E. 功能模組後續優化

### E-1 Shop
- [ ] 驗證商品管理、送禮、購買在高延遲時的行為
- [ ] 檢查 admin tab 切換與表單重置有無殘留狀態

### E-2 Quiz
- [ ] 檢查題庫大量匯入、批次啟用/刪除、每日歷練答題完整性
- [ ] 驗證載入失敗與空題庫狀態提示

### E-3 Ranking / Content Profile
- [ ] 驗證排行榜顯示/隱藏分數、排序一致性
- [ ] 驗證 profile 切換、特殊蛋啟用、展示隊伍流程

### E-4 Zones
- [ ] 驗證學習扶助 / 科展專區 URL、NFC、點名、批次掃描、歷史匯出
- [ ] 驗證兩個專區切換時不共用錯誤狀態

## F. 測試與發版

### F-1 Smoke Test
- [ ] 每輪 hotfix 後固定跑最小 smoke test
- [ ] 建立 smoke test 執行結果紀錄檔

### F-2 完整回歸
- [ ] 依 `REGRESSION_CHECKLIST.md` 跑完整人工驗收
- [ ] 將結果標成 pass / fail / blocked
- [ ] 對 fail 項建立對應 defect id

### F-3 HTML partials 前置條件
- [ ] 只有在 DOM 契約表完成後，才評估 partials proof-of-concept
- [ ] 先從單一低風險 view 試做 partials，而不是整站一起切
- [ ] partials 導入前，先確定 `main.js` 不再直接依賴過多散落的裸 DOM
