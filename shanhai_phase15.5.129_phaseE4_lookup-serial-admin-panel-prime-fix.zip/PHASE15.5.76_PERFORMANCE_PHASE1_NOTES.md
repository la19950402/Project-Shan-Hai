# PHASE15.5.76 性能第一階段修正紀錄

## 修改重點
- 正式環境 bootstrap 改回穩定版本快取，不再每次自動附加 `ts=Date.now()` 並強制 `cache: 'no-store'`。
- 保留 `file://`、debug、dev/test 模式下的 fresh bypass，避免失去除錯能力。
- 學生資料 hydration 完成後，不再立刻同時預熱題庫 / 排行榜 / 商城三條重查詢。
- 改成延後、低優先度預熱，預設只在閒置時預熱學生商城資料；排行榜與題庫維持按需載入。
- active chain 版本識別更新為 `phase15phase76perfphase1`，避免修正後仍混吃舊快取。

## 這次為什麼這樣修
這一輪只做性能第一階段，不動排行榜 summary collection 與 BOSS 題池資料模型，先優先處理兩個最直接的體感瓶頸：
1. 首頁/主鏈每次強制避開快取。
2. 學生頁剛 ready 就同時預熱多條重量級資料鏈。

## 實作細節
- `js/bootstrap-entry.js`
  - 新增 `isFreshBootBypassEnabled()`、`buildTargetUrl()`、`getBootFetchOptions()`。
  - 正式環境改為固定 `?v=buildTag` 載入主入口。
  - 只有在 `file://`、localhost/test host、`debug=1`、`mode=dev`、`boot_nocache=1` 等情況下才附加 fresh ts 並使用 `cache: 'no-store'`。
- `js/main.entry.js`
  - `ensureStudentDataReady()` 改成呼叫 `deferStudentViewWarm()`。
  - `deferStudentViewWarm()` 改用 `requestIdleCallback` / `setTimeout` 延後執行。
  - 預設僅在閒置時預熱學生商城 catalog。
  - 排行榜與題庫預熱不再於學生頁 hydration 完成時自動觸發。
  - `warmStudentViewData()` 保留為相容 alias，但實際委派給 `deferStudentViewWarm()`。

## 驗證方式
- 全部 `js/**/*.js` 通過 `node --check`。
- 確認 `bootstrap-entry.js` 不再在正式模式預設使用 `Date.now()` + `no-store`。
- 確認學生頁 hydration 流程不再直接呼叫 `Promise.allSettled([quiz, ranking, shop])`。

## 新產出包
- `project-root-phase15.5.76-performance-phase1-initial-load.zip`
