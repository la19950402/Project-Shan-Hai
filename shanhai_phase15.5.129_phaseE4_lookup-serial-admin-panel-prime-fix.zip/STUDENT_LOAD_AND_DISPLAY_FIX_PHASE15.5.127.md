# Student load / display fix audit (phase15.5.127)

## This round
Focused on two user-facing symptoms:
1. student data often failing to load
2. display switching / panel state behaving inconsistently

## Confirmed code-level causes fixed

### 1) Debuff auto-recovery could short-circuit rendering during snapshot load
In `js/modules/student.js`, `applyLoadedData()` previously returned early when `checkDebuffRecovery(data)` was true:
- it immediately called `saveToDB(data)`
- then returned before updating `currentState.studentData`
- before clearing `studentHydrationPending`
- before rendering the panel

That meant some loads could appear stuck or fail intermittently when the loaded student happened to hit debuff cooldown expiry.

### 2) Shared student identity labels were not refreshed consistently on snapshot/rebind paths
`loadStudentData()` updated the main panel, but several snapshot/rebind paths did not refresh the shared identity labels (`admName`, `stuName`, coins/class text, etc.).
That could make the displayed student info look like it had not switched even though the underlying panel data had changed.

### 3) Visibility checks used fragile `!optionalChain` logic
In multiple places the code used patterns like:
- `!studentViewDom.adminStudentPanel?.classList.contains('hidden')`
- `!adminView?.classList.contains('hidden')`

When the element was missing, that expression became `true`, which could misroute panel updates or button state.

## Fixes applied
- Added `isVisibleEl()` helper in `js/modules/student.js`
- Changed reward/display routing to use explicit visibility checks
- Changed archive voucher admin-view check to use explicit visibility check
- Changed `applyLoadedData()` so debuff auto-recovery no longer aborts rendering
- Debuff auto-save now runs after state/render update instead of before it
- Added identity label refresh on:
  - normal snapshot load
  - same-target rebind path
  - merged master hydration path
  - preview fallback path
  - reward-panel refresh path

## Validation
- `node --check js/modules/student.js`
- `node --check js/main.entry.js`
- `node scripts/validate-active-chain.mjs`
- `node scripts/deep-check-active-flow.mjs`
- `node scripts/deep-check-student-load-display-flow.mjs`

All passed.

## Added guard
New script:
- `scripts/deep-check-student-load-display-flow.mjs`

It verifies that:
- student load no longer short-circuits render on debuff recovery
- shared identity labels are refreshed from load flow
- panel visibility logic uses robust visibility helpers
