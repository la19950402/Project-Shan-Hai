# Hotfix 5 後續規劃

## Phase 15.5.6
- 商城交易與贈禮鏈錯誤保護。
- 題庫進入／結算／每日歷練保存鏈收斂。

## Phase 15.5.7
- 排行榜與 Profile 切換流程穩定化。
- 特殊蛋 / 隱藏蛋啟用流程驗證。

## Phase 16
- 共用 data-service / reward-service 收斂。
- 減少 `main.js` 對 `saveToDB()` / `processEvolution()` 的直接依賴。

## Phase 17
- DOM 契約表整理。
- 頁面區塊與 modal 的元素依賴盤點。

## HTML partials 評估
- 仍不建議立即導入。
- 需先完成完整人工回歸與 DOM 契約表後，再做 proof-of-concept。
