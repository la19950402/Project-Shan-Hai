# Phase 15.5.85 — Phase 9 Round 2 Teacher Save Chain + Boss Quiz Freeze Fix

## 本輪目標
1. 進行第九階段第二輪「老師端保存鏈專項硬化」
2. 直接排查並修正：BOSS 對戰可以選擇出戰，但進場後立刻卡住、題目不跳出的問題

---

## 本輪修改重點

### 1) 修正老師端 `explicitSerial` 與當前 `studentData` 可能錯綁的高風險缺口
檔案：`js/modules/teacher-actions.js`

問題型態：
- 老師已對 A 學生開啟待確認操作
- 中途又切到 B 學生
- 某些保存鏈會帶著 `explicitSerial=A`
- 但 `hydrateTeacherTargetData(...)` 卻直接重用當前 `studentData=B`
- 最後可能形成「用 B 的資料、卻以 A 的 serial 保存」的危險錯綁

本輪修法：
- `hydrateTeacherTargetData(...)` 現在會先判斷：
  - 若有 `explicitSerial`
  - 只有在目前資料的 `card_seq/serial` 與它一致時，才可重用當前資料
- 否則會重新依照 `explicitSerial` 從 Firestore 載入正確學生

效果：
- 避免老師端 pending action / 補發 / 狀態調整在切換學生後誤綁到錯的人

---

### 2) 老師端狀態調整與補發加入提交中防重入保護
檔案：`js/modules/teacher-actions.js`

問題型態：
- 先前 `commitAction()` 有 `teacherActionSubmitting` guard
- 但 `forceDebuff()`、`applyTeacherCompensation()` 仍可在另一筆保存尚未完成時再進來
- 容易形成多筆保存交錯、target context 被覆蓋或 UI 回寫順序錯亂

本輪修法：
- `forceDebuff()`、`applyTeacherCompensation()` 新增與 `commitAction()` 同級的提交中 guard
- 保存期間若再次點擊，直接 toast 提示稍候
- 在 `finally` 中統一釋放旗標

效果：
- 降低老師端高風險保存鏈的重入與競態問題

---

### 3) 修正 BOSS 出戰後題目不跳出的直接根因
檔案：
- `js/modules/battle.js`
- `js/main.entry.js`

根因定位：
- `confirmBattleSelection()` 在成功選出守門題後，確實有：
  - `quizSession.mode = 'battle'`
  - `quizSession.questions = [qD]`
  - `quizSession.currentIndex = 0`
  - `UI.showModal('quizPlayModal')`
- 但最後呼叫的是：
  - `callBattleMethod('renderQuizQuestion')`
- `battleApi` 裡並不存在 `renderQuizQuestion`
- 結果就是：
  - 題目 session 已建立
  - modal 已打開
  - 但題目沒有真正 render
  - 使用者體感就是「進去立刻卡住、沒有題目」

本輪修法：
- 將 `renderQuizQuestion` 正式作為依賴注入 battle module
- `confirmBattleSelection()` 改為直接呼叫已注入的 `renderQuizQuestion()`
- 若依賴缺失，會明確丟出 `renderQuizQuestion helper unavailable`

效果：
- BOSS / 守門題在選擇出戰後，會真正進入題目 render 流程
- 不再卡在 modal 已開、但沒有題目內容的狀態

---

## 這次為什麼會出現 BOSS 單一題目也卡住
不是因為你設定成單一題目仍然有問題，而是：

- 不論題庫是一題、十題，甚至已經指定了固定 `gatekeeperQuizId`
- 只要最後的「顯示題目」是叫到不存在的 battle module method
- 題目都不會真正 render

所以這個 bug 的本質是：
**battle 模組與主題目渲染函式之間的接線斷掉了。**

---

## 驗證方式
已完成：
- `node --check js/modules/teacher-actions.js`
- `node --check js/modules/battle.js`
- `node --check js/main.entry.js`
- 全部 `js/**/*.js` 再跑一輪 `node --check`
- 結果：`syntax_errors = 0`

另行確認：
- active chain 舊版 tag 已清乾淨
- `callBattleMethod('renderQuizQuestion')` 殘留數量 = 0
- battle module 已正式注入 `renderQuizQuestion`

---

## 部署後優先 smoke test
1. 首頁可開
2. 登入正常
3. 老師端查卡序 → 切學生 → 手動加分
4. 老師端切學生後做狀態調整 / 補發
5. BOSS 挑戰：
   - 能選出戰成員
   - 點確認後可正常跳出題目
   - 單一指定題目也能正常顯示
6. 答對後可進戰鬥畫面
7. 答錯後會正常結束並消耗次數

---

## 新版本
- `project-root-phase15.5.85-phase9-round2-teacher-save-chain-and-boss-quiz-fix.zip`
