# PHASE15.5.112 Phase C-3：Collection Editor UI Boundary Convergence + Deep Check

## 本輪目標

延續 `15.5.111 / Phase C-2`，把仍殘留在 `js/main.entry.js` 的 collection editor UI 邊界收斂出去，避免主入口繼續承擔：

- `openDisplayTeamEditor()` 的展示隊伍編輯器建立與渲染
- `toggleDisplayTeamItem()` 的展示隊伍選取狀態切換

本輪原則維持不變：

- **不改 boot / version chain**
- **不改 HTML 結構與既有 inline handler 行為**
- **只做主入口 → 模組委派收斂**
- **完成後補深度檢查，避免只是換寫法、沒有真正脫離主入口**

---

## 本輪實際改動

### 1) `js/modules/student.js`

新增並承接：

- `openDisplayTeamEditor()`
- `toggleDisplayTeamItem(idx)`

這兩段現在由 student module 正式持有，模組內負責：

- 讀取 `display_team` 既有選擇
- 過濾不可展示項目（死亡、全息、非 dragon/legendary）
- 建立展示隊伍編輯器 grid
- 維護 `currentState.tempDisplayTeam`
- 控制最多 5 隻的 UI 限制
- 更新 `dtCountDisplay`
- 保留既有 inline `App.toggleDisplayTeamItem(...)` 介面不變

另外，student module 現在直接使用 `getDisplayTeamDom` contract 取得：

- `displayTeamModal`
- `dtGrid`
- `dtCountDisplay`

### 2) `js/main.entry.js`

把原本完整的 collection editor UI 本體，改成純 delegate：

- `openDisplayTeamEditor() { return studentApi.openDisplayTeamEditor.apply(this, arguments); }`
- `toggleDisplayTeamItem() { return studentApi.toggleDisplayTeamItem.apply(this, arguments); }`
- `saveDisplayTeam()` 維持既有 delegate

並在掛載 `studentApi` 時補入：

- `getDisplayTeamDom`

### 3) 新增深檢腳本

新增：

- `scripts/deep-check-phasec-collection-editor-boundaries.mjs`

用途：

- 驗證主入口是否真的只剩 delegate
- 驗證展示隊伍編輯器本體是否真的移到 `student.js`
- 驗證不是只把同一段邏輯藏成另一種寫法

---

## 量化結果

### 主入口規模

- `js/main.entry.js`: **5684 → 5605 行**

### 主入口資料操作狀態

- `main getDoc(...)`: **0**
- `main getDocs(...)`: **0**
- `main setDoc(...)`: **0**
- `main saveToDB(...)`: **15**（本輪未下降）

### Collection editor 邊界狀態

- `openDisplayTeamEditor()`：**已移出主入口**
- `toggleDisplayTeamItem()`：**已移出主入口**
- `saveDisplayTeam()`：**維持由 student module 承接**

### Boot / 版本鏈

- `BOOT_ID`: **未變更**
- `BUILD_TAG`: **未變更**
- canonical active chain 維持：
  - `js/bootstrap-entry.js`
  - `js/main.entry.js`
  - `js/core/app-facade.js`
  - `js/core/api-surface.js`

---

## 驗證結果

### 語法檢查

- `node --check js/modules/student.js` ✅
- `node --check js/main.entry.js` ✅
- `node --check scripts/deep-check-phasec-collection-editor-boundaries.mjs` ✅

### Active chain 檢查

- `node scripts/validate-active-chain.mjs` ✅

### 既有深檢

- `node scripts/deep-check-active-flow.mjs` ✅
- `node scripts/deep-check-phasec-collection-boundaries.mjs` ✅
- `node scripts/deep-check-phasec-evolution-boundaries.mjs` ✅

### 本輪新增深檢

- `node scripts/deep-check-phasec-collection-editor-boundaries.mjs` ✅

本輪新增深檢確認了：

- 主入口 `openDisplayTeamEditor / toggleDisplayTeamItem` 已只剩 delegate
- 主入口不再保留 `tempDisplayTeam` 初始化與 grid 渲染本體
- 主入口不再保留 `dtItem_*` toggle 操作本體
- `student.js` 已正式承接 display team editor UI 邊界

---

## 目前階段判定

### 已完成階段

#### Phase A：Student / Token / Mirror / Save 主鏈
已基本完成。

代表：
- student/token/mirror/account/card-scan 主鏈已大幅撤出主入口
- 主入口不再直接承擔主要 student/token DB 邏輯

#### Phase B：Ranking / Shop / Batch 收斂
已基本完成。

代表：
- ranking/shop public summary fallback 已收過
- bulk progress 已從主入口移出
- 主入口直接 Firestore 查詢已降到 0

#### Phase C 前半：Collection / Evolution 邊界
已完成到 **C-3**。

代表：
- archive modal 邊界已收
- voucher redeem teacher-save 邊界已收
- evolution 規則本體已收進 `evolution.js`
- display team editor UI 邊界已收進 `student.js`

---

## 現在真正剩下的核心問題

目前主問題已經不是主入口還有多少直接 `getDoc/getDocs/setDoc`，而是：

### 1) `saveToDB()` 仍是主入口正式保存匯流點
這是目前最明顯的剩餘結構債。

### 2) `forge / pending forge / action-card / hidden reward` 邊界仍偏重
這些大多屬於「主入口仍承擔太多跨模組保存協調」的區域。

### 3) collection / student editor 已收斂，但 collection 生產鏈與獎勵鏈還沒完全收尾
也就是說，展示編輯器 UI 已收，但物件生成與兌換鏈仍有後續整理空間。

### 4) archive / deploy governance / Firestore Rules 還沒進最後收口
這是後段治理層面的固定收尾工作。

---

## 建議的下一步規劃

### Phase C-4：Forge / Action-Card Boundary Convergence
優先順序最高。

目標：
- 收 `forge / pending forge / action-card` 仍殘留在主入口的邊界
- 讓主入口更接近只管 orchestration，不持有 forge 規則與保存實作

完成條件：
- `processEvolution()` 之外的 collection 生產鏈再縮一圈
- forge / action-card 相關 UI 與保存鏈有更清楚的模組責任

### Phase C-5：Save Hub Shrink（saveToDB 匯流點瘦身）
這會是 Phase C 後半真正的關鍵。

目標：
- 盤點 `saveToDB()` 的呼叫型別
- 把可模組內自決的保存責任撤出主入口匯流點
- 讓主入口只保留最少量 canonical save bridge

### Phase D：Batch / Auth / Student 舊式 this.* 鏈回掃
在主入口實質收完之後做。

目標：
- 回掃高風險舊式依賴
- 降低回歸風險
- 提高模組可維護性

### Phase E：Archive / Deploy Governance / Firestore Rules 收尾
最後治理收口。

目標：
- archive/ 舊 variant 整理
- DEPLOY / SMOKE TEST 文件補齊
- Firestore Rules 對照現況重整

---

## 本輪結論

本輪完成後，可以更明確地說：

**Phase C 已經不只是收 collection 規則，連 collection editor UI 邊界也已經脫離主入口。**

現在 `js/main.entry.js` 的性質，已經非常接近：

- 啟動
- 模組掛載
- façade / delegate
- orchestration

而不是舊式的大型 UI + 資料 + 規則混合實作檔。

下一輪最合理的方向，是直接切入：

**Phase C-4：forge / action-card / pending forge 邊界收斂。**
