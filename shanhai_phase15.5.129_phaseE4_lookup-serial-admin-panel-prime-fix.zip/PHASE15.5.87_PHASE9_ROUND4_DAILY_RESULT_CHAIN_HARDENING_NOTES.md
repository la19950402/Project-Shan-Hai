# PHASE 15.5.87 — Phase 9 Round 4: Daily Result Chain Hardening

## 本輪目標
延續 phase 9，針對「每日挑戰答題中 / 題目切換 / 結算顯示」鏈條做第二段硬化，優先修補容易造成卡住、亂跳題、結果重複或關閉後舊 session 繼續執行的風險。

## 本輪修改重點

### 1. 新增 quiz session 進度控制 helper
檔案：`js/main.entry.js`

新增：
- `clearQuizAdvanceTimer()`
- `beginQuizSession(mode)`
- `scheduleQuizAdvance(callback, delay, expectedToken)`
- `abortQuizSession(reason)`
- `handleQuizCloseButton()`

用途：
- 集中管理 quiz session token、pending 狀態、advance timer、手動關閉。
- 避免舊 session 的 timer 在新 session 中繼續推進題目或誤觸發結算。

### 2. startDailyQuest 啟動前先中止舊 session，再建立新 token
檔案：`js/main.entry.js`

調整：
- 每次開始每日挑戰前先 `abortQuizSession('restart_daily')`
- 再 `beginQuizSession('daily')`
- 啟動失敗時會 `abortQuizSession('daily_start_failed')`

用途：
- 避免前一次未清乾淨的 daily session 殘留到新的一輪。

### 3. renderQuizQuestion 加入 aborted / 缺面板 / 空選項保護
檔案：`js/main.entry.js`

調整：
- 若 session 已 aborted，直接不 render
- 題目或作答 DOM 缺失時，先 `abortQuizSession('render_missing_dom_or_question')`
- 沒有可作答選項時，先 `abortQuizSession('render_empty_options')`

用途：
- 避免 render 失敗後，session 還維持半啟動狀態。

### 4. selectQuizOption 加入防重入與 token 檢查
檔案：`js/main.entry.js`

調整：
- `quizSession.answerPending` 為 true 時，不再重複受理點擊
- 記錄 `expectedToken` 與 `questionIndex`
- 找不到按鈕時會安全回退 pending 狀態

用途：
- 避免快速連點、重複觸發、舊 callback 對新題目生效。

### 5. 題目跳轉改成 scheduleQuizAdvance
檔案：`js/main.entry.js`

調整：
- 原本直接 `setTimeout(..., 1000)`
- 改成 `scheduleQuizAdvance(...)`
- 只有在 token 仍一致、session 未 aborted、currentIndex 未被外部改動時才會真的跳下一題或顯示結果

用途：
- 這是本輪最重要的 race-condition 修補。
- 可防止：
  - 手動關閉 modal 後，舊 timer 還偷跑
  - 新 session 開始後，舊 session 還把題目/結算覆蓋回來

### 6. showQuizResult 防重複顯示
檔案：`js/main.entry.js`

調整：
- 加入 `quizSession.resultShown` guard
- 進入結果畫面前先清掉 advance timer
- 同時把 `answerPending` 歸零

用途：
- 避免結果畫面重複執行、重複 commit 或 UI 多次切換。

### 7. quizCloseBtn 改成透過 App helper 關閉
檔案：`index.html`

調整：
- 原本：`UI.hideModal('quizPlayModal')`
- 改成：`App.handleQuizCloseButton(); return false;`

用途：
- 手動關閉每日挑戰/題目 modal 時，會先中止當前 quiz session，再關閉視窗。
- 避免關掉畫面後，舊 session 還在背景跑下一題或跳結果。

## 為什麼這樣修
這輪處理的是 daily challenge 最容易出現、但平常不一定馬上看得出的時序類 bug：
- 作答後連點或重複送答
- setTimeout 舊 callback 在新 session 還活著
- 手動關閉 modal 後，舊 session 還在繼續跳題/結算
- 結果畫面被重複觸發

這些問題通常不會表現成明顯語法錯，而是會造成：
- 看起來卡住
- 題目跳錯
- 畫面突然被舊題覆蓋
- 結束後又自己跳下一題
- 結果畫面異常重複

## 驗證方式
- `node --check js/main.entry.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 再跑一輪 syntax check
- 結果：`syntax_errors = 0`

## 部署後建議 smoke test
1. 開始每日挑戰，正常進第一題
2. 答題後快速連點，確認不會重複受理
3. 答題後立刻手動關閉 modal，確認不會又自己跳下一題
4. 關掉後再重新開始每日挑戰，確認不會被舊題或舊結果覆蓋
5. 完成最後一題，結果畫面只出現一次
6. 結果畫面關閉後，不應再自己跳回題目

## 產出包
- `project-root-phase15.5.87-phase9-round4-daily-result-chain-hardening.zip`
