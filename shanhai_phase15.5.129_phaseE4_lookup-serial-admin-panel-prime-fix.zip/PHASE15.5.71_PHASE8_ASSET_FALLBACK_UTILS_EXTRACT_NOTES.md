# Phase 15.5.71 — Phase 8 asset / fallback helper extract

## This round
A low-risk Phase 8 extraction from `main.entry.js` into:

- `js/core/asset-fallback-utils.js`

Extracted helpers:
- `isDirectVisualSource`
- `splitBattleVisualRef`
- `buildAssetObjectPaths`
- `getCachedAssetUrlFromFileBaseName`

`main.entry.js` now keeps only thin wrappers for:
- `isDirectVisualSource`
- `splitBattleVisualRef`
- `__objectPathsForAssetKey`
- `assetUrlFromFileBaseName`

## Why this batch was safe
These helpers are:
- pure or near-pure utility logic
- not part of boot/auth critical flow
- not part of save/merge/teacher/shop transaction flow
- already used as internal support utilities

## Result
- `main.entry.js` line count: 7509 -> 7479
- extracted helpers this round: 4
- canonical active chain syntax check: pass

## Remaining conservative extraction candidates
Still good candidates for future low-risk extraction:
1. pure dragon / hidden-egg visual selection helpers
2. pure battle-mon display assembly helpers
3. pure leaderboard / collection formatting helpers
4. pure CSV/export/text formatting helpers that still remain in `main.entry.js`

## Areas that should NOT be aggressively extracted yet
1. boot/auth init sequence
2. teacher target/save chain
3. student save / mirror merge flow
4. shop purchase / inventory write flow
5. main battle execution flow

## Validation completed
- `node --check js/core/asset-fallback-utils.js`
- `node --check js/main.entry.js`
- canonical active chain full syntax check
