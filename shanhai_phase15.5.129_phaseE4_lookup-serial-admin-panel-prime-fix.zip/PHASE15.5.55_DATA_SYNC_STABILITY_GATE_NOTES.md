# Phase 15.5.55 — Data Sync Stability Gate

## 本輪目標
以 `15.5.54` 為基底，只修資料同步與學生頁持久化的穩定性風險，不碰 boot/auth 主鏈。

## 本輪修正

### 1. `mergeStudentRecords()` 改為 primary-aware 合併
位置：`js/main.entry.js`

原本大量欄位使用 `Math.max()` / `Math.min()` 進行通用合併，容易導致：
- 重設後被舊值拉回
- 清空後被舊值覆蓋
- page 比 master 新時仍回退到舊值

本輪改為：
- `name / class_name / seat_number / display_team / guide_mode / guide_mode_locked / dragon_stage / dragon_path / totalXP / coins / lap / trainerRankIndex / best_rate` → **primary 優先**
- `attributes / streaks / attr_event_counts / attribute_first_gain_order` → **逐屬性 primary 優先**
- `debuffs / debuffs_timestamp` → 維持先前的 debuff-aware 規則
- `reward_events` → `dedupeLogs([...secondary, ...primary])`
- `reward_settled_ids` → union + dedupe

### 2. `syncStudentMirrorForSerial()` 改為 page-aware
位置：`js/main.entry.js`

原本在沒有 `preferredData` 時，會偏向 `students/{serial}` 當 primary。

本輪改為：
- 有 `preferredData`：`preferredData` 為 primary
- 無 `preferredData`：若 `student_pages/{token}` 存在，**優先以 page 當 primary**
- `students` 不存在但 `student_pages` 存在時，不再直接回傳 `null`

### 3. `buildStudentWritablePayload()` 補齊學生頁實際可寫欄位
位置：`js/main.entry.js`

新增納入 payload 的欄位：
- `class_name`
- `seat_number`
- `streaks`
- `attr_event_counts`
- `attribute_first_gain_order`
- `display_team`
- `lap`
- `trainerRankIndex`
- `best_rate`
- `debuffs`
- `debuffs_timestamp`
- `status`
- `status_timestamp`
- `content_profile_id`
- `ui_variant`
- `profile_flags`
- `guide_mode`
- `guide_mode_locked`

另外補了：
- `attribute_gain_order -> attribute_first_gain_order` 相容映射
- 各屬性 map / debuff / profile flags / guide mode 的正規化

### 4. 修正 `student.js` 的 `seat_no` typo
位置：`js/modules/student.js`

- `src.seat_no` → `src.seat_number`

## 驗證

### 語法檢查
已通過：
- `node --check js/main.entry.js`
- `node --check js/modules/student.js`

### Canonical active chain 全鏈語法檢查
已通過：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

## 影響範圍
本輪會直接降低以下問題再發生的機率：
- 學生端改名成功後又被舊資料蓋回
- debuff / 顯示設定 / guide mode / display team 沒有真正持久化到 `student_pages`
- `student_pages` 比 `students` 新時，補同步又被 master 舊值拉回
- 座號顯示讀到錯欄位

## 本輪刻意沒動
- boot chain
- auth/login
- UI contract / panel 收斂
- `student.js / battle.js` 的 `this.*` 第二輪清理
