# PHASE15.5.82 PERFORMANCE PHASE7 PUBLIC VIEW NOTES

## 本輪目標
延續 phase15.5.81 的 summary/public 路線，進一步把學生端常用但仍會讀主集合的兩個區塊收斂：

1. 商城 modal 改成 `shop_catalog_public` / 快取優先
2. 排行榜展示圖繼續收斂成 lazy hydrate 優先

原則維持：
- 只改 canonical active chain
- 不新增新的入口副本
- 不擴大全域變數
- 優先減少主集合讀取與 Storage 同步壓力

## 這次修改重點

### 1. 商城 modal 優先走 public summary 與快取
檔案：`js/main.entry.js`, `js/modules/shop.js`

原本學生端打開商城 modal 時，`renderShopItems()` 仍會直接掃 `shop_catalog` 主集合。

這次改成：
- 若 `currentState.studentShopCatalogCache` 已有資料，先立即渲染快取
- 再優先呼叫 `warmStudentShopCatalog(...)`
- `warmStudentShopCatalog(...)` 本身會先吃 `shop_catalog_public`，失敗才 fallback 主集合
- 只有 public summary 與快取都無法使用時，才退回舊 full scan

效果：
- 學生端打開商城 modal 時，不再預設直衝完整 `shop_catalog`
- 與學生頁商品展示共用同一條 public/summary 路線
- 已有快取時，畫面可先出再背景更新

### 2. 商城縮圖支援 asset key lazy hydrate
檔案：`js/modules/shop.js`

`renderShopImageThumb(...)` 原本只支援 direct URL，對 asset key 圖源不友善。

這次改成：
- 若有 direct URL，直接顯示
- 若沒有 direct URL 但有 `imageAssetKey/img_file`，先用 placeholder
- 同時加上 `data-asset="..."`
- 再交給既有 `hydrateStorageImages(...)` 在可見區補圖

效果：
- 商品縮圖不需要在初次 render 時就同步解析所有 Storage URL
- 商品 summary 若只存 asset key，也能正常補圖

### 3. 排行榜圖片 hydrate 改成更保守的可見範圍策略
檔案：`js/main.entry.js`

`renderRankingRows(...)` 原本直接 `hydrateStorageImages(tbody)`。

這次改成：
- `hydrateStorageImages(tbody, { rootMargin: '240px 0px', eagerLimit: 3 })`

效果：
- 排行榜只會先處理少量首屏縮圖
- 其餘在接近可見區時再解析 Storage URL
- 降低排行榜 modal 一打開時的圖片同步壓力

### 4. 模組注入補齊
檔案：`js/main.entry.js`

`createShopModule(...)` 新增注入：
- `warmStudentShopCatalog`
- `hydrateStorageImages`

目的：
- 不在 shop module 內重新擴增全域依賴
- 保持 public summary 與圖片 hydrate 策略沿用 active chain 現有 helper

### 5. Active chain 版本對齊
本輪版本：
- query tag: `phase15phase82publicphase7`
- build tag: `v15.5.82-performance-phase7-public-view-shop-modal-ranking-20260315`

已同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- canonical `js/core/*.js`
- canonical `js/modules/*.js`
- `js/ENTRY_CHAIN_MANIFEST.json`

## 驗證
已完成：
- `node --check js/main.entry.js`
- `node --check js/modules/shop.js`
- `node --check js/modules/ranking.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 再跑一輪語法檢查

結果：
- `syntax_errors = 0`

## 部署後建議 smoke test
1. 首頁正常開啟
2. 登入正常
3. 學生端打開商城 modal
4. 若已有商品快取，應先看到內容，再背景更新
5. 沒有 direct URL、只有 asset key 的商品縮圖仍能在可見區補圖
6. 排行榜 modal 開啟後，首屏縮圖先出，其餘不應一次性明顯拖慢
7. Console 不應新增 boot blocker

## 下一階段建議
下一輪最合理的是：
1. 把學生頁 / 商城 modal / 排行榜共用的圖片顯示邏輯再抽成共用 helper
2. 進一步把排行榜 fallback full scan 改成更嚴格的 background-only backfill 策略
3. 檢查是否要把商城 gift 選單也分成 admin full scan 與 public summary 兩條路，避免之後功能擴大時互相干擾
