# Phase 15.5.51 — Phase 7 High-Risk UI Contract Hardening

## 本輪目的
在不碰 boot/auth 主鏈與不改業務流程的前提下，盤查 `main.entry.js` 內仍屬高風險、且尚未 contract 化的 UI 區域，將其收斂為統一的 DOM contract 取用方式，降低執行期因 DOM 缺件、作用域失配、或事件綁定分散而導致的靜默失敗風險。

## 本輪實際修整的高風險 UI 區域

### 1. 學生資訊說明 / 駭客警示面板
新增 `getStudentInfoDom()`，統一納管：
- `statusDescTitle`
- `statusDescText`
- `attrInfoModal`
- `attrInfoTitle`
- `attrInfoIcon`
- `attrInfoChar`
- `attrInfoDesc`
- `attrInfoList`
- `hackerAlertModal`
- `haTargetName`
- `haXpDiff`
- `attrInfoModal .modal-content`（透過 modal querySelector 取回）

套用到：
- `showStatusInfo()`
- `showAttrInfo()`
- `showHackerAlert()`

### 2. 學生行動區 / 鎖定 overlay / 每日歷練 UI
新增 `getStudentActionDom()`，統一納管：
- `studentView`
- `stuDailyQuestBtn`
- `stuDailyQuestTimer`
- `actionGrid`
- `actionGridModeHint`
- `studentLockOverlay`
- `studentLockMsg`
- `studentLockPanel`
- `studentLockTitle`

套用到：
- `updateDailyQuestTimer()`
- `initActionGrid()`
- `lockStudentAccess()`
- `unlockStudentAccess()`
- `startDailyQuest()`

### 3. Runtime UI 綁定區
新增 `getRuntimeUiDom()`，統一納管：
- `adminDiagInlineWrap`
- `loginView`
- `battleArenaModal`
- `adminView`
- `batchModeView`
- `adminEmail`
- `adminPassword`
- `scanNfcBtn`
- `cancelActionBtn`

套用到：
- `toggleAdminDiagPanel()`
- `checkRoute()` 的 admin focus
- `setupEventListeners()` 內的 document click refocus
- `setupEventListeners()` 內的 NFC 按鈕綁定
- `setupEventListeners()` 內的取消動作按鈕綁定

### 4. 掃描模式 contract 小幅補強
既有 `getScanModeDom()` 補入：
- `cardSeqSearchBtn`

讓 `setupEventListeners()` 的卡序查詢按鈕也走 contract，不再直接散抓 `getElementById()`。

## 本輪特別修掉的危險漏點
在逐段回看時，發現 `startDailyQuest()` 在切換為 `getStudentActionDom()` 後，一度遺失 `btn / timerText` 區域變數。

這種錯誤：
- `node --check` 不一定會提醒
- 但實際點每日歷練時會在執行期炸掉

已補回：
- `const { dailyQuestBtn: btn, dailyQuestTimer: timerText } = getStudentActionDom();`

## 變更檔案
- `js/main.entry.js`
- `js/core/state.js`

## 新增狀態診斷欄位
在 `currentState` 新增：
- `studentInfoDomContract`
- `studentActionDomContract`
- `runtimeUiDomContract`

對應位置：
- `js/core/state.js:49-51`

## 關鍵位置
- `js/main.entry.js:773` `getStudentInfoDom()`
- `js/main.entry.js:802` `getStudentActionDom()`
- `js/main.entry.js:821` `getRuntimeUiDom()`
- `js/main.entry.js:1961` `showStatusInfo()`
- `js/main.entry.js:1973` `showAttrInfo()`
- `js/main.entry.js:1996` `showHackerAlert()`
- `js/main.entry.js:2007` `updateDailyQuestTimer()`
- `js/main.entry.js:2024` `initActionGrid()`
- `js/main.entry.js:2103` `toggleAdminDiagPanel()`
- `js/main.entry.js:2159` `lockStudentAccess()`
- `js/main.entry.js:2182` `unlockStudentAccess()`
- `js/main.entry.js:3650` admin route focus 改走 `getRuntimeUiDom()`
- `js/main.entry.js:3665` `setupEventListeners()` 改走 scan contract + card seq button
- `js/main.entry.js:3692` runtime button 綁定改走 `getRuntimeUiDom()`

## 驗證
### 語法檢查
已逐檔通過：
- `js/main.entry.js`
- `js/core/state.js`
- `js/core/dom-contract.js`

### Canonical active chain 全鏈語法檢查
已逐檔通過：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/state.js`
- `js/core/dom-contract.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

### DOM id 對表
本輪新增納管的 required ids 已逐一對回 `index.html`，無缺件。

## 誠實說明
本輪已對**實際改到的檔案與改動區塊逐段回看**，並做 canonical active chain 的整體語法檢查；但此環境無法完成瀏覽器 + Firebase 的完整互動實機驗證，因此不能宣稱所有執行路徑都已被真機覆蓋。

## 輸出
- `project-root-phase15.5.51-phase7-high-risk-ui-contract.zip`
