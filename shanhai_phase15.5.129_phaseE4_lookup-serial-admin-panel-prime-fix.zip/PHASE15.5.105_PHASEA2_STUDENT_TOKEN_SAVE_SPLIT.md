# PHASE15.5.105 Phase A-2 — Student Token / Save Path Split

## 本輪目標
在不改動 canonical active chain、HTML 大結構與主要 UI 流程的前提下，繼續把 `js/main.entry.js` 中仍直接負責 student/token/student_pages 的保存與發放邏輯往 `js/modules/student-access.js` 收斂。

這輪優先處理的是：
1. 老師端「寫學生網址到 NFC」時的 token 發放 / 補建邏輯。
2. `saveToDB()` 內 student token mode 的 `student_pages/{token}` 正式保存鏈。
3. `saveToDB()` 內 fast-admin-save 的學生 mirror 保存鏈。

---

## 實作內容

### 1. 擴充 `js/modules/student-access.js`
新增並收斂以下 helper：
- `ensureActiveTokenForSerial(serial, options)`
- `writeCurrentStudentUrlToCard(options)`
- `saveStudentTokenPayload(dataObj, explicitUid)`
- `saveFastAdminStudentPayload(payload, explicitUid)`

這批 helper 現在統一承接：
- active token 查找與缺 token 補建
- 老師端 NFC 學生網址寫入前的 token 準備
- 學生 token mode 下 `student_pages/{token}` 為 source of truth 的保存邏輯
- fast-admin-save 下 students / student_pages 的 mirror 同步

### 2. 主入口改成委派
`js/main.entry.js` 新增委派 wrapper：
- `ensureActiveTokenForSerial()`
- `writeCurrentStudentUrlToCard()`
- `saveStudentTokenPayload()`
- `saveFastAdminStudentPayload()`

並把原本主入口裡這三段直接資料責任改成委派：
- `writeNfcLinkBtn` click handler
- `saveToDB()` 的 student token mode 分支
- `saveToDB()` 的 fast-admin-save 分支

---

## 成果

### `js/main.entry.js` 繼續縮小
- 行數：`6991 -> 6934`
- `getDocs(...)`：`5 -> 5`（本輪不是查詢瘦身，重點在保存鏈與 token 發放）
- `setDoc(...)`：`14 -> 7`
- `getDoc(...)`：`17 -> 15`

### 直接責任下降的具體意義
主入口現在不再自己處理以下高風險細節：
- 「如果沒 token，要怎麼補建 token 並寫回 students」
- 「老師按下寫入 NFC 時，如何準備學生專屬 URL」
- 「student token mode 時，如何先寫 student_pages 再做 students mirror」
- 「fast-admin-save 時，如何同步 student_pages mirror」

這代表 `main.entry.js` 又更接近 orchestration 層，而不是資料落地層。

---

## 驗證結果

### 語法檢查
- `node --check js/main.entry.js`：通過
- `node --check js/modules/student-access.js`：通過

### Active chain 檢查
- `node scripts/validate-active-chain.mjs`：通過

### 深檢
- `node scripts/deep-check-active-flow.mjs`：通過
- `main_getDocs_count`：`5`
- 既有 active chain / quiz / battle / shop / legendary 檢查項目均保持綠燈

---

## 目前 Phase A 到哪裡

### 已收斂
- token 解析 / active token 查找
- student mirror 同步
- bulk repair student pages
- 匿名註冊 / 補發 / 查卡序
- 老師端寫 NFC 前 token 準備
- student token mode 保存鏈
- fast-admin-save mirror 保存鏈

### 還沒收完
Phase A 還有幾個殘留點可再往下拆：
1. `ensureStudentDataReady()` 內 student token hydration 分支，仍留在主入口。
2. 某些學生 / cards / action_cards 交界流程仍由主入口直接掌握。
3. content profile 套用時，students / student_pages 雙寫仍是主入口自行處理。

---

## 下一步建議
最合理的下一輪是 **Phase A-3：student hydration / profile mirror 收尾**。

建議順序：
1. 把 `ensureStudentDataReady()` 的 student token hydration 分支收進 `student-access`。
2. 把 `applyCurrentStudentProfile()` 的 students / student_pages 雙寫改走專責 helper。
3. 再評估是否把 `cards / action_cards / forge` 交界正式切到下一個 Phase C，而不是混在 student Phase 裡繼續拉長風險面。

