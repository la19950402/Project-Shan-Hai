# PHASE15.5.81 Performance Phase 6 - Summary Image Priority

## 本輪目標
延續 phase 15.5.80 的圖片 lazy hydrate 與題圖預取，這一輪進一步處理「重複出現的圖片與資料仍反覆走重查詢/重推斷」的問題，重點放在：

1. 排行榜展示圖改成 summary image 欄位優先。
2. 學生端商品展示改成 `shop_catalog_public` 輕量摘要集合優先。
3. 學生端商品展示卡支援 direct URL 優先、asset key 次之，並沿用 lazy hydrate。
4. 商品異動時同步更新/刪除 public summary，避免學生端每次都掃 `shop_catalog` 主集合。

---

## 這次修改的 canonical active chain 檔案
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/core/api-surface.js`
- `js/core/profile-visual-utils.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/content-profile.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/shop.js`
- `js/modules/teacher-actions.js`
- `js/modules/zones.js`

> 實際功能修改主要集中在 `js/main.entry.js` 與 `js/modules/shop.js`；其餘 canonical 檔案主要是 active chain 版本 query 對齊。

---

## 實際修改內容

### 1. 新增 `shop_catalog_public` 輕量摘要路徑
在 `js/main.entry.js` 的 `APP_CONFIG.collections` 增加：
- `shopPublic: 'shop_catalog_public'`

對應常數：
- `SHOP_PUBLIC_COLLECTION`

用途：
- 學生端展示不再優先讀取完整 `shop_catalog`。
- 先讀 `shop_catalog_public` 的輕量摘要文件；若集合還沒建立或讀取失敗，再 fallback 回舊的 `shop_catalog` 全掃。

---

### 2. 學生端商品展示新增 summary helper
在 `js/main.entry.js` 新增：
- `buildStudentShopSummaryData(raw, id)`
- `loadStudentShopCatalogSummary()`
- `syncStudentShopCatalogSummaryForId(productId, preferredData)`
- `removeStudentShopCatalogSummaryForId(productId)`
- `backfillStudentShopCatalogSummaryEntries(rows)`

效果：
- 學生端展示卡只需要的欄位被集中到 summary doc。
- 第一次 fallback 掃 `shop_catalog` 後，會批次回填 `shop_catalog_public`。
- 後續再打開學生商品展示，多半可直接走輕量摘要集合。

---

### 3. `warmStudentShopCatalog()` 改成 summary 優先
原本：
- 直接 `getDocs(collection(db, SHOP_COLLECTION))`

現在：
1. 先 `loadStudentShopCatalogSummary()`
2. 失敗或無資料時 fallback `shop_catalog`
3. fallback 後自動 `backfillStudentShopCatalogSummaryEntries(rows)`

這可降低：
- 學生頁展示區的資料量
- 每次都掃完整商品 doc 的成本

---

### 4. 學生端商品展示卡改成 direct URL / asset key 雙路支援
`renderStudentShopShowcaseCards()` 現在：
- 優先使用 `item.imageUrl`
- 若沒有 direct URL 但有 `item.imageAssetKey`，會先以 placeholder 畫出，再在 `<img>` 上掛 `data-asset`
- 之後由 `hydrateStorageImages(...)` 依可見範圍 lazy hydrate

這比先前只吃 direct URL 更完整，也避免 asset key 商品卡一直只剩 placeholder。

---

### 5. 學生商品展示區在 render 後主動 hydrate 可見範圍圖片
`renderStudentShopShowcase()` 新增：
- `hydrateShowcaseTrack()`
- 在 cached / loading / fresh / error fallback 各路徑 render 後，都會對 track 進行 lazy hydrate

設定：
- `rootMargin: '320px 0px'`
- `eagerLimit: 2`

效果：
- 當前可見卡片優先解析 asset URL
- 不會一次把整個橫向展示軌道全打 Storage

---

### 6. 排行榜展示圖資料改成明確 image 欄位優先
在 `js/main.entry.js` 新增：
- `resolveVisualMeta(raw, options)`

並套用到：
- `getRankingDisplayItems()`
- `buildLeaderboardSummaryData()`
- `renderRankingRows()`

效果：
- `display_items` 現在會顯式帶出：
  - `imageUrl`
  - `imageAssetKey`
  - 保留相容欄位 `img` / `img_file`
- 排行榜畫圖時，不再每個地方自己猜 `img` 是 direct URL 還是 asset key。
- `leaderboard_public` summary 也會同步存：
  - `display_image_urls`
  - `display_image_assets`

這讓後續若要再做更進一步的榜單圖片快取／預載，有穩定欄位可以接。

---

### 7. 商品管理儲存 / 刪除時同步更新 public summary
在 `js/modules/shop.js`：
- `saveShopProduct()` 成功後，會呼叫
  - `App.syncStudentShopCatalogSummaryForId(savedProductId, payload)`
- `deleteShopProduct()` 成功後，會呼叫
  - `App.removeStudentShopCatalogSummaryForId(productId)`

這樣 summary 不會永遠依賴 fallback/backfill 才生成。

---

### 8. active chain 版本對齊
本輪版本識別已推進到：
- query tag: `phase15phase81summaryphase6`
- build tag: `v15.5.81-performance-phase6-summary-image-priority-20260315`

已同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- canonical `js/core/*.js`
- canonical `js/modules/*.js`

---

## 為什麼這樣修
這一輪不是只為了「再加一個快取」，而是為了把前幾輪修好的圖片 lazy hydrate 與 query summary 策略延伸到真正高重複的區塊：

1. **學生商品展示** 原本還是掃 `shop_catalog` 主集合，商品一多就會拖慢。
2. **排行榜展示圖** 雖已能顯示，但圖源欄位仍偏向隱式推斷，會造成不同路徑重複猜 `img` / `asset key`。
3. 這些區塊都屬於會被反覆打開、反覆進入的頁面，若不做 summary image priority，性能會在資料量成長後再次惡化。

所以本輪目標是：
- 先把展示型資料改成更輕的 summary 路徑。
- 再把圖片來源欄位顯式化，減少每次 render 時的歧義與重工。

---

## 驗證方式
已執行：
- `node --check js/main.entry.js`
- `node --check js/modules/shop.js`
- `node --check js/modules/ranking.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 再跑一輪語法檢查

結果：
- `checked = 83`
- `syntax_errors = 0`

---

## 部署後建議優先 smoke test
1. 首頁是否正常開啟
2. 登入是否正常
3. 學生頁商品展示是否仍可顯示
4. 新增或編輯商品後，學生展示是否立即刷新
5. 刪除商品後，學生展示是否同步消失
6. 排行榜是否正常顯示異獸縮圖
7. 若榜單或展示卡圖片來源為 asset key，圖片是否能在可見範圍內正常補圖
8. console 不應新增 boot blocker；若有 warning，應只與 summary 集合尚未建立或 rules 有關

---

## 新產出打包檔
- `project-root-phase15.5.81-performance-phase6-summary-image-priority.zip`
