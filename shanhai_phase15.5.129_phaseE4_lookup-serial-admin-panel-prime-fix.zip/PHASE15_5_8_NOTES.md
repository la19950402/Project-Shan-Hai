# PHASE15_5_8_NOTES

這一輪是 **全域盤點與 façade 暴露面凍結** 的第一次正式落地，目標是用最保守的方式收斂全域，而不是直接拔掉 `window.App` / `window.UI`。

## 本輪完成

- 新增 `js/core/api-surface.js`
  - 定義 `App` required / transitional surface
  - 定義 `UI` required surface
  - 定義 required / debug-only globals
  - 建立 runtime inventory
  - 將 surface metadata 掛到 `App` / `UI`（非列舉）

- `js/main.js`
  - 匯入 `api-surface.js`
  - 在 `exposeGlobalFacade()` 後建立 `globalSurfaceInventory`
  - 將 inventory 注入 `ShanHaiSystem`

- `js/core/app-facade.js`
  - 修正 shop / quiz / zones legacy alias 掛載順序 bug

- 版本參數統一為 `phase15hotfix8`
- build tag 更新為 `v15.5.8-facade-freeze-inventory-20260314`

## 本輪刻意不做

- 不移除 `window.App`
- 不移除 `window.UI`
- 不強制 `Object.freeze(window.App)`
- 不導入 HTML partials

## 原因

這一輪的重點是 **建立可盤點、可驗證、可逐步收斂的暴露面**，先降低風險，再決定下一輪移除哪些過渡全域。
