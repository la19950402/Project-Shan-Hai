# Phase 15.5.5：老師端手動加分／狀態調整／補發流程收斂

本輪重點：
- 收斂老師端手動加分的預覽與 commit 流程，避免保存失敗時靜默結束。
- 保留 `prepareActionFromButton(this)` 的 B 方案，避免描述字串破壞 onclick。
- 老師端狀態調整（Healthy / debuff）改成有完整錯誤保護與畫面刷新。
- `checkDeathTrigger()` 改成可等待的保存流程，避免死亡重置只改到本地資料卻未真正落地。
- 卡片鑄造流程補參數檢查與按鈕 disable，避免重複送出。
- 老師端確認／取消按鈕與 debuff 開窗按鈕改成 once binding，避免重複綁定。

版本：
- query string: `phase15hotfix6`
- build tag: `v15.5.6-hotfix-shop-quiz-20260314`
