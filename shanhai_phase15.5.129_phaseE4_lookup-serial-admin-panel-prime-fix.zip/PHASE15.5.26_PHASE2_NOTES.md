# Phase 2：高頻 runtime guard（phase15.5.26）

## 本次目標
- 不改主體流程
- 只補 shop / quiz / battle / zones 最常見的 DOM 缺件爆錯
- 降低「按下按鈕就直接拋 exception」的風險

## 本次實作
### shop.stability2.js
- 為商城管理表單建立集中式欄位抓取
- `openShopAdmin()` 若缺少 modal，直接告警返回
- `editShopProduct()` 若管理表單不完整，不再直接 `null.value`
- `saveShopProduct()` 若管理表單不完整，直接提示並停止

### quiz.stability2.js
- 為題庫管理面板建立集中式 DOM 檢查
- `readQuizFormData()` 缺少必要欄位時直接提示
- `loadQuizBank()` 缺少題庫 modal / list container 時直接停止，不再進入後續渲染鏈

### battle.stability2.js
- `startBattleChallenge()` 若缺少 Boss 選角面板，直接告警
- `confirmBattleSelection()` 進入答題前先確認 quizPlay DOM 存在
- `prepareBattleArena()` 進入戰鬥前先確認 arena DOM 存在

### zones.stability2.js
- `openSupportZone()` / `openScienceZone()` 開啟前先確認專區 modal 與關鍵節點存在

## 風險控制
- 沒有改資料流
- 沒有改 Firestore 路徑
- 沒有改登入、批量模式、老師加分
- 只新增 guard 與明確錯誤提示
