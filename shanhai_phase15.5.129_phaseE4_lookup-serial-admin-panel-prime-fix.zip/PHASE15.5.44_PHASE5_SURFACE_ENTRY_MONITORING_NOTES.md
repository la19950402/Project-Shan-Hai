# Phase 15.5.44 — Surface Policy / HTML 入口監控完整化

## 本階段目標
補完整 `index.html` 直接呼叫的 `App/UI` 入口監控，讓 boot 後可以立即知道：

- HTML 直接用到的方法是否真的掛上
- 這些方法是否都被納入 surface policy
- 目前是否存在 policy 之外的直接入口

## 修改檔案
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/main.entry.js`

## 修改內容

### 1. `js/core/api-surface.js`
- 將 `index.html` 直接使用的 `App` 方法完整列為 `INDEX_HTML_DIRECT_APP_METHODS`
- 將 `index.html` 直接使用的 `UI` 方法列為 `INDEX_HTML_DIRECT_UI_METHODS`
- 補上 `INDEX_HTML_INLINE_HANDLER_SUMMARY`
- `buildGlobalSurfaceInventory()` 新增 `html` 區塊：
  - `appDirect.present/missing`
  - `uiDirect.present/missing`
  - `policyCoverage.appOutsidePolicy/uiOutsidePolicy`
  - `inlineSummary`
- `attachSurfaceMetadata()` 現在會把 HTML 入口 policy / inventory 掛到 `App` / `UI`
- `logSurfaceWarnings()` 現在也會檢查 HTML 直接入口是否缺件、是否有 policy 外項目

### 2. `js/core/global-bridge.js`
- `buildSystemNamespace()` 的 surface 摘要加入：
  - `htmlAppMissingDirect`
  - `htmlUiMissingDirect`
  - `htmlAppOutsidePolicy`
  - `htmlUiOutsidePolicy`

### 3. `js/main.entry.js`
- boot 後把 surface 摘要同步到 `window.__BOOT_DIAG.facadeSurfaceSummary`
- `<html>` 新增 `data-surface-ok="0|1"`
  - 只要 required / HTML direct / policy coverage 有缺漏，就會標成 `0`

## 驗證
### 語法檢查
- `node --check js/core/api-surface.js`
- `node --check js/core/global-bridge.js`
- `node --check js/main.entry.js`

### 入口盤查
使用 Node 對 `index.html` 做靜態比對：
- HTML 直接 `App.xxx()`：92 種
- HTML 直接 `UI.xxx()`：3 種
- `INDEX_HTML_DIRECT_APP_METHODS` 與實際 HTML 完全對齊
- `INDEX_HTML_DIRECT_UI_METHODS` 與實際 HTML 完全對齊
- `buildGlobalSurfaceInventory()` 驗證結果：
  - `html.appDirect.missing.length === 0`
  - `html.uiDirect.missing.length === 0`
  - `html.policyCoverage.appOutsidePolicy.length === 0`
  - `html.policyCoverage.uiOutsidePolicy.length === 0`

## 風險控制
- 未改動業務流程
- 未改動老師端保存鏈
- 未改動登入邏輯
- 只補監控與診斷層

## 仍需誠實說明
這一階段做的是 **靜態掛載監控完整化**，不是瀏覽器實機 smoke test。
因此它能更早抓到「沒掛上／漏進 policy」這類問題，但不能替代 Firebase 與 UI 實際互動驗證。
