# PHASE15.5.104 Phase A-1 Student Access Split Notes

## Build
- Base: `v15.5.103-fix15-battle-boss-config-split-20260316`
- This round: `Phase A-1 student/token/mirror/account split`

## What moved out of `js/main.entry.js`
New module:
- `js/modules/student-access.js`

Delegated from main entry to module:
- `buildStudentUrlFromToken`
- `generateBase62Token`
- `resolveSerialFromToken`
- `getActiveTokenForSerial`
- `syncStudentMirrorForSerial`
- `bulkRepairStudentPages`
- `generateUniqueName`
- `rollRegistrationName`
- `registerNewStudent`
- `amLookupSerial`
- `amLoadReissue`
- `amStartReissue`
- `executeReissue`

## Why this round
This is the first concrete Phase A extraction for:
- student identity / token chain
- `student_pages` mirror sync
- account lookup / reissue flow
- anonymous registration + NFC write path

Main entry now keeps these as wrappers, so call sites and global surface stay stable.

## Verification
### Active chain
- `node scripts/validate-active-chain.mjs` ✅

### Deep check
- `node scripts/deep-check-active-flow.mjs` ✅
- `main_getDocs_count`: `8 -> 5`
- `student_mirror_autoheal_count`: `3` preserved

## Remaining Phase A backlog
Still recommended next:
1. move residual student token write path inside NFC bind / scan branch
2. split `cards / action_cards / forge` later as separate phase
3. continue reducing `main.entry.js` direct DB responsibility
4. decide whether `mergeStudentRecords` stays in main as pure orchestration helper or becomes shared core util
