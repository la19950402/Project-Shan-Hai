# Firestore Rules Alignment — Phase E-3

## Scope

This alignment is based on the canonical active chain:

- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`

and the currently active runtime modules under `js/modules/*.js`.

The goal of this round is **not** to redesign the data model. It is to make Firestore Rules match the real active runtime so that current flows do not get blocked by governance cleanup.

---

## Current access model

### Admin-only operational collections

These collections are treated as teacher/admin data paths and are expected to require authenticated admin access:

- `students`
- `tag_tokens`
- `cards`
- `action_cards`
- `shop_catalog`
- `support_zone_records`
- `science_zone_records`

Why:

- They contain writable master records, token mappings, NFC/card binding state, or teacher-only operational logs.
- The current frontend already assumes `permission-denied` on these paths should be treated as a real admin-rights issue.

### Token-gated student read path

- `student_pages/{token}` is the canonical student token-mode read path.
- Students do **not** directly read `tag_tokens`.
- Validity is checked in Rules through `tag_tokens/{token}.active == true`.

Why:

- `js/main.entry.js` explicitly documents this model.
- Student flows already treat `student_pages/{token}` as the source of truth in token mode.

### Public summary / showcase collections

These collections are intentionally public-read, admin-write:

- `quiz_pool_public`
- `leaderboard_public`
- `shop_catalog_public`
- `legendary_bank`

Why:

- Student-facing views rely on them.
- The active runtime already treats them as the preferred public-facing layer and only falls back to master/admin collections in error paths.

### Admin verification collection

- `/admins/{uid}` is read by the frontend during admin verification.
- Self-read must be allowed for signed-in users checking their own allowlist doc.
- Writes stay restricted to custom-claim admins / console-side management.

---

## Special case: `quiz_bank`

`quiz_bank` is the one collection where the current runtime still needs a temporary compromise.

### Why it cannot be fully admin-only yet

The active Boss flow still reads `quiz_bank` directly for:

1. battle tower config doc: `_BATTLE_TOWER_BOSS_`
2. gatekeeper quiz doc by exact document ID

If Rules fully close `quiz_bank`, the Boss area can fail to load or a gatekeeper quiz can fail to render.

### Current compromise in `firestore.rules`

- `list/query` on `quiz_bank`: **admin only**
- exact `get` on `quiz_bank/{docId}`:
  - admin allowed
  - `_BATTLE_TOWER_BOSS_` allowed
  - active quiz docs (`isActive == true`) allowed

### Known trade-off

This means a client that already knows a specific active quiz doc ID can read that single doc.

That is broader than ideal, but it is the least disruptive alignment with the current architecture.

### Future hardening direction

A later hardening phase should move Boss public reads to a dedicated public collection such as:

- `battle_tower_public/{audience}`
- `battle_gatekeeper_public/{quizId}`

Once that exists, `quiz_bank` can go back to strict admin-only access.

---

## Collection-to-runtime map

| Collection | Runtime use | Expected rule |
|---|---|---|
| `admins` | admin verification | self get / admin list / claim-admin write |
| `students` | admin master record | admin only |
| `tag_tokens` | token map, reissue, validation backend path | admin only |
| `student_pages` | student token-mode source of truth | token-gated get, admin write |
| `cards` | NFC UID ↔ serial mapping | admin only |
| `action_cards` | forge/action-card binding | admin only |
| `quiz_bank` | admin quiz authoring + Boss config/gatekeeper exact get | admin list/write, limited get |
| `quiz_pool_public` | public quiz summary/preload | public read, admin write |
| `leaderboard_public` | student ranking summary | public read, admin write |
| `shop_catalog` | full shop admin catalog | admin only |
| `shop_catalog_public` | student shop showcase | public read, admin write |
| `legendary_bank` | student legendary board + admin publish/remove | public read, admin write |
| `support_zone_records` | teacher support zone | admin only |
| `science_zone_records` | teacher science zone | admin only |

---

## What this round does **not** claim

This alignment does **not** prove that production Rules are already deployed.

It only ensures that the repository now contains:

- an explicit `firestore.rules`
- a repository-side rules alignment note
- a deep-check script that keeps the rules file aligned with current active collection usage

Production still needs:

1. deploy the Rules
2. run teacher/admin smoke tests
3. run token-mode student smoke tests
4. verify Boss load / gatekeeper question / battle entry on the deployed project

---

## Recommended smoke order after Rules deploy

1. Admin login passes via custom claim or `/admins/{uid}`
2. Student token link can read `student_pages/{token}`
3. NFC init / reissue can write `students`, `cards`, `tag_tokens`, `student_pages`
4. Ranking / shop / quiz summary still render in student mode
5. Boss area can load battle tower config and gatekeeper quiz
6. Admin quiz / shop / legendary / zones screens remain writable

---

## Current stage

- Phase A: complete
- Phase B: complete
- Phase C: complete
- Phase D: complete
- Phase E-1: complete
- Phase E-2: complete
- **Phase E-3: this alignment round**

Next after this round:

- Phase E-4: final release governance re-audit
