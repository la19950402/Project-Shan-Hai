# SMOKE TEST ACTIVE CHAIN

## 範圍
這份 smoke test 只針對目前 canonical active chain：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- active runtime modules under `js/modules/*.js`
- `js/main.js` 不是 active entry，smoke 過程不要把它當成實際主程式

> 這是 **部署後人工 smoke test**。容器內的靜態檢查無法取代真實瀏覽器、Firebase、CDN、NFC/卡片掃描與 teacher/student 互動驗證。

## 前置條件
- 已完成 `DEPLOY_CHECKLIST.md` 的部署前腳本檢查。
- 部署目標可正常存取 Firebase 與靜態資源。
- 可登入老師端，且至少有一組可測學生資料／卡片／token。

## 建議執行順序

### 1. Boot / Login
- 開啟站點後，首頁能正常載入，沒有白屏或語法錯誤。
- 登入面板可操作，老師端可成功登入。
- `index.html` 實際載入的是 `js/bootstrap-entry.js?v=phase15phase129finalreleasegovernancereaudit`。

### 2. Teacher lookup / student load
- 用卡序查詢學生：能進入正確學生面板。
- 用 NTAG / 掃卡查詢：能解析到正確 serial。
- 同一學生重查，不會進入錯誤目標或空白 panel。
- 學生 mirror / target context 維持一致。

### 3. Student save chain
- 一般 admin save：能成功保存，重新載入後資料存在。
- fast-admin-save：能成功保存，鏡像資料同步正常。
- student token mode 保存：`student_pages/{token}` 能正確反映更新內容。
- 補發／綁卡／寫學生網址流程可完成，且 student page 可正常開啟。

### 4. Daily / Battle / Quiz route
- daily challenge 可以開始、答題、結算，不會卡在舊 session。
- battle / gatekeeper / BOSS 題目能正常載入。
- battle quiz route 不會退回舊的 direct quiz_bank 管理鏈。

### 5. Shop / Ranking / Public summary
- 學生商城可正常開啟。
- 一次購買流程可完成，數量與效果更新正常。
- leaderboard / ranking summary 可正常顯示。
- public summary / fallback 沒有明顯錯誤或空資料異常。

### 6. Collection / Display Team / Evolution
- collection 顯示區正常載入。
- `openDisplayTeamEditor()` UI 可開啟。
- `toggleDisplayTeamItem()` 後保存成功，重新整理仍維持。
- 進化相關規則（含 hidden egg / legendary rollover）沒有異常中斷。

### 7. Forge / Action-card / Teacher actions
- student prop 掃描與 action-card 流程可進入。
- forge / pending forge 掃描鏈可正常執行。
- voucher redeem 可成功落地，且老師端 mutation 流程沒有目標錯亂。

### 8. Batch / Auth / Admin diagnostics
- batch 模式 UI 可開啟。
- bulk progress modal 可打開並成功提交。
- auth 模組登入/登出/視圖切換正常。
- admin diagnostics / admin panel 的基本顯示正常。

## 最小必跑案例
如果部署時間很緊，至少跑以下 8 個案例：
1. 首頁 boot 成功
2. 老師端登入成功
3. 查卡序進學生頁成功
4. 一次 canonical save 成功
5. 一次 daily 或 battle 成功
6. 一次 shop 購買成功
7. 一次 display team 保存成功
8. 一次 forge 或 action-card 掃描鏈成功

## 失敗處理規則
- 若 boot / login 失敗：先停在 active chain 與部署快取檢查，不要直接改 archive。
- 若 student load / save 失敗：優先檢查 canonical save hub 與 student-access 邊界。
- 若 forge / collection / shop 失敗：先對照對應 phase deep-check 結果，再回看本輪變更。
- 若需要 rollback：依 `DEPLOY_CHECKLIST.md` 的回退規則執行。

## 建議紀錄格式
每次部署後至少記錄：
- 部署時間
- 環境（staging / production）
- 操作者
- 8 個最小案例是否通過
- 任何失敗案例的重現步驟與截圖/紀錄位置


## Rules alignment smoke

- `/admins/{uid}`：管理員登入後可完成 allowlist 驗證。
- `student_pages/{token}`：學生 token 連結可直接讀到頁面資料，停用 token 會被鎖定。
- `quiz_bank/_BATTLE_TOWER_BOSS_`：Boss 區塊可顯示。
- `quiz_bank/{gatekeeperQuizId}`：指定 gatekeeper 題可正常載入與作答。
- `quiz_pool_public` / `leaderboard_public` / `shop_catalog_public`：學生端摘要正常顯示。
- `shop_catalog` / `students` / `tag_tokens` / `cards`：管理端寫入仍正常。
