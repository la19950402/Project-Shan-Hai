# Phase 15.5.46 — Stability Gate + Phase 7 DOM Contract Start

## Why this stage was inserted
Before continuing the planned next phase, a focused audit of the latest active chain (`15.5.45`) found a semantic regression in `js/modules/quiz.js` introduced during the phase6 `this.*` cleanup.

The regression was not a syntax error, so `node --check` still passed, but runtime quiz flows could fail.

## What was wrong
### `js/modules/quiz.js`
- Non-string option normalization created a local `quizApi` object inside `map(...)` instead of returning an option record.
- Several internal method calls were converted away from `this.*`, but the replacement aliases were never safely initialized in runtime flow.
- `getQuizManagerElements()` / `hasQuizFormStructure()` were referenced without definitions.

These issues made the quiz module an unstable base for further work.

## What was changed
### 1. Added a shared DOM contract helper
New file:
- `js/core/dom-contract.js`

Helpers added:
- `getElementByIdSafe()`
- `pickElementsById()`
- `listMissingElementKeys()`
- `hasRequiredElementKeys()`
- `buildElementContract()`

### 2. Rebuilt `js/modules/quiz.js` to a stable API-object form
- Restored `const quizApi = { ... }` structure
- Replaced fragile internal calls with explicit `quizApi.method(...)`
- Fixed option normalization return path
- Implemented:
  - `getQuizManagerElements()`
  - `hasQuizFormStructure()`
- Added lightweight quiz DOM contract diagnostics to:
  - `currentState.quizDomContract`
  - `window.__BOOT_DIAG.quizDomContract`

### 3. Started Phase 7 on teacher-side modal/button DOM access
Updated:
- `js/modules/teacher-actions.js`

Changes:
- Uses shared DOM helper for:
  - action confirm/cancel buttons
  - forge start/cancel buttons
  - forge modal lookup
  - preview text lookup

## Why this is safer
- Does **not** change boot/auth chain
- Does **not** change HTML structure
- Does **not** add new globals
- Fixes a real runtime regression before building more changes on top of it
- Introduces DOM contract logic only in high-risk panels first

## Validation performed
- `node --check js/core/dom-contract.js`
- `node --check js/modules/quiz.js`
- `node --check js/modules/teacher-actions.js`
- `node --check js/main.entry.js`
- `node --check js/core/global-bridge.js`
- Confirmed required quiz and teacher DOM ids exist in `index.html`
- Re-checked active chain syntax remains clean

## Current assessment after this stage
### Stable enough to continue
- Active chain syntax remains clean
- Boot/auth files were not touched
- Quiz module semantic regression has been removed
- DOM contract phase has begun in a low-risk way

### Still the highest remaining structural risks
1. `js/main.entry.js` is still very heavy
2. `student.js` and `battle.js` still retain `this.*` usage
3. `secretPropTrigger` is still referenced in JS but has no DOM element
4. DOM contract coverage is only partial so far

## Recommended next stage
Continue **Phase 7** in a narrow, low-risk scope:
- extend DOM contract helpers to `shop.js`
- extend DOM contract helpers to `zones.js`
- add a small missing-element diagnostic summary for key admin/student panels

Do **not** touch boot/auth chain in that next step.
