# Phase 15.5.65 — main.entry UI / Shop Admin Convergence

## 本輪目標
在不碰 boot/auth 主鏈、不動老師端保存鏈與商城交易鏈的前提下，對 `js/main.entry.js` 做低風險收斂：

1. 系統級 UI modal / toast / confirm DOM 接線收斂
2. 商城管理面板 DOM 接線收斂
3. 全 active chain 再做一次靜態檢查，確認沒有把曾出過的錯帶回來

## 實際修改檔案
- `js/main.entry.js`
- `js/core/state.js`

## 修改內容
### 1. 新增 `getSystemUiDom()`
統一管理以下 DOM：
- `toast`
- `sysAlertTitle`
- `sysAlertMsg`
- `sysConfirmTitle`
- `sysConfirmMsg`
- `sysConfirmBtn`
- `sysCancelBtn`
- `enlargedImg`
- `enlargedTitle`
- `archiveTitle`
- `archiveImg`
- `archiveHoloText`
- `archivePrimaryActionBtn`
- `imageModal`
- `sysAlertModal`
- `sysConfirmModal`
- `adminView`

並同步寫入：
- `currentState.systemUiDomContract`
- `window.__BOOT_DIAG.systemUiDomContract`

### 2. UI object 改走 helper / bridge
以下方法已改成不直接散落使用 `document.getElementById(...)`：
- `UI.show`
- `UI.hide`
- `UI.hideModal`
- `UI.toast`
- `UI.alert`
- `UI.confirm`
- `UI.showImageModal`
- `UI.showArchiveModal`

其中：
- `show/hide/hideModal` 改走 `DomBridge.get(id)`
- `toast/alert/confirm/showImageModal/showArchiveModal` 改走 `getSystemUiDom()`

### 3. 新增 `getShopAdminDom()`
統一管理以下 DOM：
- `shopItemsContainer`
- `shopAdminHiddenEgg`
- `shopAdminEffect`
- `shopAdminHint`
- `shopAdminQty`
- `shopAdminName`
- `shopAdminCost`
- `shopAdminDesc`
- `shopAdminActive`
- `shopGiftTargetSeq`
- `shopGiftNote`
- `shopGiftAttrSelect`
- `shopGiftTargetInfo`
- `shopAdminCatalogPane`
- `shopAdminGiftPane`
- `shopAdminTabBtnCatalog`
- `shopAdminTabBtnGift`
- `shopGiftItemSelect`
- `shopGiftCatalogList`
- `shopAdminList`
- `shopAdminModal`

並同步寫入：
- `currentState.shopAdminDomContract`
- `window.__BOOT_DIAG.shopAdminDomContract`

### 4. 商城管理相關流程改走 helper
以下流程已改成透過 `getShopAdminDom()` 取 DOM：
- `renderShopItems`
- `populateHiddenEggSelect`
- `updateShopAdminFormState`
- `resetShopAdminForm`
- `resetShopGiftForm`
- `setShopAdminTab`
- `loadShopGiftOptions`
- `pickShopGiftItem`
- `fillShopGiftCurrentStudent`
- `lookupShopGiftTarget`
- `sendShopGift`
- `openShopAdmin`
- `loadShopAdminList`
- `editShopProduct`
- `saveShopProduct`

## 靜態檢查結果
### 語法檢查
- `node --check js/main.entry.js` ✅
- `node --check js/core/state.js` ✅

### canonical active chain 全鏈語法檢查
以下檔案全部通過：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

## 收斂成果
### `js/main.entry.js`
本輪前：
- `getElementById(...)` 約 **85**

本輪後：
- `getElementById(...)` 約 **23**

### 舊錯誤類型回查
本輪靜態檢查未重現：
- `Illegal return statement`
- 掛載鏈 parse/import blocker
- `this.setQuizBusy is not a function`
- `this.setShopAdminSaving is not a function`

## 風險控制
本輪 **沒有碰**：
- boot / auth 主鏈
- 老師端保存鏈
- 商城交易邏輯
- BOSS / battle 流程
- 學生端資料同步規則

## 誠實說明
本輪可以確認：
- 靜態上乾淨
- 沒有把初始化鏈寫壞
- `main.entry.js` 高風險 UI / 商城管理接線又收了一輪

但這裡仍然做不到瀏覽器 + Firebase 的完整實機驗證，因此不能宣稱所有互動路徑都已經真機覆蓋。
