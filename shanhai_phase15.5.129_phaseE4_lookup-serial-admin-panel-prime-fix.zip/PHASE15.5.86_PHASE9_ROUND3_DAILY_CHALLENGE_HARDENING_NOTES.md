# Phase 15.5.86 — Phase 9 Round 3 Daily Challenge Hardening

## 本輪目標
針對「每日挑戰 / 每日歷練」容易遇到的風險做專項硬化，避免以下常見情況造成無法開始、題目不跳出、或一題壞掉就整輪卡住：

1. 學生班級資料缺少年級，導致系統無法判斷抽題 audience。
2. quizPlayModal / questionText / optionsArea 等作答 DOM 尚未正確載入，卻先鎖定冷卻並進入流程。
3. 題池 timeout 後錯拿到別的 audience cache。
4. 題池混入壞題（缺題幹、缺選項、沒有正解），導致進場後直接報格式異常。
5. 啟動成功後 currentState.studentData 未同步到最新 last_practice_time，造成 timer / 按鈕狀態不穩。
6. render 時若剛好抽到壞題，整輪直接被中斷。

## 修改重點

### 1) 新增每日挑戰啟動上下文 helper
檔案：`js/main.entry.js`

新增：
- `getDailyQuestLaunchContext(studentData)`
- `isPlayableQuizQuestionRecord(questionRecord)`
- `buildDailyQuestQuestionSet(quizPool, options)`

用途：
- 集中解析年級 / audienceKey。
- 啟動前先篩掉缺題幹、缺足夠選項、沒有正解的壞題。
- 沒有 exact grade match 時，才回退到 active 題池。

### 2) 每日挑戰啟動前先做 quizPlay DOM preflight
檔案：`js/main.entry.js`

`startDailyQuest()` 現在在鎖定冷卻與 saveToDB 前，會先確認：
- `quizPlayModal`
- `modalContent`
- `questionText`
- `optionsArea`
- `quizPlayArea`
- `quizResultArea`

若缺失，直接提示「作答面板缺失」，避免先寫入 `last_practice_time` 卻因面板不存在而看起來像被卡住。

### 3) 年級缺失改成明確錯誤訊息
檔案：`js/main.entry.js`

原本碰到班級資料缺少年級時，會直接顯示不直觀的 modal。
現在改成明確 alert，提示需要先補上班級年級資訊。

### 4) 題池 timeout fallback 改成 audience-aware
檔案：`js/main.entry.js`

原本 timeout 後，可能只會回退到通用 `currentState.studentQuizPoolCache`。
現在會優先回退到：
- `currentState.studentQuizPoolCacheByAudience[dailyContext.audienceKey]`
- 若沒有，再退回 generic cache

這樣比較不會因為前一次載的是別的 audience，而把錯誤題池誤用在本次每日挑戰。

### 5) 啟動前先過濾壞題，啟動後再同步 currentState.studentData
檔案：`js/main.entry.js`

`startDailyQuest()` 現在：
- 先用 `buildDailyQuestQuestionSet()` 過濾壞題。
- 若題目不足，會明確指出是「沒有符合條件題目」還是「題目格式不完整」。
- `saveToDB()` 成功後，會把 `currentState.studentData = quizSession.dailyData`，讓 timer / 按鈕 / session 狀態一致。

### 6) renderQuizQuestion() 遇到壞題時先嘗試跳過
檔案：`js/main.entry.js`

`renderQuizQuestion()` 現在會：
- 若當前題不是 playable question record，先往後找下一題可作答的題目。
- 若找到，直接跳過壞題繼續。
- 若真的沒有可用題，才走原本的錯誤提示。

這樣單一壞題不會那麼容易把整輪每日挑戰直接打斷。

## 為什麼這樣修
這一輪不是要重寫每日挑戰，而是專門針對「最容易碰到、又最像啟動失敗」的風險做保守硬化：
- target audience 判斷錯
- DOM 還沒 ready
- 題池回退錯 audience
- 壞題混入題池
- 啟動成功但 UI / timer state 沒同步
- 單題格式錯拖垮整輪

## 驗證方式
- `node --check js/main.entry.js`
- 全部 `js/**/*.js` 再跑一輪 syntax check
- 結果：`83` 個 JS，`syntax_errors = 0`

## 新版本
- query tag：`phase15phase86phase9dailyhardening`
- build tag：`v15.5.86-phase9-daily-challenge-hardening-20260315`
- zip：`project-root-phase15.5.86-phase9-round3-daily-challenge-hardening.zip`

## 部署後建議優先驗證
1. 學生資料 class_name 缺少年級時，會出現明確提示，而不是直接卡住。
2. 題庫混入壞題時，每日挑戰仍能啟動可用題。
3. 若整池都只有壞題，會出現「題目格式不完整 / 題庫不足」提示。
4. 啟動後 timer 與按鈕狀態會正確反映冷卻。
5. 每日挑戰遇到單一壞題時，不應整輪直接黑掉。
