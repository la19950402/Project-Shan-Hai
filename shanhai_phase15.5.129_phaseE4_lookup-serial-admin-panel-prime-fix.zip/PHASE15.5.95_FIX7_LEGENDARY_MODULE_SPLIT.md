# Phase 15.5.95 Fix 7 — legendary module split

## 本輪目標
把仍留在 `js/main.entry.js` 的 `legendary_bank` 高風險查詢 / 寫入旁路抽離，讓主入口只保留委派，不再直接處理：

- `loadLegendaryAdmin()`
- `publishLegendary()`
- `deleteLegendary()`
- `loadActiveLegendariesForStudent()`
- `exchangeLegendary()`

## 主要修改

### 1. 新增 `js/modules/legendary.js`
集中處理：
- 研究站異獸管理讀取
- 異獸發布 / 移除
- 學生端異獸清單渲染
- 基因交換與 `exchangedCount` 回寫

### 2. `js/main.entry.js` 改成委派
主入口不再直接對 `legendary_bank` 執行：
- `getDocs(...)`
- `addDoc(...)`
- `deleteDoc(...)`
- `updateDoc(...)`

而是改為：
- `legendaryApi.loadLegendaryAdmin(...)`
- `legendaryApi.publishLegendary(...)`
- `legendaryApi.deleteLegendary(...)`
- `legendaryApi.loadActiveLegendariesForStudent(...)`
- `legendaryApi.exchangeLegendary(...)`

### 3. active version chain 升版
- `BOOT_ID`: `phase15phase95fix7legendarysplit`
- `BUILD_TAG`: `v15.5.95-fix7-legendary-module-split-20260315`

同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- `scripts/validate-active-chain.mjs`
- `scripts/deep-check-active-flow.mjs`

## 深度檢查結果
已通過：
- 全部 `js/**/*.js` syntax check
- `node scripts/validate-active-chain.mjs`
- `node scripts/deep-check-active-flow.mjs`

## 結果摘要
- `main.entry.js` 內 `getDocs(...)`：**21 -> 19**
- `main.entry.js` 內 `legendary_bank` 直接引用：**0**
- `legendary_bank` 改由 `js/modules/legendary.js` 統一承接

## 目前仍未結案
- `main.entry.js` 仍偏大
- 主入口內還有其他高成本查詢與管理端寫入未抽離
- `shop` 仍有模組 / 主入口雙軌痕跡，後續可繼續收斂
