# Phase 15.5.40 — Phase 1 Ready/Boot Guards

## 本輪目標
在不改動深層業務邏輯的前提下，補上第一階段的低風險防呆：

- 避免系統尚未初始化完成時，使用者誤觸高風險入口
- 讓 boot/readiness 狀態可被明確讀到
- 讓「按了沒反應」改成「有明確提示、且不繼續執行」

## 修改檔案
- `js/main.entry.js`
- `js/core/global-bridge.js`

## 修改內容
### 1. 為高風險入口加上方法級 ready guard
在 `main.entry.js` 新增 `__PHASE1_READY_GUARD_METHODS`，並在 façade 掛載完成後包裝以下方法：

- `enterBatchMode`
- `enterScanMode`
- `openAccountMgmt`
- `amLookupSerial`
- `amLoadReissue`
- `amStartReissue`
- `loadQuizBank`
- `openSupportZone`
- `openScienceZone`
- `openShopAdmin`
- `loadLegendaryAdmin`
- `openBattleTowerSetup`
- `openCardForge`
- `startCardForge`
- `prepareAction`
- `prepareActionFromButton`
- `commitAction`
- `forceDebuff`
- `startWebNfc`

當 `__bootState.ready !== true` 時，這些入口會：

- 停止繼續執行
- 顯示 `UI.toast('⏳ ... 系統仍在初始化中')`
- 同步更新 boot stage 為 `waiting-ready`

### 2. 新增 boot/readiness 診斷同步
在 `main.entry.js` 新增：

- `App.isSystemReady()`
- `App.getSystemReadyState()`
- `App.ensureSystemReady()`
- `__syncBootDiagnostics()`

同步輸出到：

- `window.__BOOT_DIAG.mainEntryStage`
- `window.__BOOT_DIAG.mainEntryDetail`
- `window.__BOOT_DIAG.mainEntryReady`
- `window.__BOOT_DIAG.mainEntryError`
- `window.__BOOT_DIAG.phase1ReadyGuardReport`
- `<html data-app-ready="0|1">`
- `<html data-app-stage="..."></html>`

### 3. 補 `forceOpenCardForge` 的 ready 判斷
在 `js/core/global-bridge.js` 中，若 `App.isSystemReady() === false`，
則鑄造道具卡入口直接提示並返回，不再進入 fallback 開窗流程。

## 驗證
已執行：

- `node --check js/main.entry.js`
- `node --check js/core/global-bridge.js`

## 這輪刻意沒動
- 老師端 target hydration / 保存鏈
- quiz/battle/shop 的深層業務邏輯
- `window.App / window.UI` 的收斂
- 歷史副本清理

## 下一步建議
下一輪可接著做：

1. 把 ready guard 的覆蓋範圍補到「題庫子操作 / 老師端高風險次級操作」
2. 為卡序查詢與 forge 補更具體的 hydration 診斷
3. 開始第二階段：老師端 target context 固化
