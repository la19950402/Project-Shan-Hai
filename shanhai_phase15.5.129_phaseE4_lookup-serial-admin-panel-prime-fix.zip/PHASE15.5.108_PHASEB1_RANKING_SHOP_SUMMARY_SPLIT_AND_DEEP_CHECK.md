# PHASE15.5.108 Phase B-1 — ranking / shop summary split + 深度檢查

## 本輪目標
把 `leaderboard_public` 與 `shop_catalog_public` 相關的 summary / fallback / showcase 責任，從 `js/main.entry.js` 收回 `js/modules/ranking.js` 與 `js/modules/shop.js`，讓主入口更接近純 orchestration。

## 本輪實際完成

### 1) ranking 模組正式承接 leaderboard summary 鏈
已將下列能力移入 `js/modules/ranking.js`：
- `getRankingDisplayItems`
- `getRankingLegendaryPoints`
- `buildLeaderboardSummaryData`
- `normalizeLeaderboardSummaryRecord`
- `loadLeaderboardSummary`
- `syncLeaderboardSummaryForSerial`
- `backfillLeaderboardSummaryEntries`
- `rankStudentsForBoard`
- `renderRankingRows`
- `warmRankingCache`
- `showRanking`

主入口現在改成 wrapper / 委派，不再自己執行 leaderboard summary 查詢、回填與榜單渲染 fallback。

### 2) shop 模組正式承接學生端商城 summary / showcase 鏈
已將下列能力移入 `js/modules/shop.js`：
- `normalizeStudentShopMode`
- `getStudentShopMode`
- `resolveStudentShopCardFooter`
- `buildStudentShopSummaryData`
- `normalizeStudentShopItem`
- `loadStudentShopCatalogSummary`
- `syncStudentShopCatalogSummaryForId`
- `removeStudentShopCatalogSummaryForId`
- `backfillStudentShopCatalogSummaryEntries`
- `renderStudentShopShowcaseCards`
- `warmStudentShopCatalog`
- `renderStudentShopShowcase`

另外也把 shop 模組內原本透過 App 回呼的 summary/showcase 依賴，改成直接呼叫 `shopApi` 自己的方法，避免循環委派。

### 3) main.entry.js 明顯降重
本輪前：
- `js/main.entry.js` 行數：`6745`
- `getDoc(...)`：`11`
- `getDocs(...)`：`5`
- `setDoc(...)`：`3`
- `query(...)`：`1`
- `collection(...)`：`6`

本輪後：
- `js/main.entry.js` 行數：`6149`
- `getDoc(...)`：`9`
- `getDocs(...)`：`1`
- `setDoc(...)`：`1`
- `query(...)`：`0`
- `collection(...)`：`2`

深檢摘要：
- `main_getDocs_count`: `1`
- `main_saveToDB_count`: `16`

這代表 leaderboard / shop public summary 的主要查詢與回填責任，已經不在主入口。

## 修改檔案
- `js/main.entry.js`
- `js/modules/ranking.js`
- `js/modules/shop.js`

## 驗證結果

### 語法檢查
通過：
- `js/main.entry.js`
- `js/modules/ranking.js`
- `js/modules/shop.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/student-access.js`
- `js/modules/legendary.js`
- `js/modules/zones.js`
- `js/modules/content-profile.js`
- `js/bootstrap-entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/state.js`
- `js/core/ui.js`

### active chain 檢查
通過：
- `scripts/validate-active-chain.mjs`
- `scripts/deep-check-active-flow.mjs`

active chain 仍維持：
- `BOOT_ID`: `phase15phase103fix15battlebossconfigsplit`
- `BUILD_TAG`: `v15.5.103-fix15-battle-boss-config-split-20260316`

## 額外深度檢查（本輪加做）

### A. wrapper 是否真的對到模組實作
檢查結果：
- ranking wrapper target exists: `true`
- shop wrapper target exists: `true`

### B. 主入口是否仍殘留 leaderboard / shop public 直接查詢
檢查結果：
- `main no direct leaderboard query`: `true`
- `main no direct shop public scan`: `true`

### C. 主入口是否仍殘留完整 fallback/render 內容塊
檢查結果：
- `main no direct ranking full render body`: `true`
- `main no direct shop showcase render body`: `true`

### D. 既有深檢指標
`deep-check-active-flow` 仍通過，且關鍵摘要顯示：
- `shop_module_split: true`
- `main_shop_delegates: true`
- `main_shop_student_flow_delegates: true`
- `quiz_module_split: true`
- `legendary_module_split: true`
- `main_getDocs_count: 1`

## 本輪沒有動的部分
- 沒有改 `BOOT_ID / BUILD_TAG`
- 沒有動 canonical active chain
- 沒有碰 batch / auth / forge / action_cards 高風險鏈

## 目前狀態判定
Phase A 結束後，student/token/save 主鏈已收出邊界；本輪完成後，Phase B 的 ranking / shop summary 主責也已開始真正回到模組。

目前 `js/main.entry.js` 已不再自己承接 leaderboard / shop public 的主要查詢與 fallback，主入口結構再往 orchestration 靠近一大步。

## 下一輪建議
最合理的下一輪是 **Phase B-2 / Phase C 準備段**：
1. 回掃 `main.entry.js` 剩餘 `getDoc/setDoc`，確認是否主要集中到 `cards / action_cards / forge`
2. 若確認集中，直接切入 `forge / action_cards / cards` 殘留旁路收斂
3. 若尚有零星 student/account 旁路，先做一輪小型補收再進 C
