# Phase 15.5.125 Hotfix - boot TDZ for delegatedSaveToDB

## Issue
Production boot failed during `main.entry.js` import with:

- `ReferenceError: Cannot access 'delegatedSaveToDB' before initialization`
- triggered while mounting modules that received `saveToDB: delegatedSaveToDB`

## Root cause
`delegatedSaveToDB` was defined as a `const` arrow function **after** multiple module mount calls:

- `createTeacherActionsModule(...)`
- `createBatchModule(...)`
- `createShopModule(...)`
- `createQuizModule(...)`
- `createContentProfileModule(...)`
- `createZonesModule(...)`

In ES modules, `const` is subject to TDZ. The binding existed but was not initialized yet when the object literals referenced it, so boot failed before app startup completed.

## Fix
Changed:

```js
const delegatedSaveToDB = (...args) => App.saveToDB(...args);
```

To:

```js
function delegatedSaveToDB(...args) { return App.saveToDB(...args); }
```

This preserves behavior while allowing safe pre-reference during module mount construction.

## Additional fix
Updated `scripts/deep-check-active-flow.mjs` so it accepts either:

- the old arrow-form bridge, or
- the new hoisted function-form bridge

This prevents a false-negative in governance checks.

## Validation
Passed:

- `node --check js/main.entry.js`
- `node --check scripts/deep-check-active-flow.mjs`
- `node scripts/validate-active-chain.mjs`
- `node scripts/deep-check-active-flow.mjs`
- `node scripts/deep-check-boss-flow.mjs`

## Impact
- fixes boot failure in production
- does not change BOOT_ID / BUILD_TAG
- does not change save behavior
- does not broaden runtime surface
