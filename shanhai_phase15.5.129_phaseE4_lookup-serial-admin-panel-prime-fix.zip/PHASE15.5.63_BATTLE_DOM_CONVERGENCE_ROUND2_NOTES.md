# Phase 15.5.63 - battle.js DOM convergence round 2

## Goal
Second-round low-risk convergence for `js/modules/battle.js`.

Focus:
- Do **not** touch boot/auth/main entry chains.
- Remove battle-module direct DOM coupling.
- Keep public API names unchanged.
- Re-run full active-chain syntax validation after patching.

## What changed

### 1. Added battle-local DOM contracts
Imported `buildElementContract` and added:
- `getBattleSelectionDom()`
- `getBattleArenaDom()`
- `getQuizPlayDom()`
- `getBattleTowerStudentDom()`
- `getBattleTowerAdminDom()`

These now centralize battle-related DOM lookups for:
- boss selection modal
- battle arena / settlement UI
- gatekeeper quiz modal
- student battle-tower panel
- admin battle-tower setup panel

### 2. Replaced battle module direct DOM lookups
Rewired battle flows to use the DOM contract helpers instead of scattered direct calls.
Touched areas include:
- `startBattleChallenge()`
- `selectBattleMon()`
- `confirmBattleSelection()`
- `prepareBattleArena()`
- `rollDice()`
- `showBattleSettlement()`
- `backToBattleResult()`
- `endBattle()`
- `checkBattleTowerStatus()`
- `populateBattleQuizOptions()`
- `updateBattleTowerAdminAudienceView()`
- `openBattleTowerSetup()`
- `publishBattleBoss()`
- `clearBattleBoss()`

### 3. Kept external behavior stable
No external battle API names were changed.
No HTML structure was changed.
No auth/bootstrap/main-entry wiring was changed.

## Resulting static risk reduction
`js/modules/battle.js` now has:
- `this.*` count: **0**
- `document.getElementById/querySelector/querySelectorAll` count: **0**

## Validation performed

### File-level syntax
- `node --check js/modules/battle.js`

### Full canonical active-chain syntax validation
Passed for:
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

### Manual spot checks
Re-checked for execution-risk areas after replacement:
- `prepareBattleArena()` local DOM alias usage
- `rollDice()` arena dice / result text scope
- `showBattleSettlement()` / `backToBattleResult()` scope
- `endBattle()` settlement/result/reward element access
- admin battle-tower setup error path indentation/scope

## Notes
This round is still a **static safety convergence** patch.
It does not claim full browser/Firebase runtime validation.
