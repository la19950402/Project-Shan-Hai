# 穩定性盤點與分階段修改建議（phase15.5.25）

## 盤點範圍
- 核心：`js/core/*.js`
- 模組：`js/modules/*.js`
- 入口：`index.html`、`js/bootstrap-entry*.js`、`js/main.entry*.js`

## 已盤點的分檔
### core
- `api-surface*.js`
- `app-facade*.js`
- `debug-flags.js`
- `firebase.js`
- `global-bridge.js`
- `state.js`
- `ui.js`

### modules
- `auth.js`
- `batch.js`
- `battle*.js`
- `content-profile.js`
- `quiz*.js`
- `ranking.js`
- `shop.js`
- `student.js`
- `teacher-actions.js`
- `zones.js`

### 入口檔
- `index.html`
- `bootstrap-entry*.js`（共 15 份）
- `main.entry*.js`（共 14 份）

## 高風險寫法
### A. 入口鏈平行副本過多
- `bootstrap-entry*.js` 15 份
- `main.entry*.js` 14 份
- 風險：修到其中一份卻沒有同步其餘副本，部署時容易混鏈或吃到舊快取。

### B. façade / helper 掛載缺漏
近期已實際爆過：
- `this.setQuizBusy is not a function`
- `this.setShopAdminSaving is not a function`

這代表模組已拆出，但 `App` façade 沒有完整暴露模組內部會用到的 helper。

### C. 模組以 `this.*` 交叉依賴過多
活躍主鏈中最明顯的高風險點：
- `battle.safeaudit5.js`：`this.updatePanel(...)`
- `battle.safeaudit5.js`：條件式使用 `this.getDailyResetAnchor(...)`
- `shop.js`：條件式使用 `this.isCatProfile(...)`、`this.addAttributeXP(...)`

這些方法若未被 base App 或 façade 完整提供，就會在執行期爆錯。

### D. 大量舊式 DOM 直取
高密度檔案：
- `battle*.js`：72 次 DOM 直取
- `zones.js`：46 次
- `shop.js`：45 次
- `teacher-actions.js`：33 次
- `quiz*.js`：31 次
- `student.js`：29 次
- `batch.js`：20 次

風險：某個 modal、input、button 少一個就可能在執行期直接炸掉。

### E. battle 模組責任過重
`battle.safeaudit5.js` 約 1007 行，已混合：
- Boss 入口
- 守門題
- 獎勵結算
- 每日重置
- 管理員設定

風險：任一小改動都容易波及學生端戰鬥。

## 合理可行的修改階段
### Phase 1：主鏈穩定化（低風險，先做）
目標：不改功能，只補齊活躍主鏈必需的 helper 與最明顯的 cross-call。
- 凍結一條 active chain
- 補齊 base App helper wrapper
- 修正 battle 內最直接的 cross-call

### Phase 2：高頻 runtime guard
目標：只補最常爆的 DOM 缺件點。
- shop / quiz / battle / zones
- 不改商業邏輯，只加 guard 與降級處理

### Phase 3：入口鏈收斂
目標：從多條 `bootstrap/main.entry` 收斂成單一正式主鏈 + 少量備援。
- 停止繼續複製新入口檔
- 明確標記 active / archive

### Phase 4：資料契約正規化
目標：統一 `quiz_bank`、Boss 設定、商城商品的欄位格式。
- 前端先 normalize
- 後續再逐步清資料

### Phase 5：battle / quiz / shop 深拆
目標：把 1000+ 行的 battle 與高耦合 helper 拆成 service + view 層。

## 本次已落地的 Phase 1 修改
1. 新增 active chain：`stability1`
2. `main.entry.stability1.js` 補上 base App helper：
   - `updatePanel`
   - `getDailyResetAnchor`
   - `isCatProfile`
   - `addAttributeXP`
3. `battle.stability1.js` 將 `this.updatePanel(...)` 改為 `UI.updatePanel(...)`

## 為什麼先做這一階段
因為近期連續爆的問題都不是資料庫本身，而是「拆檔後 helper 沒掛全」導致的執行期錯誤。
先補齊這一層，風險最低，也最能避免再出現 `this.xxx is not a function`。
