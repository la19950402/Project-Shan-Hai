# Phase 15.5.32 — Risk Reduction Phase 7

## 本輪目標
在不新增全域變數、不中斷 canonical active chain 的前提下，繼續消除 active 模組內高風險的 `this.*` 依賴。

## 本輪實際修改

### 1. teacher-actions.js
- 將模組回傳物件改為 `teacherApi` 常量，內部互相呼叫不再依賴 `this`。
- 新增 injected deps：
  - `saveToDB`
  - `processEvolution`
  - `checkDeathTrigger`
  - `isCurrentUserAdmin`
  - `normalizeSerial`
  - `applyDataMigration`
  - `refreshStudentIdentityLabels`
  - `refreshStudentRewardPanel`
  - `startWebNfc`
  - `backToDashboard`
  - `validateEvolutionTree`
- 目的：降低老師端手動加分、補發、狀態調整流程再次出現 `this.xxx is not a function` 的機率。

### 2. ranking.js
- 不再依賴 `this.applyDataMigration` / `this.computeTrainerProgress`。
- 改為由 `main.entry.js` 明確注入 helper。

### 3. content-profile.js
- 不再依賴 `this.normalizeSerial` / `this.getActiveTokenForSerial` / `this.applyDataMigration` / `this.saveToDB` / `this.refreshStudentRewardPanel`。
- 改為 injected deps + module-local API。

### 4. active chain 版本更新
- `index.html` → `bootstrap-entry.js?v=phase15phase7`
- `bootstrap-entry.js` → `BOOT_ID = phase15phase7`
- `main.entry.js` → `BUILD_TAG = v15.5.32-risk-reduction3-20260314`

### 5. active import chain 整理
- 將仍引用舊 query tag 的 active 檔案統一更新為 `phase15phase7`：
  - `js/modules/teacher-actions.js`
  - `js/modules/ranking.js`
  - `js/modules/content-profile.js`
  - `js/modules/batch.js`
  - `js/core/api-surface.js`

## 驗證結果
- 所有 `js/**/*.js` 已重新跑過語法檢查，全部通過。
- `teacher-actions.js` / `ranking.js` / `content-profile.js` 已清除 direct `this.*` 依賴。

## 下一階段建議
下一輪優先處理：
1. `batch.js`
2. `auth.js`
3. `student.js`

原因：
- 這三支仍保留最多 active `this.*` 流程轉接。
- 一旦 helper 掛載缺漏，最容易再次出現執行期錯誤。
