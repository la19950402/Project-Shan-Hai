# Phase 15.5.69 - Phase 8 Profile Visual Utils Extract

## 本輪目標
以最低風險方式，將 `main.entry.js` 中一批純 visual / profile display helper 抽離到獨立模組，持續替主入口減重，不碰 boot/auth、資料寫回、商城交易與老師端保存主鏈。

## 本輪新增
- `js/core/profile-visual-utils.js`

## 本輪從 `main.entry.js` 抽離的 helper
- `getCatVisual`
- `getProfileVisual`
- `getRadarLabelsForData`
- `buildCollectionDisplayItem`
- `getEggVisual`
- `getDragonVisual`
- `isDirectVisualSource`
- `splitBattleVisualRef`

## 整合方式
`main.entry.js` 保留同名薄 wrapper，內部轉呼叫：
- `getCatVisualCore`
- `getProfileVisualCore`
- `getRadarLabelsForDataCore`
- `buildCollectionDisplayItemCore`
- `getEggVisualCore`
- `getDragonVisualCore`
- `isDirectVisualSourceCore`
- `splitBattleVisualRefCore`

這樣可維持：
- 原有呼叫點不變
- 原有 module 注入不變
- 對外 API 名稱不變

## 風險控制
本輪未觸碰：
- `boot/auth` 主鏈
- 老師端保存鏈
- 商城交易鏈
- battle / student 對外 API
- AI 停用邏輯
- 學生商城展示區

## 驗證
已完成：
- `node --check js/core/profile-visual-utils.js`
- `node --check js/main.entry.js`
- canonical active chain 全鏈 `node --check`

## 本輪結果
- `main.entry.js` 行數：7654 -> 7561
- 新模組：`js/core/profile-visual-utils.js`
- 無重複 helper 定義殘留
- 無 import 名稱衝突
