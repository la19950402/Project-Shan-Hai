# Phase 15.5.28 Entry Convergence (Phase 4)

## Goal
Continue entry convergence without changing business logic.

## What changed
- Added explicit archive banners to historical `bootstrap-entry.*.js` and `main.entry.*.js` files.
- Added archive banners to historical core/module variants (`api-surface.*`, `app-facade.*`, `battle.*`, `quiz.*`, `shop.*`, `zones.*`).
- Updated `js/ENTRY_CHAIN_MANIFEST.json` to declare the canonical active chain and archived entry files.
- Added `js/MODULE_VARIANT_MANIFEST.json` to declare which module variants are active vs archived.

## Active chain (unchanged)
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`

## Active module variants
- `js/modules/battle.stability2.js`
- `js/modules/shop.stability2.js`
- `js/modules/quiz.stability2.js`
- `js/modules/zones.stability2.js`
- canonical modules: `auth.js`, `student.js`, `teacher-actions.js`, `batch.js`, `ranking.js`, `content-profile.js`

## Why this is safer
This phase reduces the risk of editing the wrong historical file during future hotfixes while keeping rollback/forensic capability.

## No runtime behavior change
This phase does not alter the active runtime logic; it only clarifies active vs archived files.

## Next recommended stage
- start converging active module variants back into canonical module filenames (`battle.js`, `quiz.js`, `shop.js`, `zones.js`)
- keep archive manifests updated while each convergence step lands
