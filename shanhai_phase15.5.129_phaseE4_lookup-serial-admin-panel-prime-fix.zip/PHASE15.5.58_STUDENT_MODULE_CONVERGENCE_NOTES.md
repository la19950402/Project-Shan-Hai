# Phase 15.5.58 — Student Module Convergence Round 1

## 目標
在不碰 boot/auth 主鏈、不改 HTML 結構的前提下，先收斂 `js/modules/student.js` 內最容易產生回歸的 `this.*` 依賴。

## 這次修改
只改：
- `js/modules/student.js`

### 核心做法
1. 將 `createStudentModule()` 由直接 `return { ... }` 改為：
   - 建立 `studentApi`
   - 補上 `callAppMethod()` / `callUiMethod()` / `callStudentMethod()`
   - 最後 `return studentApi`
2. 把模組內原本依賴 `this.*` 的呼叫改成顯式路徑：
   - 學生模組自有方法 → `callStudentMethod(...)`
   - App 方法 → `callAppMethod(...)`
   - UI 方法 → `callUiMethod(...)`
3. 補 `applyDataMigrationSafe()`，避免 migration helper 暫時缺失時直接炸掉。

### 這次收斂掉的 `this.*`
已移除的高風險依賴類型包括：
- `this.updateDragonImage`
- `this.updateCollectionGallery`
- `this.renderRadarChartRaw`
- `this.updateStatusContainer`
- `this.updateStudentAttributes`
- `this.updateDailyQuestTimer`
- `this.applyDataMigration`
- `this.mergeStudentRecords`
- `this.unlockStudentAccess`
- `this.saveToDB`
- `this.seedPreviewStudent`
- `this.lockStudentAccess`
- `this.buildPreviewStudentData`
- `this.refreshBaizeUi`
- `this.ensureBaizeHistory`

## 驗證
### 語法檢查
- `node --check js/modules/student.js`
- canonical active chain 全鏈 `node --check` 全數通過

### 靜態驗證
- `js/modules/student.js` 中 `this.*` 使用量：**0**
- `student.js` 依賴的 App / UI 方法，已對回 `js/main.entry.js` 確認存在：
  - `applyDataMigration`
  - `mergeStudentRecords`
  - `unlockStudentAccess`
  - `saveToDB`
  - `seedPreviewStudent`
  - `lockStudentAccess`
  - `buildPreviewStudentData`
  - `refreshBaizeUi`
  - `ensureBaizeHistory`
  - `updateDailyQuestTimer`

## 風險控制
這一輪**沒有碰**：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/modules/auth.js`
- `js/modules/battle.js`
- 任何 HTML 結構與 `onclick` 入口

## 目前狀態
這次是 `student.js` 的第一輪收斂，目標是先把最容易因 `this` 綁定而出錯的風險拔掉。
下一輪若要繼續收斂，最自然的順序會是：
1. `student.js` 的 direct DOM 依賴
2. `battle.js` 的 `this.*` 與 direct DOM 依賴
