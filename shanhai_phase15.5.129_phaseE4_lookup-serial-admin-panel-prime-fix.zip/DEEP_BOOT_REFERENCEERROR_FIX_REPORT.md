# 深度排查與修正報告：boot 階段 `attachEmergencyFlagGlobals is not defined`

## 結論
這次不是 Firestore、rules、AI 隱藏或資料鏈造成的 boot 失敗，而是 **第四階段注入 emergency guard 時，`shop.js` 與 `student.js` 新增了 `attachEmergencyFlagGlobals()` / `isEmergencyFlagEnabled()` / `guardLog()` 呼叫，但漏掉了對 `../core/emergency-flags.js` 的 import**。

因此模組被建立時：
- `createShopModule()` 先執行到 `attachEmergencyFlagGlobals()`
- 由於名稱未定義，直接拋出 `ReferenceError`
- 主程式 bootstrap 被中斷
- 後面的學生鏈、題庫鏈、Firestore 錯誤都來不及進一步驗證

## 實際證據
### 原始問題點
- `js/modules/shop.js`
  - 有 `attachEmergencyFlagGlobals();`
  - 有 `isEmergencyFlagEnabled(...)`
  - **沒有 import**
- `js/modules/student.js`
  - 有 `attachEmergencyFlagGlobals();`
  - 有 `isEmergencyFlagEnabled(...)`、`guardLog(...)`
  - **沒有 import**

### 已正確的對照檔
- `js/modules/quiz.js`：有 import
- `js/modules/ranking.js`：有 import
- `js/modules/student-access.js`：有 import

表示這不是 emergency-flags 檔本身不存在，而是 **兩個模組注入時漏補 import**。

## 本次修正
### 1. 修正 `js/modules/shop.js`
新增：
```js
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
```

### 2. 修正 `js/modules/student.js`
新增：
```js
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
```

## 驗證
已通過語法檢查：
- `node --check js/modules/shop.js`
- `node --check js/modules/student.js`

## 影響範圍
這次修正只處理 boot `ReferenceError`：
- 不改 Firestore 初始化
- 不改 rules
- 不改題庫邏輯
- 不改學生保存鏈

修完後，主程式至少不會再因 `attachEmergencyFlagGlobals` 未定義而在 `createShopModule()` 直接中斷。

## 下一步建議
修掉 boot 斷點後，再重新驗證：
1. 是否仍有新的 top-level `ReferenceError`
2. 學生進站是否恢復
3. 題庫是否仍是「有數量、無題目」
4. 若題庫仍失敗，再用前面補的：
   - `__printQuizPoolDiagnostics()`
   - `__auditQuizPoolSummaryHealth()`
   做精準定位
