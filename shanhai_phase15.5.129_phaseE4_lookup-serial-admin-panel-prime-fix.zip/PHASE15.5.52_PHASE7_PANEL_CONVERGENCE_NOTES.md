# Phase 15.5.52 — Phase 7 panel convergence (content profile + quiz panels)

## 本輪目標
在不碰 boot/auth 主鏈的前提下，繼續收斂 `main.entry.js` 內高風險面板的 DOM 接線，優先處理：

- 內容顯示設定面板（content profile form）
- 題庫管理面板（quiz manager）
- 每日歷練 / 修練作答與結算面板（quiz play/result）

## 修改檔案
- `js/main.entry.js`
- `js/core/state.js`

## 這次新增的 DOM contract
在 `main.entry.js` 新增：

- `getContentProfileDom()`
- `getQuizManagerDom()`
- `getQuizPlayDom()`

並在 `currentState` / `__BOOT_DIAG` 納入：

- `contentProfileDomContract`
- `quizManagerDomContract`
- `quizPlayDomContract`

## 內容設定面板收斂
將這些流程改為統一透過 `getContentProfileDom()` 取 DOM：

- `syncProfileForm()`
- `getProfilePayloadFromForm()`
- `quickApplyCatProfile()`
- `quickApplyShanhaiProfile()`

## 題庫管理面板收斂
將這些流程改為統一透過 `getQuizManagerDom()` 取 DOM：

- `resetQuizForm()`
- `fillQuizForm()`
- `readQuizFormData()`
- `importQuizBulk()`
- `updateQuizSelectionSummary()`
- `updateQuizFilterState()`
- `getFilteredQuizzes()`
- `renderQuizBankList()`
- `loadQuizBank()`
- `saveEditedQuiz()`

### 額外處理
`getQuizManagerDom()` 額外提供：

- `optionInputs`
- `correctInputs`
- `getCorrectInputByValue()`
- `getCheckedCorrectInput()`
- `modalContent`

避免題庫編輯表單仍依賴散落的 `querySelector`/`getElementById`。

## 修練作答 / 結算面板收斂
將這些流程改為統一透過 `getQuizPlayDom()` 取 DOM：

- `startDailyQuest()` 的 modal/title 取得
- `renderQuizQuestion()`
- `showQuizResult()`
- `claimQuizReward()`
- `selectQuizOption()` 內的 result desc 更新

## 驗證
### 1. targeted panel direct DOM 依賴清理
已確認 `main.entry.js` 中，以下 targeted ids 的 direct `document.getElementById(...)` 已清為 0：

- `profileSelect`
- `profileVariantSelect`
- `guideModeSelect`
- `guideModeLocked`
- `flagHideFantasy`
- `flagUseCatTheme`
- `flagSafeRandom`
- `qmFormTitle`
- `qmEditId`
- `qmSaveBtn`
- `qmCancelEditBtn`
- `qmGrade`
- `qmUnit`
- `qmQuestion`
- `qmOpt0~qmOpt3`
- `qmBulkImport`
- `qmSelectedCount`
- `qmSelectAll`
- `qmFilterGrade`
- `qmFilterUnit`
- `quizListContainer`
- `qmTotalCount`
- `quizPlayTitle`
- `quizPlayArea`
- `quizResultArea`
- `quizProgress`
- `quizQuestionText`
- `quizOptionsArea`
- `quizScoreText`
- `quizResultDesc`
- `quizRewardArea`
- `quizRewardAttr`
- `quizCloseBtn`

### 2. DOM id 對表
本輪納管的 required ids 已逐一對回 `index.html`，沒有缺件。

### 3. canonical active chain 語法檢查
已檢查：

- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

## 風險控制
本輪沒有改：

- `js/bootstrap-entry.js` 的 boot 流程
- `js/modules/auth.js`
- Firebase auth / login 綁定
- teacher target / save chain
- merge policy

這次只收斂面板接線層與診斷層，不擴大業務邏輯修改面。
