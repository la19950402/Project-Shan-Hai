# Phase 15.5.57 — 全面盤查後補修（曾漏類型低風險修補）

## 這次的目的
以 `project-root-phase15.5.56-ai-guide-disabled.zip` 為基底，重新盤查「以前真的出過錯」與「前一輪仍殘留的風險類型」，只做低風險補修，不碰 boot/auth 主鏈。

## 這次補修的漏類型

### 1. AI 區塊雖已 hidden，但仍可能透過殘留 UI 控件回寫設定
補修內容：
- `index.html`
  - `guideModeSelect` 改成 `disabled aria-disabled="true"`
  - `guideModeLocked` 改成 `disabled aria-disabled="true"`
  - `baizeGuideOpenBtn` / `baizeSendBtn` 改成 `disabled aria-disabled="true"`
- `js/main.entry.js`
  - `syncAiGuideFeatureUiState()` 會主動停用 guide button / send button / input / guide mode controls
  - 同步清空 chat history，避免 hidden modal 殘留互動內容

### 2. 內容設定表單在 AI 停用後，仍可能用 hidden/disabled 欄位覆寫 `guide_mode`
補修內容：
- `js/main.entry.js`
  - `getProfilePayloadFromForm()` 在 AI disabled 狀態下，改成保留 `currentState.studentData.guide_mode / guide_mode_locked`
  - `quickApplyCatProfile()` / `quickApplyShanhaiProfile()` 在 AI disabled 狀態下，不再改動 guide mode 控件
- `js/modules/content-profile.js`
  - 同步做相同保護，避免 module path 與 main entry path 行為不一致

### 3. AI 雖已 no-op，但 UI 還可能顯示可操作狀態
補修內容：
- `js/main.entry.js`
  - `syncAiGuideFeatureUiState()` 會將 status text 改為停用訊息
  - input placeholder 改為停用訊息
  - disabled button/title 統一顯示停用原因

## 這次沒有碰的部分
- `bootstrap-entry.js`
- `auth.js`
- teacher target/save chain
- merge policy
- battle / student 深層業務流程

## 驗證
### 語法檢查
- `js/main.entry.js`
- `js/modules/content-profile.js`
- `js/core/state.js`
- canonical active chain 17 個檔案全數 `node --check` 通過

### 靜態檢查
已確認：
- `#stuBaizeSection` 仍 hidden
- `#baizeModal` 仍 hidden
- `guideModeSelect` / `guideModeLocked` 已 disabled
- `baizeGuideOpenBtn` / `baizeSendBtn` 已 disabled
- `askBaizeViaServer()` 在 disabled 狀態下仍直接 no-op return
- profile payload 於 main entry / module 兩條路徑都會保留既有 `guide_mode`

## 產出
- `project-root-phase15.5.57-full-audit-missed-types-fix.zip`
