# Phase 15.5.92 Fix 4 — 移除制裁/撤銷功能與回歸檢查

## 本輪變更
- 移除 `index.html` 中 `App.punishHacker()` / `App.rollbackHacker()` 兩個按鈕。
- 保留異常警示 modal，但改為純提示用途，只提供關閉按鈕。
- 從 active `js/main.entry.js` 移除：
  - `async punishHacker()`
  - `async rollbackHacker()`
- 從 active `js/core/api-surface.js` 移除：
  - `punishHacker`
  - `rollbackHacker`
- `INDEX_HTML_INLINE_HANDLER_SUMMARY` 已同步更新為：
  - `total: 154`
  - `appCalls: 111`
- `js/core/state.js` 移除不再使用的 `hackerUid` active state 欄位。

## 版本
- `BOOT_ID`: `phase15phase92fix4removehacker`
- `BUILD_TAG`: `v15.5.92-fix4-remove-hacker-actions-recheck-20260315`

## 已完成檢查
1. 全部 `js/**/*.js` 語法檢查通過。
2. `scripts/validate-active-chain.mjs` 通過。
3. `scripts/deep-check-active-flow.mjs` 通過。
4. active chain 已確認不再包含：
   - `App.punishHacker()` inline handler
   - `App.rollbackHacker()` inline handler
   - `async punishHacker()` method
   - `async rollbackHacker()` method
   - `api-surface` 對兩者的 direct method 要求

## 補充判讀
- 舊歷史副本檔仍可搜尋到 `punishHacker` / `rollbackHacker`，但它們不在 active chain 中。
- 目前 active `main.entry.js` 仍有 21 個 `getDocs(...)` 與 21 個 `saveToDB(...)`，這是結構債，非本輪新增問題。

## 建議實測
- 觸發異常警示時，modal 可正常顯示目標與異常能量資訊。
- modal 只剩提示與關閉，不再出現制裁/撤銷按鈕。
- 其他老師端保存功能（贈禮、兌現）仍可正常使用。
