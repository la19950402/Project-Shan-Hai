# Phase 15.5.68 - Phase 8 profile/state utils extract

## 本輪目標
以最低風險方式，繼續替 `js/main.entry.js` 減重；只抽離純資料/純五行狀態 helper，不碰 boot/auth 主鏈、不改外部 API 名稱。

## 新增檔案
- `js/core/profile-state-utils.js`

## 抽離出去的 helper
- `getStudentTeamPanelKeyFromData`
- `getActionPanelConfigForData`
- `getMaxElementFromAttributes`
- `inferElementKeyFromText`
- `ensureAttributeFirstGainOrder`
- `markAttributeGain`
- `addAttributeXP`
- `getDominantElementFromData`

## main.entry.js 的變更方式
- 改成 import `profile-state-utils.js`
- 保留既有本地名稱（例如 `addAttributeXP`、`getDominantElementFromData`），但改成薄 wrapper / alias，避免改動外部注入與既有呼叫點
- 未改動任何 boot/auth 流程與 façade 名稱

## 結果
- `js/main.entry.js` 行數：7746 -> 7653
- 新增 `js/core/profile-state-utils.js`：106 行
- canonical active chain 全鏈 `node --check` 通過

## 風險控制
- 未碰：boot/auth 主鏈、老師端保存鏈、商城交易鏈、battle/student 對外 API
- 抽離的都是純資料/純狀態 helper
- 舊錯誤類型（parse/import blocker、quiz/shop 的 this helper 缺失）未重現
