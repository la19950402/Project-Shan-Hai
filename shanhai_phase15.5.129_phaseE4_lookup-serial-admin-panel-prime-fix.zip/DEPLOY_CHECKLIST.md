# DEPLOY CHECKLIST

## 目的
這份清單只針對目前 **canonical active chain** 的部署治理，避免再回到「修了歷史副本、卻沒有修到真正 runtime」的狀態。

## Canonical active chain
- `BOOT_ID`: `phase15phase129finalreleasegovernancereaudit`
- `BUILD_TAG`: `v15.5.129-final-release-governance-reaudit-20260316`
- `index.html` → `js/bootstrap-entry.js?v=phase15phase129finalreleasegovernancereaudit`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`

## 操作原則
1. 只修 active chain，不先修 archive。
2. `archive/variants/` 與 `archive/backups/` 只用於 rollback / forensics。
3. 不新增新的 `js/main.entry.*`、`js/bootstrap-entry.*`、`js/core/*.stability*`、`js/modules/*.safeaudit*` 類變體。
4. 部署前一定先跑靜態檢查；部署後一定照 `SMOKE_TEST_ACTIVE_CHAIN.md` 做人工 smoke。

## 部署前必要檢查（固定順序）
在專案根目錄執行：

### 1. Active chain 與 build tag 對齊
```bash
node scripts/validate-active-chain.mjs
```
預期：輸出 `ACTIVE_CHAIN_VALIDATION_OK`。

### 2. 主鏈深檢
```bash
node scripts/deep-check-active-flow.mjs
```
預期：輸出 `DEEP_CHECK_OK`。

### 3. Phase C 邊界深檢
```bash
node scripts/deep-check-phasec-collection-boundaries.mjs
node scripts/deep-check-phasec-evolution-boundaries.mjs
node scripts/deep-check-phasec-collection-editor-boundaries.mjs
node scripts/deep-check-phasec-forge-actioncard-boundaries.mjs
node scripts/deep-check-phasec-save-hub-boundaries.mjs
```
預期：全部輸出 `..._OK`。

### 4. Phase D legacy 依賴深檢
```bash
node scripts/deep-check-phased-auth-legacy-deps.mjs
node scripts/deep-check-phased-student-legacy-deps.mjs
node scripts/deep-check-phased-legacy-reaudit.mjs
```
預期：全部輸出 `..._OK`。

### 5. Phase E 治理深檢
```bash
node scripts/deep-check-phasee-archive-governance.mjs
node scripts/deep-check-phasee-deploy-governance.mjs
node scripts/deep-check-phasee-final-release-governance.mjs
```
預期：全部輸出 `..._OK`。

## 部署前人工確認
- `js/main.js` 仍留在工作區，但不是 active entry；不得把它當成部署入口或修復目標。
- `js/` 工作區沒有新的 inactive variant leak。
- `archive/variants/` 與 `archive/backups/` 沒被誤當成 active 檔案修改。
- 本輪變更若涉及 UI / teacher save / student load，已預先規劃 smoke case。
- 本輪若只有治理/文件變更，仍要確認 active chain 與 smoke docs 沒失配。

## 部署步驟
1. 以目前 canonical active chain 打包／發布。
2. 確認部署目標引用的是 `index.html` 內的 active bootstrap 路徑，而不是 archive 檔案。
3. 發布後立即開站，先做 boot/login 可用性確認。
4. 依 `SMOKE_TEST_ACTIVE_CHAIN.md` 執行最小 smoke test。
5. 將 smoke 結果記錄到本輪 deploy 記錄或報告。

## 部署後最小驗收
最小驗收至少要覆蓋：
- boot / login
- teacher lookup / student load
- canonical save path
- daily / battle
- shop / ranking public summary
- collection editor / forge / action-card
- batch / auth 基本入口

## 回退規則
1. 回退前先確認問題是否真的是 active chain，而不是部署環境快取或外部設定。
2. 若需要 rollback，先查看：
   - `js/ENTRY_CHAIN_MANIFEST.json`
   - `js/MODULE_VARIANT_MANIFEST.json`
   - `archive/README.md`
   - `ARCHIVE_VARIANT_GOVERNANCE.md`
3. 不直接在 archive 檔案上熱修；應明確 restore 到 active chain，再重跑所有部署前檢查。
4. rollback 完成後，仍需重新執行本 checklist 與 `SMOKE_TEST_ACTIVE_CHAIN.md`。

## 本輪結束判定
只有在以下條件都成立時，才算 deploy governance 過關：
- active chain validation 通過
- deep-check-active-flow 通過
- Phase C / D / E 治理 deep-check 全通過
- 部署後 smoke test 已執行且結果可追蹤


- 確認 `firestore.rules` 已與 `FIRESTORE_RULES_ALIGNMENT.md` 對齊，並完成 Rules 部署。
- 若本次部署包含權限調整，先驗證 `/admins/{uid}`、`student_pages/{token}`、Boss gatekeeper 題與 public summary collections。
