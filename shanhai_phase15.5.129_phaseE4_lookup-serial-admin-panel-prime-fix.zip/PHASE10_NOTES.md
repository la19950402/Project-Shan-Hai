# Phase 10 — teacher-actions

## 新增檔案
- `js/modules/teacher-actions.js`
- `js/core/state.js`
- `js/core/ui.js`

## 掛載方式（相容舊 HTML）
`main.js` 會在建立 `App` 後執行：

```js
teacherActionsApi = createTeacherActionsModule({...});
App.prepareAction = teacherActionsApi.prepareAction.bind(App);
App.commitAction = teacherActionsApi.commitAction.bind(App);
App.openCardForge = teacherActionsApi.openCardForge.bind(App);
App.applyTeacherCompensation = teacherActionsApi.applyTeacherCompensation.bind(App);
window.App = App;
```

因此既有 `onclick="App.xxx()"` 無需改寫。

## 狀態 / UI 解耦
- `teacher-actions.js` 明確 `import { currentState } from "../core/state.js"`
- `teacher-actions.js` 明確 `import { UI } from "../core/ui.js"`
- 其餘仍需要沿用主檔能力（如 `saveToDB`, `processEvolution`, `startWebNfc`）則透過 `this`（綁定到 `App`）呼叫。
