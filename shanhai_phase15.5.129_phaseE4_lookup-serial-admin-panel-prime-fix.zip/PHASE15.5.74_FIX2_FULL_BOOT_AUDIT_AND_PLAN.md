# Phase 15.5.74 Fix2：完整開啟失敗盤查與後續計畫

## 結論
這一輪不是只補單點，而是依照「以前真的犯過的錯」逐類盤查 active chain，並補上兩個最接近開啟失敗的來源：

1. **`file://` 直接開啟時，`bootstrap-entry.js` 先做 `fetch(main.entry.js)`，在某些瀏覽器/環境會直接卡死或被擋。**
2. **active chain 的版本識別與 cache busting 需要整體對齊，避免修好後仍混吃舊模組。**

本次已產出 `fix2`，重點是：
- 新增 `file://` 條件下的 bootstrap 直接 import fallback
- 對開啟失敗訊息補上可執行診斷提示（file protocol / 動態模組下載失敗 / Firebase CDN 受阻 / 外掛攔截）
- 將 active chain 全面對齊到 `phase15phase74fix2`

---

## 一、依照過往錯誤型態逐類盤查

### A. 語法 / parse 級錯誤
過往已真實出現過：
- `Illegal return statement`
- 多一個 `}`
- 重複宣告 / 括號不平衡
- 模組抽離後留下語法殘骸

本次檢查：
- 對 `js/` 下 **83 個 `.js` 檔** 全數執行 `node --check`

結果：
- **0 個 syntax error**

---

### B. active chain 修錯檔 / 又吃到歷史副本
過往風險：
- 改到 `safeaudit` / `stability` / `quizbanksafe` / `bossrepair` 之類歷史副本
- `index.html`、`bootstrap-entry.js`、`main.entry.js` 不一致

本次檢查：
- `index.html` script 入口
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- active import graph 是否仍指向 canonical

結果：
- active chain 仍是 canonical
- active import graph 共 **26 個檔案**，全部可解析，無遺失 import target
- 未發現 active chain 改吃歷史副本

---

### C. 抽 helper 後漏掛 / 缺函式 ReferenceError
過往已真實出現過：
- profile / visual / battle / quiz helper 抽出去後，主鏈仍直接呼叫舊函式名
- 模組初始化時直接 `ReferenceError`

本次複查重點：
- `main.entry.js` 的 profile / visual / reward / battle config / asset fallback 抽離區
- `createStudentModule` 的 `Chart` 注入
- `battle` / `quiz` / `shop` / `zones` canonical 依賴

結果：
- `fix1` 補回的 helper 仍在
- `quiz-battle-config-utils` 已確實接回 active main entry
- `Chart` 已改為安全注入，不再裸用全域 `Chart`
- active canonical modules 未重新擴散 `this.xxx()` 依賴

---

### D. DOM contract 缺口
過往風險：
- JS 以為某個 `id` 存在，HTML 實際不存在
- 頁面一開就因 `null.xxx` 或 UI contract 缺口中斷

本次檢查：
- 解析 `main.entry.js` / `battle.js` / `quiz.js` / `shop.js` / `zones.js` 裡所有 `buildElementContract(...)`
- 對照 `index.html` 的所有 `id`

結果：
- `index.html` 共檢出 **367 個 id**
- 所有 active contract 的 **required ids = 0 missing**

---

### E. 版本 query / build tag 混版
過往風險：
- 入口已是新版本，但內部 import query 還停在舊版
- 造成 bootstrap、main entry、module cache 混吃

本次處理：
- 將 active canonical chain 全面對齊到：
  - `phase15phase74fix2`
  - `v15.5.74-fix2-full-boot-audit-and-file-protocol-fallback-20260315`

同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- 所有 active canonical core/modules import query

結果：
- active chain 版本識別已整體一致

---

### F. `file://` 直接開啟造成 bootstrap 失敗
這是本次最值得補的真實風險之一。

原本狀況：
- `bootstrap-entry.js` 會先 `fetch(main.entry.js)` 做驗證
- 若使用者直接雙擊 `index.html`，在某些瀏覽器 / 環境下，`fetch(file://...)` 可能直接失敗
- 這會導致主程式還沒開始，就先卡在 bootstrap

本次修補：
- 新增 **`window.location.protocol === 'file:'`** 時的直接 import fallback
- 並在 boot panel 顯示明確提示：
  - 目前以 `file://` 開啟
  - 若仍失敗，改用本機伺服器或正式 HTTPS 網址

這一點能直接降低「雙擊 HTML 就打不開」的機率。

---

### G. 外部依賴 / Firebase CDN 受阻
此專案 active chain 仍依賴：
- `https://www.gstatic.com/firebasejs/...`

這代表若使用者環境出現以下狀況，仍可能造成開啟失敗：
- 公司/校園網路擋 gstatic
- 隱私外掛 / ad blocker 攔截 module script
- HTTPS / MIME / CSP / proxy 問題

本次補強：
- `bootstrap-entry.js` 的 fatal message 新增分類提示：
  - file protocol
  - 動態模組下載失敗
  - Firebase CDN 受阻
  - 外掛攔截 (`blocked by client`)

這不是把 Firebase 改成本地 vendor，但能把「打不開」從黑箱，變成可定位的錯誤訊息。

---

## 二、本次 fix2 實際修改內容

### 1. `js/bootstrap-entry.js`
- 新增 `classifyBootHint(...)`
- `showFatal(...)` 補上分類提示
- `startBoot()` 新增 `file://` 直接 import fallback
- 保留原本 HTTP/HTTPS 的 verified fetch + marker validation

### 2. active chain 版本對齊
已將 active canonical 檔案內的 query/tag 全面更新為 `fix2`：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/core/*.js` canonical
- `js/modules/*.js` canonical

---

## 三、這次實際跑過的檢查

### 已完成的機械檢查
1. **83 個 JS 檔 `node --check` 全過**
2. **active import graph 26 檔全部存在**
3. **active DOM contract required ids = 0 missing**
4. **active chain query / build tag 全部對齊 fix2**
5. **canonical active modules 無新增 `this.xxx()` 呼叫擴散**
6. **`Chart` 注入路徑仍安全**
7. **`NDEFReader` 使用點仍有環境守衛**

### 受環境限制、無法在此容器完成的檢查
原本嘗試用 headless Chromium 做真實開頁 smoke test，但此容器的 Chromium 會把：
- `127.0.0.1`
- `file://`

都直接攔成 **`ERR_BLOCKED_BY_ADMINISTRATOR`**，因此無法在這個沙盒內完成真瀏覽器載入驗證。

所以這次能誠實確認的是：
- 靜態結構、syntax、DOM contract、import graph、cache busting、bootstrap file protocol 風險都已處理

但仍需要在你的實際部署環境做最後 smoke test。

---

## 四、建議你立刻做的 smoke test（按順序）

### P0：確認真的能開
1. 開首頁
2. 確認 boot panel 不會永遠停住
3. 看 console 是否仍有：
   - `ReferenceError`
   - `Failed to fetch dynamically imported module`
   - `firebasejs` / `gstatic` 載入失敗
4. 檢查：
   - `typeof window.App`
   - `typeof window.App?.bindAuthControls`
   - `typeof window.UI`

### P1：登入與主鏈
5. 管理者登入
6. 確認 login panel 消失、dashboard 可進
7. 老師端查卡序 → 進學生頁

### P2：高風險主流程
8. 老師端手動加分
9. 老師端移除狀態
10. 題庫管理可載入
11. 每日歷練可進
12. BOSS 可挑戰
13. 商城管理可開
14. 排行榜可顯示
15. 專區可開

---

## 五、之後可執行的優化方向與計畫（詳細且可落地）

以下按**先穩定、再收斂、最後才優化**排序。

### Phase 0：部署穩定與驗證固化（優先級 A）
**目標：** 讓每次改版都能快速確認是不是 boot blocker。

#### 任務
1. 建一份固定 smoke test checklist
   - 首頁開啟
   - boot panel 消失
   - `window.App` / `bindAuthControls`
   - login
   - teacher lookup / add score / remove status
   - quiz / boss / shop / ranking / zones

2. 固定輸出 boot diagnostics
   - `bootId`
   - `buildTag`
   - `importMode`
   - `targetUrl`
   - `stage`
   - `error`

3. 建部署前檢查腳本
   - syntax check
   - active import graph existence
   - DOM contract check
   - active version alignment

#### 產出
- `scripts/check-active-chain.mjs`
- `SMOKE_TEST_PHASE15_ACTIVE.md`
- `DEPLOY_CHECKLIST.md`

---

### Phase 1：持續把 `main.entry.js` 減重，但只抽純 helper（優先級 A）
**目標：** 繼續減少 `main.entry.js` 體積，但不碰 boot/auth/save 主鏈。

#### 可安全抽離的區塊
1. 學生商城 preview mode helper
2. DOM accessor helper
3. 顯示文字 / profile label mapping
4. 非寫回類 UI formatter

#### 原則
- 只抽純函式
- 不動對外 API 名稱
- 不新增全域
- 抽完立刻過 syntax + smoke

#### 產出
- `js/core/student-shop-mode-utils.js`
- `js/core/dom-safe-ui-utils.js`
- `js/core/profile-label-render-utils.js`

---

### Phase 2：老師端保存鏈第二輪顯式化（優先級 A）
**目標：** 這是最需要穩的鏈，先把 target hydration / save path 全部顯式化。

#### 任務
1. 將 teacher target 解析集中成單一 helper
   - `resolveTeacherTarget()`
   - 明確輸出 `serial / uid / token / source`

2. 將保存前檢查集中
   - `assertTeacherTargetReady()`
   - `assertStudentDataLoaded()`

3. 所有老師端動作統一走同一條保存鏈
   - prepare
   - resolve target
   - validate
   - save
   - refresh current state

#### 產出
- `js/core/teacher-target-utils.js`
- `js/core/teacher-save-guard.js`
- `TEACHER_SAVE_CHAIN_AUDIT.md`

---

### Phase 3：題庫 / BOSS 共用資料鏈整理（優先級 B）
**目標：** 避免 quiz 與 boss 再互相污染。

#### 任務
1. 集中 quiz bank normalize
2. 明確區分：
   - 題庫原始 doc
   - admin view model
   - boss playable question model
3. 對壞資料建立 fallback policy
   - 題目缺欄位
   - grade token 混亂
   - options / answer 異格式

#### 產出
- `js/core/quiz-bank-normalize.js`
- `js/core/boss-question-adapter.js`
- `QUIZ_BOSS_SCHEMA_CONTRACT.md`

---

### Phase 4：商城資料鏈正式化（優先級 B）
**目標：** 現在只有學生展示模式骨架，下一步是把資料形狀與模式切換先定乾淨。

#### 任務
1. 定義 shop item schema
   - built-in
   - firestore custom item
   - hidden egg item
2. 定義 student shop mode
   - `preview`
   - `request_only`
   - `direct`
3. 讓老師端管理 / 學生端顯示共用同一份 normalize 結果

#### 產出
- `js/core/shop-item-normalize.js`
- `js/core/shop-mode-policy.js`
- `SHOP_MODE_ROADMAP.md`

---

### Phase 5：外部依賴穩定化（優先級 B）
**目標：** 降低「環境不同就打不開」的機率。

#### 任務
1. 明確列出所有外部依賴
   - Firebase CDN
   - Chart
   - Web NFC
2. 為每種依賴做 degraded mode
   - Firebase fail → 顯示明確 diagnostics
   - Chart fail → 略過圖表，但頁面可開
   - NDEF fail → 功能退化，但不阻斷 boot
3. 評估是否需要之後將關鍵 CDN 轉成本地靜態鏡像（不是現在立刻做）

#### 產出
- `EXTERNAL_DEPENDENCY_MATRIX.md`
- `DEGRADED_MODE_POLICY.md`

---

## 六、這一版之後的判準
只有在下列都成立時，才算真正過關：

1. 首頁可開
2. boot panel 不常駐
3. 登入可用
4. 老師查卡序 / 手動加分 / 移除狀態穩定
5. 題庫管理可載入
6. BOSS 可挑戰
7. 商城 / 排行榜 / 專區都能進
8. console 沒有新的 boot blocker

若只做到 syntax 過，但 boot 還會卡，就不能算完成。
