# Phase 15.5.27 Entry Convergence (Phase 3)

## Goal
Reduce active entry risk without deleting historical recovery files.

## What changed
- `index.html` now points back to canonical `js/bootstrap-entry.js?v=phase15entryconverge1`
- `js/bootstrap-entry.js` is now the active bootstrap and targets `js/main.entry.js`
- `js/main.entry.js` is now the active main entry, based on the stable Phase 2 chain
- `js/core/app-facade.js` is restored as the active canonical facade file
- `js/core/api-surface.js` is restored as the active canonical surface policy file

## Active chain
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`

## Intentionally left in place
Historical files such as `bootstrap-entry.*.js` and `main.entry.*.js` remain in the repo for rollback / forensics, but are no longer the active chain.

## Why this is safer
This reduces the chance that a future hotfix edits the wrong active entry file.

## Next recommended stage
- mark legacy entry files as archived in a manifest
- gradually converge active module variants (`battle`, `quiz`, `shop`, `zones`)
- after smoke test passes, stop adding new `main.entry.*` files unless rollback is required
