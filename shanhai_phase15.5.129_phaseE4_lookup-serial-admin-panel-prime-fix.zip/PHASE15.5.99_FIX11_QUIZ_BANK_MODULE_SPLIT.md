# Phase 15.5.99 Fix 11 — Quiz Bank Module Split

## 本輪目標
把 `main.entry.js` 中仍殘留的 `quiz_bank` 題庫管理主線外移，優先收斂：

- 題庫單筆讀取 / 編輯
- 匯入 / 匯出
- 批次上下架 / 批次刪除
- 題庫管理載入 / 新增 / 修改 / 刪除 / 狀態切換

## 本輪實作

### 1. `main.entry.js` 改為薄委派
以下方法已改為委派到 `quizApi`：

- `openEditQuiz()`
- `importQuizBulk()`
- `exportQuizBank()`
- `batchSetQuizActive()`
- `batchDeleteSelectedQuizzes()`
- `loadQuizBank()`
- `saveNewQuiz()`
- `saveEditedQuiz()`
- `deleteQuiz()`
- `toggleQuizActive()`

### 2. `js/modules/quiz.js` 正式接手題庫管理資料鏈
已補上並正式承接：

- `importQuizBulk()`
- `exportQuizBank(format)`
- `batchSetQuizActive(active)`
- `batchDeleteSelectedQuizzes()`
- `loadQuizBank()`
- `saveNewQuiz()`
- `saveEditedQuiz()`
- `deleteQuiz(id)`
- `toggleQuizActive(id, currentStatus)`

### 3. 題圖欄位與表單行為對齊
`quiz` 模組現在會透過 active 主鏈傳入的 helper 對齊既有 UI 行為：

- `getQuizManagerDom`
- `resolveQuizImageMeta`
- `updateQuizImagePreview`
- `downloadCsvFile`
- `downloadTextFile`
- `scheduleQuizPoolSummaryRefresh`

因此題圖 `imageUrl / imageAssetKey / imageAlt`、表單預覽、匯出檔案格式、summary refresh 都與 active 主鏈一致。

### 4. Active version 升級
- `BOOT_ID`: `phase15phase99fix11quizbanksplit`
- `BUILD_TAG`: `v15.5.99-fix11-quiz-bank-module-split-20260315`

## 深度檢查結果

### 版本鏈
- `index.html` 對齊新版 bootstrap query tag
- `bootstrap-entry.js` 對齊新版 `BOOT_ID`
- `main.entry.js` 對齊新版 `BUILD_TAG`
- `ENTRY_CHAIN_MANIFEST.json` 對齊 active chain

### 語法 / 解析
- 全部 `js/**/*.js` syntax check：通過
- `node scripts/validate-active-chain.mjs`：通過
- `node scripts/deep-check-active-flow.mjs`：通過

### 結構收斂成果
- `main.entry.js` 內 `getDocs(...)`：**16 → 14**
- `main.entry.js` 內已不再直接執行題庫管理鏈的：
  - `addDoc(collection(db, 'quiz_bank'), newQuiz)`
  - `updateDoc(doc(db, 'quiz_bank', editId), ...)`
  - `deleteDoc(doc(db, 'quiz_bank', id))`
  - `writeBatch(db)` 題庫批次上下架 / 刪除
- 題庫管理 CRUD / 匯入匯出 / 批次操作已集中到 `js/modules/quiz.js`

## 目前仍未收完的主線
這輪後，`quiz_bank` 在 `main.entry.js` 仍保留的直接引用，主要屬於：

- daily / battle / quiz pool 取題
- 題庫摘要 / public 路線 fallback
- BOSS / battle 特定題讀取

也就是說：

**這輪已收掉「題庫管理主線」，但「作答 / 題池 / summary 讀取主線」還沒完全外移。**

## 下一輪建議
最合理的下一輪是：

**把 `quiz_bank` 的非管理查詢路徑繼續分流，優先處理 quiz pool / battle / daily 的直接全抓 fallback。**
