# PHASE15.5.75 商城 UI / 圖源展示 / 學生頁滑選修正紀錄

## 本次目標
1. 調整老師端商品設定 UI，允許填入商品圖源網址。
2. 讓老師設定的商品可顯示在學生頁商品展示區。
3. 讓學生端商品展示區支援左右切換。
4. 儘量避免新增全域變數，沿用現有 canonical active chain。
5. 讓商城原有商品清單也能顯示縮圖，提升帶入感。

## 本次修改檔案
- `index.html`
- `js/modules/shop.js`
- `js/main.entry.js`
- `js/bootstrap-entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`

## 修改重點

### 1. 老師端商品設定 UI
在 `shopAdminCatalogPane` 新增：
- `shopAdminImageUrl`：商品圖源網址
- `shopAdminStudentTradeMode`：學生端展示模式（展示 / 申請 / 交易 / 教師限定）
- `shopAdminStudentVisible`：是否顯示於學生頁展示區
- `shopAdminImagePreview`：即時圖片預覽區

### 2. 商品資料寫入 schema
`saveShopProduct()` 現在會一併寫入：
- `image`
- `imageUrl`
- `student_visible`
- `student_trade_mode`

這讓 `main.entry.js` 既有的學生端商品展示流程可直接吃到設定後的資料，不需另開新入口。

### 3. 商店商品縮圖
`shop.js` 新增本地 helper：
- `normalizeShopImageUrl()`
- `getShopImageUrl()`
- `renderShopImageThumb()`
- `renderShopAdminImagePreview()`

用途：
- 老師端表單即時預覽圖片
- 商店商品清單顯示縮圖
- 商店管理清單顯示縮圖與圖源狀態
- 內建商品也預留可吃 alias image/imageUrl 的能力

### 4. 學生端商品展示區左右切換
`index.html` 的 `studentShopSection` 補上：
- `studentShopPrevBtn`
- `studentShopNextBtn`

`main.entry.js` 新增本地 rail helper：
- `getStudentShopRailStep()`
- `updateStudentShopRailButtons()`
- `scrollStudentShopRail()`
- `bindStudentShopRailControls()`

這些 helper 不新增全域變數，直接掛在 active main entry 的 local scope 中。

### 5. 學生商品卡資訊補強
`normalizeStudentShopItem()` 與 `renderStudentShopShowcaseCards()` 補強：
- 讀取更多圖片欄位來源（`image` / `imageUrl` / `img` / `thumbnailUrl` / `cover`）
- 顯示商品價格
- 保留 sold out / 展示模式 / 申請模式 / 交易模式文案

### 6. 快取識別對齊
將 active chain 版本識別從 `phase15phase74fix2` 對齊到：
- `phase15phase75shopui`
- `v15.5.75-shop-ui-image-showcase-20260315`

避免部署後前端混吃舊快取。

## 驗證方式
- `node --check js/modules/shop.js`
- `node --check js/main.entry.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 語法檢查通過
- 靜態確認新增 DOM id 與 active chain 對應一致

## 後續建議執行順序

### A. 立即 smoke test
1. 首頁可開
2. 登入成功
3. 老師端打開商城管理視窗
4. 新增商品並填入圖片網址
5. 儲存後確認：
   - 商城管理清單有縮圖
   - 學生頁展示區出現該商品
   - 學生頁可左右切換商品
   - 商店兌換清單有縮圖

### B. 第二輪收斂
1. 將商品圖片 helper 抽成 `core/shop-visual-utils.js`
2. 將學生端商品卡 UI 與商店 modal 卡 UI 共用化
3. 補商品圖片載入失敗的更細 fallback diagnostics

### C. 上線前檢查
1. staging hard refresh 檢查是否吃到 `phase15phase75shopui`
2. 確認 `window.App` / 登入 / 老師商城 / 學生頁都正常
3. 確認沒有新增 boot blocker 或新的 `ReferenceError`
