# Phase 15.5.24 深度巡檢與高風險熱修紀錄

基底：`project-root-phase15.5.23-quizbank-safe-diagnostics.zip`
策略：**不改主體流程、不擴大重構、只補高風險且容易直接報錯的點**。

## 這次已確認

- 所有 `js/**/*.js` 已重新做語法檢查，未發現新的 parse 級壞檔。
- 目前主體可登入，故本輪不碰 auth / Firebase 初始化流程。
- 目前高風險點主要來自：
  1. 舊式 DOM 直取未做 null guard
  2. 部分管理面板缺元件時會直接 throw
  3. Battle / 題庫 / 結算流程有少數「找不到面板就靜默失敗」的情況
  4. 主鏈有 query tag 不一致的隱性風險

## 這次立即修復的高風險點

### 1) 商城管理面板缺元件會直接報錯
已補：
- `editShopProduct()`
- `saveShopProduct()`

風險：
- `shopAdminName / Cost / Desc / Effect / Qty / HiddenEgg / Active` 任一欄位缺失時，原本會直接 `Cannot read properties of null`。

修法：
- 先抓 DOM 節點
- 缺欄位時直接 `UI.alert()`，不再進入後續寫入流程

### 2) 註冊流程面板缺元件時會直接報錯
已補：
- `rollRegistrationName()`
- `registerNewStudent()`
- UID 顯示區塊更新

風險：
- `regRandomNameDisplay / submitRegAndWriteBtn / submitRegBtn / regGrade / regCardSeq / regUidDisplay` 缺失時會直接炸

修法：
- 全部補 null guard
- 保持原流程不變，只在 DOM 缺失時給明確提示

### 3) 商城購買時的屬性選擇面板缺元件會直接報錯
已補：
- 進化石 / 奇石兩條分支

風險：
- `attrSelectTitle / confirmAttrSelectBtn / attrSelectDropdown` 缺一個就會炸

修法：
- 進入 modal 前先驗證三個元件
- 缺失就提示，不往下走

### 4) 題庫管理載入後更新總數時可能因為計數 DOM 缺失而失敗
已補：
- `loadQuizBank()` 內 `qmTotalCount`

風險：
- 資料其實讀成功，但因 `qmTotalCount` 缺失導致後續又報錯，看起來像題庫整體失敗

修法：
- 改成 guarded update

### 5) 修練結算與領獎面板缺元件時會直接報錯
已補：
- `showQuizResult()`
- `claimQuizReward()`

風險：
- `quizScoreText / quizResultDesc / quizRewardAttr` 缺失時會直接 throw
- `currentState.studentData.logs` 不存在時 push 也會炸

修法：
- 補結算 DOM guard
- 領獎前補 `logs` 與 `totalXP` 初始值
- 屬性名稱改成容錯讀法

### 6) 異獸管理面板缺元件時會直接報錯
已補：
- `loadLegendaryAdmin()`
- `publishLegendary()`
- `loadActiveLegendariesForStudent()`

風險：
- `laActiveList / laSelectId / laPoints / laReqAttr / laReqCount / stuLegendaryList / teacherSpeechText` 缺失時直接報錯

修法：
- 加 DOM guard
- 缺元件時直接警示或安全返回

### 7) 批次調整面板缺元件時會直接報錯
已補：
- `getBulkSerialRange()`
- `bulkUpdateProgressAndGrade()`

風險：
- `bulkStartSerial / bulkEndSerial / bulkGradeSelect / bulkRankSelect / bulkResetProgress` 缺失時會直接炸

修法：
- 補表單完整性驗證

### 8) BOSS 選角 / 守門題錯誤時存在靜默失敗與保存失敗無保護
已補：
- `battle.safeaudit.js`
  - `startBattleChallenge()`
  - `selectBattleMon()`
  - `handleBattleQuizAnswer()`

風險：
- `bsGrid` 缺失時原本直接 return，表面像按鈕沒反應
- 選中項 DOM 不存在時會出現不一致狀態
- 答錯後寫回失敗沒有 catch，可能把學生端卡在不明狀態

修法：
- 缺選角面板時直接 alert
- 選中項不存在時記警告並返回
- 答錯保存失敗時給明確 toast，並保持畫面可繼續操作

### 9) 主鏈 surface 檢查模組有 query tag 不一致風險
已補：
- 新增 `core/api-surface.safeaudit.js`
- 改成和目前主鏈一致的 import tag

風險：
- 原本 `api-surface.quizbankfix.js` 內部仍引用不同版本 tag，屬於隱性混鏈來源

修法：
- 建立 safeaudit copy，讓主鏈 surface 檢查引用一致

## 仍屬高風險，但這輪先記錄、未大改

### A. 專案仍保留多條平行入口鏈
目前資料夾內仍存在多個 `bootstrap-entry.*` / `main.entry.*` 副本。

風險：
- 之後若再改功能，很容易只修到某一條入口鏈
- 部署時若切錯入口，會重演「看似同版、實際不同內容」的問題

建議後續：
- 確認目前正式主鏈後，淘汰過時副本或移到 archive 目錄

### B. `main.entry.*` 仍然過大
主入口仍承擔：
- UI 與流程
- legacy 行為
- 題庫管理
- 商城
- 異獸管理
- 每日歷練結算

風險：
- 一個局部修改很容易波及別的功能

建議後續：
- 先以「只拆最常出錯的管理面板」為優先，不要一次大拆

### C. `quiz_bank` 仍同時承擔題目與 Boss 設定用途
風險：
- 題庫管理、每日歷練、Boss 守門題都共享同一來源
- 格式混雜時容易互相污染

建議後續：
- 後續可把 Boss 設定與題目文件分流，或至少補明確 `docType`

## 這次輸出的正式入口
- `index.html` -> `bootstrap-entry.safeaudit.js?v=phase15safeaudit1`
- `bootstrap-entry.safeaudit.js`
- `main.entry.safeaudit.js`

## 這次修改檔案
- `index.html`
- `js/bootstrap-entry.safeaudit.js`
- `js/main.entry.safeaudit.js`
- `js/modules/battle.safeaudit.js`
- `js/core/api-surface.safeaudit.js`

## 總結
這次沒有重寫主體流程，而是把「最容易直接報錯的執行期缺口」補成可降級處理。
優先目標是：**避免未來再因為少一個 DOM 或某個 modal 缺欄位，就把整段流程炸掉。**
