# Phase 15.5.53 — Phase 7 Panel Convergence Round 2

## 本輪目標
延續 Phase 7 的 DOM contract / 面板收斂策略，針對 `main.entry.js` 中仍屬高風險、但不直接牽動 boot/auth 主鏈的 UI 區域，進行低風險收斂。

本輪處理範圍：
- 戰塔 / BOSS 設定區
- 老師操作快捷鈕
- 專區連結 / NFC 區

## 修改檔案
- `js/main.entry.js`
- `js/core/state.js`

## 修改重點
### 1. 新增 DOM contract helper
在 `main.entry.js` 新增：
- `getTeacherUtilityDom()`
- `getZoneLinkDom()`
- `getBattleSetupDom()`

### 2. 新增 state / boot diagnostics 欄位
在 `currentState` 新增：
- `teacherUtilityDomContract`
- `zoneLinkDomContract`
- `battleSetupDomContract`

並透過既有 `syncMainEntryDomContract()` 同步寫入 `window.__BOOT_DIAG`。

### 3. 戰塔 / BOSS 設定區收斂
將下列初始化改成走 `getBattleSetupDom()`：
- `laSelectId`
- `laPreviewImg`
- `laPreviewName`
- `btSetType`
- `btSetBoss`
- `btBossPreviewImg`
- `btBossPreviewName`

### 4. 老師操作快捷鈕收斂
將下列按鈕改成走 `getTeacherUtilityDom()`：
- `confirmActionBtn`
- `writeNfcLinkBtn`
- `openShopBtn`
- `openCardForgeBtn`
- `openDebuffBtn`

另外補上低風險重複綁定 guard：
- `boundWriteNfcLink`
- `boundOpenShop`

### 5. 專區連結 / NFC 區收斂
將下列入口改成走 `getZoneLinkDom()`：
- `writeSupportZoneNfcBtn`
- `supportZoneUrlDisplay`
- `writeScienceZoneNfcBtn`
- `scienceZoneUrlDisplay`
- `secretPropTrigger`（保留 optional，不列 required）

另外補上重複綁定 guard：
- `boundSupportZoneWrite`
- `boundScienceZoneWrite`

### 6. 補抓到的邏輯衝突
在即時監控 (`onSnapshot`) 區塊，原本一度誤把 `dashboardView` 判斷改成 `loginView`；已修正為透過 `getRuntimeUiDom().dashboardView` 正確判斷。

## 驗證方式
### 語法檢查
已通過：
- `node --check js/main.entry.js`
- `node --check js/core/state.js`
- `node --check js/core/dom-contract.js`

### canonical active chain 全鏈語法檢查
已通過：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/state.js`
- `js/core/dom-contract.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

### DOM id 對表
本輪新增 required ids 均已對回 `index.html`，無缺件。

### targeted direct DOM 檢查
本輪收進 contract 的下列 ids，在 `main.entry.js` 已無直接 `document.getElementById(...)`：
- `confirmActionBtn`
- `writeNfcLinkBtn`
- `openShopBtn`
- `openCardForgeBtn`
- `openDebuffBtn`
- `writeSupportZoneNfcBtn`
- `supportZoneUrlDisplay`
- `writeScienceZoneNfcBtn`
- `scienceZoneUrlDisplay`
- `laSelectId`
- `btSetType`
- `btSetBoss`

## 風險控制
本輪沒有修改：
- `bootstrap-entry.js`
- `auth.js`
- 登入流程
- teacher target/save chain
- merge policy

仍屬接線層收斂，不是核心初始化鏈改寫。
