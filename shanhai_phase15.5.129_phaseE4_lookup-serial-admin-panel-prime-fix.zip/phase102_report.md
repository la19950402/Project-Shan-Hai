# PHASE 15.5.102 FIX14 — Battle Quiz Route Convergence

## 本輪主題
把 `battle.js` 內仍直接讀取 `quiz_bank` 的 **BOSS 題目 / gatekeeper / battle tower config 讀取路徑**，改成優先走 `quiz` 模組統一路徑，降低 battle 模組自行拼題與直讀題庫的分散度。

## 本輪實際修正

### 1. `js/modules/quiz.js`
新增並正式承接 battle 專用 quiz helper：

- `loadBattleTowerConfigDoc(docId = BATTLE_TOWER_DOC_ID)`
- `listBattleGatekeeperQuestions(audienceKey = 'default')`
- `pickBattleGatekeeperQuestion(options = {})`
- `loadBattleGatekeeperQuestion(gatekeeperQuizId = 'random', options = {})`

另外把 `normalizeQuizQuestionRecord(...)` 升級為 battle/daily 共用版本，補齊：

- `content / body / description`
- `correctIdx`
- `optionA / optionB / optionC / optionD`
- `options` 物件格式
- `options` 字串格式（換行 / `|`）
- 答案文字對 option 內容比對

### 2. `js/modules/battle.js`
把 battle 讀題與讀設定改成優先委派給 quiz 模組：

- `confirmBattleSelection()`
  - 改走 `loadBattleGatekeeperQuestion(...)`
- `checkBattleTowerStatus()`
  - 改走 `loadBattleTowerConfigDoc(...)`
- `populateBattleQuizOptions()`
  - 改走 `listBattleGatekeeperQuestions(...)`
- `openBattleTowerSetup()`
  - audience change / initial load 的 battle tower doc 讀取，改走 `loadBattleTowerConfigDoc(...)`

### 3. `js/main.entry.js`
新增 App delegate：

- `loadBattleTowerConfigDoc()`
- `listBattleGatekeeperQuestions()`
- `pickBattleGatekeeperQuestion()`
- `loadBattleGatekeeperQuestion()`

並把這些 delegate 注入 `createBattleModule(...)`。

## 版本
- `BOOT_ID`: `phase15phase102fix14battlequizroute`
- `BUILD_TAG`: `v15.5.102-fix14-battle-quiz-route-convergence-20260316`

## 檢查結果
- 全部 `js/**/*.js` syntax check：**通過**
- `node scripts/validate-active-chain.mjs`：**通過**
- `node scripts/deep-check-active-flow.mjs`：**通過**

## 深檢重點
已確認：

- active version chain 對齊
- battle 已優先使用 quiz route helper
- `battle.js` 已不再直接 `getDoc(doc(db, 'quiz_bank', gatekeeperQuizId))`
- `battle.js` 已不再直接讀 `_BATTLE_TOWER_BOSS_` config doc
- `main.entry.js` 已有 battle quiz delegate
- `quiz.js` 已正式承接 battle quiz routing helper

## 目前仍未完全收斂的殘留
本輪後 `battle.js` 仍保留 **2 處** 直接 `getDocs(collection(db, 'quiz_bank'))`：

1. `pickRandomGatekeeperQuestion()` 的本地 fallback full scan
2. `populateBattleQuizOptions()` 在 helper 缺失時的本地 fallback scan

它們已是 fallback 性質，不再是主路徑，但若下一輪要繼續收斂，最合理的方向就是把這兩處 fallback 也改成 quiz 模組內專責保底。
