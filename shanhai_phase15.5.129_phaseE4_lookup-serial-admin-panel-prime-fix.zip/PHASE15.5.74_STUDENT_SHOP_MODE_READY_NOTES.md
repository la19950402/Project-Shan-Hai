# PHASE15.5.74 — Student Shop Mode-Ready Showcase

## 本輪目標
在不開放學生直接購買、也不增加交易風險的前提下，先把學生商品展示區改成「可切換模式」的骨架：

- 預設 `preview`
- 不顯示購買按鈕
- 保留未來切換 `request_only` / `direct` 的 UI 結構
- 不新增不必要的全域變數

## 修改檔案
- `index.html`
- `js/core/state.js`
- `js/main.entry.js`

## 主要修改
1. `currentState.studentShopMode = 'preview'`
2. 學生商品展示區容器新增 `data-mode="preview"`
3. 商品展示標題文案改為可切模式說明
4. `main.entry.js` 新增學生商品模式 helper：
   - `normalizeStudentShopMode()`
   - `getStudentShopMode()`
   - `resolveStudentShopCardFooter()`
5. `normalizeStudentShopItem()` 現在會讀入：
   - `student_trade_mode`
   - `student_enabled`
   - `requires_teacher_approval`
   並正規化為：
   - `preview`
   - `request_only`
   - `direct`
   - `admin_only`
6. `renderStudentShopShowcaseCards()` 現在保留 `action-slot` 結構，但僅顯示模式提示，不生成按鈕
7. `renderStudentShopShowcase()` 會同步：
   - `section.dataset.mode`
   - 狀態列文字（展示模式 / 申請模式 / 交易模式）

## 目前行為
- 預設仍是展示模式，不開放購買
- 商品卡會顯示剩餘數量、說明與模式提示
- 未來可在不重做整個展示區的情況下，切換為 `request_only` 或 `direct`

## 風險控制
- 未新增交易提交流程
- 未碰老師端保存鏈
- 未碰商城扣庫存/金幣鏈
- 未碰 boot/auth 主鏈

## 驗證
- `node --check js/main.entry.js`
- `node --check js/core/state.js`
- `node --check js/modules/student.js`
- canonical active chain 全鏈 `node --check` 通過
