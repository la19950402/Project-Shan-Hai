# 第一階段：驗證前觀測強化（題庫鏈詳細診斷）

## 本階段目標
在**不改題庫業務邏輯**的前提下，補強題庫鏈觀測，讓測試時能直接判斷問題落點：
- `quiz_pool_public` 摘要是否存在
- 摘要的 `question_count` / `question_ids` 是否合理
- 依 `question_ids` 逐筆讀取 `quiz_bank/{id}` 時，成功幾題
- 失敗原因是：文件不存在、inactive、題目格式不完整、正解缺失，還是讀取失敗

## 本次修改檔案
- `js/modules/quiz.js`
- `js/core/state.js`

## 實際新增內容
### 1. `currentState.quizPoolDiagnostics`
新增題庫診斷狀態，按 audience 分桶保存：
- `summaryExists`
- `summaryQuestionCount`
- `summaryQuestionIdsCount`
- `selectedQuestionIdsCount`
- `resolvedQuestionCount`
- `missingQuestionIds`
- `invalidQuestionIds`
- `invalidQuestionReasons`
- `fetchFailureIds`
- `events`

### 2. `quiz_pool_public` 摘要診斷
`loadQuizPoolAudienceDoc()` 會記錄：
- 摘要是否存在
- `question_count`
- `question_ids` 長度
- `sample_questions` 長度
- `updatedAt`

並輸出 console log：
- `[quiz-pool][summary]`

### 3. `question_ids -> quiz_bank/{id}` 逐筆讀取診斷
`loadQuizQuestionsByIds(ids, { audienceKey })` 現在會記錄：
- requested ids 數量與前幾個 id
- 真正成功 resolve 的題目數量與前幾個 id
- `missingQuestionIds`
- `fetchFailureIds`
- `invalidQuestionIds`
- `invalidQuestionReasons`

目前會分類的 invalid 原因：
- `missing-id`
- `inactive-or-disabled`
- `missing-question`
- `insufficient-options`
- `empty-option-text`
- `missing-correct-answer`

並輸出 console log：
- `[quiz-pool][ids]`

### 4. `warmStudentQuizPool()` 全鏈診斷
新增整體鏈路紀錄：
- 是否直接回 cache
- 初始摘要題數與 ID 數
- 是否合併 `default` 摘要
- 最終選中的 id 數量
- 最終成功載入的題目數量
- 是否走 admin fallback
- 最終來源：`cache` / `summary-by-id` / `admin-fallback` / `error`

並輸出 console log：
- `[quiz-pool][warm]`

### 5. 全域除錯函式
新增兩個全域 helper：
- `window.__getQuizPoolDiagnostics()`
- `window.__printQuizPoolDiagnostics(audienceKey?)`

## 測試時建議觀察
### Console
看以下 3 組訊息：
- `[quiz-pool][summary]`
- `[quiz-pool][ids]`
- `[quiz-pool][warm]`

### Console 手動執行
```js
__printQuizPoolDiagnostics()
```
或指定 audience：
```js
__printQuizPoolDiagnostics('default')
__printQuizPoolDiagnostics('grade3')
__printQuizPoolDiagnostics('support')
```

## 預期能快速判斷的情況
### 情況 A：有題目數量，但 `question_ids` 幾乎沒有
問題偏向：`quiz_pool_public` 摘要髒掉。

### 情況 B：`question_ids` 有很多，但 `resolvedQuestionCount` 很少
問題偏向：`quiz_bank/{id}` 缺失、inactive 或格式不完整。

### 情況 C：`fetchFailureCount` 明顯大於 0
問題偏向：Firestore 讀取失敗、離線、權限或連線層問題。

### 情況 D：`invalidQuestionReasons.missing-correct-answer` 或 `insufficient-options` 很多
問題偏向：題目資料格式本身有問題。

## 本階段刻意沒做的事
- 沒改 Firestore rules
- 沒改學生保存鏈
- 沒改題庫 fallback 業務邏輯
- 沒做資料 repair / backfill apply

這一階段只負責把題庫鏈的真實斷點照亮。
