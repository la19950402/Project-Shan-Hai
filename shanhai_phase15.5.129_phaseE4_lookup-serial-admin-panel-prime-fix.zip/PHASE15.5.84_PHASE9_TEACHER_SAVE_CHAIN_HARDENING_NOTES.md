# PHASE 15.5.84 - Phase 9 Teacher Save Chain Hardening

## 基底
- 基於：`project-root-phase15.5.83-bug-sweep-phase8-stability-audit.zip`
- 本輪目標：老師端保存鏈專項硬化

## 本輪修改重點

### 1. 老師端切換學生時，清除舊的 pending action / forge 狀態
檔案：`js/modules/teacher-actions.js`

新增：
- `getTeacherActiveSerial()`
- `clearStaleTeacherActionState(nextSerial)`
- `applyTeacherTargetSelection(data, options)`
- `lookupTeacherTargetBySerial(rawSerial, options)`

行為改變：
- 當老師端切換到另一位學生時：
  - 舊的 `pendingAction` 會被清掉
  - 舊的 `pendingForgeData` 若綁定其他學生，也會一起清掉
  - 可避免「上一位學生的確認視窗 / forge 狀態殘留到下一位學生」

### 2. 老師端保存完成後，不再把畫面蓋回已切走的舊學生
檔案：`js/modules/teacher-actions.js`

新增：
- `canApplyTeacherTargetResult(serial, { allowEmptyActive })`
- `adoptTeacherSavedResult(app, saved, serial, options)`

行為改變：
- `persistTeacherData(...)` 不再無條件把 `currentUid/studentData` 綁回保存目標
- 如果保存期間畫面已切到別位學生，保存仍成功，但不會把畫面覆蓋回舊對象

### 3. `lookupByCardSeq()` 改成走老師端集中 helper
檔案：`js/main.entry.js`

行為改變：
- `lookupByCardSeq()` 不再自己手動：
  - `getDoc(...)`
  - `currentState.currentUid = ...`
  - `currentState.studentData = ...`
  - `UI.updatePanel(...)`
- 改為呼叫：
  - `this.lookupTeacherTargetBySerial(seqStr, ...)`
- 查卡序時若老師端保存尚在進行中，會先阻止切換學生

### 4. 老師端後續動作統一採用保存結果收養 helper
檔案：`js/modules/teacher-actions.js`

已接上的流程：
- `commitAction()`
- `checkDeathTrigger()`
- `forceDebuff()`
- `applyTeacherCompensation()`

效果：
- 保存成功後，只有當前 active target 仍是該學生，才會刷新目前畫面
- 若 active target 已改變，仍保留保存成功，但不干擾當前老師畫面

### 5. 補發流程避免錯誤綁定非當前學生 target context
檔案：`js/modules/teacher-actions.js`

行為改變：
- `applyTeacherCompensation()` 若補發目標不是目前 active target，不再提前把 teacher target context 綁到該學生
- 避免補發其他卡序時，把當前老師面板的 target context 汙染掉

## 過去常錯點回掃（本輪）

### A. 查卡序流程是否仍分散寫 state/UI
- 結果：已收斂到 `lookupTeacherTargetBySerial(...)`
- 目的：避免 lookup 路徑與後續老師端保存鏈各自維護不同 target 狀態

### B. 老師端保存完成是否會覆蓋已切換的畫面
- 結果：已加 `canApplyTeacherTargetResult(...)` 與 `adoptTeacherSavedResult(...)`
- 目的：消除典型 async race bug

### C. 切換學生時，舊 pending action / forge 是否殘留
- 結果：已加 `clearStaleTeacherActionState(...)`
- 目的：避免加分確認視窗或巡堂 forge 狀態套用到錯誤學生

### D. 保存中是否仍允許切換學生
- 結果：`lookupByCardSeq()` 與 `lookupTeacherTargetBySerial()` 已阻止保存中切換
- 目的：降低老師端保存鏈時序錯亂風險

## 語法與靜態檢查
- `node --check js/modules/teacher-actions.js` ✅
- `node --check js/main.entry.js` ✅
- `find js -type f -name '*.js' | xargs node --check` ✅

## active chain 版本對齊
- query tag：`phase15phase84teacherphase9`
- build tag：`v15.5.84-phase9-teacher-save-chain-hardening-20260315`

已同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- canonical `js/core/*.js`
- canonical `js/modules/*.js`

## 部署後優先驗證
1. 首頁可正常開
2. 登入正常
3. 老師端查卡序可進學生頁
4. 查 A 學生後開加分確認，再改查 B 學生，舊確認視窗不應誤套用到 B
5. 老師端手動加分保存中，嘗試切換學生，應先被阻止
6. 老師端移除狀態 / 附加狀態保存成功後，若中途已切到他人，不應把畫面覆寫回舊學生
7. 補發其他卡序時，不應把目前老師面板 target context 改亂

## 新產出
- `project-root-phase15.5.84-phase9-teacher-save-chain-hardening.zip`
