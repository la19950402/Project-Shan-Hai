# Phase 15.5.64 — student.js DOM convergence round 2

## 本輪目標
延續 phase 15.5.63 對 battle.js 的第二輪收斂，這一輪針對 `js/modules/student.js` 做低風險收斂：

- 不碰 boot/auth 主鏈
- 不碰老師端保存鏈
- 不改外部 API 名稱
- 把 student 模組剩餘 direct DOM 依賴收進 student-local DOM getters

## 修改檔案
- `js/modules/student.js`

## 主要修改
### 1. 新增 student-local DOM helpers
- `getById(id)`
- `queryAll(selector, root)`
- `pickDom(idMap)`
- `getStudentDisplayDom(prefix)`
- `getStudentIdentityDom()`
- `getStudentViewDom()`
- `getShopStatusDom()`

### 2. 收斂 direct DOM 依賴
將以下區塊改為透過 helper 取 DOM：
- `updateDragonImage()`
- `updateCollectionGallery()`
- `updateStudentAttributes()`
- `renderRadarChartRaw()`
- `updateStatusContainer()`
- `updatePanel()`
- `loadStudentData()` 內 shop modal 同步
- `refreshStudentIdentityLabels()`
- `refreshStudentRewardPanel()`

### 3. 安全性提升
在 `updatePanel()`、`refreshStudentIdentityLabels()` 等函式中，改為 DOM 存在才寫入，降低 panel 缺件時的執行期風險。

## 靜態檢查結果
### student.js
- `this.*`：0
- `getElementById(...)`：0
- `querySelectorAll(...)`：0

### canonical active chain
已再次對以下檔案執行 `node --check`，全部通過：
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

## 風險控制
本輪沒有改動：
- `js/main.entry.js`
- `js/bootstrap-entry.js`
- `js/modules/auth.js`
- 任何 HTML 結構
- 任何老師端保存與資料同步邏輯

## 結論
`student.js` 已完成第二輪低風險收斂：
- `this.*` 依賴為 0
- direct DOM 依賴為 0
- active chain 全鏈語法檢查通過
