# Archive / Variant Governance

## Goal
Reduce accidental edits and grep noise by moving inactive variants out of the active `js/` workspace while preserving rollback paths.

## What moved
- Historical entry variants: `archive/variants/js/bootstrap-entry.*.js`, `archive/variants/js/main.entry.*.js`
- Historical core variants: `archive/variants/js/core/*`
- Historical module variants: `archive/variants/js/modules/*`
- Backup snapshots: `archive/backups/js/main.entry.js.bak`, `archive/backups/js/main.entry.js.pre1552bak`, `archive/backups/js/main.entry.rewritten.js`

## Active chain remains
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- canonical runtime modules in `js/modules/*.js`

## Operator rule
Always repair active chain first. Archived variants are for rollback/forensics only.
