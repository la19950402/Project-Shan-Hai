# phase15.5.60 student hydration / ranking / quiz / boss fix

## 修改目標
沿著學生端實際症狀修補：
- 點 BOSS 時偶發「尚未載入學生資料」
- 點排行榜常要等很久才出現
- 進入每日歷練 / 題庫容易載入很久或失敗

## 這次採用的保守策略
不碰 boot/auth 主鏈、不大拆架構，只修三條線：
1. 學生資料 hydration 先可用再背景 merge
2. 排行榜加背景預熱 + 快取 + timeout fallback
3. 每日歷練題庫加 active 題池快取與預熱

## 主要修改
### js/modules/student.js
- `student_pages/{token}` snapshot 到達後，先立即：
  - 回填 `currentUid`
  - 寫入 `currentState.studentData`
  - 記錄 `studentDataReadyAt / studentDataLastSource`
  - 解鎖學生面板
- 與 `students/{serial}` 的 merge 改成背景 promise，不再阻塞學生面板可用性
- 學生資料更新後會背景預熱：
  - 排行榜資料
  - active 題庫池

### js/main.entry.js
新增：
- `ensureStudentDataReady()`
- `warmStudentQuizPool()`
- `rankStudentsForBoard()`
- `renderRankingRows()`
- `warmRankingCache()`
- `warmStudentViewData()`

調整：
- `showRanking()` 改成快取優先、背景更新、逾時顯示等待提示
- `startDailyQuest()` 先 `ensureStudentDataReady()`
- `startDailyQuest()` 改用 active 題池快取，不再每次都全量掃 quiz_bank 才開始篩選

### js/modules/battle.js
- `startBattleChallenge()` 先嘗試 `ensureStudentDataReady()`
- 如果學生資料只是「尚在同步」而不是永久缺失，就不會立刻直接報錯

### js/core/state.js
新增快取 / 診斷狀態：
- `studentDataReadyAt`
- `studentDataLastSource`
- `studentHydrationPending`
- `studentHydrationError`
- `studentQuizPoolCache / studentQuizPoolLoadedAt / studentQuizPoolPromise / studentQuizPoolLastError`
- `rankingCache / rankingCacheLoadedAt / rankingCachePromise / rankingCacheLastError`
- `studentViewWarmPromise / studentViewWarmStartedAt`

## 這次針對的根因
### BOSS 線
原本學生端讀到 `student_pages/{token}` 後，還會先等 `students/{serial}` merge 完成，才真正把資料穩定寫進 `currentState.studentData`。
這會讓點 BOSS 時，資料其實已經有，但 UI 還覺得「尚未載入」。

### 排行榜線
原本每次點排行榜都直接全量讀 `students`，沒有任何快取，也沒有 timeout fallback。
如果 Firestore 當次偏慢，就會讓使用者體感像卡死。

### 題庫 / 每日歷練線
原本每次開始每日歷練都全量讀 `quiz_bank` 再客端篩選。
現在改成先預熱 active 題池，開始時優先用快取，必要時才等待補抓。

## 驗證
- `node --check js/main.entry.js`
- `node --check js/modules/student.js`
- `node --check js/modules/battle.js`
- canonical active chain 全鏈語法檢查通過

## 仍需實機驗證的功能
- 學生端進入後 1~3 秒內直接點 BOSS
- 學生端進入後立即點排行榜
- 學生端進入後立即點每日歷練
- 網路較慢時，排行榜是否先顯示快取 / 等待訊息，再自動更新
