# Phase 15.5.80 — Performance Phase 5: Image Loading Strategy

## 本輪目標
延續 phase15.5.79 的題圖展示鏈，這一輪不再新增 UI，而是收斂圖片載入策略，降低 BOSS / 每日歷練 / 排行榜 / 商城中 `data-asset` 圖片對首頁與互動流程的拖累。

## 修改重點

### 1) `data-asset` 改為 lazy hydrate
- 檔案：`js/main.entry.js`
- 調整 `hydrateStorageImages(root, options)`：
  - 預設不再對整個 root 內所有 `img[data-asset]` 立刻 `getDownloadURL`
  - 改為：
    - 先處理少量 eager 圖片（預設前 2 張）
    - 其餘交給 `IntersectionObserver`，進入可視範圍後才真正 hydrate
- 目的：降低排行榜、商城、收藏、戰鬥畫面一次 render 時大量打 Storage 的情況

### 2) 加入 asset URL promise cache
- 檔案：`js/main.entry.js`
- `resolveAssetUrlFromFileBaseName(...)` 新增 `__assetUrlPromiseCache`
- 避免相同 asset key 在短時間內被多次同時 `getDownloadURL`
- 目的：降低重複 token 解析與無效網路等待

### 3) 當前題圖優先載入
- 檔案：`js/main.entry.js`
- `renderQuizQuestionMedia(...)` 現在會：
  - 對當前題圖設定 `loading='eager'`
  - 設定 `decoding='async'`
  - 嘗試設定 `fetchPriority='high'`
  - asset key 題圖使用 `hydrateStorageImages(questionMedia, { immediate: true, eagerLimit: 1 })`
- 目的：讓目前正在作答的題圖優先載出，不被其他隱藏圖拖慢

### 4) 下一題題圖輕量預取
- 檔案：`js/main.entry.js`
- 新增 `prefetchQuizQuestionMedia(...)`
- `renderQuizQuestion()` 會在 render 當前題目後，背景預取下一題圖片：
  - 直接 URL：建立 `Image()` 暖快取
  - asset key：在 idle 時段先解析 URL
- 目的：降低切下一題時題圖空窗

### 5) 保持 direct URL 優先
- 檔案：`js/main.entry.js`
- 既有 direct URL 優先策略保留
- 題圖若已是 `https://` / `data:` / `blob:`，直接使用，不走 Storage token 解析

## 為什麼這樣修
這一輪是性能收斂，不動資料模型，優先處理「圖片載入時機錯誤」這個會廣泛拖累整體體感的問題：
- 原本很多 `data-asset` 圖片在 render 時就全部開始 hydrate
- 現在改成「可視才載、當前題優先、下一題預取」
- 這種方式比繼續增加 Firebase 配額更直接，也更符合目前專案穩定優先的原則

## 驗證方式
- `node --check js/main.entry.js`
- `node --check js/bootstrap-entry.js`
- 全部 `js/**/*.js` 再跑一輪 syntax check
- 結果：`syntax_errors = 0`

## 版本識別
- query tag：`phase15phase80imageperfphase5`
- build tag：`v15.5.80-performance-phase5-image-loading-strategy-20260315`

## 建議 smoke test
1. 首頁可正常開啟
2. 登入正常
3. 打開題庫管理，題庫清單縮圖仍可顯示
4. 進每日歷練：當前題圖應優先載出
5. 快速切到下一題：若下一題有圖，體感應較前版更順
6. 排行榜 / 商城 / 收藏等含多張圖的區塊，不應一打開就造成整頁明顯卡頓
