# Phase 15.5.45 — Phase 6 this.* 依賴第二輪清理

## 本輪目標
在不觸碰 boot/auth 主鏈的前提下，先對高風險但相對低耦合的 active modules 做 `this.*` 依賴清理，降低 callback / event handler / 解構呼叫時因 `this` 綁定不穩導致的功能失效風險。

## 本輪修改範圍
只改 canonical active modules：

- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/zones.js`

未改：

- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/modules/auth.js`
- `js/modules/teacher-actions.js`

## 修改方式
### 1. 模組回傳物件改為具名 API 物件
原本三個模組都是直接 `return { ... }`。

本輪改成：

- `const shopApi = { ... }`
- `const quizApi = { ... }`
- `const zonesApi = { ... }`

最後再 `return xxxApi;`

### 2. 模組內部自呼叫改走 local alias，而非 `this.xxx()`
原本很多內部流程在同一個模組裡會用：

- `this.getBuiltInShopItems()`
- `this.resetQuizForm()`
- `this.openSupportZone()`
- `this.handleScienceStudentChange()`

這種寫法在 callback / event handler / 解構呼叫場景下，若 `this` 不是預期的 module api，就可能壞掉。

本輪改為：

- 先建立 local alias，例如 `const getBuiltInShopItems = (...args) => shopApi.getBuiltInShopItems(...args);`
- 內部互相呼叫改成直接使用 alias，例如 `getBuiltInShopItems()`

### 3. legacy fallback 也改為顯式 api 參照
原本 quiz / shop 內有少數 legacy fallback 仍依賴 `this.someLegacyMethod`。

本輪改成：

- `quizApi.importQuizBulkLegacy`
- `quizApi.exportQuizBankLegacy`
- `shopApi.handleShopPurchaseLegacy`
- `shopApi.applyShopEffectLegacy`

避免在非 method-call context 下讀到錯誤的 `this`。

## 風險控制
本輪沒有：

- 改 HTML
- 改 façade 掛載名
- 改 main entry 注入
- 改登入鏈
- 改 teacher target/save chain

所以風險主要限制在模組內部的自呼叫方式，不會去干擾初始化主鏈。

## 驗證
已完成：

- `node --check js/modules/shop.js`
- `node --check js/modules/quiz.js`
- `node --check js/modules/zones.js`

另外做了靜態盤查：

- `shop.js` 內 `this.*` 使用數：0
- `quiz.js` 內 `this.*` 使用數：0
- `zones.js` 內 `this.*` 使用數：0

## 本輪結果
這一輪完成的是 **Phase 6 的低風險第一刀**：
先把 `shop / quiz / zones` 的 module-internal `this.*` 自呼叫清掉，讓這三個 active modules 對執行 context 的依賴下降。

下一輪若繼續做 Phase 6，可再往：

- `teacher-actions.js`
- `battle.js`

做同型收斂，但那兩個模組耦合更高，需要比這一輪更保守。
