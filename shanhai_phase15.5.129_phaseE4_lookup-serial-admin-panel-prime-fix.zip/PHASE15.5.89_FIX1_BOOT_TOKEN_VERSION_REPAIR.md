# PHASE 15.5.89 — Fix 1: Boot Token + Version Repair

## Root cause found

- Active `js/main.entry.js` contained a literal line break inside a single-quoted `UI.alert(...)` string in the daily challenge launch guard.
- This produced a browser-side parse failure: `SyntaxError: Invalid or unexpected token` / `Unterminated string literal`.
- The previous `bootstrap-entry.js` marker check was too loose, so a file could pass marker validation yet still fail at parse/import time.

## Fixes applied

1. Replaced the broken multiline single-quoted alert string with explicit `\n\n` escapes.
2. Bumped active version identifiers from `phase15phase88phase9auditfix` to `phase15phase89fix1bootrepair`.
3. Updated build tag to `v15.5.89-fix1-boot-token-version-repair-20260315`.
4. Strengthened `bootstrap-entry.js` validation markers to require the exact active build tag and a tail sentinel.
5. Added last-chunk diagnostics and clearer syntax-error hints to boot failure output.
6. Added `scripts/validate-active-chain.mjs` to verify:
   - active version alignment
   - esbuild parse/bundle of `js/main.entry.js`
   - esbuild parse/bundle of the bootstrap-rewritten entry content

## Recommended local check

```bash
node scripts/validate-active-chain.mjs
```
