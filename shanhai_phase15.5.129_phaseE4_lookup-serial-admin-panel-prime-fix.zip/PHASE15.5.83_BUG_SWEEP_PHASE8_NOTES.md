# Phase 15.5.83 Bug Sweep / Stability Audit Notes

## 本輪目標
這一輪不是再加新功能，而是針對過去反覆出錯的型態做低風險清理，優先消除：

1. 背景同步 async 任務用 `try/catch` 包住但沒有 `await`，實際上會漏掉 rejection
2. active module 重新依賴 `globalThis.App`，讓模組邊界退化
3. Web NFC 建構器 / 支援判斷散落，多處各自判斷，容易再次出現環境型 runtime bug
4. active chain 版本標記漂移，讓部署後容易混吃舊快取

---

## 實際修改

### 1. `main.entry.js`：補背景任務統一入口，避免 fire-and-forget rejection 漏失
新增：
- `scheduleBackgroundTask(label, work, { logger })`

改寫：
- `syncStudentMirrorForSerial()` 內的 leaderboard summary 背景同步
- 註冊流程匿名建檔後的 leaderboard summary 背景同步
- `saveToDB()` 學生 token 儲存後的 leaderboard summary 背景同步
- `saveToDB()` fast admin save 後的 leaderboard summary 背景同步
- `warmStudentQuizPool()` 觸發題池 summary 重建時的背景同步

### 2. `shop.js`：移除對 `globalThis.App` 的直接依賴
`createShopModule(...)` 新增注入：
- `syncStudentShopCatalogSummaryForId`
- `removeStudentShopCatalogSummaryForId`
- `renderStudentShopShowcase`

原本：
- `globalThis.App?.syncStudentShopCatalogSummaryForId?.(...)`
- `globalThis.App?.removeStudentShopCatalogSummaryForId?.(...)`
- `globalThis.App?.renderStudentShopShowcase?.(...)`

現在改為模組注入後呼叫，避免 active module 再退回直接碰全域 façade。

### 3. `main.entry.js` / `zones.js`：Web NFC 建構器改成集中安全 helper
新增 local helper：
- `getNdefReaderCtor()`
- `hasWebNfcSupport()`
- `createNdefReaderOrThrow()`

用途：
- 取代 scattered `new window.NDEFReader()`
- 取代 scattered `'NDEFReader' in window`
- 將「是否支援 / 是否在 HTTPS 安全環境」的判斷邏輯集中

這樣之後若 Web NFC 行為要再調整，不需要再到多個流程各自補。

### 4. active chain 版本對齊
- query tag：`phase15phase83bugsweep1`
- build tag：`v15.5.83-bug-sweep-phase8-stability-audit-20260315`

已同步更新：
- `index.html`
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- canonical `js/core/*.js`
- canonical `js/modules/*.js`

---

## 盤查過去常錯點：本輪檢查結果

### A. 語法 / parse 級錯誤
- 掃描範圍：`js/**/*.js`
- 檔案數：`83`
- 結果：`syntax_errors = 0`

### B. active chain 版本漂移
- 檢查舊 tag：`phase15phase82publicphase7`
- active canonical 檔案內殘留：`0`

### C. active canonical 對全域 `App` / `forceOpenCardForge` 的直接依賴
- 檢查：`globalThis.App | window.App | window.forceOpenCardForge`
- active canonical 檔案內殘留：`0`

### D. Web NFC 直接 constructor / 舊式 support check
- 檢查：`new window.NDEFReader()`、`'NDEFReader' in window`
- `main.entry.js` + `js/modules/zones.js` 殘留：`0`

### E. canonical modules 的 `this.*` 風險
- 掃描 canonical modules 後仍有 `2` 處 `this.`
- 這 `2` 處都在 `shop.js` 生成 `<img onerror="this...">` 的 HTML fallback 字串
- 不屬於模組方法綁定風險，不是先前那類 `this.someHelper is not a function`

---

## 為什麼這輪值得先做
這次修的是「最容易反覆出現、而且平常不一定第一眼看得出來」的 bug 類型：

1. **背景同步 rejection 漏失**
   表面上看起來有 `try/catch`，但實際上 async 函式沒 `await`，失敗時會悄悄變成未捕捉 promise rejection。

2. **module 又退回 global façade**
   這會讓模組界線變鬆，之後又回到「少掛一個全域就炸」的舊路。

3. **NFC 支援判斷分散**
   以前這類環境錯很容易在某一條流程補了、另一條流程漏掉。

---

## 這輪沒有碰的東西
為了維持穩定，這輪刻意沒有碰：
- auth / boot 主流程順序
- 老師端保存鏈核心邏輯
- BOSS / ranking / shop 的主要業務規則
- HTML 結構與舊 `onclick` 相容策略

---

## 部署後優先驗證
1. 首頁正常開啟
2. 登入正常
3. 老師端商城管理：新增 / 刪除商品後，學生展示仍正常刷新
4. 匿名註冊 / 學生儲存 / fast admin save 後，console 不應再出現背景 summary 未捕捉錯誤
5. 支援 NFC 的裝置上：
   - 註冊寫卡
   - 寫入專屬網址
   - 補發寫卡
   - 支援/科展專區寫卡
   這些流程若失敗，應該是受控錯誤訊息，而不是直接 runtime crash

---

## 產出
- Zip: `project-root-phase15.5.83-bug-sweep-phase8-stability-audit.zip`
- Notes: `PHASE15.5.83_BUG_SWEEP_PHASE8_NOTES.md`
