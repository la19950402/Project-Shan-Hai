# Phase 13

本輪以 **保守相容** 方式新增以下模組：

- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`
- `js/core/firebase.js`

## 共用依賴

新模組統一透過 ES Module `import` 取得：

- `./core/ui.js`
- `./core/state.js`
- `./core/firebase.js`

## 掛載回 window.App 的相容層 API

### Shop
- `App.getBuiltInShopItems`
- `App.getShopEffectLabel`
- `App.getShopButtonHtml`
- `App.renderShopItems`
- `App.populateHiddenEggSelect`
- `App.updateShopAdminFormState`
- `App.resetShopAdminForm`
- `App.resetShopGiftForm`
- `App.setShopAdminTab`
- `App.getAdminGiftableShopItems`
- `App.loadShopGiftOptions`
- `App.pickShopGiftItem`
- `App.lookupShopGiftTarget`
- `App.getShopGiftItemMeta`
- `App.applyAdminGiftEffect`
- `App.sendShopGift`
- `App.openShopAdmin`
- `App.loadShopAdminList`
- `App.editShopProduct`
- `App.saveShopProduct`
- `App.deleteShopProduct`
- `App.openShop`
- `App.applyShopEffect`
- `App.handleShopPurchase`

### Quiz
- `App.resetQuizForm`
- `App.fillQuizForm`
- `App.openEditQuiz`
- `App.cancelQuizEdit`
- `App.readQuizFormData`
- `App.importQuizBulk`
- `App.exportQuizBank`
- `App.updateQuizSelectionSummary`
- `App.updateQuizFilterState`
- `App.getFilteredQuizzes`
- `App.toggleQuizSelection`
- `App.toggleAllQuizSelections`
- `App.renderQuizBankList`
- `App.batchSetQuizActive`
- `App.batchDeleteSelectedQuizzes`
- `App.loadQuizBank`
- `App.saveNewQuiz`
- `App.saveEditedQuiz`
- `App.deleteQuiz`
- `App.toggleQuizActive`
- `App.startDailyQuest`
- `App.renderQuizQuestion`
- `App.selectQuizOption`

### Ranking
- `App.showRanking`

### Content Profile
- `App.getProfilePayloadFromForm`
- `App.applyCurrentStudentProfile`
- `App.quickApplyCatProfile`
- `App.quickApplyShanhaiProfile`

### Zones
- `App.buildSupportZoneUrl`
- `App.buildScienceZoneUrl`
- `App.openRequestedAdminPanel`
- `App.loadSupportStudentsList`
- `App.useCurrentStudentInSupportZone`
- `App.handleSupportStudentChange`
- `App.getSupportRecordDocRef`
- `App.collectSupportDailyForm`
- `App.fillSupportDailyForm`
- `App.renderSupportTodayRecord`
- `App.loadSupportTodayRecord`
- `App.saveSupportRecordForStudent`
- `App.saveSupportRecord`
- `App.supportCheckIn`
- `App.saveSupportDailyRecord`
- `App.supportCheckOut`
- `App.markSupportAbsent`
- `App.copySupportZoneUrl`
- `App.writeSupportZoneLinkToNfc`
- `App.openSupportZone`
- `App.exportSupportHistoryCurrent`
- `App.exportSupportHistoryAll`
- `App.loadScienceStudentsList`
- `App.useCurrentStudentInScienceZone`
- `App.handleScienceStudentChange`
- `App.getScienceRecordDocRef`
- `App.collectScienceDailyForm`
- `App.fillScienceDailyForm`
- `App.renderScienceTodayRecord`
- `App.loadScienceTodayRecord`
- `App.saveScienceRecordForStudent`
- `App.saveScienceRecord`
- `App.scienceCheckIn`
- `App.saveScienceDailyRecord`
- `App.scienceCheckOut`
- `App.markScienceAbsent`
- `App.copyScienceZoneUrl`
- `App.writeScienceZoneLinkToNfc`
- `App.openScienceZone`
- `App.exportScienceHistoryCurrent`
- `App.exportScienceHistoryAll`

## 實作取向

本輪採「**保守抽離 + 相容覆寫**」：

- 主檔既有功能保留，降低退化風險
- 新模組先落檔並掛回 `window.App`
- 對於高風險複雜流程（部分 quiz / zones / shop deep flow），保留 legacy fallback 入口

這樣可以先完成模組邊界建立，再逐步把更深層 helper/service 往模組內收。
