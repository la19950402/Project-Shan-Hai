# Phase 14.1：Façade 收斂清理

## 本輪目標
- 將 `main.js` 中最大宗的 legacy `App.xxx = ...` 直接掛載收回模組與 façade。
- 統一版本參數，降低快取混淆。
- 保持既有 HTML/`onclick="App.xxx()"` 不變。

## 本輪完成
1. `zones.js` 改為承接學習扶助 / 科展團隊專區的實作邏輯，不再只是 legacy wrapper。
2. `content-profile.js` 新增 `activateHiddenEggFromArchive()`，移除主檔對特殊異獸蛋切換的 direct assignment。
3. `app-facade.js` 擴充：
   - `contentProfile` facade 納入 `activateHiddenEggFromArchive`
   - `zones` facade 納入 support/science zone 的完整 API（含 batch scan 與 reward helper）
4. `main.js` 移除 support/science zone 與 hidden egg 相關的 direct `App.xxx = ...` 大區塊。
5. 版本參數統一為 `phase14cleanup1`：
   - `index.html`
   - `main.js`
   - `shop.js` / `quiz.js` / `ranking.js` / `content-profile.js` / `zones.js`
6. `BUILD_TAG` 更新為 `v14.1-phase14-cleanup-20260313`

## 清理成果
- `main.js` 內 direct `App.xxx = ...` 由大量散落收斂到只剩 1 個：
  - `App.refreshStudentIdentityLabels`
- `window.App` 的舊 API 主要改由 `app-facade.js` 統一掛載。

## 仍保留的設計取捨
- `refreshStudentIdentityLabels` 仍在 `main.js`，因為它與主檔中的面板更新流程耦合較深，適合下一輪再評估是否併入 `student.js`。
- HTML partials 仍不建議現在導入；現況仍有大量固定 `id`/`getElementById`/`innerHTML` 契約。
