# PHASE 15.5.33 — Teacher Target Hardening / Phase 8

## Scope
- Harden teacher-side manual XP / debuff flows without changing business logic.
- Avoid new globals.
- Keep canonical entry chain.

## Changes
1. teacher-actions.js
   - Added `resolveTeacherTargetSerial()` and `hydrateTeacherTargetData()` to recover the current teacher target from `students/{serial}` when `currentState.studentData` is temporarily missing/stale.
   - `openCardForge()`, `startCardForge()`, `prepareAction()`, `prepareActionFromButton()`, `commitAction()`, and `forceDebuff()` now hydrate the target before proceeding.
   - `forceDebuff()` now calls `teacherApi.checkDeathTrigger(...)` directly instead of looping back through an injected facade helper.
2. main.entry.js
   - Removed unnecessary `checkDeathTrigger` injection into teacher-actions module factory.
   - Bumped active chain version tag to `phase15phase8`.

## Intent
Reduce intermittent teacher-side failures after card-seq lookup / panel entry, especially:
- manual XP actions reporting student data missing
- status removal/addition failing due to state timing windows

## Risk
Low-to-moderate. Changes are isolated to teacher action flows and canonical entry versions.
