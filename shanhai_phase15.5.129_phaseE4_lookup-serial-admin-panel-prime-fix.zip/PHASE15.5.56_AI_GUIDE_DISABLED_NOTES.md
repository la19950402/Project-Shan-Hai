# PHASE15.5.56 AI GUIDE DISABLED NOTES

## Goal
Disable and hide AI guide functionality (Baize / Sage Cat) without restructuring the app or breaking the canonical boot/login chain.

## Files changed
- `index.html`
- `js/main.entry.js`
- `js/core/state.js`

## What changed
### 1. AI guide is now globally disabled at runtime
Added `AI_GUIDE_RUNTIME.enabled = false` in `js/main.entry.js`.

### 2. Student AI UI is hidden by default
- `#stuBaizeSection` now has `hidden`
- `#baizeModal` now has `hidden`
- teacher-side AI guide selector row is hidden by default
- profile hint text updated to state AI guide is disabled

### 3. Existing API/HTML entry points are preserved but no longer activate AI
- `App.openBaizeModal()` now exits early with a toast
- `App.sendBaizeMessage()` now exits early with a toast
- `askBaizeViaServer()` no longer calls Firebase when AI is disabled

### 4. Startup sync ensures AI stays hidden
`syncAiGuideFeatureUiState()` runs during init before the Baize UI binding path completes.

### 5. Compatibility kept intact
- No façade removal
- No HTML handler removal
- No boot/auth changes
- No data-structure changes

## Verification
### Syntax
Passed:
- `js/main.entry.js`
- `js/core/state.js`
- canonical active chain full syntax check

### Static checks
Confirmed:
- AI runtime flag exists and is disabled
- student AI section is hidden in HTML
- AI modal is hidden in HTML
- teacher AI guide controls are hidden in HTML
- `openBaizeModal()` and `sendBaizeMessage()` now no-op safely
- `askBaizeViaServer()` does not call backend when disabled

## Important note
This phase **hides and disables** AI guidance. It does **not** fully delete the skeleton DOM or compatibility methods. That is intentional to reduce regression risk.
