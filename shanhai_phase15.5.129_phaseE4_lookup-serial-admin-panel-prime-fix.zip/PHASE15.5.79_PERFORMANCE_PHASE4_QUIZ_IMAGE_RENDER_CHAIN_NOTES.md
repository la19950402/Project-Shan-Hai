# PHASE 15.5.79 — Performance Phase 4 / Quiz Image Render Chain

## 這次修改重點

本輪是接續 phase15.5.78 的下一階段，主題不是再改排行榜或題池，而是把 **題圖資料鏈與 render path 正式接上**，讓：

1. 題庫管理可以設定題圖來源
2. 題庫匯入 / 匯出可以攜帶題圖欄位
3. 題庫清單可以看到題圖縮圖
4. 每日歷練 / BOSS 作答畫面可以正式顯示題圖
5. 題圖來源同時支援：
   - 直接網址 `imageUrl`
   - Storage asset key `imageAssetKey`

## 實際修改檔案

- `index.html`
- `js/main.entry.js`
- `js/modules/battle.js`
- `js/modules/quiz.js`
- `js/bootstrap-entry.js`
- `js/ENTRY_CHAIN_MANIFEST.json`
- active canonical imports / version tags

## 這次怎麼修

### 1. 題庫管理 UI 新增題圖欄位
在 `quizManagerModal` 新增：

- `qmImageUrl`
- `qmImageAsset`
- `qmImagePreview`
- `qmImagePreviewHint`

老師現在可以直接填：

- 題圖網址（https://...）
- Storage 檔名 / asset key

而且表單內會即時預覽。

### 2. 題圖來源解析集中化
在 `js/main.entry.js` 新增：

- `resolveQuizImageMeta(raw)`
- `updateQuizImagePreview(meta)`
- `previewQuizImageFromForm()`
- `renderQuizQuestionMedia(questionRecord)`

用途：

- 集中判斷 direct URL vs asset key
- 避免題圖欄位在不同流程下各自亂猜
- 繼續沿用既有 `hydrateStorageImages(...)`，不新增新全域

### 3. 作答畫面正式加入題圖區塊
在 `quizPlayModal` 新增：

- `quizQuestionMedia`
- `quizQuestionImage`
- `quizQuestionImageHint`

`renderQuizQuestion()` 現在會先呼叫 `renderQuizQuestionMedia(q)`，所以：

- 每日歷練題目可以顯示題圖
- BOSS / 戰鬥題目若題目資料含圖，也能顯示
- 直接網址優先顯示
- Storage asset key 會走既有 hydration/fallback 流程

### 4. 題庫資料讀寫正式支援題圖欄位
這次已讓以下流程支援：

- `readQuizFormData()`
- `fillQuizForm()`
- `resetQuizForm()`
- `importQuizBulk()`
- `exportQuizBank('json'/'csv')`
- `renderQuizBankList()`

新增欄位：

- `imageUrl`
- `image`
- `imageAssetKey`
- `imageAlt`

### 5. 匯入 / 匯出格式擴充
CSV 現在新增欄位：

- `imageUrl`
- `imageAssetKey`

Tab 貼上格式仍相容舊 8 欄；若有第 9 / 10 欄，會視為：

- 題圖網址
- 題圖 asset key

JSON 匯入也會自動解析：

- `imageUrl`
- `image_url`
- `questionImage`
- `question_image`
- `image`
- `img`
- `imageAssetKey`
- `assetKey`
- `img_file`

### 6. 題池摘要與 battle/quiz normalize 一起補齊題圖欄位
這次不只補 UI，還把 canonical normalize 路徑一起補上：

- `js/main.entry.js` 的 `buildQuizPoolQuestionSummary(...)`
- `js/modules/battle.js` 的 `normalizeQuizQuestionRecord(...)`
- `js/modules/quiz.js` 的 `normalizeQuizQuestionRecord(...)`

避免出現：

- 題庫管理看得到圖
- 但題池摘要丟掉圖欄位
- 最後 BOSS / 每日歷練 render 還是沒圖

## 為什麼這樣修

這一輪是補「題圖常常載不出來」的真正結構缺口。

先前問題不只是效能，而是：

- 題目資料可能有圖欄位
- 但作答畫面的 DOM 沒有正式題圖區
- battle / quiz normalize 沒把圖欄位穩定保留下來
- 題庫管理也沒有正式欄位讓老師設定題圖

所以這次採取的是：

- 不新增新入口
- 不擴大全域面
- 直接在 canonical active chain 補完整題圖資料鏈

## 驗證方式

已完成：

- `node --check js/main.entry.js`
- `node --check js/modules/battle.js`
- `node --check js/modules/quiz.js`
- `node --check` 全部 `js/**/*.js`

結果：

- `syntax_errors = 0`

## 部署後建議 smoke test

1. 首頁可正常開啟
2. 登入正常
3. 老師端打開題庫管理
4. 新增一題，填 `imageUrl`
5. 儲存後確認題庫清單有縮圖
6. 編輯同一題，改成只填 `imageAssetKey`
7. 再確認題庫清單縮圖正常
8. 進每日歷練，確認題目可顯示題圖
9. 進 BOSS / 戰鬥題目，若題目有圖，確認題圖可顯示
10. 題圖可點擊放大

## 新版本

- build/query tag: `phase15phase79quizimagephase4`
- build tag: `v15.5.79-performance-phase4-quiz-image-render-chain-20260315`

輸出包：

- `project-root-phase15.5.79-performance-phase4-quiz-image-render-chain.zip`
