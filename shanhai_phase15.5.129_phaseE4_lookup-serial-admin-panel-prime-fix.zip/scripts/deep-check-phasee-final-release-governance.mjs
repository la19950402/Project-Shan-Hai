#!/usr/bin/env node
import { existsSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';
const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';
const OLD_BOOT_ID = 'phase15phase103fix15battlebossconfigsplit';
const OLD_BUILD_TAG = 'v15.5.103-fix15-battle-boss-config-split-20260316';

const read = (path) => readFileSync(path, 'utf8');
const indexText = read('index.html');
const bootstrapText = read('js/bootstrap-entry.js');
const mainText = read('js/main.entry.js');
const entryManifestText = read('js/ENTRY_CHAIN_MANIFEST.json');
const moduleManifestText = read('js/MODULE_VARIANT_MANIFEST.json');
const deployDoc = read('DEPLOY_CHECKLIST.md');
const smokeDoc = read('SMOKE_TEST_ACTIVE_CHAIN.md');
const rulesDoc = read('FIRESTORE_RULES_ALIGNMENT.md');
const mainLegacyText = existsSync('js/main.js') ? read('js/main.js') : '';

function run(script) {
  execFileSync('node', [script], { stdio: 'pipe' });
}

const criticalScripts = [
  'scripts/validate-active-chain.mjs',
  'scripts/deep-check-active-flow.mjs',
  'scripts/deep-check-phasec-evolution-boundaries.mjs',
  'scripts/deep-check-phasec-save-hub-boundaries.mjs',
  'scripts/deep-check-phasee-archive-governance.mjs',
  'scripts/deep-check-phasee-deploy-governance.mjs',
  'scripts/deep-check-phasee-firestore-rules-alignment.mjs',
  'scripts/deep-check-boss-flow.mjs'
];

const scriptResults = {};
for (const script of criticalScripts) {
  try {
    run(script);
    scriptResults[script] = 'ok';
  } catch (err) {
    scriptResults[script] = `failed: ${String(err?.message || err)}`;
  }
}

const checks = {
  version_tokens_aligned:
    indexText.includes(`./js/bootstrap-entry.js?v=${BOOT_ID}`) &&
    bootstrapText.includes(`const BOOT_ID = '${BOOT_ID}';`) &&
    bootstrapText.includes(BUILD_TAG) &&
    mainText.includes(`const BUILD_TAG = '${BUILD_TAG}';`) &&
    mainText.includes(`// ENTRY_TAIL_SENTINEL: ${BOOT_ID}-tail`) &&
    entryManifestText.includes(`"active_bootstrap": "js/bootstrap-entry.js?v=${BOOT_ID}"`) &&
    entryManifestText.includes(`"active_main_entry": "js/main.entry.js?v=${BOOT_ID}"`) &&
    entryManifestText.includes(`"active_build_tag": "${BUILD_TAG}"`) &&
    deployDoc.includes(BOOT_ID) &&
    deployDoc.includes(BUILD_TAG) &&
    smokeDoc.includes(BOOT_ID),
  old_release_tokens_removed_from_active_governance:
    !indexText.includes(OLD_BOOT_ID) &&
    !bootstrapText.includes(OLD_BOOT_ID) &&
    !bootstrapText.includes(OLD_BUILD_TAG) &&
    !mainText.includes(OLD_BOOT_ID) &&
    !mainText.includes(OLD_BUILD_TAG) &&
    !entryManifestText.includes(OLD_BOOT_ID) &&
    !deployDoc.includes(OLD_BOOT_ID) &&
    !smokeDoc.includes(OLD_BOOT_ID),
  legacy_main_js_not_active:
    existsSync('js/main.js') &&
    !indexText.includes('src="./js/main.js"') &&
    !bootstrapText.includes("'./main.js'") &&
    !entryManifestText.includes('"mainEntry": "js/main.js"') &&
    !entryManifestText.includes('"active_main_entry": "js/main.js"') &&
    mainLegacyText.includes('document.getElementById'),
  deploy_docs_reference_final_reaudit:
    /node scripts\/deep-check-phasee-final-release-governance\.mjs/.test(deployDoc) &&
    /js\/main\.js[^\n]*不是 active entry/.test(smokeDoc),
  firestore_rules_docs_still_linked:
    deployDoc.includes('firestore.rules') &&
    deployDoc.includes('FIRESTORE_RULES_ALIGNMENT.md') &&
    rulesDoc.includes('student_pages/{token}') &&
    rulesDoc.includes('_BATTLE_TOWER_BOSS_'),
  critical_governance_checks_all_green:
    Object.values(scriptResults).every((value) => value === 'ok')
};

const summary = {
  critical_script_count: criticalScripts.length,
  critical_script_pass_count: Object.values(scriptResults).filter((value) => value === 'ok').length,
  main_entry_lines: mainText.split('\n').length,
  legacy_main_lines: mainLegacyText ? mainLegacyText.split('\n').length : 0,
  active_bootstrap_ref_count: (indexText.match(/bootstrap-entry\.js\?v=/g) || []).length,
  final_boot_token_reference_count: (
    [indexText, bootstrapText, mainText, entryManifestText, deployDoc, smokeDoc]
      .join('\n')
      .match(new RegExp(BOOT_ID, 'g')) || []
  ).length
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASEE_FINAL_RELEASE_GOVERNANCE_FAILED');
  console.error(JSON.stringify({ checks, summary, failed, scriptResults }, null, 2));
  process.exit(1);
}

console.log('DEEP_CHECK_PHASEE_FINAL_RELEASE_GOVERNANCE_OK');
console.log(JSON.stringify({ checks, summary, scriptResults }, null, 2));
