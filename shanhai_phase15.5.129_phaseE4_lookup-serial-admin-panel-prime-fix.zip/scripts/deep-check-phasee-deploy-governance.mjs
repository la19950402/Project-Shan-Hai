#!/usr/bin/env node
import { readFileSync } from 'node:fs';

function read(path) {
  return readFileSync(path, 'utf8');
}

function includesAll(text, tokens = []) {
  return tokens.every(token => text.includes(token));
}

const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';
const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';

const deployDoc = read('DEPLOY_CHECKLIST.md');
const smokeDoc = read('SMOKE_TEST_ACTIVE_CHAIN.md');
const entryManifestText = read('js/ENTRY_CHAIN_MANIFEST.json');
const moduleManifestText = read('js/MODULE_VARIANT_MANIFEST.json');

const requiredDeployTokens = [
  'DEPLOY CHECKLIST',
  BOOT_ID,
  BUILD_TAG,
  'js/bootstrap-entry.js',
  'js/main.entry.js',
  'js/core/app-facade.js',
  'js/core/api-surface.js',
  'node scripts/validate-active-chain.mjs',
  'node scripts/deep-check-active-flow.mjs',
  'node scripts/deep-check-phasec-collection-boundaries.mjs',
  'node scripts/deep-check-phasec-evolution-boundaries.mjs',
  'node scripts/deep-check-phasec-collection-editor-boundaries.mjs',
  'node scripts/deep-check-phasec-forge-actioncard-boundaries.mjs',
  'node scripts/deep-check-phasec-save-hub-boundaries.mjs',
  'node scripts/deep-check-phased-auth-legacy-deps.mjs',
  'node scripts/deep-check-phased-student-legacy-deps.mjs',
  'node scripts/deep-check-phased-legacy-reaudit.mjs',
  'node scripts/deep-check-phasee-archive-governance.mjs',
  'node scripts/deep-check-phasee-deploy-governance.mjs',
  'SMOKE_TEST_ACTIVE_CHAIN.md',
  'archive/variants/',
  'rollback'
];

const requiredSmokeTokens = [
  'SMOKE TEST ACTIVE CHAIN',
  'js/bootstrap-entry.js',
  'js/main.entry.js',
  BOOT_ID,
  'Teacher lookup / student load',
  'Student save chain',
  'Daily / Battle / Quiz route',
  'Shop / Ranking / Public summary',
  'Collection / Display Team / Evolution',
  'Forge / Action-card / Teacher actions',
  'Batch / Auth / Admin diagnostics',
  '最小必跑案例',
  'rollback'
];

const checks = {
  deploy_doc_present: deployDoc.includes('# DEPLOY CHECKLIST'),
  deploy_doc_covers_active_chain: includesAll(deployDoc, [BOOT_ID, BUILD_TAG, 'js/bootstrap-entry.js', 'js/main.entry.js', 'js/core/app-facade.js', 'js/core/api-surface.js']),
  deploy_doc_covers_script_order: includesAll(deployDoc, requiredDeployTokens),
  deploy_doc_mentions_archive_governance: deployDoc.includes('archive/README.md') && deployDoc.includes('ARCHIVE_VARIANT_GOVERNANCE.md'),
  smoke_doc_present: smokeDoc.includes('# SMOKE TEST ACTIVE CHAIN'),
  smoke_doc_covers_manual_paths: includesAll(smokeDoc, requiredSmokeTokens),
  smoke_doc_covers_minimum_cases: smokeDoc.includes('8 個案例') || smokeDoc.includes('8 個最小案例'),
  entry_manifest_mentions_deploy_docs: entryManifestText.includes('DEPLOY_CHECKLIST.md') && entryManifestText.includes('SMOKE_TEST_ACTIVE_CHAIN.md'),
  module_manifest_mentions_deploy_docs: moduleManifestText.includes('DEPLOY_CHECKLIST.md') && moduleManifestText.includes('SMOKE_TEST_ACTIVE_CHAIN.md')
};

const summary = {
  deploy_script_reference_count: (deployDoc.match(/node scripts\//g) || []).length,
  smoke_section_count: (smokeDoc.match(/^### /gm) || []).length,
  minimum_case_count_mentions: (smokeDoc.match(/^[1-8]\./gm) || []).length,
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASEE_DEPLOY_GOVERNANCE_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}

console.log('DEEP_CHECK_PHASEE_DEPLOY_GOVERNANCE_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
