#!/usr/bin/env node
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

function read(path) {
  return readFileSync(path, 'utf8');
}

function walk(dir, acc = []) {
  if (!existsSync(dir)) return acc;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, acc);
    else acc.push(full.replace(/\\/g, '/'));
  }
  return acc;
}

const entryManifest = JSON.parse(read('js/ENTRY_CHAIN_MANIFEST.json'));
const moduleManifest = JSON.parse(read('js/MODULE_VARIANT_MANIFEST.json'));
const archiveReadme = read('archive/README.md');
const governanceDoc = read('ARCHIVE_VARIANT_GOVERNANCE.md');

const archivedEntryFiles = entryManifest.archivedEntryFiles || [];
const archivedCoreVariants = entryManifest.archivedCoreVariants || [];
const archivedModuleVariants = Object.values(moduleManifest.archivedVariants || {}).flat();
const archivedPaths = [...archivedEntryFiles, ...archivedCoreVariants, ...archivedModuleVariants];
const activePaths = [
  ...Object.values(entryManifest.active || {}),
  ...Object.values(entryManifest.activeModuleVariants || {}),
  ...Object.values(moduleManifest.active || {}),
];

const activeUnique = [...new Set(activePaths)];
const archivedUnique = [...new Set(archivedPaths)];
const jsFiles = walk('js');
const archiveVariantFiles = walk('archive/variants');
const archiveBackupFiles = walk('archive/backups');

const suffixPattern = /(batchui|bossrepairclean2?|chainfix2?|quizbankfix|quizbanksafe|safeaudit[1-5]?|stability[1-2]|syntaxfix|verify|quizbusyfix|shopbusyfix)\.js$/;
const activeWorkspaceVariantLeaks = jsFiles.filter(path => suffixPattern.test(path));
const activeWorkspaceBackupLeaks = jsFiles.filter(path => /main\.entry\.(js\.bak|js\.pre1552bak|rewritten\.js)$/.test(path));

const missingArchived = archivedUnique.filter(path => !existsSync(path));
const activeInArchive = activeUnique.filter(path => path.startsWith('archive/'));
const archivedOutsideArchive = archivedUnique.filter(path => !path.startsWith('archive/variants/'));
const overlap = archivedUnique.filter(path => activeUnique.includes(path));

const checks = {
  entry_manifest_version_bumped: entryManifest.version === 'phase15entryconverge5',
  module_manifest_version_bumped: moduleManifest.version === 'phase15modulevariant4',
  archived_entry_paths_point_to_archive: archivedEntryFiles.every(path => path.startsWith('archive/variants/')),
  archived_core_paths_point_to_archive: archivedCoreVariants.every(path => path.startsWith('archive/variants/')),
  archived_module_paths_point_to_archive: archivedModuleVariants.every(path => path.startsWith('archive/variants/')),
  all_manifest_archives_exist: missingArchived.length === 0,
  no_active_files_under_archive: activeInArchive.length === 0,
  no_archived_paths_outside_archive: archivedOutsideArchive.length === 0,
  no_active_archived_overlap: overlap.length === 0,
  no_variant_leaks_left_in_js_workspace: activeWorkspaceVariantLeaks.length === 0,
  no_backup_leaks_left_in_js_workspace: activeWorkspaceBackupLeaks.length === 0,
  archive_readme_present: archiveReadme.includes('Archive governance') && archiveReadme.includes('archive/variants/js/...'),
  governance_doc_present: governanceDoc.includes('Archive / Variant Governance') && governanceDoc.includes('Always repair active chain first.')
};

const summary = {
  archived_entry_count: archivedEntryFiles.length,
  archived_core_count: archivedCoreVariants.length,
  archived_module_count: archivedModuleVariants.length,
  archive_variant_file_count: archiveVariantFiles.length,
  archive_backup_file_count: archiveBackupFiles.length,
  active_workspace_variant_leak_count: activeWorkspaceVariantLeaks.length,
  active_workspace_backup_leak_count: activeWorkspaceBackupLeaks.length,
  missing_archived_count: missingArchived.length,
  active_file_count: activeUnique.length,
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASEE_ARCHIVE_GOVERNANCE_FAILED');
  console.error(JSON.stringify({ checks, summary, failed, missingArchived, activeWorkspaceVariantLeaks, activeWorkspaceBackupLeaks, activeInArchive, archivedOutsideArchive, overlap }, null, 2));
  process.exit(1);
}

console.log('DEEP_CHECK_PHASEE_ARCHIVE_GOVERNANCE_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
