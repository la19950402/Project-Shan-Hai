#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(path, 'utf8');
const mainText = read('js/main.entry.js');
const studentAccessText = read('js/modules/student-access.js');
const contentProfileText = read('js/modules/content-profile.js');
const zonesText = read('js/modules/zones.js');
const shopText = read('js/modules/shop.js');

const hasDelegatedBridgeDeclaration =
  mainText.includes('const delegatedSaveToDB = (...args) => App.saveToDB(...args);') ||
  mainText.includes('function delegatedSaveToDB(...args) { return App.saveToDB(...args); }');

const delegatedBridgeUsages = (mainText.match(/saveToDB:\s*delegatedSaveToDB/g) || []).length;

const checks = {
  main_save_delegate_present:
    mainText.includes("isFastAdminSaveMode(...args) { return studentAccessApi.isFastAdminSaveMode(...args); },") &&
    mainText.includes("async saveToDB(...args) { return studentAccessApi.saveToDB(...args); },"),
  main_save_hub_body_removed:
    !mainText.includes("const isStudentTokenMode = (currentState.viewMode === 'student' && !!currentState.currentToken);") &&
    !mainText.includes('const MAX_LOGS = 200;') &&
    !mainText.includes('return await studentAccessApi.saveCanonicalStudentPayload(payload, serial);'),
  student_access_save_hub_present:
    studentAccessText.includes('async saveToDB(dataObj, explicitUid = null)') &&
    studentAccessText.includes("const isStudentTokenMode = (currentState.viewMode === 'student' && !!currentState.currentToken);") &&
    studentAccessText.includes('const maxLogs = 200;') &&
    studentAccessText.includes('return await this.saveStudentTokenPayload(payload, explicitUid);') &&
    studentAccessText.includes('return await this.saveFastAdminStudentPayload(payload, serial);') &&
    studentAccessText.includes('return await this.saveCanonicalStudentPayload(payload, serial);'),
  student_access_fast_admin_mode_present:
    studentAccessText.includes('isFastAdminSaveMode(explicitUid = null)') &&
    studentAccessText.includes("['batch', 'support-batch', 'science-batch'].includes(String(currentState.scanIntention || ''))"),
  save_bridge_centralized:
    hasDelegatedBridgeDeclaration &&
    delegatedBridgeUsages >= 5 &&
    !mainText.includes('saveToDB: (...args) => App.saveToDB(...args)'),
  save_consumers_still_mount_through_bridge:
    mainText.includes('teacherActionsApi = createTeacherActionsModule({') &&
    mainText.includes('saveToDB: delegatedSaveToDB') &&
    contentProfileText.includes('saveToDB(') &&
    zonesText.includes('saveToDB(') &&
    shopText.includes('saveToDB(')
};

const summary = {
  main_saveToDB_count: (mainText.match(/\bsaveToDB\s*\(/g) || []).length,
  main_delegate_save_bridge_count: delegatedBridgeUsages,
  student_access_saveToDB_count: (studentAccessText.match(/\bsaveToDB\s*\(/g) || []).length,
  student_access_fast_admin_mode_count: (studentAccessText.match(/isFastAdminSaveMode\s*\(/g) || []).length,
  bridge_declared_as_function: mainText.includes('function delegatedSaveToDB(...args) { return App.saveToDB(...args); }')
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASEC_SAVE_HUB_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('DEEP_CHECK_PHASEC_SAVE_HUB_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
