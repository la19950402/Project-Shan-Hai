#!/usr/bin/env node
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';
const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';
const root = process.cwd();
const mainEntryPath = join(root, 'js/main.entry.js');
const bootstrapPath = join(root, 'js/bootstrap-entry.js');
const indexPath = join(root, 'index.html');
const manifestPath = join(root, 'js/ENTRY_CHAIN_MANIFEST.json');
const quizSessionUtilsPath = join(root, 'js/core/quiz-session-utils.js');
const quizModulePath = join(root, 'js/modules/quiz.js');
const tempDir = mkdtempSync(join(tmpdir(), 'shanhai-active-chain-'));
const rewrittenPath = join(tempDir, 'main.entry.rewritten.js');

function assertIncludes(label, text, token) {
  if (!text.includes(token)) {
    throw new Error(`${label} 缺少預期內容: ${token}`);
  }
}

function rewriteRelativeImports(sourceText, targetUrl) {
  const baseHref = new URL('./', targetUrl).href;
  return String(sourceText || '')
    .replace(/from\s+(["'])\.\/([^"']+)\1/g, (_m, quote, relPath) => `from ${quote}${baseHref}${relPath}${quote}`)
    .replace(/import\(\s*(["'])\.\/([^"']+)\1\s*\)/g, (_m, quote, relPath) => `import(${quote}${baseHref}${relPath}${quote})`);
}

function runEsbuildBundleCheck(entryPath) {
  execFileSync('npx', ['--yes', 'esbuild', entryPath, '--bundle', '--format=esm', '--platform=browser', '--log-level=warning', '--outfile=' + join(tempDir, 'bundle.js')], {
    stdio: 'pipe'
  });
}

function runEsbuildParseCheck(entryPath) {
  execFileSync('npx', ['--yes', 'esbuild', entryPath, '--format=esm', '--platform=browser', '--log-level=warning', '--outfile=' + join(tempDir, 'parsed.js')], {
    stdio: 'pipe'
  });
}

try {
  const mainText = readFileSync(mainEntryPath, 'utf8');
  const bootstrapText = readFileSync(bootstrapPath, 'utf8');
  const indexText = readFileSync(indexPath, 'utf8');
  const manifestText = readFileSync(manifestPath, 'utf8');
  const quizSessionUtilsText = readFileSync(quizSessionUtilsPath, 'utf8');
  const quizModuleText = readFileSync(quizModulePath, 'utf8');

  assertIncludes('index.html', indexText, `./js/bootstrap-entry.js?v=${BOOT_ID}`);
  assertIncludes('bootstrap-entry.js', bootstrapText, `const BOOT_ID = '${BOOT_ID}';`);
  assertIncludes('bootstrap-entry.js', bootstrapText, BUILD_TAG);
  assertIncludes('main.entry.js', mainText, `const BUILD_TAG = '${BUILD_TAG}';`);
  assertIncludes('main.entry.js', mainText, `// ENTRY_TAIL_SENTINEL: ${BOOT_ID}-tail`);
  assertIncludes('ENTRY_CHAIN_MANIFEST.json', manifestText, `"active_bootstrap": "js/bootstrap-entry.js?v=${BOOT_ID}"`);
  assertIncludes('ENTRY_CHAIN_MANIFEST.json', manifestText, `"active_main_entry": "js/main.entry.js?v=${BOOT_ID}"`);
  assertIncludes('ENTRY_CHAIN_MANIFEST.json', manifestText, `"active_build_tag": "${BUILD_TAG}"`);
  assertIncludes('js/core/quiz-session-utils.js', quizSessionUtilsText, 'export function beginDailyQuizSession');
  assertIncludes('js/core/quiz-session-utils.js', quizSessionUtilsText, 'export function beginBattleQuizSession');
  assertIncludes('js/modules/quiz.js', quizModuleText, 'async importQuizBulk()');
  assertIncludes('js/modules/quiz.js', quizModuleText, "async exportQuizBank(format = 'json')");

  runEsbuildBundleCheck(mainEntryPath);

  const targetUrl = new URL(`https://example.invalid/js/main.entry.js?v=${BOOT_ID}`);
  const rewrittenText = `${rewriteRelativeImports(mainText, targetUrl)}\n//# sourceURL=${targetUrl.href}`;
  writeFileSync(rewrittenPath, rewrittenText, 'utf8');
  runEsbuildParseCheck(rewrittenPath);

  console.log('ACTIVE_CHAIN_VALIDATION_OK');
  console.log(`BOOT_ID=${BOOT_ID}`);
  console.log(`BUILD_TAG=${BUILD_TAG}`);
} finally {
  rmSync(tempDir, { recursive: true, force: true });
}
