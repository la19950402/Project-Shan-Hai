#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const mainText = readFileSync('js/main.entry.js', 'utf8');
const studentText = readFileSync('js/modules/student.js', 'utf8');
const teacherText = readFileSync('js/modules/teacher-actions.js', 'utf8');
const apiSurfaceText = readFileSync('js/core/api-surface.js', 'utf8');

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

const checks = {
  ui_archive_modal_delegates_to_student_module:
    mainText.includes("showArchiveModal(index) { return studentApi.showArchiveModal.apply(this, arguments);; },"),
  app_display_team_delegates_to_student_module:
    mainText.includes("async saveDisplayTeam() { return studentApi.saveDisplayTeam.apply(this, arguments); }"),
  app_voucher_redeem_delegates_to_teacher_module:
    mainText.includes("async redeemCollectionVoucher(index) { return teacherActionsApi.redeemCollectionVoucher.apply(this, arguments); },"),
  main_no_archive_modal_body:
    !mainText.includes("const { archiveTitle: titleEl, archiveImg: imgEl, archiveHoloText: holoText, archivePrimaryActionBtn: primaryBtn, adminView } = getSystemUiDom();") &&
    !mainText.includes("this.showModal('archiveModal');"),
  main_no_voucher_teacher_mutation_body:
    !mainText.includes("source: 'teacher:voucher-redeem'") &&
    !mainText.includes("voucher.redeemedAt = Date.now();") &&
    !mainText.includes("voucher.redeemedBy = auth.currentUser?.email || auth.currentUser?.uid || 'teacher';"),
  main_no_display_team_save_body:
    !mainText.includes("data.display_team = team;") &&
    !mainText.includes("action_type: 'display_team'") &&
    !mainText.includes("UI.hideModal('displayTeamModal');"),
  student_module_owns_archive_modal:
    studentText.includes("showArchiveModal(index) {") &&
    studentText.includes("UI.showModal('archiveModal');") &&
    studentText.includes("callAppMethod('redeemCollectionVoucher', index);") &&
    studentText.includes("callStudentMethod('renderRadarChartRaw', statsObj, 'archiveRadarChart', 'archive', borderColor, bgColor);") ,
  student_module_owns_display_team_save:
    studentText.includes("async saveDisplayTeam() {") &&
    studentText.includes("action_type: 'display_team'") &&
    studentText.includes("UI.hideModal('displayTeamModal');") &&
    studentText.includes("callAppMethod('saveToDB', data);") ,
  teacher_module_owns_voucher_redeem:
    teacherText.includes("async redeemCollectionVoucher(index) {") &&
    teacherText.includes("source: 'teacher:voucher-redeem'") &&
    teacherText.includes("voucher.redeemedAt = Date.now();") &&
    teacherText.includes("voucher.redeemedBy = auth.currentUser?.email || auth.currentUser?.uid || 'teacher';") &&
    teacherText.includes("UI.hideModal('archiveModal');"),
  api_surface_still_exposes_collection_actions:
    apiSurfaceText.includes("'saveDisplayTeam'") &&
    apiSurfaceText.includes("'showArchiveModal'") &&
    apiSurfaceText.includes("'showStatusInfo'") &&
    apiSurfaceText.includes("'showAttrInfo'")
};

const summary = {
  main_showArchiveModal_count: count(/showArchiveModal\(/g, mainText),
  main_redeemCollectionVoucher_count: count(/redeemCollectionVoucher\(/g, mainText),
  main_saveDisplayTeam_count: count(/saveDisplayTeam\(/g, mainText),
  student_archive_modal_count: count(/showArchiveModal\(/g, studentText),
  student_display_team_count: count(/saveDisplayTeam\(/g, studentText),
  teacher_voucher_redeem_count: count(/redeemCollectionVoucher\(/g, teacherText)
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('PHASEC_COLLECTION_BOUNDARY_CHECK_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('PHASEC_COLLECTION_BOUNDARY_CHECK_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
