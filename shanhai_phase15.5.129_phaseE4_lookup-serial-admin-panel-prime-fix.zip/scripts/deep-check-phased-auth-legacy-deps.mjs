#!/usr/bin/env node
import { readFileSync } from 'node:fs';

function read(path) {
  return readFileSync(path, 'utf8');
}

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

const mainText = read('js/main.entry.js');
const authText = read('js/modules/auth.js');

const checks = {
  auth_module_present: authText.includes('export function createAuthModule(deps = {})'),
  auth_no_direct_document_getelementbyid: !authText.includes('document.getElementById'),
  auth_no_direct_document_listeners: !authText.includes('document.addEventListener('),
  auth_no_direct_localstorage: !authText.includes('localStorage.'),
  auth_uses_injected_document_and_storage:
    authText.includes('const docRef = documentRef || globalThis.document || null;') &&
    authText.includes('const authStorage = storage || globalThis.localStorage || null;'),
  auth_uses_dom_contract_helpers:
    authText.includes('const readLoginDom = () => (typeof getAuthLoginDom === \'function\'') &&
    authText.includes('const readViewsDom = () => (typeof getAuthViewsDom === \'function\'') &&
    authText.includes('const readAdminDiagDom = () => (typeof getAdminDiagDom === \'function\''),
  main_mounts_auth_dom_contracts:
    mainText.includes('function getAuthLoginDom() {') &&
    mainText.includes('function getAuthViewsDom() {') &&
    mainText.includes('function getAdminDiagDom() {') &&
    mainText.includes('getAuthLoginDom: (...args) => getAuthLoginDom(...args),') &&
    mainText.includes('getAuthViewsDom: (...args) => getAuthViewsDom(...args),') &&
    mainText.includes('getAdminDiagDom: (...args) => getAdminDiagDom(...args),') &&
    mainText.includes('documentRef: globalThis.document || null,') &&
    mainText.includes('storage: globalThis.localStorage || null'),
  auth_session_mode_uses_view_contract: authText.includes('const { dashboardView } = readViewsDom();'),
  auth_bind_controls_uses_login_contract: authText.includes('const { adminEmailInput, adminPwdInput, loginBtn } = readLoginDom();'),
  auth_render_diag_uses_diag_contract: authText.includes('const dom = readAdminDiagDom();') && authText.includes('setTextList(dom.buildEls, diag.build || BUILD_TAG);')
};

const summary = {
  auth_document_getelementbyid_count: count(/document\.getElementById/g, authText),
  auth_document_listener_count: count(/document\.addEventListener\(/g, authText),
  auth_localstorage_count: count(/localStorage\./g, authText),
  auth_getById_helper_count: count(/getById\(/g, authText),
  auth_read_dom_contract_count: count(/read(Login|Views|AdminDiag)Dom\(/g, authText),
  main_auth_dom_helper_count: [
    'function getAuthLoginDom() {',
    'function getAuthViewsDom() {',
    'function getAdminDiagDom() {'
  ].filter((needle) => mainText.includes(needle)).length
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASED_AUTH_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}

console.log('DEEP_CHECK_PHASED_AUTH_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
