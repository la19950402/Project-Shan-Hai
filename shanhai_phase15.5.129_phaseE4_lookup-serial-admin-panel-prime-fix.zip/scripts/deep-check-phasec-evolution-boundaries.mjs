#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';

const mainText = readFileSync('js/main.entry.js', 'utf8');
const evolutionText = readFileSync('js/modules/evolution.js', 'utf8');
const rankingText = readFileSync('js/modules/ranking.js', 'utf8');
const teacherText = readFileSync('js/modules/teacher-actions.js', 'utf8');
const batchText = readFileSync('js/modules/batch.js', 'utf8');
const shopText = readFileSync('js/modules/shop.js', 'utf8');
const zonesText = readFileSync('js/modules/zones.js', 'utf8');

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

function extractDeclaredMethodBody(source, declarationPattern) {
  const match = source.match(declarationPattern);
  if (!match || typeof match.index !== 'number') return '';
  const braceStart = source.indexOf('{', match.index);
  if (braceStart === -1) return '';
  let depth = 0;
  for (let i = braceStart; i < source.length; i += 1) {
    const ch = source[i];
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) return source.slice(braceStart + 1, i);
    }
  }
  return '';
}

const mainProcessBody = extractDeclaredMethodBody(mainText, /\n\s*processEvolution\(data\)\s*\{/);
const mainProgressBody = extractDeclaredMethodBody(mainText, /\ncomputeTrainerProgress\(data\)\s*\{/);
const mainRateBody = extractDeclaredMethodBody(mainText, /\ngetRateFromRankIndex\(rankIndex\)\s*\{/);
const mainLapBody = extractDeclaredMethodBody(mainText, /\ngetRateFromLap\(lap\)\s*\{/);
const mainValidateBody = extractDeclaredMethodBody(mainText, /\n\s*validateEvolutionTree\(\)\s*\{/);

const checks = {
  main_imports_evolution_module:
    mainText.includes(`import { createEvolutionModule } from "./modules/evolution.js?v=${BOOT_ID}";`),
  main_mounts_evolution_module:
    mainText.includes('evolutionApi = createEvolutionModule({') &&
    mainText.includes('getDominantElementFromData: (...args) => App.getDominantElementFromData(...args),') &&
    mainText.includes('getDragonVisual: (...args) => getDragonVisual(...args)'),
  main_processEvolution_delegates:
    mainProcessBody.includes('return evolutionApi?.processEvolution ? evolutionApi.processEvolution(...arguments) : data;'),
  main_computeTrainerProgress_delegates:
    mainProgressBody.includes('return evolutionApi?.computeTrainerProgress ? evolutionApi.computeTrainerProgress(...arguments)') &&
    !mainProgressBody.includes('legendaryCount >= 1') &&
    !mainProgressBody.includes('dragonItems.length'),
  main_rate_helpers_delegate:
    mainRateBody.includes('return evolutionApi?.getRateFromRankIndex ? evolutionApi.getRateFromRankIndex(...arguments) : 5;') &&
    mainLapBody.includes('return evolutionApi?.getRateFromLap ? evolutionApi.getRateFromLap(...arguments) : 5;'),
  main_validateEvolutionTree_delegates:
    mainValidateBody.includes('return evolutionApi?.validateEvolutionTree ? evolutionApi.validateEvolutionTree(...arguments) : [];'),
  main_no_evolution_rule_body:
    !mainProcessBody.includes('成熟期達成：') &&
    !mainProcessBody.includes('特殊異獸蛋') &&
    !mainProcessBody.includes("type: 'legendary'") &&
    !mainProcessBody.includes("type: 'dragon'") &&
    !mainProcessBody.includes('data.hidden_eggs = remainingEggs;'),
  evolution_module_exports_factory:
    evolutionText.includes('export function createEvolutionModule(deps = {})'),
  evolution_module_owns_rollover_rules:
    evolutionText.includes('const applyHiddenEggLegendaryRollover = (data, maxEl) => {') &&
    evolutionText.includes("type: 'legendary'") &&
    evolutionText.includes('[特殊異獸蛋]') &&
    evolutionText.includes('data.hidden_eggs = remainingEggs;'),
  evolution_module_owns_mature_archive_gate:
    evolutionText.includes('const shouldArchiveFinalDragon = afterStage >= 2 || isAdultStage;') &&
    evolutionText.includes('detail: `成熟期達成：${vis.name} 已封存，獲得新的初始龍蛋 (+${coinsEarned}🪙)`'),
  evolution_module_resets_new_egg_state:
    evolutionText.includes('const resetForNewDragonEgg = (data) => {') &&
    evolutionText.includes('data.dragon_stage = -1;') &&
    evolutionText.includes('data.dragon_path = null;') &&
    evolutionText.includes('data.attributes = defaultAttributes();') &&
    evolutionText.includes('data.debuffs = defaultDebuffs();'),
  evolution_module_no_legacy_adult_rollover_phrase:
    !evolutionText.includes('成年期滿載'),
  evolution_module_owns_progress_and_rate_rules:
    evolutionText.includes('computeTrainerProgress(data) {') &&
    evolutionText.includes('legendaryCount >= 1 && stageIdx >= 2') &&
    evolutionText.includes('getRateFromRankIndex(rankIndex) {') &&
    evolutionText.includes('getRateFromLap(lap) {'),
  downstream_modules_still_use_app_boundary:
    teacherText.includes('processEvolution,') &&
    batchText.includes('processEvolution,') &&
    shopText.includes('processEvolution,') &&
    zonesText.includes('processEvolution,'),
  ranking_still_consumes_progress_boundary:
    rankingText.includes('computeTrainerProgress(data = {}) {')
};

const summary = {
  main_lines: mainText.split('\n').length,
  evolution_lines: evolutionText.split('\n').length,
  main_processEvolution_count: count(/processEvolution\(/g, mainText),
  evolution_processEvolution_count: count(/processEvolution\(/g, evolutionText),
  main_computeTrainerProgress_count: count(/computeTrainerProgress\(/g, mainText),
  evolution_computeTrainerProgress_count: count(/computeTrainerProgress\(/g, evolutionText),
  main_rule_marker_count: count(/成熟期達成：|\[特殊異獸蛋\]|type: 'legendary'/g, mainProcessBody),
  evolution_rule_marker_count: count(/成熟期達成：|\[特殊異獸蛋\]|type: 'legendary'/g, evolutionText)
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('PHASEC_EVOLUTION_BOUNDARY_CHECK_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('PHASEC_EVOLUTION_BOUNDARY_CHECK_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
