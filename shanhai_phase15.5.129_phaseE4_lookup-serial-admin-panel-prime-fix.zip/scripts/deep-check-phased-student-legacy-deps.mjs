#!/usr/bin/env node
import { readFileSync } from 'node:fs';

function read(path) {
  return readFileSync(path, 'utf8');
}

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

const mainText = read('js/main.entry.js');
const studentText = read('js/modules/student.js');

const checks = {
  student_module_present: studentText.includes('export function createStudentModule(deps = {})'),
  student_uses_injected_document_ref: studentText.includes('const docRef = documentRef || globalThis.document || null;'),
  student_no_direct_document_getelementbyid: !studentText.includes('document.getElementById'),
  student_no_direct_document_queryselectorall: !studentText.includes('document.querySelectorAll'),
  student_no_direct_document_createelement: !studentText.includes('document.createElement'),
  student_uses_dom_contract_readers:
    studentText.includes("const readStudentDisplayDom = (prefix) => (typeof getStudentDisplayDom === 'function'") &&
    studentText.includes("const readStudentIdentityDom = () => (typeof getStudentIdentityDom === 'function'") &&
    studentText.includes("const readStudentViewDom = () => (typeof getStudentViewDom === 'function'") &&
    studentText.includes("const readStudentShopStatusDom = () => (typeof getStudentShopStatusDom === 'function'"),
  student_panel_uses_display_contract: studentText.includes('const panelDom = readStudentDisplayDom(pfx);'),
  student_identity_uses_identity_contract: studentText.includes('const identityDom = readStudentIdentityDom();'),
  student_view_uses_view_contract: studentText.includes('const studentViewDom = readStudentViewDom();'),
  student_shop_status_uses_contract: count(/const shopStatusDom = readStudentShopStatusDom\(\);/g, studentText) >= 2,
  student_lifetime_row_uses_create_node: studentText.includes("const chip = createNode('div');"),
  main_mounts_student_dom_contracts:
    mainText.includes('function getStudentDisplayDom(prefix = \'stu\') {') &&
    mainText.includes('function getStudentIdentityDom() {') &&
    mainText.includes('function getStudentViewDom() {') &&
    mainText.includes('function getStudentShopStatusDom() {') &&
    mainText.includes('getStudentDisplayDom: (...args) => getStudentDisplayDom(...args),') &&
    mainText.includes('getStudentIdentityDom: (...args) => getStudentIdentityDom(...args),') &&
    mainText.includes('getStudentViewDom: (...args) => getStudentViewDom(...args),') &&
    mainText.includes('getStudentShopStatusDom: (...args) => getStudentShopStatusDom(...args),') &&
    mainText.includes('documentRef: globalThis.document || null')
};

const summary = {
  student_document_getelementbyid_count: count(/document\.getElementById/g, studentText),
  student_document_queryselectorall_count: count(/document\.querySelectorAll/g, studentText),
  student_document_createelement_count: count(/document\.createElement/g, studentText),
  student_read_dom_contract_count: count(/readStudent(Display|Identity|View|ShopStatus)Dom\(/g, studentText),
  main_student_dom_helper_count: [
    'function getStudentDisplayDom(prefix = \'stu\') {',
    'function getStudentIdentityDom() {',
    'function getStudentViewDom() {',
    'function getStudentShopStatusDom() {'
  ].filter((needle) => mainText.includes(needle)).length
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_PHASED_STUDENT_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}

console.log('DEEP_CHECK_PHASED_STUDENT_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
