#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const mainText = readFileSync('js/main.entry.js', 'utf8');
const teacherText = readFileSync('js/modules/teacher-actions.js', 'utf8');
const studentAccessText = readFileSync('js/modules/student-access.js', 'utf8');

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

function extractDeclaredMethodBody(source, declarationPattern) {
  const match = source.match(declarationPattern);
  if (!match || typeof match.index !== 'number') return '';
  const braceStart = source.indexOf('{', match.index);
  if (braceStart === -1) return '';
  let depth = 0;
  for (let i = braceStart; i < source.length; i += 1) {
    const ch = source[i];
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) return source.slice(braceStart + 1, i);
    }
  }
  return '';
}

const mainStartPropBody = extractDeclaredMethodBody(mainText, /\n\s*startStudentPropScan\(\)\s*\{/);
const mainExecutePropBody = extractDeclaredMethodBody(mainText, /\n\s*executeStudentPropAction\(\)\s*\{/);
const mainHandleScanBody = extractDeclaredMethodBody(mainText, /\n\s*async handleCardScan\(uid\)\s*\{/);
const teacherStartPropBody = extractDeclaredMethodBody(teacherText, /\n\s*async startStudentPropScan\(\)\s*\{/);
const teacherHandlePropBody = extractDeclaredMethodBody(teacherText, /\n\s*async handleStudentPropScan\(rawKey\)\s*\{/);
const teacherHandleForgeBody = extractDeclaredMethodBody(teacherText, /\n\s*async handleForgeScan\(rawKey\)\s*\{/);
const teacherExecutePropBody = extractDeclaredMethodBody(teacherText, /\n\s*async executeStudentPropAction\(action\)\s*\{/);

const checks = {
  main_delegates_student_prop_methods:
    mainStartPropBody.includes('return teacherActionsApi.startStudentPropScan.apply(this, arguments);') &&
    mainExecutePropBody.includes('return teacherActionsApi.executeStudentPropAction.apply(this, arguments);'),
  main_handleCardScan_delegates_forge_and_student_prop:
    mainHandleScanBody.includes("await teacherActionsApi.handleStudentPropScan.call(this, rawKey);") &&
    mainHandleScanBody.includes("await teacherActionsApi.handleForgeScan.call(this, rawKey);") &&
    !mainText.includes("this.executeStudentPropAction(actionData);") &&
    !mainText.includes("await studentAccessApi.bindPendingForgeActionCard(rawKey);") &&
    !mainText.includes("window.history.replaceState(null, '', `?view=student&serial=${resolved.serial}`);"),
  main_mounts_teacher_actions_with_action_card_hooks:
    mainText.includes('getActionCardPayload: (...args) => studentAccessApi?.getActionCardPayload(...args),') &&
    mainText.includes('bindPendingForgeActionCard: (...args) => studentAccessApi?.bindPendingForgeActionCard(...args),') &&
    mainText.includes('resolveStudentRecordFromScanKey: (...args) => studentAccessApi?.resolveStudentRecordFromScanKey(...args)'),
  teacher_module_owns_forge_binding_flow:
    teacherHandleForgeBody.includes("await bindPendingForgeActionCard(rawKey);") &&
    teacherHandleForgeBody.includes("UI.hideModal('cardForgeModal');") &&
    teacherHandleForgeBody.includes("UI.toast('✅ 道具卡鑄造綁定成功！');"),
  teacher_module_owns_student_prop_scan_flow:
    teacherStartPropBody.includes("currentState.scanIntention = 'student_prop';") &&
    teacherHandlePropBody.includes("const actionData = typeof getActionCardPayload === 'function' ? await getActionCardPayload(rawKey) : null;") &&
    teacherHandlePropBody.includes("await teacherApi.executeStudentPropAction.call(this, actionData);") &&
    teacherHandlePropBody.includes("window.history.replaceState(null, '', `?view=student&serial=${resolved.serial}`);") &&
    teacherHandlePropBody.includes("this.loadStudentData(resolved.serial, 'student', {"),
  teacher_module_owns_student_prop_execution:
    teacherExecutePropBody.includes("if (action && (action.type === 'debuff' || action.debuffKey)) {") &&
    teacherExecutePropBody.includes("if (await teacherApi.checkDeathTrigger.call(this, data, debuffKey)) return currentState.studentData;") &&
    teacherExecutePropBody.includes("const saved = await saveToDB(data);") &&
    teacherExecutePropBody.includes("data = processEvolution(data);") &&
    teacherExecutePropBody.includes("const panel = document.getElementById('studentView')?.querySelector?.('.tech-panel');"),
  student_access_still_owns_action_card_storage:
    studentAccessText.includes("async getActionCardPayload(rawKey) {") &&
    studentAccessText.includes("async bindPendingForgeActionCard(rawKey) {") &&
    studentAccessText.includes("await setDoc(doc(db, 'action_cards', normalizedKey), currentState.pendingForgeData);")
};

const summary = {
  main_lines: mainText.split('\n').length,
  teacher_lines: teacherText.split('\n').length,
  main_saveToDB_count: count(/saveToDB\(/g, mainText),
  main_action_card_markers: count(/student_prop|forge|actionCard|action_cards|getActionCardPayload|bindPendingForgeActionCard/g, mainHandleScanBody),
  teacher_forge_markers: count(/student_prop|forge|actionCard|action_cards|getActionCardPayload|bindPendingForgeActionCard/g, teacherText),
  student_access_action_card_markers: count(/action_cards|getActionCardPayload|bindPendingForgeActionCard/g, studentAccessText)
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('PHASEC_FORGE_ACTIONCARD_BOUNDARY_CHECK_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('PHASEC_FORGE_ACTIONCARD_BOUNDARY_CHECK_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
