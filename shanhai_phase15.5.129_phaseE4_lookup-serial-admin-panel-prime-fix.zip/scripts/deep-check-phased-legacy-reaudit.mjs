import fs from 'node:fs';

const read = (p) => fs.readFileSync(p, 'utf8');
const count = (re, text) => (text.match(re) || []).length;

const mainText = read('js/main.entry.js');
const batchText = read('js/modules/batch.js');
const authText = read('js/modules/auth.js');
const studentText = read('js/modules/student.js');

const checks = {
  batch_no_legacy_state_import: !batchText.includes('from "../core/state.js'),
  batch_no_legacy_ui_import: !batchText.includes('from "../core/ui.js'),
  batch_no_direct_document_getelementbyid: !batchText.includes('document.getElementById'),
  batch_has_batchmode_dom_reader: batchText.includes('const readBatchModeDom = () =>'),
  batch_mount_injects_state_ui_dom:
    mainText.includes('currentState, batchState, UI,') &&
    mainText.includes('getBatchModeDom: (...args) => getBatchModeDom(...args)'),
  auth_no_direct_document_getelementbyid: !authText.includes('document.getElementById'),
  auth_no_direct_document_listeners: !authText.includes('document.addEventListener('),
  auth_no_direct_localstorage_write: !authText.includes('localStorage.'),
  student_no_direct_document_getelementbyid: !studentText.includes('document.getElementById'),
  student_no_direct_document_queryselectorall: !studentText.includes('document.querySelectorAll'),
  student_no_direct_document_createelement: !studentText.includes('document.createElement'),
};

const failures = Object.entries(checks).filter(([, ok]) => !ok);
const metrics = {
  main_lines: mainText.split('\n').length,
  batch_lines: batchText.split('\n').length,
  auth_lines: authText.split('\n').length,
  student_lines: studentText.split('\n').length,
  batch_direct_document_getelementbyid_count: count(/document\.getElementById/g, batchText),
  batch_legacy_state_import_count: count(/from "\.\.\/core\/state\.js|from '\.\.\/core\/state\.js/g, batchText),
  batch_legacy_ui_import_count: count(/from "\.\.\/core\/ui\.js|from '\.\.\/core\/ui\.js/g, batchText),
  auth_direct_document_getelementbyid_count: count(/document\.getElementById/g, authText),
  student_direct_document_createelement_count: count(/document\.createElement/g, studentText),
};

console.log(JSON.stringify({ checks, metrics, failures }, null, 2));

if (failures.length) process.exit(1);
