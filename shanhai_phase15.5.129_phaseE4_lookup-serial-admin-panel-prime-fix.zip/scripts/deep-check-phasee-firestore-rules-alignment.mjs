import fs from 'fs';
import path from 'path';

const root = process.cwd();
const rulesPath = path.join(root, 'firestore.rules');
const reportPath = path.join(root, 'FIRESTORE_RULES_ALIGNMENT.md');
const deployPath = path.join(root, 'DEPLOY_CHECKLIST.md');
const smokePath = path.join(root, 'SMOKE_TEST_ACTIVE_CHAIN.md');
const entryManifestPath = path.join(root, 'js', 'ENTRY_CHAIN_MANIFEST.json');
const moduleManifestPath = path.join(root, 'js', 'MODULE_VARIANT_MANIFEST.json');

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

function ensure(file, label) {
  if (!fs.existsSync(file)) throw new Error(`${label} missing: ${path.relative(root, file)}`);
}

ensure(rulesPath, 'firestore rules');
ensure(reportPath, 'rules alignment report');
ensure(deployPath, 'deploy checklist');
ensure(smokePath, 'smoke doc');
ensure(entryManifestPath, 'entry manifest');
ensure(moduleManifestPath, 'module manifest');

const rules = read(rulesPath);
const report = read(reportPath);
const deploy = read(deployPath);
const smoke = read(smokePath);
const entryManifest = JSON.parse(read(entryManifestPath));
const moduleManifest = JSON.parse(read(moduleManifestPath));

const expectedMatches = [
  '/admins/{uid}',
  '/students/{serial}',
  '/tag_tokens/{token}',
  '/student_pages/{token}',
  '/cards/{uid}',
  '/action_cards/{cardId}',
  '/quiz_bank/{docId}',
  '/quiz_pool_public/{audienceKey}',
  '/leaderboard_public/{serial}',
  '/shop_catalog/{itemId}',
  '/shop_catalog_public/{itemId}',
  '/legendary_bank/{docId}',
  '/support_zone_records/{docId}',
  '/science_zone_records/{docId}'
];

const expectedRulesSnippets = [
  "function isAdmin()",
  "function isActiveToken(token)",
  "docId == '_BATTLE_TOWER_BOSS_'",
  'resource.data.isActive == true',
  'allow get: if isActiveToken(token) || isAdmin();',
  'allow create, update, delete: if isAdmin();'
];

for (const match of expectedMatches) {
  if (!rules.includes(`match ${match}`)) throw new Error(`firestore.rules missing match block: ${match}`);
}
for (const snippet of expectedRulesSnippets) {
  if (!rules.includes(snippet)) throw new Error(`firestore.rules missing snippet: ${snippet}`);
}

const braceBalance = [...rules].reduce((n, ch) => n + (ch === '{' ? 1 : ch === '}' ? -1 : 0), 0);
if (braceBalance !== 0) throw new Error(`firestore.rules brace imbalance: ${braceBalance}`);
if (!report.includes('Special case: `quiz_bank`')) throw new Error('alignment report missing quiz_bank compromise section');
if (!report.includes('student_pages/{token}')) throw new Error('alignment report missing student_pages token section');
if (!/Firestore/i.test(deploy) || !/student_pages\/\{token\}/.test(smoke)) throw new Error('governance docs not aligned with rules rollout');

const riskNotes = Array.isArray(moduleManifest.riskNotes) ? moduleManifest.riskNotes : [];
if (!riskNotes.some((note) => /Firestore Rules/i.test(String(note)))) {
  throw new Error('module manifest riskNotes missing Firestore Rules context');
}

const active = entryManifest?.active || {};
const activeModules = entryManifest?.activeModuleVariants || {};
if (active.mainEntry !== 'js/main.entry.js') throw new Error('entry manifest active mainEntry drifted');
if (activeModules.quiz !== 'js/modules/quiz.js') throw new Error('entry manifest quiz module drifted');

const summary = {
  firestore_rules_exists: true,
  alignment_report_exists: true,
  rules_match_blocks: expectedMatches.length,
  rules_brace_balance: braceBalance,
  deploy_doc_mentions_firestore: /Firestore/i.test(deploy),
  smoke_doc_mentions_student_pages: /student_pages\/{token}/.test(smoke),
  entry_main: active.mainEntry,
  active_quiz_module: activeModules.quiz,
  module_risk_notes_count: riskNotes.length
};

console.log('deep-check-phasee-firestore-rules-alignment: PASS');
console.log(JSON.stringify(summary, null, 2));
