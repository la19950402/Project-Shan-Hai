#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';
const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';

function read(path) {
  return readFileSync(path, 'utf8');
}

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

const indexText = read('index.html');
const bootstrapText = read('js/bootstrap-entry.js');
const mainText = read('js/main.entry.js');
const teacherText = read('js/modules/teacher-actions.js');
const studentText = read('js/modules/student.js');
const battleText = read('js/modules/battle.js');
const stateText = read('js/core/state.js');
const quizSessionUtilsText = read('js/core/quiz-session-utils.js');
const manifestText = read('js/ENTRY_CHAIN_MANIFEST.json');
const apiSurfaceText = read('js/core/api-surface.js');
const legendaryText = read('js/modules/legendary.js');
const shopText = read('js/modules/shop.js');
const quizText = read('js/modules/quiz.js');
const studentAccessText = read('js/modules/student-access.js');

const checks = {
  version_in_index: indexText.includes(`./js/bootstrap-entry.js?v=${BOOT_ID}`),
  version_in_bootstrap: bootstrapText.includes(`const BOOT_ID = '${BOOT_ID}';`),
  build_tag_in_main: mainText.includes(`const BUILD_TAG = '${BUILD_TAG}';`),
  tail_sentinel: mainText.includes(`// ENTRY_TAIL_SENTINEL: ${BOOT_ID}-tail`),
  manifest_aligned:
    manifestText.includes(`"active_bootstrap": "js/bootstrap-entry.js?v=${BOOT_ID}"`) &&
    manifestText.includes(`"active_build_tag": "${BUILD_TAG}"`),
  teacher_mutation_helper: teacherText.includes('async function runTeacherMutation(app, options = {})'),
  gift_uses_teacher_helper: shopText.includes("source: 'shop-admin:apply-gift'"),
  voucher_uses_teacher_helper:
    mainText.includes("source: 'teacher:voucher-redeem'") ||
    (mainText.includes("async redeemCollectionVoucher(index) { return teacherActionsApi.redeemCollectionVoucher.apply(this, arguments); },") &&
     teacherText.includes("source: 'teacher:voucher-redeem'") &&
     teacherText.includes("async redeemCollectionVoucher(index) {")),
  hacker_actions_removed:
    !mainText.includes('async punishHacker()') &&
    !mainText.includes('async rollbackHacker()') &&
    !indexText.includes('App.punishHacker()') &&
    !indexText.includes('App.rollbackHacker()') &&
    !apiSurfaceText.includes('punishHacker') &&
    !apiSurfaceText.includes('rollbackHacker'),
  lookup_defers_selection: mainText.includes('deferSelection: true') && teacherText.includes('if (options.deferSelection === true)'),
  teacher_mutation_serial_sync: teacherText.includes('function resolveTeacherMutationSerial') && teacherText.includes('await waitForStudentHydrationTarget(resolvedSerial'),
  student_bind_start_sync: studentText.includes("action: 'admin-bind-start'") && studentText.includes('activeToken: bindToken'),
  student_signature_guard: studentText.includes('buildStudentRenderSignature') && studentText.includes('admin-snapshot-same'),
  student_same_target_rebind_guard: studentText.includes('alreadyShowingRequestedAdminTarget') && studentText.includes('admin-preloaded-same-target'),
  student_same_target_shows_panel: studentText.includes("UI.show('adminStudentPanel');") && studentText.includes("UI.hideModal('previewPanel');"),
  main_lookup_autoheals_student_mirror: mainText.includes("student-mirror:autoheal:lookupByCardSeq") && mainText.includes("student-mirror:autoheal:amLookupSerial") && mainText.includes("student-mirror:autoheal:nfc-read"),
  student_load_context_fields: stateText.includes('studentLoadMode') && stateText.includes('studentLoadRequestedUid') && stateText.includes('studentLoadActiveSerial'),
  student_docref_uses_normalized_serial: studentText.includes('doc(db, COLLECTION_NAME, requestedSerial || uid)'),
  quiz_session_schema_extended:
    stateText.includes('QUIZ_SESSION_INITIAL_STATE') &&
    stateText.includes('QUIZ_SESSION_RUNTIME_FIELDS') &&
    stateText.includes('createQuizSessionSnapshot') &&
    stateText.includes('lastDailySessionToken'),
  quiz_session_utils_present:
    quizSessionUtilsText.includes('export function resetQuizSession') &&
    quizSessionUtilsText.includes('export function beginQuizSession') &&
    quizSessionUtilsText.includes('export function beginDailyQuizSession') &&
    quizSessionUtilsText.includes('export function beginBattleQuizSession') &&
    quizSessionUtilsText.includes('export function abortQuizSession'),
  app_session_wrappers_delegate:
    mainText.includes('return resetQuizSessionCore(overrides);') &&
    mainText.includes('return beginQuizSessionCore(mode, overrides);') &&
    mainText.includes('return abortQuizSessionCore(reason, overrides);') &&
    mainText.includes('return scheduleQuizAdvanceCore(callback, delay, expectedToken);'),
  daily_uses_session_helper:
    mainText.includes('const dailySessionToken = beginDailyQuizSessionCore({') &&
    !mainText.includes('quizSession.dailyRemainingAtStart = remainingRewardCount;') &&
    !mainText.includes('quizSession.lastDailySessionToken = dailySessionToken;'),
  battle_uses_session_helper:
    battleText.includes("beginQuizSession('battle', { questions: [qD], currentIndex: 0, score: 0 });") &&
    battleText.includes("beginBattleQuizSession(qD, 'battle');") &&
    !battleText.includes("quizSession.questions = [qD];"),
  battle_parser_extended: battleText.includes('source.correctIdx') && battleText.includes('source.optionA') && battleText.includes('source.content'),
  battle_string_options_regex: battleText.includes(String.raw`split(/\r?\n|\|/)`),
  battle_uses_quiz_route_helpers:
    battleText.includes("typeof loadBattleGatekeeperQuestion === 'function'") &&
    battleText.includes("typeof loadBattleTowerConfigDoc === 'function'") &&
    battleText.includes("typeof listBattleGatekeeperQuestions === 'function'") &&
    battleText.includes("typeof saveBattleTowerAudienceConfig === 'function'") &&
    battleText.includes("typeof clearBattleTowerAudienceConfig === 'function'"),
  battle_no_direct_gatekeeper_getdoc: !battleText.includes("const s = await getDoc(doc(db, 'quiz_bank', gatekeeperQuizId));"),
  battle_no_direct_boss_config_read: !battleText.includes("await getDoc(doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_'));") && !battleText.includes("const snap = await getDoc(doc(db, 'quiz_bank', BATTLE_TOWER_DOC_ID));"),
  battle_no_direct_boss_config_write: !battleText.includes("await setDoc(ref, normalized);") && !battleText.includes("await deleteDoc(ref);") && !battleText.includes("const ref = doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_');"),
  legendary_module_split: mainText.includes('createLegendaryModule') && mainText.includes('legendaryApi = createLegendaryModule({') && legendaryText.includes('export function createLegendaryModule'),
  main_no_direct_legendary_getdocs: !mainText.includes("getDocs(collection(db, 'legendary_bank'))"),
  main_no_direct_legendary_adddoc: !mainText.includes("addDoc(collection(db, 'legendary_bank')"),
  main_no_direct_legendary_deletedoc: !mainText.includes("deleteDoc(doc(db, 'legendary_bank'"),
  main_no_direct_legendary_updatedoc: !mainText.includes('updateDoc(legRef'),
  legendary_exchange_counter_update: legendaryText.includes('await updateDoc(legRef, { exchangedCount: exchanged + 1 });'),
  shop_module_split: mainText.includes('shopApi = createShopModule({') && shopText.includes('export function createShopModule'),
  main_no_direct_shop_catalog_scan: !mainText.includes('const snap = await getDocs(collection(db, SHOP_COLLECTION));'),
  main_no_direct_shop_setdoc: !mainText.includes('setDoc(doc(db, SHOP_COLLECTION, id), payload, { merge: false });') && !mainText.includes('setDoc(ref, payload, { merge: true });'),
  main_no_direct_shop_deletedoc: !mainText.includes('deleteDoc(doc(db, SHOP_COLLECTION, productId))'),
  main_shop_delegates: mainText.includes('return shopApi.renderShopItems(...arguments);') && mainText.includes('return shopApi.sendShopGift(...arguments);') && mainText.includes('return shopApi.saveShopProduct(...arguments);'),
  main_shop_student_flow_delegates:
    mainText.includes('async openShop() { return shopApi.openShop(...arguments); },') &&
    mainText.includes('async applyShopEffect() { return shopApi.applyShopEffect(...arguments); },') &&
    mainText.includes('async handleShopPurchase() { return shopApi.handleShopPurchase(...arguments); },'),
  main_no_direct_shop_purchase_getdoc: !mainText.includes('const snap = await getDoc(itemRef);') && !mainText.includes('const latest = await getDoc(itemRef);'),
  main_no_direct_shop_purchase_updatedoc: !mainText.includes('await updateDoc(itemRef, { quantity: Math.max(0, q - 1), updatedAt: Date.now() });'),
  shop_student_purchase_in_module:
    shopText.includes("async applyShopEffect(data, itemMeta, cost)") &&
    shopText.includes("const effectResult = await shopApi.applyShopEffect(data, itemMeta, cost);") &&
    shopText.includes("await updateDoc(itemRef, { quantity: Math.max(0, q - 1), updatedAt: Date.now() });"),
  shop_teacher_save_bridge: shopText.includes("source: 'shop-admin:apply-gift'") && shopText.includes('teacherActionsApi.runTeacherMutation.call(globalThis.App || teacherActionsApi,'),
  shop_fill_current_student: shopText.includes('fillShopGiftCurrentStudent()'),
  quiz_module_split: mainText.includes('quizApi = createQuizModule({') && quizText.includes('export function createQuizModule'),
  main_quiz_manager_delegates:
    mainText.includes('async openEditQuiz() { return quizApi.openEditQuiz(...arguments); },') &&
    mainText.includes('async importQuizBulk() { return quizApi.importQuizBulk(...arguments); },') &&
    mainText.includes('async exportQuizBank() { return quizApi.exportQuizBank(...arguments); },') &&
    mainText.includes('async batchSetQuizActive() { return quizApi.batchSetQuizActive(...arguments); },') &&
    mainText.includes('async batchDeleteSelectedQuizzes() { return quizApi.batchDeleteSelectedQuizzes(...arguments); },') &&
    mainText.includes('async loadQuizBank() { return quizApi.loadQuizBank(...arguments); },') &&
    mainText.includes('async saveNewQuiz() { return quizApi.saveNewQuiz(...arguments); },') &&
    mainText.includes('async saveEditedQuiz() { return quizApi.saveEditedQuiz(...arguments); },') &&
    mainText.includes('async deleteQuiz() { return quizApi.deleteQuiz(...arguments); },') &&
    mainText.includes('async toggleQuizActive() { return quizApi.toggleQuizActive(...arguments); },'),
  main_no_direct_quiz_manager_adddoc: !mainText.includes("await addDoc(collection(db, 'quiz_bank'), newQuiz);") && !mainText.includes("await addDoc(collection(db, 'quiz_bank'), { ...item, timestamp: Date.now() });"),
  main_no_direct_quiz_manager_updatedoc: !mainText.includes("await updateDoc(doc(db, 'quiz_bank', editId)") && !mainText.includes("await updateDoc(doc(db, 'quiz_bank', id), { isActive: !currentStatus, updatedAt: Date.now() });"),
  main_no_direct_quiz_manager_deletedoc: !mainText.includes("await deleteDoc(doc(db, 'quiz_bank', id));"),
  main_no_direct_quiz_manager_batch: !mainText.includes("selectedIds.forEach(id => batch.update(doc(db, 'quiz_bank', id), { isActive: !!active, updatedAt: Date.now() }))") && !mainText.includes("selectedIds.forEach(id => batch.delete(doc(db, 'quiz_bank', id)))"),

  main_quiz_pool_delegates:
    mainText.includes('normalizeQuizPoolAudienceKey() { return quizApi.normalizeQuizPoolAudienceKey(...arguments); },') &&
    mainText.includes('async loadQuizPoolAudienceDoc() { return quizApi.loadQuizPoolAudienceDoc(...arguments); },') &&
    mainText.includes('syncQuizPoolSummaryFromQuizBank() { return quizApi.syncQuizPoolSummaryFromQuizBank(...arguments); },') &&
    mainText.includes('async warmStudentQuizPool() { return quizApi.warmStudentQuizPool(...arguments); },'),
  main_battle_quiz_delegates:
    mainText.includes('async loadBattleTowerConfigDoc() { return quizApi.loadBattleTowerConfigDoc(...arguments); },') &&
    mainText.includes('async listBattleGatekeeperQuestions() { return quizApi.listBattleGatekeeperQuestions(...arguments); },') &&
    mainText.includes('async pickBattleGatekeeperQuestion() { return quizApi.pickBattleGatekeeperQuestion(...arguments); },') &&
    mainText.includes('async loadBattleGatekeeperQuestion() { return quizApi.loadBattleGatekeeperQuestion(...arguments); },') &&
    mainText.includes('async saveBattleTowerAudienceConfig() { return quizApi.saveBattleTowerAudienceConfig(...arguments); },') &&
    mainText.includes('async clearBattleTowerAudienceConfig() { return quizApi.clearBattleTowerAudienceConfig(...arguments); },'),
  main_no_direct_quiz_pool_active_query:
    !mainText.includes("snapshot = await getDocs(query(collection(db, 'quiz_bank'), where('isActive', '==', true), limit(240)));") &&
    !mainText.includes("console.warn('[warmStudentQuizPool] active-query failed, fallback to full scan:'"),
  quiz_module_handles_quiz_pool:
    quizText.includes("async loadQuizPoolAudienceDoc(audienceKey = 'default')") &&
    quizText.includes('syncQuizPoolSummaryFromQuizBank(options = {})') &&
    quizText.includes('async warmStudentQuizPool(options = {})') &&
    quizText.includes("snapshot = await getDocs(query(collection(db, 'quiz_bank'), where('isActive', '==', true), limit(240)));") &&
    quizText.includes("console.warn('[warmStudentQuizPool] quiz_pool_public failed, fallback to direct query:'"),
  quiz_module_handles_import_export:
    quizText.includes("async importQuizBulk()") &&
    quizText.includes("async exportQuizBank(format = 'json')") &&
    quizText.includes("await addDoc(collection(db, 'quiz_bank'), { ...item, timestamp: Date.now() });") &&
    quizText.includes("downloadTextFile(`quiz_bank_${formatLocalDateKey()}.json`") ,
  quiz_module_handles_battle_route:
    (quizText.includes("async loadBattleTowerConfigDoc(docId = BATTLE_TOWER_DOC_ID)") || quizText.includes("async loadBattleTowerConfigDoc(docId = BATTLE_TOWER_DOC_ID, options = {})")) &&
    quizText.includes("async saveBattleTowerAudienceConfig(audiencePayload = {}, options = {})") &&
    quizText.includes("async clearBattleTowerAudienceConfig(audienceKey = 'default')") &&
    quizText.includes("async listBattleGatekeeperQuestions(audienceKey = 'default')") &&
    quizText.includes("async pickBattleGatekeeperQuestion(options = {})") &&
    quizText.includes("async loadBattleGatekeeperQuestion(gatekeeperQuizId = 'random', options = {})"),
  main_save_hub_delegates_to_student_access:
    mainText.includes('isFastAdminSaveMode(...args) { return studentAccessApi.isFastAdminSaveMode(...args); },') &&
    mainText.includes('async saveToDB(...args) { return studentAccessApi.saveToDB(...args); },'),
  student_access_save_hub_present:
    (mainText.includes('const delegatedSaveToDB = (...args) => App.saveToDB(...args);') ||
      mainText.includes('function delegatedSaveToDB(...args) { return App.saveToDB(...args); }')) &&
    studentText.includes('saveDisplayTeam') === true &&
    studentAccessText.includes('async saveToDB(dataObj, explicitUid = null)') &&
    studentAccessText.includes('isFastAdminSaveMode(explicitUid = null)') &&
    studentAccessText.includes('return await this.saveStudentTokenPayload(payload, explicitUid);') &&
    studentAccessText.includes('return await this.saveFastAdminStudentPayload(payload, serial);') &&
    studentAccessText.includes('return await this.saveCanonicalStudentPayload(payload, serial);'),

};

const summary = {
  main_getDocs_count: count(/\bgetDocs\s*\(/g, mainText),
  main_saveToDB_count: count(/\bsaveToDB\s*\(/g, mainText),
  main_teacher_mutation_call_count: count(/runTeacherMutation\.call\(this/g, mainText),
  load_student_call_count: count(/loadStudentData\(/g, mainText),
  lookup_defer_selection_count: count(/deferSelection:\s*true/g, mainText),
  student_mirror_autoheal_count: count(/student-mirror:autoheal:/g, mainText),
  teacher_context_sync_count: count(/syncTeacherTargetContext\(/g, studentText) + count(/syncTeacherTargetContext\(/g, teacherText),
  main_legendary_bank_refs: count(/legendary_bank/g, mainText),
  legendary_module_getDocs_count: count(/\bgetDocs\s*\(/g, legendaryText),
  shop_module_getDocs_count: count(/\bgetDocs\s*\(/g, shopText),
  shop_module_getDoc_count: count(/\bgetDoc\s*\(/g, shopText),
  shop_module_updateDoc_count: count(/\bupdateDoc\s*\(/g, shopText),
  main_shop_collection_refs: count(/SHOP_COLLECTION/g, mainText),
  main_shop_purchase_delegate_count: count(/shopApi\.(openShop|applyShopEffect|handleShopPurchase)\(\.\.\.arguments\);/g, mainText),
  main_quiz_bank_refs: count(/collection\(db, 'quiz_bank'\)/g, mainText),
  quiz_module_getDocs_count: count(/\bgetDocs\s*\(/g, quizText),
  quiz_module_addDoc_count: count(/\baddDoc\s*\(/g, quizText),
  quiz_module_updateDoc_count: count(/\bupdateDoc\s*\(/g, quizText),
  quiz_module_deleteDoc_count: count(/\bdeleteDoc\s*\(/g, quizText),
  battle_quiz_bank_getDoc_count: count(/getDoc\(doc\(db, 'quiz_bank'/g, battleText),
  battle_quiz_bank_getDocs_count: count(/getDocs\(collection\(db, 'quiz_bank'\)\)/g, battleText),
  battle_quiz_bank_setDoc_count: count(/setDoc\(ref, normalized\)/g, battleText),
  battle_quiz_bank_deleteDoc_count: count(/deleteDoc\(ref\)/g, battleText),
  main_quiz_pool_delegate_count: count(/quizApi\.(normalizeQuizPoolAudienceKey|loadQuizPoolAudienceDoc|syncQuizPoolSummaryFromQuizBank|warmStudentQuizPool)\(\.\.\.arguments\);/g, mainText),
  main_battle_quiz_delegate_count: count(/quizApi\.(loadBattleTowerConfigDoc|listBattleGatekeeperQuestions|pickBattleGatekeeperQuestion|loadBattleGatekeeperQuestion|saveBattleTowerAudienceConfig|clearBattleTowerAudienceConfig)\(\.\.\.arguments\);/g, mainText),
  quiz_session_helper_reference_count:
    count(/resetQuizSessionCore\(/g, mainText) +
    count(/beginQuizSessionCore\(/g, mainText) +
    count(/beginDailyQuizSessionCore\(/g, mainText) +
    count(/beginBattleQuizSession\(/g, battleText),
  quiz_session_runtime_field_count: count(/^[ ]{2}[a-zA-Z][a-zA-Z0-9]+:/gm, stateText)
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('DEEP_CHECK_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('DEEP_CHECK_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
