import fs from 'fs';

const student = fs.readFileSync('js/modules/student.js', 'utf8');
const issues = [];

if (!student.includes("shouldPersistRecoveredDebuffs = Boolean(callStudentMethod('checkDebuffRecovery', data));")) {
  issues.push('student load no longer persists debuff recovery through deferred save guard');
}
if (student.includes("if (callStudentMethod('checkDebuffRecovery', data)) { callAppMethod('saveToDB', data); return { data, mergeMasterPromise }; }")) {
  issues.push('student load still short-circuits render on debuff recovery');
}
if (!student.includes("callStudentMethod('refreshStudentIdentityLabels', data);")) {
  issues.push('loaded student snapshots no longer refresh shared identity labels');
}
if (!student.includes("const studentViewHidden = !isVisibleEl(studentViewDom.studentView);")) {
  issues.push('student reward panel still uses fragile studentView visibility detection');
}
if (!student.includes("const adminPanelVisible = isVisibleEl(studentViewDom.adminStudentPanel);")) {
  issues.push('student reward panel still uses fragile admin panel visibility detection');
}
if (!student.includes("const isAdminView = isVisibleEl(adminView);")) {
  issues.push('archive voucher view still uses fragile admin visibility detection');
}

if (issues.length) {
  console.error('Student load/display deep check failed:');
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}

console.log('Student load/display deep check passed.');
