import fs from 'node:fs';

const studentText = fs.readFileSync(new URL('../js/modules/student.js', import.meta.url), 'utf8');
const quizText = fs.readFileSync(new URL('../js/modules/quiz.js', import.meta.url), 'utf8');
const legendaryText = fs.readFileSync(new URL('../js/modules/legendary.js', import.meta.url), 'utf8');

const checks = {
  student_master_cache_present:
    studentText.includes('const masterStudentRecordCache = {') &&
    studentText.includes('const loadMasterStudentRecord = async (serial, options = {}) => {') &&
    studentText.includes("const masterData = await loadMasterStudentRecord(currentState.currentUid, { maxAgeMs: 12000 });"),
  student_aux_refresh_scheduled:
    studentText.includes('const scheduleStudentAuxPanelsRefresh = (data = {}) => {') &&
    studentText.includes('currentState.studentAuxRefreshTimer = setTimeout(() => {') &&
    studentText.includes('scheduleStudentAuxPanelsRefresh(data);'),
  quiz_bank_cached_render_present:
    quizText.includes('const forceRefresh = !!options.forceRefresh;') &&
    quizText.includes('const hasFreshCache = cachedQuizzes.length > 0') &&
    quizText.includes('if (cachedQuizzes.length) renderCachedQuizBank(cachedQuizzes);') &&
    quizText.includes('currentState.quizBankLoadedAt = Date.now();'),
  quiz_mutations_force_refresh:
    (quizText.match(/await quizApi\.loadQuizBank\(\{ forceRefresh: true \}\);/g) || []).length >= 5,
  battle_tower_config_cache_present:
    quizText.includes('const battleTowerConfigCache = { docId: \'\', data: null, loadedAt: 0, promise: null };') &&
    quizText.includes('async loadBattleTowerConfigDoc(docId = BATTLE_TOWER_DOC_ID, options = {}) {') &&
    quizText.includes('battleTowerConfigCache.data = payload ? JSON.parse(JSON.stringify(payload)) : null;'),
  legendary_items_cache_present:
    legendaryText.includes('const legendaryItemsCache = { items: null, loadedAt: 0, promise: null };') &&
    legendaryText.includes('async function fetchLegendaryItems(options = {}) {') &&
    legendaryText.includes('legendaryItemsCache.items = items;'),
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('LOAD_HOTSPOT_DEEP_CHECK_FAILED');
  console.error(JSON.stringify({ checks, failed }, null, 2));
  process.exit(1);
}
console.log('LOAD_HOTSPOT_DEEP_CHECK_OK');
console.log(JSON.stringify({ checks }, null, 2));
