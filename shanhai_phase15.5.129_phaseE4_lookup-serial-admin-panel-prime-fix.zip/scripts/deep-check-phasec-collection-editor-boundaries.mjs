#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const mainText = readFileSync('js/main.entry.js', 'utf8');
const studentText = readFileSync('js/modules/student.js', 'utf8');
const apiSurfaceText = readFileSync('js/core/api-surface.js', 'utf8');

function count(pattern, text) {
  const matches = text.match(pattern);
  return matches ? matches.length : 0;
}

function extractDeclaredMethodBody(source, declarationPattern) {
  const match = source.match(declarationPattern);
  if (!match || typeof match.index !== 'number') return '';
  const braceStart = source.indexOf('{', match.index);
  if (braceStart === -1) return '';
  let depth = 0;
  for (let i = braceStart; i < source.length; i += 1) {
    const ch = source[i];
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) return source.slice(braceStart + 1, i);
    }
  }
  return '';
}

const mainOpenBody = extractDeclaredMethodBody(mainText, /\n\s*openDisplayTeamEditor\(\)\s*\{/);
const mainToggleBody = extractDeclaredMethodBody(mainText, /\n\s*toggleDisplayTeamItem\(\)\s*\{/);
const studentOpenBody = extractDeclaredMethodBody(studentText, /\n\s*openDisplayTeamEditor\(\)\s*\{/);
const studentToggleBody = extractDeclaredMethodBody(studentText, /\n\s*toggleDisplayTeamItem\(idx\)\s*\{/);

const checks = {
  main_delegates_display_team_editor:
    mainOpenBody.includes('return studentApi.openDisplayTeamEditor.apply(this, arguments);') &&
    mainToggleBody.includes('return studentApi.toggleDisplayTeamItem.apply(this, arguments);'),
  main_no_display_team_editor_body:
    !mainText.includes('currentState.tempDisplayTeam = [...new Set(selected)].slice(0, 5);') &&
    !mainText.includes('onclick="App.toggleDisplayTeamItem(${idx})"') &&
    !mainText.includes('const el = DomBridge.get(`dtItem_${idx}`);') &&
    !mainText.includes('UI.toast("最多只能選 5 隻展示！")'),
  student_module_owns_display_team_editor:
    studentOpenBody.includes('currentState.tempDisplayTeam = [...new Set(selected)].slice(0, 5);') &&
    studentOpenBody.includes('onclick="App.toggleDisplayTeamItem(${idx})"') &&
    studentOpenBody.includes('hydrateStorageImages(grid);') &&
    studentOpenBody.includes("UI.showModal('displayTeamModal');"),
  student_module_owns_display_team_toggle:
    studentToggleBody.includes('const nextIdx = Number(idx);') &&
    studentToggleBody.includes('const el = getById(`dtItem_${nextIdx}`);') &&
    studentToggleBody.includes("UI.toast('最多只能選 5 隻展示！')") &&
    studentToggleBody.includes('countDisplay.innerText = currentState.tempDisplayTeam.length;'),
  student_module_uses_display_team_dom_contract:
    studentText.includes("const dom = typeof getDisplayTeamDom === 'function' ? getDisplayTeamDom() : {};") &&
    studentText.includes('const { modal, grid, countDisplay } = dom || {};'),
  api_surface_still_exposes_display_team_entry:
    apiSurfaceText.includes("'openDisplayTeamEditor'") &&
    apiSurfaceText.includes("'saveDisplayTeam'")
};

const summary = {
  main_lines: mainText.split('\n').length,
  student_lines: studentText.split('\n').length,
  main_openDisplayTeamEditor_count: count(/openDisplayTeamEditor\(/g, mainText),
  main_toggleDisplayTeamItem_count: count(/toggleDisplayTeamItem\(/g, mainText),
  student_openDisplayTeamEditor_count: count(/openDisplayTeamEditor\(/g, studentText),
  student_toggleDisplayTeamItem_count: count(/toggleDisplayTeamItem\(/g, studentText),
  main_tempDisplayTeam_markers: count(/tempDisplayTeam|dtItem_|displayTeamModal/g, mainText),
  student_tempDisplayTeam_markers: count(/tempDisplayTeam|dtItem_|displayTeamModal/g, studentText)
};

const failed = Object.entries(checks).filter(([, ok]) => !ok);
if (failed.length) {
  console.error('PHASEC_COLLECTION_EDITOR_BOUNDARY_CHECK_FAILED');
  console.error(JSON.stringify({ checks, summary, failed }, null, 2));
  process.exit(1);
}
console.log('PHASEC_COLLECTION_EDITOR_BOUNDARY_CHECK_OK');
console.log(JSON.stringify({ checks, summary }, null, 2));
