#!/usr/bin/env node
import fs from 'fs';

const battle = fs.readFileSync('js/modules/battle.js', 'utf8');
const mainEntry = fs.readFileSync('js/main.entry.js', 'utf8');

const failures = [];

if (/const\s+confirmBtn\s*=\s*arenaElsEnd\.confirmBtn;/.test(battle)) {
  failures.push('prepareBattleArena 仍引用未宣告的 arenaElsEnd.confirmBtn');
}

if (!/const\s+confirmBtn\s*=\s*arenaEls\.confirmBtn;/.test(battle)) {
  failures.push('prepareBattleArena 未改用 arenaEls.confirmBtn');
}

if (!/if\s*\(gatekeeperQuizId\s*!==\s*'random'\)\s*\{[\s\S]*listBattleGatekeeperQuestions[\s\S]*isPlayableQuizQuestion[\s\S]*UI\.alert\('指定的守門題不存在、未啟用，或目前題目格式無法作答。請重新選擇有效題目，或改用隨機抽題。', '發布失敗'\)/.test(battle)) {
  failures.push('publishBattleBoss 缺少指定守門題可作答驗證');
}

if (/optsArea\.innerHTML \+= `?<button class=\"btn\"/.test(mainEntry) || /optsArea\.innerHTML \+= `?<button class=\"btn quiz-opt-btn\"/.test(mainEntry)) {
  failures.push('renderQuizQuestion 仍以 innerHTML += 注入作答按鈕');
}

if (!/document\.createElement\('button'\)/.test(mainEntry) || !/btn\.textContent = optionText;/.test(mainEntry) || !/btn\.addEventListener\('click', \(\) => App\.handleBattleQuizAnswer/.test(mainEntry)) {
  failures.push('renderQuizQuestion 尚未改為安全的按鈕建立流程');
}

if (failures.length) {
  console.error('Boss flow deep check failed:');
  failures.forEach((item) => console.error(`- ${item}`));
  process.exit(1);
}

console.log('Boss flow deep check passed.');
