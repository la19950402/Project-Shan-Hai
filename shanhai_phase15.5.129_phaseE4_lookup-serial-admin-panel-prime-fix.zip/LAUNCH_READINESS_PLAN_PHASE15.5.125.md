# Launch Readiness Plan — phase15.5.125

## Current baseline
- Active chain validation: pass
- Active flow deep check: pass
- Boss flow deep check: pass
- Archive governance deep check: pass
- Deploy governance deep check: pass
- Firestore rules alignment deep check: pass
- Latest hotfix applied: boot TDZ for `delegatedSaveToDB`

## What is ready
- Canonical active chain is clear and stable.
- Main entry no longer performs direct Firestore reads/writes.
- Phase C/D boundary convergence and legacy dependency sweeps are in place.
- Archive governance and deploy/smoke docs exist.
- Repository-side Firestore rules baseline exists.
- Boss runtime hotfixes and boot TDZ hotfix are included.

## What is NOT yet proven by repository checks alone
- Production Rules deployment status
- Real browser cache/CDN propagation behavior
- Netlify environment consistency
- Actual Firebase permissions under production project
- NFC / card / device-specific behavior
- Real teacher/student smoke path across live data

## Top pre-launch risks
1. Production still serving an older bundle or cached bootstrap/main chain.
2. Firestore Rules not deployed or only partially matching repository baseline.
3. Boss flow depending on exact-doc `quiz_bank` access and live data validity.
4. Token-mode student flow blocked by rules or stale `tag_tokens`/`student_pages` data.
5. Existing live data with old field shapes causing runtime path mismatches.
6. Smoke tests skipped after deploy because static checks all passed.

## Recommended launch sequence
### Stage 1 — freeze + verify
- Freeze active chain files.
- Do not modify archive files.
- Re-run all validation/deep-check scripts.
- Confirm `BOOT_ID` and `BUILD_TAG` match deployed HTML reference.

### Stage 2 — staging deploy
- Deploy staging using canonical active chain only.
- Deploy Firestore Rules from repository baseline.
- Hard-refresh and verify boot/login.
- Run full smoke, not just minimal smoke.

### Stage 3 — production canary
- Deploy production during a low-risk window.
- Immediately verify boot/login and student token mode.
- Test one boss/gatekeeper path and one teacher save path.
- Keep rollback candidate ready from previous known-good package.

### Stage 4 — production smoke and sign-off
- Run the 8 minimum smoke cases.
- Also run rules-alignment smoke:
  - `/admins/{uid}` self-check
  - `student_pages/{token}` token read
  - `quiz_bank/_BATTLE_TOWER_BOSS_`
  - `quiz_bank/{gatekeeperQuizId}` exact-doc get
  - public summaries
- Record operator, environment, time, result, and any incident.

## Detailed execution checklist
### A. Before deploy
- `node scripts/validate-active-chain.mjs`
- `node scripts/deep-check-active-flow.mjs`
- `node scripts/deep-check-boss-flow.mjs`
- `node scripts/deep-check-phasec-collection-boundaries.mjs`
- `node scripts/deep-check-phasec-evolution-boundaries.mjs`
- `node scripts/deep-check-phasec-collection-editor-boundaries.mjs`
- `node scripts/deep-check-phasec-forge-actioncard-boundaries.mjs`
- `node scripts/deep-check-phasec-save-hub-boundaries.mjs`
- `node scripts/deep-check-phased-auth-legacy-deps.mjs`
- `node scripts/deep-check-phased-student-legacy-deps.mjs`
- `node scripts/deep-check-phased-legacy-reaudit.mjs`
- `node scripts/deep-check-phasee-archive-governance.mjs`
- `node scripts/deep-check-phasee-deploy-governance.mjs`
- `node scripts/deep-check-phasee-firestore-rules-alignment.mjs`

### B. Deploy order
1. Static site/app bundle
2. Firestore Rules
3. Hard refresh and boot check
4. Full smoke on staging or canary
5. Production release
6. Production smoke

### C. Required live-path checks
- Teacher login
- Card lookup / NTAG lookup
- Student page token load
- Canonical save
- Fast-admin-save
- Daily challenge
- Boss gatekeeper and battle entry
- Shop purchase
- Ranking summary
- Collection editor save
- Forge/action-card flow
- Batch modal submit

## Rollback criteria
Rollback immediately if any of the following occurs:
- boot failure / blank page
- login unavailable
- teacher lookup cannot enter student panel
- canonical save fails
- token-mode student pages cannot read
- boss gatekeeper or battle entry fails in production
- rules deployment causes admin writes to fail

## Rollback method
- Restore previous known-good active package.
- Do not hotfix archived variants.
- Re-run active-chain validation and minimum smoke after rollback.
- Keep incident notes tied to exact package/build used.

## Recommended next engineering work after launch
1. Boss public-read hardening to remove the temporary `quiz_bank` exact-get compromise.
2. Final release governance re-audit.
3. Add a single command wrapper to run all deep checks in fixed order.
4. Add a browser-side smoke helper or checklist recorder.
5. Evaluate whether `firestore.rules` should be accompanied by emulator tests.
