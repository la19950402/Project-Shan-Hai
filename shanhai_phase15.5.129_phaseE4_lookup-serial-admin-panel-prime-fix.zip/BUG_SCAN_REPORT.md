# BUG SCAN REPORT

## Fixed in Phase 15.5.8

1. **Façade legacy alias mounting order bug**
   - File: `js/core/app-facade.js`
   - Problem: shop / quiz / zones 的 legacy alias 先 `preserveAliases()`、後 `bindMethods()`，導致別名其實不會被掛上。
   - Fix: 改成先掛正式方法，再建立 legacy alias。

2. **Version token drift**
   - Files: `js/modules/shop.js`, `js/modules/quiz.js`, `js/modules/ranking.js`, `js/modules/content-profile.js`, `js/modules/zones.js`
   - Problem: 仍引用 `phase14cleanup2`，會造成混合快取風險。
   - Fix: 全部統一為 `phase15hotfix8`。

## Remaining high-confidence risks

1. **Transitional global still in use**
   - File: `js/main.js:3484-3485`
   - Detail: 仍直接透過 `window.forceOpenCardForge(...)` 啟動巡堂加分橋接。這是相容層，不是立即錯誤，但仍屬待收斂項。

2. **Main entry remains very large**
   - File: `js/main.js`
   - Detail: 主檔仍非常大，並含大量 DOM / route / timer / NFC / profile / reward 流程。這會提高局部修改時的回歸風險。

3. **Browser-only Firebase imports limit Node-side runtime validation**
   - Files: `js/core/firebase.js` and modules importing it
   - Detail: 以 Node 進行 dynamic import 驗證時，會受 `https:` ESM 限制影響；正式驗證仍需瀏覽器端 smoke test。

4. **UI extended methods are still duck-typed**
   - Files: `js/main.js`, `js/modules/battle.js`, `js/modules/teacher-actions.js`
   - Detail: 例如 `UI.updateDailyQuestTimer` 不是 `core/ui.js` 原生宣告的一部分，而是主系統後續補掛。功能可用，但 discoverability 偏低。

5. **DOM contract is still implicit**
   - Files: 多數模組
   - Detail: 仍大量依賴固定 `id` / `getElementById` / `innerHTML`。在未整理 DOM 契約表前，不建議導入 HTML partials。

## Static findings summary

- direct `App.xxx = ...` assignments in JS: **0**
- stale version token findings after this phase: **0**
- syntax check status: **PASS**