# PHASE15.5.107 / Phase A-4 — canonical save + preview seed split

## 本輪定位
本輪延續 Phase A，目標是把主入口裡仍直接承擔的兩段 student/save 責任再往 `student-access` 收一輪：

1. `saveToDB()` 的一般 admin save 主路徑
2. `seedPreviewStudent()` 的 preview seed 讀寫

這一輪 **沒有升版 active chain 的 BOOT_ID / BUILD_TAG**，仍維持目前 canonical active chain：

- `BOOT_ID`: `phase15phase103fix15battlebossconfigsplit`
- `BUILD_TAG`: `v15.5.103-fix15-battle-boss-config-split-20260316`

原因：這輪仍以「降低主入口直接 DB 責任」為主，不額外擾動 boot/version 鏈。

---

## 本輪實際修改

### 1) `js/modules/student-access.js`
新增兩個專責方法：

- `saveCanonicalStudentPayload(payload, explicitUid)`
- `seedPreviewStudent(cardSeqStr)`

#### `saveCanonicalStudentPayload(...)`
承接原本 `main.entry.js -> saveToDB()` 裡的一般保存主路徑：
- 正規化 `serial`
- 寫入 `students/{serial}`
- 接續呼叫 `syncStudentMirrorForSerial(...)`
- 若目前目標就是當前學生，回填 `currentState.studentData`

效果：
- 主入口不再自己直接做 canonical `students` 寫入
- 一般 admin save 與 mirror sync 的責任進一步集中到 `student-access`

#### `seedPreviewStudent(...)`
把原本主入口的 preview seed 流程收進模組：
- 先檢查 `students/{serial}` 是否已存在
- 若不存在則寫入 preview sample
- 若 Firestore 被 rules 擋住，維持既有 fallback：
  - 直接把 sample 放進 `currentState.studentData`
  - 更新 panel
  - 顯示 toast

效果：
- preview seed 也不再由主入口自己直接 `getDoc/setDoc`
- student preview 流程與 student-access 責任更一致

### 2) `js/main.entry.js`
調整兩段：

#### `seedPreviewStudent(...)`
改成純委派：
- `App.seedPreviewStudent(...) -> studentAccessApi.seedPreviewStudent(...)`

#### `saveToDB(...)`
保留模式判斷，但把一般 admin save 主路徑改為委派：
- student token mode -> `saveStudentTokenPayload(...)`
- fast-admin-save -> `saveFastAdminStudentPayload(...)`
- 一般 canonical save -> `studentAccessApi.saveCanonicalStudentPayload(...)`

這代表目前 `saveToDB()` 已更接近真正的 orchestration：
- 決定使用哪一條保存鏈
- 不再自己執行一般 `students` 主寫入

---

## 指標變化

### `js/main.entry.js` 規模
- 行數：`6773 -> 6745`

### 主入口直接 DB 操作計數
- `getDoc(...)`: `12 -> 11`
- `getDocs(...)`: `5 -> 5`
- `setDoc(...)`: `5 -> 3`
- `deleteDoc(...)`: `2 -> 2`
- `writeBatch(...)`: `2 -> 2`

### 粗略 direct DB ops 總量（以 `getDoc/getDocs/setDoc/deleteDoc/writeBatch` 計）
- `26 -> 23`

### 仍維持不變
- `main_getDocs_count`: `5`
- `main_saveToDB_count`: `16`

---

## 驗證結果

已通過：

- `node --check js/main.entry.js`
- `node --check js/modules/student-access.js`
- `node scripts/validate-active-chain.mjs`
- `node scripts/deep-check-active-flow.mjs`

驗證摘要：
- `ACTIVE_CHAIN_VALIDATION_OK`
- `DEEP_CHECK_OK`

---

## 本輪完成後的結論

這輪的實質效果有兩個：

1. `saveToDB()` 雖然仍在主入口，但一般 admin save 主路徑已經不再自己碰 `students` 的正式寫入
2. preview seed 這條 student preview 旁路，也已從主入口撤出

也就是說，Phase A 走到這裡，主入口對 student/token/save 這條鏈的角色更明確變成：
- 模式判斷
- 委派
- UI orchestration

而不是自己執行多段保存/預覽資料寫入。

---

## 還沒收完的殘留

本輪沒有處理、且下一輪最值得接的區塊：

1. `cards / action_cards / forge` 相關直碰 DB 仍在主入口
2. `leaderboard_public / shop_public` 的 summary/fallback 仍在主入口
3. `handleCardScan()` 內仍有一批 student/card lookup 類 `getDoc(...)`

---

## 建議下一輪

接下來最合理的方向有兩個：

### 選項 A：延續 Phase A 收掃卡/卡片鏈
把 `handleCardScan()` 裡與 `cards / action_cards / student lookup` 相關的 DB 讀寫，再往 student/auth/forge 邊界收一輪。

### 選項 B：轉入 Phase B 收 summary/fallback
開始把：
- `leaderboard_public`
- `shop_catalog_public`

這兩條 summary/fallback 往 ranking / shop 模組回收。

如果沿你目前既定順序，**我建議下一輪先轉入 Phase B**：因為 student/token/save 主鏈已經收出一個足夠清楚的邊界，接下來收 summary/fallback，能更明顯降低主入口效能與資料責任壓力。
