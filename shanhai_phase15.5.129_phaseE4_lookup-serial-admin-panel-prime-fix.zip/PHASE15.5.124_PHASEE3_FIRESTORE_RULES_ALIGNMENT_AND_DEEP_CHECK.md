# Phase 15.5.124 — Phase E-3 Firestore Rules alignment + deep check

## 本輪目標

在不動 boot/version chain、不改 runtime 業務邏輯的前提下，補齊目前 canonical active chain 對應的 Firestore Rules 治理收尾，並把規則對齊結果納入可重跑檢查。

## 本輪實際完成

### 1. 新增 `firestore.rules`

依目前 active runtime 的實際資料路徑補上對應規則，涵蓋：

- `admins`
- `students`
- `tag_tokens`
- `student_pages`
- `cards`
- `action_cards`
- `quiz_bank`
- `quiz_pool_public`
- `leaderboard_public`
- `shop_catalog`
- `shop_catalog_public`
- `legendary_bank`
- `support_zone_records`
- `science_zone_records`

### 2. 新增 `FIRESTORE_RULES_ALIGNMENT.md`

把本輪 rules 對齊的設計依據、資料路徑與風險折衷整理成文件，特別註明：

- `student_pages/{token}` 是學生 token mode 的正式讀取入口
- `tag_tokens` 不直接開給學生端
- `quiz_bank` 目前仍保留「exact get 折衷」以維持 Boss config / gatekeeper 題可讀

### 3. 新增 deep-check

新增：

- `scripts/deep-check-phasee-firestore-rules-alignment.mjs`

檢查內容包括：

- `firestore.rules` 是否存在
- 是否涵蓋預期 collection match blocks
- 是否有 `isAdmin()` / `isActiveToken()` 等關鍵規則函式
- `quiz_bank` 的 Boss / active quiz 折衷是否明確存在
- deploy / smoke docs 是否已對齊 Rules rollout
- manifests 是否已納入 rules alignment 治理資訊

### 4. 補 deploy / smoke 文檔

更新：

- `DEPLOY_CHECKLIST.md`
- `SMOKE_TEST_ACTIVE_CHAIN.md`

新增 Rules rollout 的部署前檢查與 smoke cases，避免 Rules 部署後只驗 Hosting/JS，不驗權限實際效果。

### 5. 更新 manifests

更新：

- `js/ENTRY_CHAIN_MANIFEST.json`
- `js/MODULE_VARIANT_MANIFEST.json`

讓治理層明確記錄：

- `firestore.rules`
- `FIRESTORE_RULES_ALIGNMENT.md`
- `scripts/deep-check-phasee-firestore-rules-alignment.mjs`

## 本輪最重要的結論

### 1. `student_pages/{token}` 規則模型已正式化

目前 repository 已明確對齊：

- 學生端不直接讀 `tag_tokens`
- 學生端以 `student_pages/{token}` 為正式讀取入口
- token 是否有效由 Rules 透過 `tag_tokens/{token}.active` 判定

### 2. `quiz_bank` 仍有架構折衷，但已被明寫而不是隱性存在

為了不破壞現有 Boss 功能，`quiz_bank` 目前不能完全 admin-only。

本輪採用的折衷是：

- `list/query`：admin only
- `get`：允許
  - admin
  - `_BATTLE_TOWER_BOSS_`
  - `isActive == true` 的題目文件

這個折衷能維持：

- Boss 區塊可讀 battle tower config
- gatekeeper 題可依 doc id 讀取

但也代表：

- 只要知道某個 active quiz doc id，就可讀該題

這不是最理想的最終狀態，因此已在 alignment doc 中明列為 **後續硬化項**。

## 驗證結果

### 新增 deep-check

- `node --check scripts/deep-check-phasee-firestore-rules-alignment.mjs`：通過
- `node scripts/deep-check-phasee-firestore-rules-alignment.mjs`：通過

### 既有治理 / active checks

- `scripts/validate-active-chain.mjs`：通過
- `scripts/deep-check-active-flow.mjs`：通過
- `scripts/deep-check-phasee-archive-governance.mjs`：通過
- `scripts/deep-check-phasee-deploy-governance.mjs`：通過
- `scripts/deep-check-boss-flow.mjs`：通過

## 本輪未更動

- `BOOT_ID`
- `BUILD_TAG`
- runtime 業務邏輯
- canonical active chain 結構

## 目前階段判定

- Phase A：完成
- Phase B：完成
- Phase C：完成
- Phase D：完成
- Phase E-1：完成
- Phase E-2：完成
- **Phase E-3：完成**

目前專案已進入 **最終治理再盤點前夕**。

## 下一步建議

### Phase E-4：final release governance re-audit

下一輪最合理的是做最後一次全域治理回掃，重點不是再加功能，而是確認：

1. active chain / manifests / archive / deploy docs / rules docs 全部對齊
2. `firestore.rules` 與實際 active runtime path 沒再漂移
3. Boss hotfix、evolution hotfix、governance deep-check 沒有互相打架
4. 形成一份 final release audit report

## 本輪產出

- `firestore.rules`
- `FIRESTORE_RULES_ALIGNMENT.md`
- `scripts/deep-check-phasee-firestore-rules-alignment.mjs`
- 更新後的 `DEPLOY_CHECKLIST.md`
- 更新後的 `SMOKE_TEST_ACTIVE_CHAIN.md`
- 更新後的 manifests
