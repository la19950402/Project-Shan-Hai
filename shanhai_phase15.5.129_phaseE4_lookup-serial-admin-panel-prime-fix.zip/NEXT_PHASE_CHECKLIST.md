# NEXT_PHASE_CHECKLIST

## 建議下一階段：Phase 15.5.9

目標：`window.App` 暴露面分級凍結 + DOM 契約表初稿。

### 建議工作

1. 將 `window.App` API 分為：
   - 必留（HTML `onclick` 仍依賴）
   - 過渡保留（legacy alias / bridge）
   - 待移除（debug / fallback / bridge helper）

2. 盤點 `window.forceOpenCardForge` 的實際呼叫點，改成 façade 入口

3. 建立 DOM 契約表：
   - loginView
   - dashboardView
   - adminStudentPanel
   - previewPanel
   - battle modal
   - batch mode panel
   - shop / quiz / zones modal

4. 人工回歸重點
   - 啟動 / 登入
   - 老師查學生
   - 老師手動加分
   - 批量模式
   - Boss 結算
   - 商城 / 題庫

### 完成門檻

- `window.App` 暴露面有正式分級表
- `window.forceOpenCardForge` 不再是直接業務入口
- DOM 契約表至少涵蓋老師端 / Battle / Batch 三大區塊
