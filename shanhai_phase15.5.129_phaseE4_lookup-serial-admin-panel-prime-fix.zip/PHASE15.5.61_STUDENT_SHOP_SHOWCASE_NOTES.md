# Phase 15.5.61 — Student Shop Showcase (read-only)

## Scope
Low-risk student-facing shop showcase only.

- Added a new student showcase block under the exchange area, in the former Baize placement zone.
- Read-only display only: no purchase button, no inventory mutation, no transaction path.
- Reused existing shop collection as the source of truth for quantity.
- Did not touch login/auth flow, teacher shop purchase flow, or admin purchase logic.

## Files changed
- `index.html`
- `js/core/state.js`
- `js/main.entry.js`
- `js/modules/student.js`

## What changed
### HTML
Added a dedicated student shop showcase section:
- `studentShopSection`
- `studentShopStatus`
- `studentShopTrack`

Position:
- under the exchange area
- below `stuLegendaryList`
- in the same region previously occupied by the AI guide area

### State
Added cache + diagnostics:
- `studentShopCatalogCache`
- `studentShopCatalogLoadedAt`
- `studentShopCatalogPromise`
- `studentShopCatalogLastError`
- `studentShopShowcaseDomContract`

### main.entry.js
Added:
- `getStudentShopShowcaseDom()`
- `normalizeStudentShopItem()`
- `renderStudentShopShowcaseCards()`
- `warmStudentShopCatalog()`
- `renderStudentShopShowcase()`

Behavior:
- reads from `SHOP_COLLECTION`
- uses DB `quantity` as the displayed remaining stock
- sorts available items before sold-out items
- only shows:
  - items with `student_visible === true`
  - OR legacy `physical_reward` items when `student_visible` is unset
- does not expose any buy action

Also extended `warmStudentViewData()` to prewarm the student shop catalog.

### student.js
When student view updates, it now triggers:
- `App.renderStudentShopShowcase(...)`

This happens:
- after initial student snapshot render
- after background master merge render
- after reward panel refresh

## Safety constraints kept
- No purchase flow added
- No inventory decrement logic added
- No mutation of shop documents from student view
- No change to teacher/admin shop purchase path
- No change to AI disabled runtime guard

## Verification
### Syntax checks
Passed:
- `js/main.entry.js`
- `js/modules/student.js`
- `js/core/state.js`

### Canonical active chain syntax checks
Passed:
- `js/bootstrap-entry.js`
- `js/main.entry.js`
- `js/core/app-facade.js`
- `js/core/api-surface.js`
- `js/core/global-bridge.js`
- `js/core/dom-contract.js`
- `js/core/state.js`
- `js/modules/auth.js`
- `js/modules/student.js`
- `js/modules/teacher-actions.js`
- `js/modules/batch.js`
- `js/modules/battle.js`
- `js/modules/shop.js`
- `js/modules/quiz.js`
- `js/modules/ranking.js`
- `js/modules/content-profile.js`
- `js/modules/zones.js`

## Known limitation
Teacher admin UI does not yet provide dedicated fields for:
- student visibility toggle
- custom image URL

So this version supports them if present in DB, but does not yet add admin form fields for editing them.
