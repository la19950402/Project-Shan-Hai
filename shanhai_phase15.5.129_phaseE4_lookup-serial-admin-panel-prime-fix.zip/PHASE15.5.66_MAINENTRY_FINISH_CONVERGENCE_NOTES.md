# Phase 15.5.66 — main.entry 剩餘 direct DOM 收尾

## 本輪目標
把 `main.entry.js` 剩餘散落的 direct DOM 存取收尾，維持低風險，不碰 boot/auth 主鏈與交易邏輯。

## 本輪修改
- `applyProfileStaticTexts()` 改走 `DomBridge.get(...)`
- `createBattleDiceFaces()` 改走 `DomBridge.get(...)`
- `__updateLegendarySelectPreview()` 改走 `DomBridge.get(...)`
- 學生道具成功後的 tech panel 高亮改走 `DomBridge.get('studentView')?.querySelector(...)`
- 排行榜背景刷新中的 modal 檢查改走 `getRankingDom()`
- 題庫作答按鈕集合改走 `getQuizPlayDom().optionsArea?.querySelectorAll(...)`
- 展示隊伍 item 切換改走 `DomBridge.get(...)`
- boot panel 與 fallback login 欄位改走 `DomBridge.get(...)`

## 檢查結果
- `js/main.entry.js` 語法檢查通過
- canonical active chain 全鏈 `node --check` 通過
- `main.entry.js` 中剩餘 direct `document.getElementById/querySelector/querySelectorAll` 只剩 `DomBridge` helper 本身

## 風險控制
本輪未修改：
- boot/auth 主流程邏輯
- 老師端保存鏈
- 商城交易邏輯
- battle / student 模組業務流程
