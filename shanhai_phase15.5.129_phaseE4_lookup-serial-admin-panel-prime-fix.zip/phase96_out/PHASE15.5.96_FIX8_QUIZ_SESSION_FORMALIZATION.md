# Phase 15.5.96 Fix 8 — quizSession 正式化

## 本輪目標
- 將 `quizSession` runtime 實際使用欄位正式收斂到 `js/core/state.js`
- 抽出統一的 `reset / begin / abort / schedule` helper
- 讓 battle / daily 使用同一套 session 初始化路徑
- 避免 battle/daily 模組自行擴寫初始化欄位

## 主要修改

### 1. `js/core/state.js`
- 新增 `QUIZ_SESSION_INITIAL_STATE`
- 新增 `QUIZ_SESSION_RUNTIME_FIELDS`
- 新增 `cloneQuizSessionValue()`
- 新增 `createQuizSessionSnapshot()`
- `quizSession` 改為由正式 snapshot 建立

### 2. `js/core/quiz-session-utils.js`（新增）
- `clearQuizAdvanceTimer()`
- `resetQuizSession()`
- `beginQuizSession()`
- `beginDailyQuizSession()`
- `beginBattleQuizSession()`
- `abortQuizSession()`
- `scheduleQuizAdvance()`

### 3. `js/main.entry.js`
- App 的 session 方法改為委派到 `quiz-session-utils`
- 新增 `resetQuizSession()` wrapper
- `startDailyQuest()` 改成用 `beginDailyQuizSessionCore(...)`
- 移除 daily start 內原本分散的 session 初始化欄位寫入

### 4. `js/modules/battle.js`
- 引入 `beginBattleQuizSession()` helper
- `confirmBattleSelection()` 改為：
  - 優先 `beginQuizSession('battle', { questions, currentIndex, score })`
  - fallback 用 `beginBattleQuizSession(qD, 'battle')`
- 移除 battle 內原本分散的 `quizSession.mode/questions/currentIndex/score` 初始化寫入

## 深度檢查結果
- JS syntax check：通過
- `node scripts/validate-active-chain.mjs`：通過
- `node scripts/deep-check-active-flow.mjs`：通過

## 確認到的正式化結果
- battle / daily 已使用同一套 session helper 進行初始化
- `state.js` 已有正式的 session schema 與 snapshot 建立方式
- App 端 `begin / reset / abort / schedule` 已統一委派
- battle 模組不再自行擴寫啟動階段的主要 session 欄位
- daily 啟動時不再逐條手動重設 `dailyRemainingAtStart / dailyCoinsEarned / dailyXpEarned / dailyLifetimeMetricsCommitted / lastDailySessionToken`

## 尚未刻意收的部分
這一輪沒有刻意把所有 runtime 變化都封進 helper，例如：
- 作答時的 `answerPending`
- 進題/換題時的 `currentIndex`
- 結算時的 `resultShown`
- 累積獎勵時的 `dailyCoinsEarned / dailyXpEarned`

這些仍留在流程內直接更新，因為它們屬於「進行中狀態變化」，不是「session 結構初始化／重置」。

## 版本
- BOOT_ID: `phase15phase96fix8quizsessionformal`
- BUILD_TAG: `v15.5.96-fix8-quiz-session-formalization-20260315`
