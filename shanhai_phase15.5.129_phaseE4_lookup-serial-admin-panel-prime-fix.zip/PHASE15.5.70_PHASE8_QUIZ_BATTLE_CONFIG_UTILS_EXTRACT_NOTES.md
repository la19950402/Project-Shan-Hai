# Phase 15.5.70 — Phase 8 quiz/battle config utils extract

## 本輪目標
延續保守拆分策略，從 `main.entry.js` 抽出一批純資料 / 純設定 helper，避免碰 boot/auth、存檔鏈與交易鏈。

## 本輪修改檔案
- `js/main.entry.js`
- `js/core/quiz-battle-config-utils.js` (new)

## 抽離出去的 helper
- `normalizeQuizGradeToken`
- `isQuizEnabled`
- `quizMatchesStudentGrade`
- `getStudentGradeInfo`
- `getBattleAudienceOptions`
- `normalizeBossDiceCount`
- `normalizeBattleTowerDoc`
- `getBattleBossConfigForAudience`
- `getBattleBossConfigForStudent`
- `getBattleMonStage`
- `getBattleMonDiceCount`
- `getBattleStageLabel`

## 整合方式
`main.entry.js` 保留既有同名 wrapper，改由 wrapper 呼叫 `core/quiz-battle-config-utils.js`。
因此：
- 原有呼叫點不變
- 原有注入方式不變
- 對外 API 名稱不變

## 清理狀況
- `main.entry.js` 行數：7746 -> 7510
- 本輪抽出 12 個純 helper
- `main.entry.js` 未留下舊 helper 的完整定義重複版本

## 驗證
- `node --check js/core/quiz-battle-config-utils.js`
- `node --check js/main.entry.js`
- canonical active chain 全鏈 `node --check` 全數通過

## 風險控制
本輪未碰：
- boot / auth 主鏈
- 老師端保存鏈
- 商城交易鏈
- battle / student 對外 API
- AI 停用邏輯
- 學生商城展示區
