// @phase9-split:auth-module
export function createAuthModule(deps = {}) {
  const {
    auth, db, doc, getDoc, signInWithEmailAndPassword, signInAnonymously, signOut,
    UI, currentState, BUILD_TAG, firebaseConfig, __setBootStatus, __bindLoginFallback,
    openRequestedAdminPanel,
    lockStudentAccess,
    getAuthLoginDom,
    getAuthViewsDom,
    getAdminDiagDom,
    documentRef,
    storage
  } = deps;

  const docRef = documentRef || globalThis.document || null;
  const authStorage = storage || globalThis.localStorage || null;
  const getById = (id) => docRef?.getElementById?.(id) || null;
  const readLoginDom = () => (typeof getAuthLoginDom === 'function'
    ? (getAuthLoginDom() || {})
    : {
        adminEmailInput: getById('adminEmail'),
        adminPwdInput: getById('adminPassword'),
        loginBtn: getById('loginBtn')
      });
  const readViewsDom = () => (typeof getAuthViewsDom === 'function'
    ? (getAuthViewsDom() || {})
    : {
        loginView: getById('loginView'),
        dashboardView: getById('dashboardView'),
        adminView: getById('adminView'),
        viewerModeBadge: getById('viewerModeBadge'),
        exitPreviewBtn: getById('exitPreviewBtn')
      });
  const readAdminDiagDom = () => (typeof getAdminDiagDom === 'function'
    ? (getAdminDiagDom() || {})
    : {
        buildEls: [getById('adminDiagBuild'), getById('adminDiagInlineBuild')],
        projectEls: [getById('adminDiagProject'), getById('adminDiagInlineProject')],
        emailEls: [getById('adminDiagEmail'), getById('adminDiagInlineEmail')],
        uidEls: [getById('adminDiagUid'), getById('adminDiagInlineUid')],
        claimEls: [getById('adminDiagClaim'), getById('adminDiagInlineClaim')],
        allowlistEls: [getById('adminDiagAllowlist'), getById('adminDiagInlineAllowlist')],
        finalEls: [getById('adminDiagFinal'), getById('adminDiagInlineFinal')],
        errorEls: [getById('adminDiagError'), getById('adminDiagInlineError')],
        checkedAtEls: [getById('adminDiagCheckedAt'), getById('adminDiagInlineCheckedAt')],
        summaryEls: [getById('adminDiagSummary'), getById('adminDiagInlineSummary')]
      });
  const setNodeText = (node, value) => {
    if (node) node.textContent = value == null || value === '' ? '-' : String(value);
  };
  const setTextList = (nodes, value) => {
    (Array.isArray(nodes) ? nodes : []).forEach((node) => setNodeText(node, value));
  };

  const authApi = {
    async ensureStudentAuth() {
      if (auth.currentUser) return;
      await signInAnonymously(auth);
    },

    async isCurrentUserAdmin() {
      const user = auth.currentUser;
      const diag = {
        build: BUILD_TAG,
        projectId: firebaseConfig?.projectId || '(unknown)',
        email: user?.email || '',
        uid: user?.uid || '',
        claimAdmin: '未檢查',
        allowlist: '未檢查',
        final: '否',
        lastError: '',
        checkedAt: new Date().toLocaleString('zh-TW'),
        summary: '尚未檢查'
      };

      if (!user) {
        diag.summary = '尚未登入，無法驗證管理員權限';
        currentState.adminDiag = diag;
        authApi.renderAdminDiagnostics();
        return false;
      }

      try {
        await user.getIdToken(true);
        const token = await user.getIdTokenResult();
        const claimOk = token?.claims?.admin === true;
        diag.claimAdmin = claimOk ? '是' : '否';
        if (claimOk) {
          diag.final = '是';
          diag.summary = '已通過管理員驗證（來源：custom claim）';
          currentState.adminDiag = diag;
          authApi.renderAdminDiagnostics();
          console.info('[auth] admin granted by custom claim');
          return true;
        }
      } catch (e) {
        diag.claimAdmin = '讀取失敗';
        diag.lastError = `claim 檢查失敗：${e?.code || e?.message || String(e)}`;
        console.warn('[auth] getIdTokenResult failed:', e);
      }

      try {
        const adminSnap = await getDoc(doc(db, 'admins', user.uid));
        const ok = adminSnap.exists();
        diag.allowlist = ok ? '存在' : '不存在';
        diag.final = ok ? '是' : '否';
        diag.summary = ok ? '已通過管理員驗證（來源：Firestore admins 名單）' : '未通過管理員驗證';
        currentState.adminDiag = diag;
        authApi.renderAdminDiagnostics();
        console.info('[auth] admin allowlist exists =', ok, 'uid =', user.uid);
        return ok;
      } catch (e) {
        diag.allowlist = '讀取失敗';
        diag.final = '否';
        diag.summary = '未通過管理員驗證';
        diag.lastError = diag.lastError
          ? `${diag.lastError}；allowlist 檢查失敗：${e?.code || e?.message || String(e)}`
          : `allowlist 檢查失敗：${e?.code || e?.message || String(e)}`;
        currentState.adminDiag = diag;
        authApi.renderAdminDiagnostics();
        console.warn('[auth] admin allowlist check failed:', e);
        return false;
      }
    },

    renderAdminDiagnostics() {
      const diag = currentState.adminDiag || {};
      const dom = readAdminDiagDom();
      setTextList(dom.buildEls, diag.build || BUILD_TAG);
      setTextList(dom.projectEls, diag.projectId || firebaseConfig.projectId);
      setTextList(dom.emailEls, diag.email || auth.currentUser?.email || '');
      setTextList(dom.uidEls, diag.uid || auth.currentUser?.uid || '');
      setTextList(dom.claimEls, diag.claimAdmin || '未檢查');
      setTextList(dom.allowlistEls, diag.allowlist || '未檢查');
      setTextList(dom.finalEls, diag.final || '未檢查');
      setTextList(dom.errorEls, diag.lastError || '');
      setTextList(dom.checkedAtEls, diag.checkedAt || '');
      (Array.isArray(dom.summaryEls) ? dom.summaryEls : []).forEach((summaryEl) => {
        if (!summaryEl) return;
        summaryEl.textContent = diag.summary || '尚未檢查';
        summaryEl.style.color = (diag.final === '是')
          ? 'var(--success)'
          : ((diag.uid || diag.email) ? 'var(--warning)' : 'var(--text-muted)');
      });
    },

    async tryAutoEnterAdmin() {
      try {
        const ok = await authApi.isCurrentUserAdmin();
        currentState.isAdmin = ok;
        if (ok) {
          UI.hide('loginView');
          UI.show('dashboardView');
          UI.toast('SESSION RESUMED');
          currentState.pendingAdminPanelOpened = false;
          if (typeof openRequestedAdminPanel === 'function') await openRequestedAdminPanel();
        }
      } catch (e) {
        console.warn('[auth] auto-enter failed:', e);
      }
    },

    async logoutAdmin() {
      try { await signOut(auth); } catch (e) { console.warn(e); }
      currentState.isAdmin = false;
      UI.hide('dashboardView');
      UI.hide('adminView');
      UI.hide('viewerModeBadge');
      UI.hide('exitPreviewBtn');
      UI.show('loginView');
      authApi.resetSessionIdleTimer();
    },

    bindSessionActivityWatchers() {
      if (currentState.sessionActivityBound || !docRef?.addEventListener) return;
      currentState.sessionActivityBound = true;
      const handler = () => authApi.resetSessionIdleTimer();
      ['pointerdown', 'keydown', 'touchstart', 'mousedown', 'scroll'].forEach((evt) => {
        docRef.addEventListener(evt, handler, { passive: true });
      });
      docRef.addEventListener('visibilitychange', () => {
        if (!docRef.hidden) authApi.resetSessionIdleTimer();
      });
    },

    getSessionIdleMode() {
      const { dashboardView } = readViewsDom();
      const dashboardHidden = dashboardView?.classList?.contains('hidden');
      const adminVisible = currentState.viewMode === 'admin' && currentState.isAdmin && dashboardHidden === false;
      const studentVisible = currentState.viewMode === 'student' && currentState.studentLocked !== true && !!currentState.currentTokenValidated;
      if (adminVisible) return 'admin';
      if (studentVisible) return 'student';
      return null;
    },

    async handleIdleTimeout(mode) {
      if (mode === 'admin') {
        await authApi.logoutAdmin();
        UI.alert('老師端因長時間未操作，系統已自動登出。\n\n請重新輸入帳號密碼登入，以避免共用裝置被他人誤用。', '已自動登出');
        return;
      }

      if (mode === 'student') {
        try { await signOut(auth); } catch (e) { console.warn(e); }
        (typeof lockStudentAccess === 'function' ? lockStudentAccess : (() => {}))('學生頁因長時間未操作，已自動鎖定。\n\n請重新感應學生卡後再繼續使用。');
        UI.toast('學生頁已自動鎖定');
      }
    },

    resetSessionIdleTimer() {
      if (currentState.sessionIdleTimer) {
        clearTimeout(currentState.sessionIdleTimer);
        currentState.sessionIdleTimer = null;
      }

      const mode = authApi.getSessionIdleMode();
      if (!mode) return;

      currentState.lastActivityAt = Date.now();
      const timeoutMs = mode === 'admin' ? 15 * 60 * 1000 : 20 * 60 * 1000;
      currentState.sessionIdleTimer = setTimeout(() => {
        authApi.handleIdleTimeout(mode);
      }, timeoutMs);
    },

    // @phase9-split:auth-login-bind
    bindAuthControls() {
      const { adminEmailInput, adminPwdInput, loginBtn } = readLoginDom();
      __bindLoginFallback(authApi);

      if (!adminEmailInput || !adminPwdInput || !loginBtn) {
        __setBootStatus('setupEventListeners-partial', '登入欄位缺失，已保留最小啟動能力');
        return false;
      }

      let savedEmail = '';
      try {
        savedEmail = authStorage?.getItem?.('adminEmail') || '';
      } catch (_) {
        savedEmail = '';
      }
      if (savedEmail) adminEmailInput.value = savedEmail;

      const enterHandler = (e) => {
        if (e.key === 'Enter') loginBtn.click();
      };
      adminEmailInput.addEventListener('keypress', enterHandler);
      adminPwdInput.addEventListener('keypress', enterHandler);

      if (!authApi.__loginHandlerBound) {
        authApi.__loginHandlerBound = true;
        loginBtn.dataset.loginBound = 'app';
        loginBtn.addEventListener('click', async () => {
          const email = (adminEmailInput ? adminEmailInput.value : '').trim();
          const pwd = adminPwdInput.value || '';

          if (!email || !pwd) {
            UI.alert('請輸入管理者 Email 與密碼。\n（需先在 Firebase Authentication 建立帳號）', '登入失敗');
            return;
          }

          const btn = loginBtn;
          const originalText = btn.innerText;
          btn.disabled = true;
          btn.innerText = 'AUTHENTICATING...';

          try {
            await signInWithEmailAndPassword(auth, email, pwd);
            try { authStorage?.setItem?.('adminEmail', email); } catch (_) {}

            if (auth.currentUser) {
              try { await auth.currentUser.getIdToken(true); } catch (_) {}
            }

            const ok = await authApi.isCurrentUserAdmin();
            currentState.isAdmin = ok;

            if (!ok) {
              const uid = auth.currentUser?.uid || '(unknown uid)';
              await signOut(auth);
              UI.alert(`此帳號已成功登入，但目前仍未通過管理者驗證。

目前登入 UID：${uid}

請擇一完成：
1) 使用 Admin SDK 為此 UID 設定 custom claim：admin=true
2) 確認 Firestore 的 /admins/${uid} 文件存在，且前端連的是同一個 Firebase 專案

完成後請重新登入。`, '權限不足');
              return;
            }

            UI.hide('loginView');
            UI.show('dashboardView');
            UI.toast('ACCESS GRANTED');
            currentState.pendingAdminPanelOpened = false;
            if (typeof openRequestedAdminPanel === 'function') await openRequestedAdminPanel();
            authApi.resetSessionIdleTimer();
            adminPwdInput.value = '';
          } catch (e) {
            console.error(e);
            UI.alert(
              `登入失敗，請確認：
- Firebase Authentication 已啟用 Email/Password
- Email/密碼正確
- 網路正常`,
              '登入失敗'
            );
          } finally {
            btn.disabled = false;
            btn.innerText = originalText;
          }
        });
      }

      return true;
    }
  };

  return authApi;
}
