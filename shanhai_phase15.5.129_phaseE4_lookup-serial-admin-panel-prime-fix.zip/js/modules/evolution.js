export function createEvolutionModule(deps = {}) {
  const {
    CONSTANTS,
    ELEMENT_KEYS = [],
    getDominantElementFromData,
    getDragonVisual
  } = deps;

  const defaultAttributes = () => ({ metal: 0, wood: 0, water: 0, fire: 0, earth: 0 });
  const defaultDebuffs = () => ({ Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 });
  const ensureLogs = (data) => {
    if (!Array.isArray(data.logs)) data.logs = [];
    return data.logs;
  };
  const ensureCollection = (data) => {
    if (!Array.isArray(data.collection)) data.collection = [];
    return data.collection;
  };
  const buildDragonArchiveEntry = ({ data, element, stage, vis, extra = {} }) => ({
    type: 'dragon',
    element,
    path: data.dragon_path,
    stage,
    name: vis.name,
    img_file: vis.file,
    img: '',
    stats: { ...(data.attributes || {}) },
    timestamp: Date.now(),
    ...extra
  });
  const clearActiveHiddenEggIfMatch = (data, eggId) => {
    if (String(data.active_hidden_egg_id || '') === String(eggId || '')) {
      data.active_hidden_egg_id = '';
      data.active_hidden_egg = null;
    }
  };
  const applyHiddenEggLegendaryRollover = (data, maxEl) => {
    if (!Array.isArray(data.hidden_eggs) || !data.hidden_eggs.length) return;
    const remainingEggs = [];
    for (const egg of data.hidden_eggs) {
      const eggKey = egg?.hiddenEggId || egg?.id;
      const eggMeta = CONSTANTS?.HIDDEN_EGGS?.[eggKey] || egg;
      if (eggMeta && eggMeta.requiredAttr === maxEl) {
        ensureCollection(data);
        data.collection = data.collection.filter((item) => !(item.type === 'hidden_egg' && String(item.id || item.hiddenEggId || '') === String(egg.id || egg.hiddenEggId || '')));
        const legendaryName = eggMeta.beastName || String(eggMeta.name || '').replace(/蛋$/, '');
        const legendaryImg = eggMeta.legendaryImg || (eggMeta.forms && eggMeta.forms.adult) || eggMeta.img;
        data.collection.push({
          type: 'legendary',
          name: legendaryName,
          img: legendaryImg,
          points: Number(eggMeta.points) || 0,
          hiddenEggId: eggMeta.id || egg.hiddenEggId || '',
          element: maxEl,
          timestamp: Date.now()
        });
        clearActiveHiddenEggIfMatch(data, eggMeta.id || egg.hiddenEggId || '');
        ensureLogs(data).push({
          timestamp: Date.now(),
          action_type: 'legendary',
          detail: `[特殊異獸蛋] ${eggMeta.name} 養成完成，轉化為隱藏異獸 ${legendaryName}（★${Number(eggMeta.points) || 0}）`
        });
      } else {
        remainingEggs.push(egg);
      }
    }
    data.hidden_eggs = remainingEggs;
  };
  const resetForNewDragonEgg = (data) => {
    data.attributes = defaultAttributes();
    data.streaks = defaultAttributes();
    data.attr_event_counts = defaultAttributes();
    data.debuffs = defaultDebuffs();
    data.debuffs_timestamp = null;
    data.dragon_stage = -1;
    data.dragon_path = null;
  };

  return {
    validateEvolutionTree() {
      const paths = CONSTANTS?.MEDIA?.DRAGON_PATHS || {};
      const missing = ELEMENT_KEYS.filter((k) => !(paths[k] && Array.isArray(paths[k].stages) && paths[k].stages.length >= 3));
      if (missing.length) console.warn('[evolution-tree] 缺少完整進化路線:', missing);
      else console.info('[evolution-tree] 五行屬性進化路線已完整覆蓋。');
      return missing;
    },

    computeTrainerProgress(data) {
      const col = Array.isArray(data?.collection) ? data.collection : [];
      const stage = Number(data?.dragon_stage);
      const stageIdx = Number.isFinite(stage) ? stage : -1;

      const dragonItems = col.filter((i) =>
        i && typeof i === 'object' &&
        i.type === 'dragon' &&
        !(i.isHologram === true || i.isHologram === 'true')
      );

      const dragonMilestones = dragonItems.length;
      const uniquePaths = new Set(dragonItems.map((i) => String(i.path || i.element || '')).filter(Boolean)).size;
      const legendaryCount = col.filter((i) => i && typeof i === 'object' && i.type === 'legendary').length;

      let rankIndex = 0;
      if (legendaryCount >= 1 && stageIdx >= 2) rankIndex = 7;
      else if (legendaryCount >= 1) rankIndex = 6;
      else if (stageIdx >= 2 && dragonMilestones >= 3) rankIndex = 5;
      else if (stageIdx >= 2) rankIndex = 4;
      else if (stageIdx >= 1) rankIndex = 3;
      else if (stageIdx >= 0) rankIndex = 2;
      else if ((Number(data?.totalXP) || 0) > 0) rankIndex = 1;
      else rankIndex = 0;

      const rankName = (CONSTANTS?.TRAINER_RANKS && CONSTANTS.TRAINER_RANKS[rankIndex]) ? CONSTANTS.TRAINER_RANKS[rankIndex] : '新手學徒';
      return { dragonMilestones, uniquePaths, legendaryCount, rankIndex, rankName };
    },

    getRateFromRankIndex(rankIndex) {
      const idx = Number.isFinite(Number(rankIndex)) ? Number(rankIndex) : 0;
      const v = CONSTANTS?.TRAINER_RATE_BY_RANK?.[idx];
      return Number(v) || 5;
    },

    getRateFromLap(lap) {
      const L = Number(lap) || 1;
      return (L === 2) ? 4 : (L === 3) ? 3 : (L >= 4) ? 2 : 5;
    },

    processEvolution(data) {
      if (!data || typeof data !== 'object') return data;

      data.totalXP = Number(data.totalXP) || 0;
      data.coins = Number(data.coins) || 0;
      data.lap = Number(data.lap) || 1;

      if (!data.attributes || typeof data.attributes !== 'object') data.attributes = {};
      if (!data.streaks || typeof data.streaks !== 'object') data.streaks = {};
      ensureLogs(data);
      for (const k of ELEMENT_KEYS) {
        data.attributes[k] = Number(data.attributes[k]) || 0;
        data.streaks[k] = Number(data.streaks[k]) || 0;
      }

      while (data.totalXP >= 100) {
        if (data.debuffs?.Frozen > 0) {
          data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: '因【冰凍】影響無法成長升級。' });
          break;
        }

        const overflowXP = data.totalXP - 100;
        const maxEl = typeof getDominantElementFromData === 'function' ? getDominantElementFromData(data) : (ELEMENT_KEYS[0] || 'metal');

        let stageIdx = Number(data.dragon_stage);
        if (!Number.isFinite(stageIdx)) stageIdx = -1;
        const beforeStage = stageIdx;
        const isAdultStage = stageIdx >= 2;

        if (stageIdx < 0) {
          data.dragon_path = maxEl;
          data.dragon_stage = 0;
        } else if (stageIdx < 2) {
          data.dragon_stage = stageIdx + 1;
        } else {
          data.dragon_stage = 2;
        }

        const afterStage = Number(data.dragon_stage);
        const shouldArchiveFinalDragon = afterStage >= 2 || isAdultStage;

        const prog = this.computeTrainerProgress(data);
        const storedRank = Number(data.trainerRankIndex);
        const rankIdx = Math.max(Number.isFinite(storedRank) ? storedRank : 0, prog.rankIndex);
        data.trainerRankIndex = rankIdx;

        const rateFromRank = this.getRateFromRankIndex(rankIdx);
        const rateFromLap = this.getRateFromLap(data.lap);
        data.best_rate = Number(data.best_rate);
        if (!Number.isFinite(data.best_rate)) data.best_rate = 99;
        data.best_rate = Math.min(data.best_rate, rateFromRank, rateFromLap);

        let rate = Math.min(rateFromRank, data.best_rate);
        if (data.debuffs?.Paralyzed > 0) rate *= Math.pow(2, data.debuffs.Paralyzed);
        const coinsEarned = Math.floor(100 / rate);

        data.coins += coinsEarned;

        const vis = typeof getDragonVisual === 'function'
          ? (getDragonVisual(data) || { name: '龍獸', file: '', img: '' })
          : { name: '龍獸', file: '', img: '' };
        ensureCollection(data);

        if (shouldArchiveFinalDragon) {
          applyHiddenEggLegendaryRollover(data, maxEl);

          data.collection.push(buildDragonArchiveEntry({
            data,
            element: maxEl,
            stage: 2,
            vis,
            extra: { isFinal: true }
          }));

          resetForNewDragonEgg(data);
          data.logs.push({ timestamp: Date.now(), action_type: 'evolution', detail: `成熟期達成：${vis.name} 已封存，獲得新的初始龍蛋 (+${coinsEarned}🪙)` });
          data.totalXP = 0;
        } else {
          data.logs.push({ timestamp: Date.now(), action_type: 'evolution', detail: `成長：${vis.name} (+${coinsEarned}🪙)` });
          data.totalXP = overflowXP;
        }
      }

      return data;
    }
  };
}
