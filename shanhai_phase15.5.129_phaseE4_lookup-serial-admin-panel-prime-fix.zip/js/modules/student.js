import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
// @phase9-split:student-module
export function createStudentModule(deps = {}) {
  attachEmergencyFlagGlobals();
  const {
    db, doc, getDoc, onSnapshot, UI, currentState, radarChartInstances, CONSTANTS,
    COLLECTION_NAME, STUDENT_PAGE_COLLECTION, Chart, App,
    getProfileLabels, getProfileDebuffInfo, getProfileAttributeInfo, getProfileVisual,
    isCatProfile, colorToRgba, setImgFromFileBaseName, buildCollectionDisplayItem,
    hydrateStorageImages, getRadarLabelsForData, applyProfileStaticTexts, syncProfileForm,
    getDisplayTeamDom,
    getStudentDisplayDom,
    getStudentIdentityDom,
    getStudentViewDom,
    getStudentShopStatusDom,
    documentRef
  } = deps;

  let studentApi = null;
  const docRef = documentRef || globalThis.document || null;
  const callAppMethod = (name, ...args) => (typeof App?.[name] === 'function' ? App[name](...args) : undefined);
  const callUiMethod = (name, ...args) => (typeof UI?.[name] === 'function' ? UI[name](...args) : undefined);
  const callStudentMethod = (name, ...args) => (typeof studentApi?.[name] === 'function' ? studentApi[name](...args) : undefined);
  const applyDataMigrationSafe = (data) => callAppMethod('applyDataMigration', data) || data;
  const getById = (id) => docRef?.getElementById?.(id) || null;
  const queryAll = (selector, root = docRef) => Array.from(root?.querySelectorAll?.(selector) || []);
  const createNode = (tagName) => docRef?.createElement?.(tagName) || null;
  const isVisibleEl = (el) => Boolean(el && !el.classList?.contains('hidden'));
  const pickDom = (idMap = {}) => Object.fromEntries(Object.entries(idMap).map(([key, id]) => [key, typeof id === 'function' ? id() : getById(id)]));
  const readStudentDisplayDom = (prefix) => (typeof getStudentDisplayDom === 'function'
    ? (getStudentDisplayDom(prefix) || {})
    : pickDom({
        classSeat: `${prefix}ClassSeat`,
        name: `${prefix}Name`,
        coins: `${prefix}Coins`,
        lapBadge: `${prefix}LapBadge`,
        xpBar: `${prefix}XpBar`,
        xpText: `${prefix}XpText`,
        streakRow: `${prefix}StreakRow`,
        lifetimeStatsRow: prefix === 'stu' ? 'stuLifetimeStatsRow' : null,
        logsList: prefix === 'adm' ? 'admLogsList' : null,
      }));
  const readStudentIdentityDom = () => (typeof getStudentIdentityDom === 'function'
    ? (getStudentIdentityDom() || {})
    : pickDom({
        admName: 'admName',
        stuName: 'stuName',
        batchStuName: 'batchStuName',
        admClassSeat: 'admClassSeat',
        stuClassSeat: 'stuClassSeat',
        batchStuClass: 'batchStuClass',
        admCoins: 'admCoins',
        stuCoins: 'stuCoins',
        batchStuXp: 'batchStuXp',
      }));
  const readStudentViewDom = () => (typeof getStudentViewDom === 'function'
    ? (getStudentViewDom() || {})
    : pickDom({
        studentView: 'studentView',
        adminStudentPanel: 'adminStudentPanel',
      }));
  const readStudentShopStatusDom = () => (typeof getStudentShopStatusDom === 'function'
    ? (getStudentShopStatusDom() || {})
    : {
        shopModal: getById('shopModal'),
        shopCoins: getById('shopCoins'),
        itemButtons: queryAll('#shopModal .shop-item'),
      });
  const getLifetimeMetricValue = (data, key) => {
    const n = Number(data?.[key]);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  };
  const renderLifetimeStatsRow = (data, rowEl) => {
    if (!rowEl) return;
    const bossWins = getLifetimeMetricValue(data, 'boss_win_total');
    const dailyCorrect = getLifetimeMetricValue(data, 'daily_correct_total');
    rowEl.innerHTML = '';
    const stats = [
      { icon: '⚔️', label: '討伐', value: bossWins, color: 'var(--danger)', title: '帳號創立以來成功討伐 Boss 的總次數' },
      { icon: '📘', label: '答對', value: dailyCorrect, color: 'var(--color-grass)', title: '帳號創立以來每日修練答對的總題數' }
    ];
    stats.forEach((item) => {
      const chip = createNode('div');
      if (!chip) return;
      chip.className = 'streak-item';
      chip.style.borderColor = item.color;
      chip.style.color = item.color;
      chip.style.cursor = 'default';
      chip.title = item.title;
      chip.innerHTML = `<span>${item.icon}</span><span style="font-family:'Noto Sans TC'; letter-spacing:0.5px;">${item.label}</span><span style="margin-left:2px; font-family:'Orbitron'; font-weight:bold;">${item.value}</span>`;
      rowEl.appendChild(chip);
    });
  };
  const buildStudentRenderSignature = (data = {}) => {
    try {
      const normalized = applyDataMigrationSafe(JSON.parse(JSON.stringify(data || {})));
      const snapshot = {
        serial: normalized.card_seq || normalized.serial || '',
        name: normalized.name || '',
        class_name: normalized.class_name || '',
        seat_number: normalized.seat_number || '',
        coins: Number(normalized.coins) || 0,
        totalXP: Number(normalized.totalXP) || 0,
        updatedAt: Number(normalized.updatedAt || normalized.updated_at || normalized.timestamp) || 0,
        debuffs: normalized.debuffs || {},
        active_token: normalized.active_token || normalized.page_token || '',
        logsTail: Array.isArray(normalized.logs) ? normalized.logs.slice(-3) : [],
        collectionTail: Array.isArray(normalized.collection) ? normalized.collection.slice(-2).map((item) => ({
          type: item?.type || '',
          name: item?.name || '',
          status: item?.status || '',
          timestamp: item?.timestamp || 0
        })) : []
      };
      return JSON.stringify(snapshot);
    } catch (_) {
      return `sig-fallback:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    }
  };
  const masterStudentRecordCache = { serial: '', data: null, loadedAt: 0, promise: null };
  const loadMasterStudentRecord = async (serial, options = {}) => {
    const normalizedSerial = normalizeSerialLike(serial);
    if (!normalizedSerial) return null;
    const force = !!options.force;
    const maxAgeMs = Math.max(3000, Number(options.maxAgeMs) || 12000);
    const now = Date.now();
    if (!force && masterStudentRecordCache.serial === normalizedSerial && masterStudentRecordCache.data && (now - masterStudentRecordCache.loadedAt) < maxAgeMs) {
      return applyDataMigrationSafe(JSON.parse(JSON.stringify(masterStudentRecordCache.data)));
    }
    if (!force && masterStudentRecordCache.serial === normalizedSerial && masterStudentRecordCache.promise) {
      return await masterStudentRecordCache.promise;
    }
    let loadPromise;
    loadPromise = (async () => {
      try {
        const snap = await getDoc(doc(db, COLLECTION_NAME, normalizedSerial));
        const payload = snap.exists() ? applyDataMigrationSafe(snap.data() || {}) : null;
        masterStudentRecordCache.serial = normalizedSerial;
        masterStudentRecordCache.data = payload ? JSON.parse(JSON.stringify(payload)) : null;
        masterStudentRecordCache.loadedAt = Date.now();
        return payload ? applyDataMigrationSafe(JSON.parse(JSON.stringify(payload))) : null;
      } finally {
        if (masterStudentRecordCache.promise === loadPromise) masterStudentRecordCache.promise = null;
      }
    })();
    masterStudentRecordCache.serial = normalizedSerial;
    masterStudentRecordCache.promise = loadPromise;
    return await loadPromise;
  };
  const scheduleStudentAuxPanelsRefresh = (data = {}) => {
    const serial = normalizeSerialLike(data.card_seq || data.serial || currentState.currentUid || '');
    const signature = JSON.stringify({
      serial,
      token: data.active_token || data.page_token || currentState.currentToken || '',
      totalXP: Number(data.totalXP) || 0,
      coins: Number(data.coins) || 0,
      collectionLen: Array.isArray(data.collection) ? data.collection.length : 0,
      todayBattleUsed: !!data.today_battle_used,
      todayBattleDate: Number(data.today_battle_date) || 0,
      profile: String(data.content_profile_id || ''),
    });
    const now = Date.now();
    if (currentState.studentAuxRefreshSignature === signature && (now - (currentState.studentAuxRefreshAt || 0)) < 1200) return;
    currentState.studentAuxRefreshSignature = signature;
    currentState.studentAuxRefreshAt = now;
    if (currentState.studentAuxRefreshTimer) {
      try { clearTimeout(currentState.studentAuxRefreshTimer); } catch (_) {}
    }
    currentState.studentAuxRefreshTimer = setTimeout(() => {
      if (currentState.viewMode !== 'student' && currentState.viewMode !== 'preview') return;
      try { App.loadActiveLegendariesForStudent(); } catch (_) {}
      try { App.checkBattleTowerStatus(data); } catch (_) {}
    }, 80);
  };
  const normalizeSerialLike = (value) => {
    const digits = String(value || '').replace(/[^0-9]/g, '');
    return digits ? digits.padStart(3, '0') : '';
  };

  studentApi = {
          updateDragonImage(data, imgElementId) {
            const imgEl = getById(imgElementId);
            if (!imgEl) return;

            const capId = String(imgElementId).replace('Img', 'Caption');
            const capEl = getById(capId);
            const vis = getProfileVisual(data || {});
            if (vis.file) {
              setImgFromFileBaseName(imgEl, vis.file, { shadowColor: (vis.color || 'var(--cyan)') });
            } else {
              imgEl.removeAttribute('data-asset');
              imgEl.src = vis.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
            }
            imgEl.className = 'dragon-img';
            imgEl.style.filter = `drop-shadow(0 0 20px ${vis.color || 'var(--cyan)'})`;
            const displayEl = imgEl.closest('.dragon-display');
            if (displayEl) {
              if (isCatProfile(data)) {
                const glowStrong = colorToRgba(vis.color, 0.34);
                const glowSoft = colorToRgba(vis.color, 0.16);
                displayEl.style.background = `radial-gradient(circle at 50% 62%, ${glowStrong} 0%, ${glowSoft} 35%, transparent 68%)`;
                displayEl.style.borderColor = vis.color || 'rgba(0,229,255,0.2)';
                displayEl.style.boxShadow = `inset 0 0 26px ${glowSoft}, 0 0 24px ${glowSoft}`;
              } else {
                displayEl.style.background = 'radial-gradient(circle, rgba(0,229,255,0.1) 0%, transparent 60%)';
                displayEl.style.borderColor = 'rgba(0,229,255,0.2)';
                displayEl.style.boxShadow = 'none';
              }
            }
            if (capEl) capEl.innerText = vis.caption || '';
          },
          updateCollectionGallery(data, galleryId) {
            const gallery = getById(galleryId);
            if (!gallery) return;

            const isUnsafeUrl = (u) => {
              const s = String(u || '');
              if (!s) return false;
              if (s.startsWith('data:')) return false;
              if (!/^https?:\/\//i.test(s)) return false;
              return !/firebasestorage\.googleapis\.com\/v0\/b\//i.test(s);
            };
            const safeImg = (u) => (isUnsafeUrl(u) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (u || CONSTANTS.MEDIA.PLACEHOLDER_SVG));

            const col = data.collection || [];
            const profileLabels = getProfileLabels(data);
            const isStudentGallery = String(galleryId || '').startsWith('stu');
            if (col.length > 0) {
              gallery.innerHTML = '';
              col.forEach((item, index) => {
                if (isStudentGallery && item && item.type === 'voucher' && item.status === 'redeemed') return;
                const disp = buildCollectionDisplayItem(item, data);
                if (item.type === 'legendary') {
                  const img = (disp && disp.img) || safeImg(item.img);
                  const title = (disp && disp.title) || item.name || '稀有異獸';
                  gallery.innerHTML += `
                    <div class="collection-item legendary-item" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" alt="${title}">
                      <span>${title}</span>
                    </div>`;
                  return;
                }

                if (item.type === 'dead_dragon') {
                  const causeName = getProfileDebuffInfo(item.cause, data)?.name || '未知';
                  const img = (disp && disp.img) || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
                  const deadText = isCatProfile(data) ? `照護紀錄` : `死於${causeName}`;
                  gallery.innerHTML += `
                    <div class="collection-item" style="border-color:rgba(255,0,85,0.3);" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" alt="DEATH RECORD" style="filter: brightness(0.85) opacity(0.65) drop-shadow(0 0 5px var(--danger));">
                      <span style="color:var(--danger); font-size:10px;">${deadText}</span>
                    </div>`;
                  return;
                }

                if (item.type === 'dragon') {
                  const info = getProfileAttributeInfo(item.element, data) || { color: 'var(--cyan)' };
                  const fileBase = item.img_file || '';
                  const dataAttr = fileBase && !isCatProfile(data) ? `data-asset="${fileBase}"` : '';
                  const img = (disp && disp.img) || (fileBase && !isCatProfile(data) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : safeImg(item.img));
                  const name = (disp && disp.title) || item.name || (isCatProfile(data) ? '貓咪夥伴' : '龍獸');
                  gallery.innerHTML += `
                    <div class="collection-item" style="border-color:rgba(255,255,255,0.2);" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" ${dataAttr} alt="${name}">
                      <span style="color:${info.color}">${name}</span>
                    </div>`;
                  return;
                }

                if (item.type === 'hidden_egg') {
                  const eggMeta = CONSTANTS.HIDDEN_EGGS[item.hiddenEggId || item.id] || item;
                  const isActiveEgg = String(data.active_hidden_egg_id || '') === String(item.hiddenEggId || item.id || '');
                  const img = (eggMeta.forms && eggMeta.forms.egg) || (disp && disp.img) || safeImg(item.img || eggMeta.img);
                  const name = eggMeta.name || item.name || '特殊異獸蛋';
                  const sub = isActiveEgg ? '目前孵化中' : '點擊可設為目前的蛋';
                  gallery.innerHTML += `
                    <div class="collection-item ${isActiveEgg ? 'legendary-item' : ''}" style="border-color:${isActiveEgg ? 'var(--legendary-gold)' : 'rgba(0,229,255,0.22)'};" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" alt="${name}" style="filter:drop-shadow(0 0 12px var(--color-water));">
                      <span style="color:${isActiveEgg ? 'var(--legendary-gold)' : 'var(--color-water)'}; font-size:10px;">${name}<br>${sub}</span>
                    </div>`;
                  return;
                }

                if (item.type === 'material') {
                  const info = getProfileAttributeInfo(item.element, data) || { color: 'var(--cyan)', name: '?' };
                  const fileBase = item.img_file || '';
                  const dataAttr = fileBase && !isCatProfile(data) ? `data-asset="${fileBase}"` : '';
                  const img = (disp && disp.img) || (fileBase && !isCatProfile(data) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : safeImg(item.img));
                  const name = (disp && disp.title) || item.name || `${info.name}${isCatProfile(data) ? '素材' : '系素材'}`;
                  gallery.innerHTML += `
                    <div class="collection-item" style="border-color:rgba(255,255,255,0.15);" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" ${dataAttr} alt="${name}" style="filter: drop-shadow(0 0 10px ${info.color});">
                      <span style="color:${info.color}; font-size:10px;">${name}</span>
                    </div>`;
                  return;
                }

                if (item.type === 'voucher') {
                  const img = (disp && disp.img) || safeImg(item.img);
                  const active = item.status !== 'redeemed';
                  const name = (disp && disp.title) || item.name || '兌換憑證';
                  gallery.innerHTML += `
                    <div class="collection-item" style="border-color:${active ? 'var(--legendary-gold)' : 'rgba(255,255,255,0.15)'};" onclick="UI.showArchiveModal(${index})">
                      <img src="${img}" alt="${name}" style="filter: drop-shadow(0 0 10px ${active ? 'var(--legendary-gold)' : 'rgba(255,255,255,0.35)'});">
                      <span style="color:${active ? 'var(--legendary-gold)' : 'var(--text-muted)'}; font-size:10px;">${active ? '兌換憑證' : '已兌現'}</span>
                    </div>`;
                  return;
                }

                gallery.innerHTML += `
                  <div class="collection-item" style="border-color:rgba(255,255,255,0.08);" onclick="UI.showArchiveModal(${index})">
                    <img src="${CONSTANTS.MEDIA.PLACEHOLDER_SVG}" alt="LEGACY">
                    <span style="color:var(--text-muted); font-size:10px;">舊版封存</span>
                  </div>`;
              });
            } else {
              gallery.innerHTML = `<div style="color:var(--text-muted); font-size:0.8em; width:100%; text-align:center; padding: 20px; font-family:'Orbitron';">${profileLabels.galleryEmpty || '尚未建立圖鑑資料'}</div>`;
            }
            try { hydrateStorageImages(gallery); } catch (_) {}
          },
          showArchiveModal(index) {
            const collection = Array.isArray(currentState.studentData?.collection) ? currentState.studentData.collection : [];
            const item = collection[index];
            currentState.archiveIndex = index;
            const { archiveTitle: titleEl, archiveImg: imgEl, archiveHoloText: holoText, archivePrimaryActionBtn: primaryBtn, adminView } = pickDom({
              archiveTitle: 'archiveTitle',
              archiveImg: 'archiveImg',
              archiveHoloText: 'archiveHoloText',
              archivePrimaryActionBtn: 'archivePrimaryActionBtn',
              adminView: 'adminView'
            });
            if (!item || !titleEl || !imgEl || !holoText) {
              UI.toast('封存預覽元件不存在');
              return;
            }
            holoText.classList.add('hidden');
            if (primaryBtn) {
              primaryBtn.classList.add('hidden');
              primaryBtn.innerText = '設為目前孵化中的蛋';
              primaryBtn.disabled = false;
              primaryBtn.style.opacity = '1';
              primaryBtn.onclick = null;
            }

            const isUnsafeUrl = (u) => {
              const s = String(u || '');
              if (!s) return false;
              if (s.startsWith('data:')) return false;
              if (!/^https?:\/\//i.test(s)) return false;
              return !/firebasestorage\.googleapis\.com\/v0\/b\//i.test(s);
            };
            const safeImg = (u) => (isUnsafeUrl(u) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (u || CONSTANTS.MEDIA.PLACEHOLDER_SVG));
            const renderArchiveRadar = (statsObj, borderColor, bgColor) => {
              callStudentMethod('renderRadarChartRaw', statsObj, 'archiveRadarChart', 'archive', borderColor, bgColor);
            };

            if (item.type === 'legendary') {
              const disp = buildCollectionDisplayItem(item, currentState.studentData);
              titleEl.innerText = isCatProfile(currentState.studentData) ? `[ 特殊救援夥伴 ]` : `[ 異獸夥伴・${item.name || '稀有異獸'} ]`;
              titleEl.style.color = 'var(--legendary-gold)';
              imgEl.src = (disp && disp.img) || safeImg(item.img);
              imgEl.style.filter = 'drop-shadow(0 0 30px var(--legendary-gold))';
              renderArchiveRadar({ metal: 100, wood: 100, water: 100, fire: 100, earth: 100 }, 'rgba(255,183,0,1)', 'rgba(255,183,0,0.2)');
            } else if (item.type === 'dead_dragon') {
              const causeName = getProfileDebuffInfo(item.cause, currentState.studentData)?.name || '未知異常';
              titleEl.innerText = isCatProfile(currentState.studentData) ? `[ 照護紀錄 - ${causeName} ]` : `[ 死亡紀錄 - 死於${causeName} ]`;
              titleEl.style.color = 'var(--danger)';
              imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
              imgEl.style.filter = 'brightness(0.9) opacity(0.65) drop-shadow(0 0 20px var(--danger))';
              renderArchiveRadar(item.stats || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, 'rgba(255,0,85,1)', 'rgba(255,0,85,0.2)');
            } else if (item.type === 'dragon') {
              const info = getProfileAttributeInfo(item.element, currentState.studentData) || { icon: '❓', name: '?', color: 'var(--cyan)' };
              titleEl.innerText = isCatProfile(currentState.studentData) ? `[ ${buildCollectionDisplayItem(item, currentState.studentData)?.title || '貓咪夥伴'} ]` : `[ ${item.name || '龍獸'} - 成長結算能量 ]`;
              titleEl.style.color = info.color;
              if (isCatProfile(currentState.studentData)) {
                imgEl.src = (buildCollectionDisplayItem(item, currentState.studentData)?.img) || safeImg(item.img);
                imgEl.style.filter = `drop-shadow(0 0 30px ${info.color})`;
              } else if (item.img_file) {
                setImgFromFileBaseName(imgEl, item.img_file, { shadowColor: info.color });
              } else {
                imgEl.src = safeImg(item.img);
                imgEl.style.filter = `drop-shadow(0 0 30px ${info.color})`;
              }
              renderArchiveRadar(item.stats || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, info.color, 'rgba(255,255,255,0.1)');
            } else if (item.type === 'hidden_egg') {
              const eggMeta = CONSTANTS.HIDDEN_EGGS[item.hiddenEggId || item.id] || item;
              const isActiveEgg = String(currentState.studentData?.active_hidden_egg_id || '') === String(item.hiddenEggId || item.id || '');
              titleEl.innerText = `[ ${eggMeta.name || '特殊異獸蛋'} ]`;
              titleEl.style.color = 'var(--color-water)';
              imgEl.src = (eggMeta.forms && eggMeta.forms.egg) || safeImg(item.img || eggMeta.img);
              imgEl.style.filter = 'drop-shadow(0 0 28px var(--color-water))';
              renderArchiveRadar(item.stats || currentState.studentData?.attributes || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, 'rgba(0,180,255,1)', 'rgba(0,180,255,0.18)');
              if (primaryBtn) {
                primaryBtn.classList.remove('hidden');
                primaryBtn.innerText = isActiveEgg ? '目前已是這顆蛋' : '設為目前孵化中的蛋';
                primaryBtn.disabled = isActiveEgg;
                primaryBtn.style.opacity = isActiveEgg ? '0.6' : '1';
              }
            } else if (item.type === 'material') {
              const info = CONSTANTS.ATTRIBUTES[item.element] || { icon: '❓', name: '?', color: 'var(--cyan)' };
              titleEl.innerText = isCatProfile(currentState.studentData) ? `[ ${buildCollectionDisplayItem(item, currentState.studentData)?.title || (info.name + '素材')} ]` : `[ 素材 - ${item.name || (info.name + '系素材')} ]`;
              titleEl.style.color = info.color;
              if (item.img_file) {
                setImgFromFileBaseName(imgEl, item.img_file, { shadowColor: info.color });
              } else {
                imgEl.src = safeImg(item.img);
                imgEl.style.filter = `drop-shadow(0 0 25px ${info.color})`;
              }
              renderArchiveRadar(item.stats || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, info.color, 'rgba(255,255,255,0.08)');
            } else if (item.type === 'voucher') {
              const disp = buildCollectionDisplayItem(item, currentState.studentData);
              const active = item.status !== 'redeemed';
              titleEl.innerText = `[ ${item.name || (active ? '兌換憑證' : '已兌現憑證')} ]`;
              titleEl.style.color = active ? 'var(--legendary-gold)' : 'var(--text-muted)';
              imgEl.src = (disp && disp.img) || safeImg(item.img);
              imgEl.style.filter = `drop-shadow(0 0 26px ${active ? 'var(--legendary-gold)' : 'rgba(255,255,255,0.35)'})`;
              renderArchiveRadar(item.stats || currentState.studentData?.attributes || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, active ? 'rgba(255,183,0,1)' : 'rgba(180,180,180,1)', active ? 'rgba(255,183,0,0.12)' : 'rgba(255,255,255,0.08)');
              if (primaryBtn) {
                const isAdminView = isVisibleEl(adminView);
                primaryBtn.classList.remove('hidden');
                primaryBtn.innerText = active ? (isAdminView ? '老師兌現憑證' : '向老師出示憑證') : '此憑證已兌現';
                primaryBtn.disabled = !active || !isAdminView;
                primaryBtn.style.opacity = (!active || !isAdminView) ? '0.6' : '1';
                if (isAdminView && active) {
                  primaryBtn.onclick = () => callAppMethod('redeemCollectionVoucher', index);
                }
              }
            } else {
              titleEl.innerText = '[ 舊版封存資料 ]';
              titleEl.style.color = 'var(--text-muted)';
              imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
              imgEl.style.filter = 'drop-shadow(0 0 15px rgba(255,255,255,0.15))';
              renderArchiveRadar({ metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, 'rgba(0,229,255,0.4)', 'rgba(0,229,255,0.08)');
            }

            UI.showModal('archiveModal');
          },
          openDisplayTeamEditor() {
            const dom = typeof getDisplayTeamDom === 'function' ? getDisplayTeamDom() : {};
            const { modal, grid, countDisplay } = dom || {};
            if (!modal || !grid) return;

            const data = currentState.studentData;
            if (!data) return;

            const col = Array.isArray(data.collection) ? data.collection : [];
            let selected = Array.isArray(data.display_team) ? data.display_team.slice() : [];
            selected = selected.map((v) => Number(v)).filter((v) => Number.isFinite(v));
            selected = selected.filter((i) => {
              if (i < 0 || i >= col.length) return false;
              const it = col[i];
              if (!it) return false;
              if (it.isHologram === true || it.isHologram === 'true') return false;
              if (it.type === 'dead_dragon') return false;
              return it.type === 'dragon' || it.type === 'legendary';
            });

            currentState.tempDisplayTeam = [...new Set(selected)].slice(0, 5);
            if (countDisplay) countDisplay.innerText = currentState.tempDisplayTeam.length;

            grid.innerHTML = '';
            col.forEach((it, idx) => {
              if (!it) return;
              if (it.isHologram === true || it.isHologram === 'true') return;
              if (it.type === 'dead_dragon') return;
              if (it.type !== 'dragon' && it.type !== 'legendary') return;

              let border = 'rgba(255,255,255,0.15)';
              let label = it.name || '龍獸';
              let img = it.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;

              if (it.type === 'legendary') {
                border = 'var(--legendary-gold)';
                label = `異獸 - ${it.name || '稀有異獸'}`;
              } else if (it.type === 'dragon') {
                const info = CONSTANTS.ATTRIBUTES[it.element] || { color: 'var(--cyan)', name: '?' };
                border = info.color;
                label = it.name || `${info.name}系龍獸`;
              }

              const sel = currentState.tempDisplayTeam.includes(idx);
              const fileBase = it.img_file || '';
              const imgSrc = fileBase ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : img;
              const dataAttr = fileBase ? `data-asset="${String(fileBase).replace(/"/g, '&quot;')}"` : '';
              grid.innerHTML += `
                <div class="team-item-btn ${sel ? 'selected' : ''}" id="dtItem_${idx}" onclick="App.toggleDisplayTeamItem(${idx})" style="border-color:${border};">
                  <img src="${imgSrc}" ${dataAttr} alt="${label}">
                  <div style="margin-top:6px; font-size:10px; text-align:center; color:${border}; line-height:1.2;">${label}</div>
                </div>`;
            });

            hydrateStorageImages(grid);
            UI.showModal('displayTeamModal');
          },
          toggleDisplayTeamItem(idx) {
            if (!Array.isArray(currentState.tempDisplayTeam)) currentState.tempDisplayTeam = [];
            const nextIdx = Number(idx);
            if (!Number.isFinite(nextIdx)) return;

            const dom = typeof getDisplayTeamDom === 'function' ? getDisplayTeamDom() : {};
            const { countDisplay } = dom || {};
            const el = getById(`dtItem_${nextIdx}`);
            const pos = currentState.tempDisplayTeam.indexOf(nextIdx);

            if (pos !== -1) {
              currentState.tempDisplayTeam.splice(pos, 1);
              if (el) el.classList.remove('selected');
            } else {
              if (currentState.tempDisplayTeam.length >= 5) return UI.toast('最多只能選 5 隻展示！');
              currentState.tempDisplayTeam.push(nextIdx);
              if (el) el.classList.add('selected');
            }

            if (countDisplay) countDisplay.innerText = currentState.tempDisplayTeam.length;
          },
          async saveDisplayTeam() {
            if (!currentState.studentData) return null;
            const data = applyDataMigrationSafe(JSON.parse(JSON.stringify(currentState.studentData || {})));
            const collection = Array.isArray(data.collection) ? data.collection : [];
            let team = Array.isArray(currentState.tempDisplayTeam) ? currentState.tempDisplayTeam.slice() : [];
            team = team.map((v) => Number(v)).filter((v) => Number.isFinite(v));
            team = team.filter((idx) => idx >= 0 && idx < collection.length && collection[idx] && !(collection[idx].isHologram === true || collection[idx].isHologram === 'true') && collection[idx].type !== 'dead_dragon');
            team = [...new Set(team)].slice(0, 5);
            data.display_team = team;
            data.logs = Array.isArray(data.logs) ? data.logs : [];
            data.logs.push({ timestamp: Date.now(), action_type: 'display_team', detail: `更新展示隊伍 (${team.length}/5)` });
            const saved = await callAppMethod('saveToDB', data);
            UI.hideModal('displayTeamModal');
            UI.toast('⭐ 展示隊伍已更新');
            return saved || data;
          },
          updateStudentAttributes(data, rowId) {
            const row = getById(rowId);
            if(!row) return;
            row.innerHTML = '';
            for (const attr of CONSTANTS.ATTR_ORDER) {
               const srcObj = (String(rowId||'').startsWith('stu') ? (data.attr_event_counts || {}) : (data.attributes || {}));
               const val = srcObj[attr] || 0;
               const info = getProfileAttributeInfo(attr, data);
               const color = val > 0 ? info.color : 'var(--text-muted)';
               const borderColor = val > 0 ? info.color : 'rgba(0,139,153,0.3)';
               row.innerHTML += `<div class="streak-item" style="color:${color}; border-color:${borderColor}; cursor:pointer;" onclick="UI.showAttrInfo('${attr}')" title="點擊查看學習指標">${info.icon} <span style="margin-left:2px; font-family:'Orbitron'; font-weight:bold;">${val}</span></div>`;
            }
          },
          renderRadarChartRaw(statsObj, canvasId, instanceKey, borderColor, bgColor) {
            const ctx = getById(canvasId);
            if (!ctx || typeof Chart !== "function") return;
            const dataVals = [ statsObj.metal||0, statsObj.wood||0, statsObj.water||0, statsObj.fire||0, statsObj.earth||0 ];
            const srcData = (String(instanceKey || '').startsWith('stu') || String(instanceKey || '').startsWith('adm')) ? currentState.studentData : null;
            const radarLabels = getRadarLabelsForData(srcData);
            if (radarChartInstances[instanceKey]) {
              radarChartInstances[instanceKey].data.datasets[0].data = dataVals;
              radarChartInstances[instanceKey].data.labels = radarLabels;
              radarChartInstances[instanceKey].data.datasets[0].borderColor = borderColor;
              radarChartInstances[instanceKey].data.datasets[0].backgroundColor = bgColor;
              radarChartInstances[instanceKey].data.datasets[0].pointBorderColor = borderColor;
              radarChartInstances[instanceKey].update();
            } else {
              radarChartInstances[instanceKey] = new Chart(ctx, {
                type: 'radar',
                data: {
                  labels: radarLabels,
                  datasets: [{ label: '能量分布', data: dataVals, backgroundColor: bgColor, borderColor: borderColor, pointBackgroundColor: '#fff', pointBorderColor: borderColor, pointRadius: 3, borderWidth: 1.5 }]
                },
                options: { responsive: true, maintainAspectRatio: false, scales: { r: { angleLines: { color: 'rgba(255, 255, 255, 0.1)' }, grid: { color: 'rgba(255, 255, 255, 0.1)' }, pointLabels: { color: '#00e5ff', font: { family: 'Noto Sans TC', size: 10 } }, ticks: { display: false, min: 0 } } }, plugins: { legend: { display: false }, tooltip: { enabled: false } } }
              });
            }
          },
          updateStatusContainer(data, containerId) {
            const c = getById(containerId);
            if(!c) return;
            c.innerHTML = '';
            let hasDebuff = false;
            for (const [key, count] of Object.entries(data.debuffs || {})) {
              if (count > 0) {
                hasDebuff = true; const info = getProfileDebuffInfo(key, data);
                c.innerHTML += `<span class="badge" style="color:${info.color}; border-color:${info.color}; cursor:pointer;" onclick="UI.showStatusInfo('${key}')" title="點擊查看說明">${info.name} x${count}</span>`;
              }
            }
            if (!hasDebuff) c.innerHTML = `<span class="badge status-Healthy">${getProfileLabels(data).statusHealthy || '狀態穩定'}</span>`;
          },
          updatePanel(data, isStudentMode = false) {
            const pfx = isStudentMode ? 'stu' : 'adm';
            applyProfileStaticTexts(data, isStudentMode);
            syncProfileForm(data);
            const classText = (!isStudentMode && data.card_seq) ? `${data.class_name} | 卡序 #${data.card_seq}` : `${data.class_name}`;
            const panelDom = readStudentDisplayDom(pfx);
            if (panelDom.classSeat) panelDom.classSeat.innerText = classText;
            if (panelDom.name) panelDom.name.innerText = data.name;
            if (panelDom.coins) panelDom.coins.innerText = data.coins;
            const prog = App.computeTrainerProgress(data);
    const storedRank = Number(data.trainerRankIndex);
    const rankIdx = Math.max(Number.isFinite(storedRank) ? storedRank : 0, prog.rankIndex);
    data.trainerRankIndex = rankIdx; // 單調不減（不掉階）
    const rankName = CONSTANTS.TRAINER_RANKS[rankIdx] || '見習守護員';
    if (panelDom.lapBadge) panelDom.lapBadge.innerText = `守護位階：${rankName}`;
            if (panelDom.xpBar) panelDom.xpBar.style.width = `${Math.min(data.totalXP, 100)}%`;
            if (panelDom.xpText) panelDom.xpText.innerText = `${data.totalXP} / 100`;

            callStudentMethod('updateDragonImage', data, `${pfx}DragonImg`);
            callStudentMethod('updateCollectionGallery', data, `${pfx}Collection`);
            callStudentMethod('renderRadarChartRaw', data.attributes, `${pfx}RadarChart`, pfx, 'rgba(0, 229, 255, 1)', 'rgba(0, 229, 255, 0.25)');
            callStudentMethod('updateStatusContainer', data, `${pfx}StatusContainer`);

            if (!isStudentMode) {
              if (panelDom.streakRow) {
                panelDom.streakRow.innerHTML = '';
                for (const attr of CONSTANTS.ATTR_ORDER) {
                  const val = data.streaks[attr] || 0;
                  const info = getProfileAttributeInfo(attr, data);
                  const color = val >= 3 ? 'var(--warning)' : (info.color || 'var(--cyan)');
                  panelDom.streakRow.innerHTML += `<div class="streak-item" style="color:${color}; border-color:${color}; cursor:pointer;" onclick="UI.showAttrInfo('${attr}')" title="點擊查看學習指標">${info.icon} <span style="margin-left:2px;">${val}</span></div>`;
                }
              }
              if (panelDom.logsList) {
                panelDom.logsList.innerHTML = '';
                const sortedLogs = [...data.logs].reverse().slice(0, 20);
                sortedLogs.forEach(log => {
                  const d = new Date(log.timestamp);
                  const timeStr = `${d.getMonth()+1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
                  const isDeath = log.detail.includes('[死亡]');
                  panelDom.logsList.innerHTML += `<div class="log-item"><span style="color:var(--text-muted);">[${timeStr}]</span> <span style="font-family:'Noto Sans TC'; color:${isDeath?'var(--danger)':'#fff'};">${log.detail}</span></div>`;
                });
              }
            } else {
              callStudentMethod('updateStudentAttributes', data, `${pfx}StreakRow`); 
              renderLifetimeStatsRow(data, panelDom.lifetimeStatsRow);
              callUiMethod('updateDailyQuestTimer');
              scheduleStudentAuxPanelsRefresh(data);
            }
          },

          loadStudentData(uid, mode, options = {}) {
            if(currentState.unsubscribe) currentState.unsubscribe();

            const isPreview = (currentState.viewMode === 'preview');
            const isStudentTokenMode = (mode === 'student' && !isPreview);
            const bindRequestedAt = Date.now();
            const bindToken = `student-load:${mode || 'unknown'}:${uid || ''}:${bindRequestedAt}:${Math.random().toString(36).slice(2, 8)}`;
            currentState.studentLoadToken = bindToken;
            currentState.studentLoadMode = mode || '';
            currentState.studentLoadRequestedUid = String(uid || '');
            currentState.studentLoadRequestedAt = bindRequestedAt;
            currentState.studentHydrationPending = true;
            currentState.studentHydrationError = '';
            const preloadedData = options?.preloadedData ? applyDataMigrationSafe(JSON.parse(JSON.stringify(options.preloadedData))) : null;
            const requestedSerial = isStudentTokenMode ? '' : normalizeSerialLike(options?.serial || uid || preloadedData?.card_seq || preloadedData?.serial || '');
            currentState.studentLoadActiveSerial = requestedSerial || '';
            const requestedToken = isStudentTokenMode ? String(uid || '').trim() : '';
            const preloadedSignature = preloadedData ? buildStudentRenderSignature(preloadedData) : '';
            const shouldPrimeView = Boolean(preloadedData) && options?.primeView !== false;
            const alreadyShowingRequestedAdminTarget = Boolean(
              mode === 'admin' &&
              requestedSerial &&
              normalizeSerialLike(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid || '') === requestedSerial &&
              currentState.studentLoadLastRenderSignature &&
              preloadedSignature &&
              currentState.studentLoadLastRenderSignature === preloadedSignature
            );
            let lastRenderSignature = alreadyShowingRequestedAdminTarget ? preloadedSignature : '';

            // 方案A：學生端以 token 作為文件ID（student_pages/{token}）
            if (isStudentTokenMode) {
              currentState.currentToken = requestedToken;
              currentState.currentTokenValidated = true;
              // serial 會在資料讀到後由 data.card_seq / data.serial 回填
              currentState.currentUid = null;
            } else {
              currentState.currentUid = requestedSerial || uid;
            }

            if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
              try {
                App.syncTeacherTargetContext(preloadedData || currentState.studentData, {
                  source: options?.source || 'loadStudentData:admin',
                  action: 'admin-bind-start',
                  serial: requestedSerial || currentState.currentUid || null,
                  hydrated: false,
                  hasStudentData: Boolean(preloadedData || currentState.studentData),
                  activeToken: bindToken,
                  clearError: true
                });
              } catch (bindErr) {
                console.warn('[student-view] bind-start syncTeacherTargetContext failed:', bindErr?.message || bindErr);
              }
            }

            const applyLoadedData = (rawData, sourceTag = '') => {
              let data = applyDataMigrationSafe(rawData || {});
              let mergeMasterPromise = null;
              let shouldPersistRecoveredDebuffs = false;

              if (isStudentTokenMode) {
                const serialRaw = data.card_seq || data.serial || '';
                const serialDigits = String(serialRaw).replace(/[^0-9]/g, '');
                currentState.currentUid = serialDigits ? serialDigits.padStart(3, '0') : null;
                if (currentState.currentToken) {
                  data.active_token = currentState.currentToken;
                  data.page_token = currentState.currentToken;
                } else if (currentState.currentUid && mode !== 'student') {
                  guardLog('student-master-merge', 'blocked by emergency flag', { serial: currentState.currentUid, mode });
                }

                if (currentState.studentLocked) callAppMethod('unlockStudentAccess');

                if (currentState.currentUid && mode !== 'student' && !isEmergencyFlagEnabled('disableStudentMasterMerge')) {
                  const snapshotData = JSON.parse(JSON.stringify(data || {}));
                  const expectedBindToken = bindToken;
                  mergeMasterPromise = (async () => {
                    try {
                      const masterData = await loadMasterStudentRecord(currentState.currentUid, { maxAgeMs: 12000 });
                      if (currentState.studentLoadToken !== expectedBindToken) return null;
                      if (!masterData) return null;
                      const merged = callAppMethod('mergeStudentRecords', snapshotData, masterData, currentState.currentUid) || snapshotData;
                      if (currentState.currentToken) {
                        merged.active_token = currentState.currentToken;
                        merged.page_token = currentState.currentToken;
                      }
                      return merged;
                    } catch (mergeErr) {
                      console.warn('[student-view] merge master record failed:', mergeErr?.message || mergeErr);
                      return null;
                    }
                  })();
                }
              }

              shouldPersistRecoveredDebuffs = Boolean(callStudentMethod('checkDebuffRecovery', data));
              const renderSignature = buildStudentRenderSignature(data);
              currentState.studentData = data;
              currentState.studentDataReadyAt = Date.now();
              markPerfPoint('student', 'student-data-ready', {
                mode,
                source: sourceTag || (mode === 'student' ? 'student-snapshot' : 'admin-snapshot'),
                serial: currentState.currentUid || data.card_seq || data.serial || '',
                hasToken: Boolean(currentState.currentToken)
              });
              currentState.studentDataLastSource = sourceTag || (mode === 'student' ? 'student-snapshot' : 'admin-snapshot');
              currentState.studentHydrationError = '';
              currentState.studentHydrationPending = false;
              currentState.studentLoadActiveSerial = normalizeSerialLike(currentState.currentUid || data.card_seq || data.serial || requestedSerial || '');
              callStudentMethod('refreshStudentIdentityLabels', data);
              if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
                try {
                  App.syncTeacherTargetContext(data, {
                    source: sourceTag || 'loadStudentData:admin',
                    action: 'admin-snapshot',
                    serial: currentState.currentUid || data.card_seq || data.serial || null,
                    hydrated: true,
                    clearError: true,
                    activeToken: bindToken
                  });
                } catch (targetErr) {
                  console.warn('[student-view] syncTeacherTargetContext failed:', targetErr?.message || targetErr);
                }
              }
              if (lastRenderSignature && lastRenderSignature === renderSignature) {
                currentState.studentDataLastSource = sourceTag || currentState.studentDataLastSource || '';
                if (mode === 'admin') {
                  try {
                    UI.show('adminStudentPanel');
                    UI.hideModal('previewPanel');
                  } catch (_) {}
                }
                if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
                  try {
                    App.syncTeacherTargetContext(data, {
                      source: sourceTag || 'loadStudentData:admin',
                      action: 'admin-snapshot-same',
                      serial: currentState.currentUid || data.card_seq || data.serial || null,
                      hydrated: true,
                      clearError: true,
                      activeToken: bindToken
                    });
                  } catch (_) {}
                }
                if (shouldPersistRecoveredDebuffs) {
                  try { Promise.resolve(callAppMethod('saveToDB', data)).catch((e) => console.warn('[student-view] debuff auto-save failed:', e?.message || e)); } catch (e) { console.warn('[student-view] debuff auto-save failed:', e?.message || e); }
                }
                return { data, mergeMasterPromise, skippedRender: true };
              }
              lastRenderSignature = renderSignature;
              currentState.studentLoadLastRenderSignature = renderSignature;
              if (mode === 'admin') UI.initActionGrid();

              const shopStatusDom = readStudentShopStatusDom();
              if (shopStatusDom.shopModal && !shopStatusDom.shopModal.classList.contains('hidden')) {
                if (shopStatusDom.shopCoins) shopStatusDom.shopCoins.innerText = data.coins || 0;
                shopStatusDom.itemButtons.forEach((b) => { b.disabled = false; b.style.opacity = 1; });
              }

              if (mode === 'admin') { UI.show('adminStudentPanel'); UI.updatePanel(data, false); UI.hideModal('previewPanel'); }
              else { UI.updatePanel(data, true); }
              if (shouldPersistRecoveredDebuffs) {
                try { Promise.resolve(callAppMethod('saveToDB', data)).catch((e) => console.warn('[student-view] debuff auto-save failed:', e?.message || e)); } catch (e) { console.warn('[student-view] debuff auto-save failed:', e?.message || e); }
              }
              if (mode === 'student') {
                try { callAppMethod('renderStudentShopShowcase', { source: sourceTag || (isStudentTokenMode ? 'student-snapshot' : 'student-direct') }); } catch (_) {}
                try { callAppMethod('warmStudentViewData', { source: sourceTag || (isStudentTokenMode ? 'student-snapshot' : 'student-direct') }); } catch (_) {}
              }
              if (mergeMasterPromise) {
                const expectedBindToken = bindToken;
                void mergeMasterPromise.then((merged) => {
                  if (!merged) return;
                  if (currentState.studentLoadToken !== expectedBindToken) return;
                  currentState.studentData = merged;
                  currentState.studentDataReadyAt = Date.now();
                  markPerfPoint('student', 'student-data-merged-master-ready', {
                    mode,
                    serial: currentState.currentUid || merged.card_seq || merged.serial || '',
                    source: 'student_pages:merged-master'
                  });
                  currentState.studentDataLastSource = 'student_pages:merged-master';
                  currentState.studentHydrationPending = false;
                  currentState.studentLoadActiveSerial = normalizeSerialLike(currentState.currentUid || merged.card_seq || merged.serial || '');
                  callStudentMethod('refreshStudentIdentityLabels', merged);
                  if (mode === 'admin') {
                    UI.show('adminStudentPanel');
                    UI.updatePanel(merged, false);
                    UI.hideModal('previewPanel');
                  } else {
                    UI.updatePanel(merged, true);
                    try { callAppMethod('renderStudentShopShowcase', { source: 'student_pages:merged-master' }); } catch (_) {}
                  }
                });
              }
              return { data, mergeMasterPromise };
            };

            if (shouldPrimeView && !alreadyShowingRequestedAdminTarget) {
              try {
                applyLoadedData(preloadedData, mode === 'admin' ? 'admin-preloaded' : 'student-preloaded');
              } catch (primeErr) {
                console.warn('[student-view] preloaded render failed:', primeErr?.message || primeErr);
              }
            } else if (alreadyShowingRequestedAdminTarget) {
              currentState.studentHydrationPending = true;
              currentState.studentDataLastSource = 'admin-rebind-same-target';
              if (preloadedData) callStudentMethod('refreshStudentIdentityLabels', preloadedData);
              if (mode === 'admin') {
                try {
                  UI.show('adminStudentPanel');
                  UI.hideModal('previewPanel');
                } catch (_) {}
              }
              if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
                try {
                  App.syncTeacherTargetContext(preloadedData, {
                    source: 'loadStudentData:admin',
                    action: 'admin-preloaded-same-target',
                    serial: requestedSerial || currentState.currentUid || preloadedData?.card_seq || preloadedData?.serial || null,
                    hydrated: true,
                    clearError: true,
                    touch: false,
                    activeToken: bindToken
                  });
                } catch (_) {}
              }
            }

            const docRef = isStudentTokenMode
              ? doc(db, STUDENT_PAGE_COLLECTION, requestedToken || uid)
              : doc(db, COLLECTION_NAME, requestedSerial || uid);

            currentState.unsubscribe = onSnapshot(
              docRef,
              async (docSnap) => {
                if (currentState.studentLoadToken !== bindToken) return;
                if (docSnap.exists()) {
                  applyLoadedData(docSnap.data() || {}, isStudentTokenMode ? 'student_pages:snapshot' : (mode === 'student' ? 'student-snapshot' : 'admin-snapshot'));
                } else {
                  currentState.studentHydrationPending = false;
                  currentState.studentHydrationError = docRef?.path ? `missing:${docRef.path}` : 'missing-document';
                  if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
                    try {
                      App.syncTeacherTargetContext(currentState.studentData, {
                        source: 'loadStudentData:admin',
                        action: 'admin-snapshot-missing',
                        serial: requestedSerial || currentState.currentUid || null,
                        hydrated: Boolean(currentState.studentData),
                        hasStudentData: Boolean(currentState.studentData),
                        error: currentState.studentHydrationError,
                        activeToken: bindToken
                      });
                    } catch (_) {}
                  }
                }
                if(mode === 'student') {
                  if (currentState.viewMode === 'preview') {
                    // 測試模式預覽：若資料不存在，自動補一筆卡序資料，方便你看到「真實畫面」
                    (async () => { await callAppMethod('seedPreviewStudent', uid); })();
                  } else if (isStudentTokenMode) {
                    callAppMethod('lockStudentAccess', '查無學員資料（此卡片尚未建檔或已被移除），請找老師協助。');
                  } else {
                    UI.toast('查無學員資料');
                  }
                }
              },
              (err) => {
                if (currentState.studentLoadToken !== bindToken) return;
                console.error(err);
                currentState.studentHydrationPending = false;
                currentState.studentHydrationError = err?.message || String(err || '未知錯誤');

                if (mode === 'student' && currentState.viewMode === 'preview') {
                  // rules 擋讀取時，也要讓預覽能看到畫面
                  const sample = callAppMethod('buildPreviewStudentData', uid);
                  currentState.currentUid = uid;
                  currentState.studentData = sample;
                  callStudentMethod('refreshStudentIdentityLabels', sample);
                  UI.updatePanel(sample, true);
                  UI.toast('⚠️ Firestore 讀取失敗，已改用本機預覽資料（請檢查 Rules / 登入狀態）。');
                  return;
                }

                if (mode === 'student' && isStudentTokenMode) {
                  // token 無效 / 停用 / 權限不足（由 Rules 控制）
                  callAppMethod('lockStudentAccess', '此卡片已停用或無權限讀取，請找老師協助。');
                  UI.toast('❌ 卡片驗證失敗');
                  return;
                }

                if (mode === 'admin' && App && typeof App.syncTeacherTargetContext === 'function') {
                  try {
                    App.syncTeacherTargetContext(currentState.studentData, {
                      source: 'loadStudentData:admin',
                      action: 'admin-snapshot-error',
                      serial: currentState.currentUid || null,
                      hydrated: Boolean(currentState.studentData),
                      hasStudentData: Boolean(currentState.studentData),
                      error: err?.message || err,
                      activeToken: bindToken
                    });
                  } catch (_) {}
                }
                UI.toast(`讀取資料失敗：${err.message || err}`);
              }
            );
          },

          checkDebuffRecovery(data) {
            let hasDebuff = false; for (let v of Object.values(data.debuffs || {})) if (v > 0) hasDebuff = true;
            if (hasDebuff && data.debuffs_timestamp) {
              if (Date.now() - data.debuffs_timestamp >= CONSTANTS.DEBUFF_CD_MS) {
                data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 }; data.debuffs_timestamp = null;
                data.logs.push({timestamp: Date.now(), action_type: 'system', detail: '狀態冷卻完畢，異常狀態自動清除。'}); return true;
              }
            }
            return false;
          },



          refreshStudentIdentityLabels(data) {
            const src = applyDataMigrationSafe(JSON.parse(JSON.stringify(data || currentState.studentData || {})));
            const classSeat = [src.class_name, src.seat_number].filter(Boolean).join('｜') || String(src.class_name || '---');
            const name = String(src.name || '未命名學生');
            const coins = Number(src.coins) || 0;
            const xp = Number(src.totalXP) || 0;
            const identityDom = readStudentIdentityDom();
            if (identityDom.admName) identityDom.admName.innerText = name;
            if (identityDom.stuName) identityDom.stuName.innerText = name;
            if (identityDom.batchStuName) identityDom.batchStuName.innerText = name;
            if (identityDom.admClassSeat) identityDom.admClassSeat.innerText = classSeat;
            if (identityDom.stuClassSeat) identityDom.stuClassSeat.innerText = classSeat;
            if (identityDom.batchStuClass) identityDom.batchStuClass.innerText = String(src.class_name || '---');
            if (identityDom.admCoins) identityDom.admCoins.innerText = String(coins);
            if (identityDom.stuCoins) identityDom.stuCoins.innerText = String(coins);
            if (identityDom.batchStuXp) identityDom.batchStuXp.innerText = `${xp} 點`;
          },

          refreshStudentRewardPanel(dataObj = null, forceStudentPanel = false) {
            const latest = applyDataMigrationSafe(JSON.parse(JSON.stringify(dataObj || currentState.studentData || {})));
            currentState.studentData = latest;

            const studentViewDom = readStudentViewDom();
            const studentViewHidden = !isVisibleEl(studentViewDom.studentView);
            const adminPanelVisible = isVisibleEl(studentViewDom.adminStudentPanel);
            callStudentMethod('refreshStudentIdentityLabels', latest);

            if (forceStudentPanel || (!studentViewHidden && currentState.viewMode !== 'admin')) {
              UI.updatePanel(latest, true);
            } else if (currentState.viewMode === 'admin' && adminPanelVisible) {
              UI.updatePanel(latest, false);
            }

            const shopStatusDom = readStudentShopStatusDom();
            if (shopStatusDom.shopCoins) shopStatusDom.shopCoins.innerText = Number(latest.coins) || 0;

            callAppMethod('refreshBaizeUi', latest);
            callAppMethod('ensureBaizeHistory');
            try { callAppMethod('renderStudentShopShowcase', { source: 'refreshStudentRewardPanel' }); } catch (_) {}

            return latest;
          },
  };

  return studentApi;
}
