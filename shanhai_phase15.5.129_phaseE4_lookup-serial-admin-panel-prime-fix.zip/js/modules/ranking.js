import { UI } from "../core/ui.js?v=phase15phase91fix3teachersavecheck";
import { currentState } from "../core/state.js?v=phase15phase91fix3teachersavecheck";
import { db, collection, doc, getDoc, getDocs, limit, orderBy, query, setDoc, writeBatch } from "../core/firebase.js?v=phase15phase91fix3teachersavecheck";
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";

attachEmergencyFlagGlobals();
const canUseAdminRankingFallback = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableStudentAdminCollectionFallback');
const canUseRankingSummaryBackfill = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableClientSummaryBackfill');

export function createRankingModule({ COLLECTION_NAME, LEADERBOARD_COLLECTION, CONSTANTS, hydrateStorageImages, applyDataMigration, computeTrainerProgress, normalizeSerial, resolveVisualMeta, getRankingDom }) {
  const rankingApi = {
    applyDataMigration(data = {}) {
      return typeof applyDataMigration === 'function'
        ? applyDataMigration(data)
        : JSON.parse(JSON.stringify(data || {}));
    },
    computeTrainerProgress(data = {}) {
      return typeof computeTrainerProgress === 'function'
        ? (computeTrainerProgress(data) || { rankIndex: 0 })
        : { rankIndex: 0 };
    },
    normalizeSerial(value = '') {
      if (typeof normalizeSerial === 'function') return normalizeSerial(value);
      const digits = String(value || '').replace(/\D+/g, '');
      return digits ? digits.padStart(3, '0').slice(-3) : '';
    },
    resolveVisualMeta(source = {}, options = {}) {
      if (typeof resolveVisualMeta === 'function') return resolveVisualMeta(source, options) || {};
      return {
        imageUrl: String(source?.imageUrl || source?.img || ''),
        imageAssetKey: String(source?.imageAssetKey || source?.img_file || ''),
        imageAlt: String(options?.alt || source?.imageAlt || source?.name || '').trim()
      };
    },
    getRankingDisplayItems(studentLike = {}) {
      const directItems = Array.isArray(studentLike?.display_items)
        ? studentLike.display_items
        : (Array.isArray(studentLike?.displayItems)
          ? studentLike.displayItems
          : (Array.isArray(studentLike?.team_preview) ? studentLike.team_preview : []));
      const sanitizeItems = (items) => (Array.isArray(items) ? items : []).map((item) => {
        const visual = this.resolveVisualMeta(item, { alt: String(item?.name || '') });
        return {
          type: String(item?.type || ''),
          name: String(item?.name || ''),
          element: String(item?.element || ''),
          img: visual.imageUrl || '',
          img_file: visual.imageAssetKey || '',
          imageUrl: visual.imageUrl || '',
          imageAssetKey: visual.imageAssetKey || '',
          points: Number(item?.points) || 0,
          isHologram: item?.isHologram === true || item?.isHologram === 'true'
        };
      }).filter((item) => item && item.type !== 'dead_dragon' && (item.type === 'dragon' || item.type === 'legendary'));
      if (directItems.length) return sanitizeItems(directItems);

      const col = Array.isArray(studentLike?.collection) ? studentLike.collection : [];
      let displayItems = [];
      if (Array.isArray(studentLike?.display_team) && studentLike.display_team.length > 0) {
        displayItems = studentLike.display_team.map((v) => col[Number(v)]).filter((i) => i && !(i.isHologram === true || i.isHologram === 'true') && i.type !== 'dead_dragon' && (i.type === 'dragon' || i.type === 'legendary'));
      }
      if (displayItems.length === 0) {
        displayItems = col.filter((i) => i && !(i.isHologram === true || i.isHologram === 'true') && i.type !== 'dead_dragon' && (i.type === 'dragon' || i.type === 'legendary')).slice(-5);
      }
      return sanitizeItems(displayItems);
    },
    getRankingLegendaryPoints(studentLike = {}) {
      const explicit = Number(studentLike?.legendaryPoints ?? studentLike?.legendary_points);
      if (Number.isFinite(explicit) && explicit > 0) return explicit;
      const col = Array.isArray(studentLike?.collection) ? studentLike.collection : this.getRankingDisplayItems(studentLike);
      return (col || []).filter((item) => item?.type === 'legendary').reduce((sum, item) => sum + (Number(item?.points) || 0), 0);
    },
    buildLeaderboardSummaryData(data = {}, serial = '') {
      const normalized = this.applyDataMigration(JSON.parse(JSON.stringify(data || {})));
      const s = this.normalizeSerial(serial || normalized.card_seq || normalized.serial || normalized.uid || '');
      const rankProgress = this.computeTrainerProgress(normalized);
      const rankIndex = Math.max(Number(normalized?.trainerRankIndex) || 0, rankProgress.rankIndex);
      const totalXP = Number(normalized?.totalXP) || 0;
      const legendaryPoints = this.getRankingLegendaryPoints(normalized);
      const displayItems = this.getRankingDisplayItems(normalized);
      return {
        serial: s,
        card_seq: s,
        studentId: s,
        name: String(normalized?.name || '未命名'),
        class_name: String(normalized?.class_name || ''),
        totalXP,
        trainerRankIndex: rankIndex,
        legendaryPoints,
        rankScore: rankIndex * 1000000 + legendaryPoints * 1000 + totalXP,
        display_items: displayItems,
        display_image_urls: displayItems.map((item) => String(item?.imageUrl || item?.img || '')).filter(Boolean),
        display_image_assets: displayItems.map((item) => String(item?.imageAssetKey || item?.img_file || '')).filter(Boolean),
        updated_at: Date.now()
      };
    },
    normalizeLeaderboardSummaryRecord(raw = {}, docId = '') {
      const serial = this.normalizeSerial(raw?.serial || raw?.card_seq || raw?.studentId || docId || '');
      const displayItems = this.getRankingDisplayItems(raw);
      const trainerRankIndex = Number(raw?.trainerRankIndex ?? raw?.rankIndex) || 0;
      const totalXP = Number(raw?.totalXP) || 0;
      const legendaryPoints = this.getRankingLegendaryPoints(raw);
      const rankScore = Number(raw?.rankScore);
      return {
        serial,
        card_seq: serial,
        name: String(raw?.name || '未命名'),
        class_name: String(raw?.class_name || ''),
        totalXP,
        trainerRankIndex,
        legendaryPoints,
        rankScore: Number.isFinite(rankScore) ? rankScore : (trainerRankIndex * 1000000 + legendaryPoints * 1000 + totalXP),
        display_items: displayItems,
        display_team: displayItems.map((_, idx) => idx),
        collection: displayItems,
        rankingSource: 'leaderboard_public',
        updated_at: Number(raw?.updated_at || raw?.updatedAt) || 0
      };
    },
    async loadLeaderboardSummary(limitCount = 30) {
      const snapshot = await getDocs(query(collection(db, LEADERBOARD_COLLECTION), orderBy('rankScore', 'desc'), limit(Math.max(1, Number(limitCount) || 30))));
      const rows = [];
      snapshot.forEach((docSnap) => {
        const row = this.normalizeLeaderboardSummaryRecord(docSnap.data() || {}, docSnap.id);
        if (row && row.name) rows.push(row);
      });
      rows.sort((a, b) => ((Number(b?.rankScore) || 0) - (Number(a?.rankScore) || 0))
        || ((Number(b?.legendaryPoints) || 0) - (Number(a?.legendaryPoints) || 0))
        || ((Number(b?.totalXP) || 0) - (Number(a?.totalXP) || 0))
        || ((Number(b?.updated_at) || 0) - (Number(a?.updated_at) || 0)));
      return rows.slice(0, Math.max(1, Number(limitCount) || 30));
    },
    syncLeaderboardSummaryForSerial(serial, preferredData = null) {
      const s = this.normalizeSerial(serial);
      if (!s) return Promise.resolve(null);
      const provided = preferredData ? this.applyDataMigration(JSON.parse(JSON.stringify(preferredData || {}))) : null;
      const runner = async () => {
        let sourceData = provided;
        if (!sourceData) {
          const studentSnap = await getDoc(doc(db, COLLECTION_NAME, s));
          if (!studentSnap.exists()) return null;
          sourceData = this.applyDataMigration(JSON.parse(JSON.stringify(studentSnap.data() || {})));
        }
        const summary = this.buildLeaderboardSummaryData(sourceData, s);
        await setDoc(doc(db, LEADERBOARD_COLLECTION, s), summary, { merge: true });
        return summary;
      };
      return runner().catch((err) => {
        console.warn('[leaderboard-summary] sync failed:', err?.message || err);
        return null;
      });
    },
    backfillLeaderboardSummaryEntries(students = []) {
      const list = Array.isArray(students) ? students : [];
      if (!list.length) return Promise.resolve(0);
      const top = this.rankStudentsForBoard(list).slice(0, 30);
      const runner = async () => {
        const batch = writeBatch(db);
        let touched = 0;
        top.forEach((student) => {
          const serial = this.normalizeSerial(student?.card_seq || student?.serial || student?.uid || '');
          if (!serial) return;
          batch.set(doc(db, LEADERBOARD_COLLECTION, serial), this.buildLeaderboardSummaryData(student, serial), { merge: true });
          touched += 1;
        });
        if (touched < 1) return 0;
        await batch.commit();
        return touched;
      };
      return runner().catch((err) => {
        console.warn('[leaderboard-summary] backfill failed:', err?.message || err);
        return 0;
      });
    },
    rankStudentsForBoard(students = []) {
      const list = Array.isArray(students) ? [...students] : [];
      list.sort((a, b) => {
        const aProg = this.computeTrainerProgress(a);
        const bProg = this.computeTrainerProgress(b);
        const aRank = Math.max(Number(a?.trainerRankIndex) || 0, aProg.rankIndex);
        const bRank = Math.max(Number(b?.trainerRankIndex) || 0, bProg.rankIndex);
        if (bRank !== aRank) return bRank - aRank;
        const aLegPts = this.getRankingLegendaryPoints(a);
        const bLegPts = this.getRankingLegendaryPoints(b);
        if (bLegPts !== aLegPts) return bLegPts - aLegPts;
        return (Number(b?.totalXP) || 0) - (Number(a?.totalXP) || 0);
      });
      return list.slice(0, 30);
    },
    renderRankingRows(students = [], tbody = null) {
      if (!tbody) return;
      tbody.innerHTML = '';
      if (!Array.isArray(students) || !students.length) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">目前尚無資料</td></tr>';
        return;
      }

      const isUnsafeUrl = (u) => {
        const s = String(u || '');
        if (!s) return false;
        if (s.startsWith('data:')) return false;
        if (!/^https?:\/\//i.test(s)) return false;
        return !/firebasestorage\.googleapis\.com\/v0\/b\//i.test(s);
      };
      const safeImg = (u) => (isUnsafeUrl(u) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (u || CONSTANTS.MEDIA.PLACEHOLDER_SVG));

      students.forEach((st, idx) => {
        let rankClass = '';
        if (idx === 0) rankClass = 'rank-1'; else if (idx === 1) rankClass = 'rank-2'; else if (idx === 2) rankClass = 'rank-3';
        const prog = st?.rankingSource === 'leaderboard_public' ? { rankIndex: Number(st?.trainerRankIndex) || 0 } : this.computeTrainerProgress(st);
        const rankIdx = Math.max(Number(st.trainerRankIndex) || 0, prog.rankIndex);
        const rankName = CONSTANTS.TRAINER_RANKS[rankIdx] || '新手學徒';
        const displayItems = this.getRankingDisplayItems(st);
        let collectionHtml = '<div style="display:flex; gap:5px; flex-wrap:wrap;">';
        const escAttr = (v) => String(v || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
        const isHttp = (v) => /^https?:\/\//i.test(String(v || ''));
        if (displayItems.length > 0) {
          displayItems.forEach((item) => {
            const title = escAttr(item?.name || '');
            const imageUrl = String(item?.imageUrl || item?.img || '');
            const imageAssetKey = String(item?.imageAssetKey || item?.img_file || '');
            const directUrl = isHttp(imageUrl) ? safeImg(imageUrl) : CONSTANTS.MEDIA.PLACEHOLDER_SVG;
            const assetKey = imageAssetKey ? escAttr(imageAssetKey) : ((!isHttp(imageUrl) && imageUrl) ? escAttr(imageUrl) : '');
            if (item.type === 'legendary') {
              collectionHtml += `<img src="${directUrl}" ${assetKey ? `data-asset="${assetKey}"` : ''} style="width:35px; height:35px; object-fit:contain; filter:drop-shadow(0 0 3px var(--legendary-gold)); border:1px solid var(--legendary-gold); border-radius:5px; background:rgba(255,183,0,0.1);" title="${title || '稀有異獸'}">`;
            } else if (item.type === 'dragon') {
              const info = CONSTANTS.ATTRIBUTES[item.element] || { color: 'var(--cyan)', name: '?' };
              collectionHtml += `<img src="${directUrl}" ${assetKey ? `data-asset="${assetKey}"` : ''} style="width:35px; height:35px; object-fit:contain; filter:drop-shadow(0 0 2px ${info.color}); border:1px solid rgba(255,255,255,0.2); border-radius:5px; background:rgba(0,0,0,0.5);" title="${title || (info.name + '系龍獸')}">`;
            }
          });
        } else {
          collectionHtml += '<span style="color:#555; font-size:0.8em;">無展示資料</span>';
        }
        collectionHtml += '</div>';
        const legPts = this.getRankingLegendaryPoints(st);
        tbody.innerHTML += `
          <tr>
            <td class="${rankClass}">#${idx + 1}</td>
            <td>
              <div style="font-weight:bold; font-family:Noto Sans TC, sans-serif; font-size:1.1em;">${st.name}</div>
              <div class="tech-font" style="font-size:0.75em; color:var(--text-muted);">${st.class_name}</div>
            </td>
            <td class="tech-font">
              <span class="badge" style="border-color:var(--cyan); color:var(--cyan); margin-bottom:4px; display:inline-block;">${rankName}</span><br>
              ${legPts > 0 ? `<span style="color:var(--legendary-gold); font-size:0.85em;">★ ${legPts} pts</span><br>` : ''}
              <span style="font-size:0.85em; color:#ccc;">${st.totalXP} 點總能量</span>
            </td>
            <td>${collectionHtml}</td>
          </tr>
        `;
      });
      hydrateStorageImages(tbody, { rootMargin: '240px 0px', eagerLimit: 3 });
    },
    async warmRankingCache(options = {}) {
      const force = !!options.force;
      const maxAgeMs = Math.max(30000, Number(options.maxAgeMs) || 180000);
      const now = Date.now();
      if (!force && Array.isArray(currentState.rankingCache) && currentState.rankingCache.length && (now - (currentState.rankingCacheLoadedAt || 0)) < maxAgeMs) {
        return currentState.rankingCache;
      }
      if (!force && currentState.rankingCachePromise) return currentState.rankingCachePromise;

      let loadPromise;
      loadPromise = (async () => {
        try {
          let ranked = [];
          let summaryErr = null;
          try {
            ranked = await this.loadLeaderboardSummary(30);
          } catch (err) {
            summaryErr = err;
            console.warn('[warmRankingCache] leaderboard_public failed, fallback to full scan:', err?.message || err);
          }
          if ((!Array.isArray(ranked) || ranked.length < 1) && canUseAdminRankingFallback()) {
            const snapshot = await getDocs(collection(db, COLLECTION_NAME));
            const students = [];
            snapshot.forEach((docSnap) => { students.push(this.applyDataMigration(docSnap.data())); });
            ranked = this.rankStudentsForBoard(students);
            try { this.backfillLeaderboardSummaryEntries(students); } catch (_) {}
          }
          currentState.rankingCache = ranked;
          currentState.rankingCacheLoadedAt = Date.now();
          currentState.rankingCacheLastError = summaryErr ? (summaryErr?.message || String(summaryErr)) : '';
          return ranked;
        } catch (err) {
          currentState.rankingCacheLastError = err?.message || String(err || '未知錯誤');
          if (Array.isArray(currentState.rankingCache) && currentState.rankingCache.length) {
            return currentState.rankingCache;
          }
          throw err;
        } finally {
          if (currentState.rankingCachePromise === loadPromise) currentState.rankingCachePromise = null;
        }
      })();
      currentState.rankingCachePromise = loadPromise;
      return loadPromise;
    },
    async showRanking() {
      const dom = typeof getRankingDom === 'function'
        ? (getRankingDom() || {})
        : { modal: document.getElementById('rankingModal'), tableBody: document.getElementById('rankingTableBody') };
      const modal = dom.modal;
      const tbody = dom.tableBody;
      if (!modal || !tbody) {
        UI.alert('排行榜面板缺少必要元件，請重新整理頁面後再試。', '系統異常');
        return;
      }
      UI.showModal('rankingModal');

      const cached = Array.isArray(currentState.rankingCache) ? currentState.rankingCache : [];
      if (cached.length) {
        this.renderRankingRows(cached, tbody);
      } else {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">載入榜單中...</td></tr>';
      }

      const fetchPromise = this.warmRankingCache({ force: cached.length < 1, maxAgeMs: 180000, source: 'showRanking' });
      const timeoutToken = Symbol('ranking-timeout');
      try {
        const ranked = await Promise.race([
          fetchPromise,
          new Promise((resolve) => window.setTimeout(() => resolve(timeoutToken), 6500))
        ]);
        if (ranked === timeoutToken) {
          if (cached.length) {
            UI.toast('排行榜更新較慢，先顯示快取資料。');
          } else {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--warning);">榜單載入較慢，背景同步中…</td></tr>';
          }
          fetchPromise.then((fresh) => {
            const latestDom = typeof getRankingDom === 'function'
              ? (getRankingDom() || {})
              : { modal: document.getElementById('rankingModal') };
            if (latestDom.modal && !latestDom.modal.classList.contains('hidden')) {
              this.renderRankingRows(fresh, tbody);
            }
          }).catch((err) => {
            console.error(err);
            if (!cached.length) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red;">讀取失敗</td></tr>';
          });
          return;
        }
        this.renderRankingRows(ranked, tbody);
      } catch (e) {
        console.error(e);
        if (cached.length) {
          this.renderRankingRows(cached, tbody);
          UI.toast('排行榜同步失敗，已顯示快取資料。');
        } else {
          tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red;">讀取失敗</td></tr>';
        }
      }
    }
  };

  return rankingApi;
}
