import { UI } from "../core/ui.js?v=phase15phase98fix10shopstudentsplit";
import { currentState } from "../core/state.js?v=phase15phase98fix10shopstudentsplit";
import { db, collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, writeBatch } from "../core/firebase.js?v=phase15phase98fix10shopstudentsplit";
import { buildElementContract } from "../core/dom-contract.js?v=phase15phase98fix10shopstudentsplit";
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";

export function createShopModule({ SHOP_COLLECTION, SHOP_PUBLIC_COLLECTION, COLLECTION_NAME, CONSTANTS, getContentProfile, normalizeSerial, applyDataMigration, resolveVisualMeta, saveToDB, processEvolution, isCatProfile, addAttributeXP, hydrateStorageImages, getStudentShopShowcaseDom, bindStudentShopRailControls, updateStudentShopRailButtons, teacherActionsApi, getDominantElementFromData }) {
  function getShopDomElements() {
    const contract = buildElementContract({
      itemsContainer: 'shopItemsContainer',
      coins: 'shopCoins',
      adminModal: 'shopAdminModal',
      adminList: 'shopAdminList',
      adminName: 'shopAdminName',
      adminCost: 'shopAdminCost',
      adminDesc: 'shopAdminDesc',
      adminEffect: 'shopAdminEffect',
      adminQty: 'shopAdminQty',
      adminImageUrl: 'shopAdminImageUrl',
      adminStudentTradeMode: 'shopAdminStudentTradeMode',
      adminStudentVisible: 'shopAdminStudentVisible',
      adminImagePreview: 'shopAdminImagePreview',
      adminHiddenEgg: 'shopAdminHiddenEgg',
      adminActive: 'shopAdminActive',
      adminHint: 'shopAdminHint',
      adminCatalogPane: 'shopAdminCatalogPane',
      adminGiftPane: 'shopAdminGiftPane',
      adminTabBtnCatalog: 'shopAdminTabBtnCatalog',
      adminTabBtnGift: 'shopAdminTabBtnGift',
      giftTargetSeq: 'shopGiftTargetSeq',
      giftItemSelect: 'shopGiftItemSelect',
      giftAttrSelect: 'shopGiftAttrSelect',
      giftNote: 'shopGiftNote',
      giftTargetInfo: 'shopGiftTargetInfo',
      giftCatalogList: 'shopGiftCatalogList',
      shopModal: 'shopModal',
      attrSelectModal: 'attrSelectModal',
      attrSelectTitle: 'attrSelectTitle',
      confirmAttrSelectBtn: 'confirmAttrSelectBtn',
      attrSelectDropdown: 'attrSelectDropdown'
    }, [
      'itemsContainer', 'coins', 'adminModal', 'adminList',
      'adminName', 'adminCost', 'adminDesc', 'adminEffect', 'adminQty', 'adminImageUrl', 'adminStudentTradeMode',
      'adminStudentVisible', 'adminImagePreview', 'adminHiddenEgg', 'adminActive',
      'adminHint', 'adminCatalogPane', 'adminGiftPane', 'adminTabBtnCatalog', 'adminTabBtnGift',
      'giftTargetSeq', 'giftItemSelect', 'giftAttrSelect', 'giftNote', 'giftTargetInfo', 'giftCatalogList',
      'shopModal', 'attrSelectModal', 'attrSelectTitle', 'confirmAttrSelectBtn', 'attrSelectDropdown'
    ]);
    currentState.shopDomContract = { checkedAt: Date.now(), missing: contract.missing.slice(), ok: contract.ok };
    try {
      const diagBase = (globalThis.__BOOT_DIAG && typeof globalThis.__BOOT_DIAG === 'object') ? globalThis.__BOOT_DIAG : {};
      globalThis.__BOOT_DIAG = {
        ...diagBase,
        shopDomContract: {
          ok: contract.ok,
          missing: contract.missing.slice(),
          checkedAt: currentState.shopDomContract.checkedAt
        }
      };
    } catch (_) {}
    return contract.elements;
  }

  const getShopAdminFormElements = () => {
    const dom = getShopDomElements();
    return {
      name: dom.adminName,
      cost: dom.adminCost,
      desc: dom.adminDesc,
      effect: dom.adminEffect,
      qty: dom.adminQty,
      imageUrl: dom.adminImageUrl,
      studentTradeMode: dom.adminStudentTradeMode,
      studentVisible: dom.adminStudentVisible,
      imagePreview: dom.adminImagePreview,
      hiddenEgg: dom.adminHiddenEgg,
      active: dom.adminActive
    };
  };

  const hasCompleteShopAdminForm = (els = getShopAdminFormElements()) => !!(
    els.name && els.cost && els.desc && els.effect && els.qty && els.imageUrl &&
    els.studentTradeMode && els.studentVisible && els.imagePreview && els.hiddenEgg && els.active
  );

  const escapeHtml = (value = '') => String(value || '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch] || ch));
  const escapeAttr = (value = '') => escapeHtml(value).replace(/'/g, '&#39;');
  const shopImagePlaceholder = () => CONSTANTS?.MEDIA?.PLACEHOLDER_SVG || '';
  const isAllowedShopImageUrl = (value = '') => /^(https?:\/\/|data:image\/|blob:)/i.test(String(value || '').trim());
  const normalizeShopImageUrl = (value = '') => {
    const trimmed = String(value || '').trim();
    return isAllowedShopImageUrl(trimmed) ? trimmed : '';
  };
  const getShopImageUrl = (item = {}) => normalizeShopImageUrl(item.image || item.imageUrl || item.img || item.thumbnailUrl || item.cover || '');
  const renderShopImageThumb = (item = {}, options = {}) => {
    const size = Math.max(42, Number(options.size) || 64);
    const radius = Math.max(8, Math.round(size * 0.2));
    const src = getShopImageUrl(item) || shopImagePlaceholder();
    const placeholder = escapeAttr(shopImagePlaceholder());
    const assetKey = (!getShopImageUrl(item) && String(item.imageAssetKey || item.image_asset_key || item.img_file || '').trim())
      ? escapeAttr(String(item.imageAssetKey || item.image_asset_key || item.img_file || '').trim())
      : '';
    return `<div style="width:${size}px; min-width:${size}px; height:${size}px; border-radius:${radius}px; overflow:hidden; border:1px solid rgba(255,255,255,0.12); background:rgba(255,255,255,0.04); display:flex; align-items:center; justify-content:center;">
      <img src="${escapeAttr(src)}" ${assetKey ? `data-asset="${assetKey}"` : ''} alt="${escapeAttr(item.name || '商品縮圖')}" loading="lazy" referrerpolicy="no-referrer" onerror="this.onerror=null;this.src='${placeholder}';" style="width:100%; height:100%; object-fit:cover; display:block;">
    </div>`;
  };
  const renderShopAdminImagePreview = () => {
    const form = getShopAdminFormElements();
    const preview = form.imagePreview;
    if (!preview) return;
    const rawUrl = form.imageUrl?.value || '';
    const safeUrl = normalizeShopImageUrl(rawUrl);
    if (!safeUrl) {
      preview.innerHTML = '<div style="color:var(--text-muted); font-size:0.74em; line-height:1.5; text-align:center; font-family:Noto Sans TC, sans-serif;">尚未設定商品圖片</div>';
      return;
    }
    preview.innerHTML = `<img src="${escapeAttr(safeUrl)}" alt="商品預覽" referrerpolicy="no-referrer" onerror="this.onerror=null;this.src='${escapeAttr(shopImagePlaceholder())}';" style="width:100%; height:100%; object-fit:cover; display:block;">`;
  };

  attachEmergencyFlagGlobals();
  const canUseAdminShopFallback = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableStudentAdminCollectionFallback');
  const canUseShopSummaryBackfill = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableClientSummaryBackfill');
  const setShopBusy = (flag = true) => { currentState.shopBusy = !!flag; };
  const setShopAdminSaving = (flag = true) => { currentState.shopAdminSaving = !!flag; };
  const setShopGiftSending = (flag = true) => { currentState.shopGiftSending = !!flag; };
  const isShopInteractionLocked = () => !!(currentState.shopBusy || currentState.shopAdminSaving || currentState.shopGiftSending);
  const normalizeSerialSafe = (value = '') => {
    if (typeof normalizeSerial === 'function') return normalizeSerial(value);
    const digits = String(value || '').replace(/\D+/g, '');
    return digits ? digits.padStart(3, '0').slice(-3) : '';
  };
  const migrateStudentData = (data = {}) => typeof applyDataMigration === 'function'
    ? applyDataMigration(JSON.parse(JSON.stringify(data || {})))
    : JSON.parse(JSON.stringify(data || {}));
  const saveStudentData = async (data, serial) => {
    if (typeof saveToDB !== 'function') throw new Error('saveToDB helper unavailable');
    return await saveToDB(data, serial);
  };
  const processEvolutionSafe = (data) => (typeof processEvolution === 'function' ? processEvolution(data) : data);
  const isCatProfileSafe = (data) => (typeof isCatProfile === 'function' ? isCatProfile(data) : false);
  const addAttributeXPSafe = (data, attr, amount) => { if (typeof addAttributeXP === 'function') addAttributeXP(data, attr, amount); };

  const syncStudentShopCatalogSummary = async (productId, data) => {
    if (!shopApi || typeof shopApi.syncStudentShopCatalogSummaryForId !== 'function') return null;
    return await shopApi.syncStudentShopCatalogSummaryForId(productId, data);
  };
  const removeStudentShopCatalogSummary = async (productId) => {
    if (!shopApi || typeof shopApi.removeStudentShopCatalogSummaryForId !== 'function') return null;
    return await shopApi.removeStudentShopCatalogSummaryForId(productId);
  };
  const refreshStudentShopShowcase = async (options = {}) => {
    if (!shopApi || typeof shopApi.renderStudentShopShowcase !== 'function') return null;
    return await shopApi.renderStudentShopShowcase(options);
  };
  const getShopShowcaseDom = () => (typeof getStudentShopShowcaseDom === 'function'
    ? (getStudentShopShowcaseDom() || {})
    : {
        section: document.getElementById('studentShopSection'),
        status: document.getElementById('studentShopStatus'),
        track: document.getElementById('studentShopTrack'),
        prevBtn: document.getElementById('studentShopPrevBtn'),
        nextBtn: document.getElementById('studentShopNextBtn')
      });
  const bindShopRailControls = () => {
    if (typeof bindStudentShopRailControls === 'function') return bindStudentShopRailControls();
    return null;
  };
  const refreshShopRailButtons = () => {
    if (typeof updateStudentShopRailButtons === 'function') return updateStudentShopRailButtons();
    return null;
  };
  const resolveVisualMetaSafe = (source = {}, options = {}) => (typeof resolveVisualMeta === 'function'
    ? (resolveVisualMeta(source, options) || {})
    : {
        imageUrl: String(source?.imageUrl || source?.img || ''),
        imageAssetKey: String(source?.imageAssetKey || source?.img_file || ''),
        imageAlt: String(options?.alt || source?.imageAlt || source?.name || '').trim()
      });

  const getShopFlowDomElements = () => {
    const dom = getShopDomElements();
    return {
      shopModal: dom.shopModal,
      shopCoins: dom.coins,
      attrSelectModal: dom.attrSelectModal,
      attrSelectTitle: dom.attrSelectTitle,
      confirmAttrSelectBtn: dom.confirmAttrSelectBtn,
      attrSelectDropdown: dom.attrSelectDropdown
    };
  };
  const ensureShopFlowDom = () => {
    const dom = getShopFlowDomElements();
    if (!dom.shopModal || !dom.shopCoins) {
      UI.alert('商城面板缺少必要元件，請重新整理頁面後再試。', '系統異常');
      return null;
    }
    return dom;
  };
  const ensureAttrSelectDom = () => {
    const dom = getShopFlowDomElements();
    if (!dom.attrSelectModal || !dom.attrSelectTitle || !dom.confirmAttrSelectBtn || !dom.attrSelectDropdown) {
      UI.alert('屬性選擇面板缺少必要元件，請重新整理頁面後再試。', '系統異常');
      return null;
    }
    return dom;
  };
  const buildShopVoucherRecord = (itemMeta = {}, data = {}, voucherTs = Date.now()) => ({
    type: 'voucher',
    voucherId: `voucher_${String(itemMeta.id || 'item').replace(/[^a-zA-Z0-9_-]/g, '')}_${voucherTs}`,
    itemId: String(itemMeta.id || ''),
    name: itemMeta.name || '實體商品兌換憑證',
    desc: itemMeta.desc || '請向老師出示此憑證兌換實體物品。',
    img: itemMeta.img || itemMeta.image || itemMeta.imageUrl || CONSTANTS.MEDIA.PLACEHOLDER_SVG,
    status: 'active',
    purchasedAt: voucherTs,
    redeemedAt: null,
    redeemedBy: null,
    stats: { ...(data.attributes || {}) },
    timestamp: voucherTs
  });

  const shopApi = {
    getBuiltInShopItems() {
      const profile = getContentProfile(currentState.studentData);
      const alias = profile.builtInShop || {};
      return [
        { id: 'antidote', name: alias.antidote?.name || '💊 萬靈藥', desc: alias.antidote?.desc || '清除所有負面狀態', cost: 10, borderColor: 'var(--color-grass)', effectType: 'antidote', quantity: null, active: true, builtIn: true, image: normalizeShopImageUrl(alias.antidote?.image || alias.antidote?.imageUrl || '') },
        { id: 'evo_stone', name: alias.evo_stone?.name || '✨ 各系進化石', desc: alias.evo_stone?.desc || '指定屬性直接 +30 XP', cost: 20, borderColor: 'var(--color-fire)', effectType: 'evo_stone', quantity: null, active: true, builtIn: true, image: normalizeShopImageUrl(alias.evo_stone?.image || alias.evo_stone?.imageUrl || '') },
        { id: 'wonder_stone', name: alias.wonder_stone?.name || '🌟 進化奇石', desc: alias.wonder_stone?.desc || '指定屬性素材 +1', cost: 50, borderColor: 'var(--color-fairy)', effectType: 'wonder_stone', quantity: null, active: true, builtIn: true, image: normalizeShopImageUrl(alias.wonder_stone?.image || alias.wonder_stone?.imageUrl || '') },
        { id: 'azure_kirin_egg', name: '🌊 碧瀾麒麟蛋', desc: '水屬性隱藏異獸蛋；沿用原本經驗累積與進化節奏，最終可轉化為碧瀾麒麟（★100）', cost: 100, borderColor: 'var(--color-water)', effectType: 'hidden_egg', hiddenEggId: 'azure_kirin', quantity: null, active: true, builtIn: true, image: normalizeShopImageUrl(alias.hidden_egg?.image || alias.hidden_egg?.imageUrl || '') },
        { id: 'marshmallow_physical', name: '🍡 烤棉花糖(實體)', desc: '需在老師面前購買才能獲得（否則不算數）', cost: 50, borderColor: 'var(--color-electric)', effectType: 'physical_reward', quantity: null, active: true, builtIn: true, image: normalizeShopImageUrl(alias.physical_reward?.image || alias.physical_reward?.imageUrl || '') }
      ];
    },
    getShopEffectLabel(effectType) {
      const alias = (getContentProfile(currentState.studentData).builtInShop || {});
      const map = { antidote: alias.antidote?.name || '萬靈藥', evo_stone: alias.evo_stone?.name || '進化石', wonder_stone: alias.wonder_stone?.name || '進化奇石', physical_reward: '實體兌換品', hidden_egg: alias.hidden_egg?.name || '特殊異獸蛋' };
      return map[effectType] || effectType || '自訂商品';
    },
    getShopButtonHtml(item) {
      const cost = Number(item.cost) || 0;
      const qty = (item.quantity === null || item.quantity === undefined || item.quantity === '') ? null : Math.max(0, Number(item.quantity) || 0);
      const soldOut = qty !== null && qty <= 0;
      const inactive = item.active === false;
      const borderColor = (soldOut || inactive) ? '#666' : (item.borderColor || 'var(--color-electric)');
      const extra = item.effectType === 'hidden_egg' && item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId]
        ? `<div style="font-size:0.68em; color:var(--legendary-gold); font-family:'Noto Sans TC'; margin-top:6px;">${escapeHtml(CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].desc)}</div>`
        : '';
      const statusLabel = inactive ? '未上架' : (qty === null ? '不限量' : (soldOut ? '售罄' : `剩餘 ${qty}`));
      const statusColor = inactive ? 'var(--text-muted)' : (soldOut ? '#999' : (item.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--cyan)'));
      return `<button class="btn shop-item" onclick="App.handleShopPurchase('${escapeAttr(item.id)}', ${cost}, ${item.builtIn ? 'true' : 'false'})" ${soldOut || inactive ? 'disabled' : ''} style="text-align:left; border-color:${borderColor}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.55' : '1'};">
        <div style="display:flex; gap:12px; align-items:flex-start;">
          ${renderShopImageThumb(item, { size: 58 })}
          <div style="flex:1; min-width:0;">
            <div style="font-family:'Noto Sans TC'; font-weight:700; line-height:1.4;">${escapeHtml(item.name || '未命名商品')} <span class="tech-font" style="color:${soldOut || inactive ? '#999' : 'var(--legendary-gold)'};">${cost} 🪙</span></div>
            <div style="font-size:0.7em; color:${soldOut || inactive ? '#999' : 'var(--text-muted)'}; font-family:'Noto Sans TC'; margin-top:4px; line-height:1.5;">${escapeHtml(item.desc || '—')}</div>
            ${extra}
            <div class="tech-font" style="margin-top:8px; font-size:0.72em; color:${statusColor};">${escapeHtml(statusLabel)}</div>
          </div>
        </div>
      </button>`;
    },
    setShopBusy(flag = true) { setShopBusy(flag); },
    setShopAdminSaving(flag = true) { setShopAdminSaving(flag); },
    setShopGiftSending(flag = true) { setShopGiftSending(flag); },
    isShopInteractionLocked() { return isShopInteractionLocked(); },
    async renderShopItems() {
      const container = getShopDomElements().itemsContainer;
      if (!container) return;
      const renderList = (customItems = []) => {
        const items = [...getBuiltInShopItems(), ...(Array.isArray(customItems) ? customItems : [])]
          .filter((item) => item && (item.builtIn || item.active !== false));
        items.sort((a, b) => {
          const aq = (a.quantity === null || a.quantity === undefined || a.quantity === '') ? Infinity : Number(a.quantity);
          const bq = (b.quantity === null || b.quantity === undefined || b.quantity === '') ? Infinity : Number(b.quantity);
          const aSold = Number.isFinite(aq) && aq <= 0 ? 1 : 0;
          const bSold = Number.isFinite(bq) && bq <= 0 ? 1 : 0;
          return aSold - bSold || (Number(a.cost) || 0) - (Number(b.cost) || 0) || String(a.name || '').localeCompare(String(b.name || ''), 'zh-Hant');
        });
        container.innerHTML = items.map(item => getShopButtonHtml(item)).join('') || `<div style="color:var(--text-muted); text-align:center;">目前沒有上架商品</div>`;
        try { hydrateStorageImages?.(container, { rootMargin: '260px 0px', eagerLimit: 3 }); } catch (_) {}
        return items;
      };

      const cachedCustom = Array.isArray(currentState.studentShopCatalogCache) ? currentState.studentShopCatalogCache : [];
      if (cachedCustom.length) renderList(cachedCustom);
      else container.innerHTML = '<div style="color:var(--text-muted); text-align:center;">商城資料載入中...</div>';

      if (shopApi && typeof shopApi.warmStudentShopCatalog === 'function') {
        try {
          const customItems = await shopApi.warmStudentShopCatalog({ force: cachedCustom.length < 1, maxAgeMs: 180000, source: 'shop-modal:render' });
          renderList(customItems);
          return;
        } catch (e) {
          console.warn('[shop] public catalog failed, fallback to full scan:', e);
          if (cachedCustom.length) return;
        }
      }

      let items = [];
      try {
        const snap = await getDocs(collection(db, SHOP_COLLECTION));
        snap.forEach(d => {
          const data = d.data() || {};
          items.push({ id: d.id, builtIn: false, name: data.name || '未命名商品', desc: data.desc || '', cost: Number(data.cost) || 0, quantity: data.quantity ?? 0, active: data.active !== false, effectType: data.effectType || 'physical_reward', hiddenEggId: data.hiddenEggId || '', image: normalizeShopImageUrl(data.image || data.imageUrl || data.img || ''), borderColor: data.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--color-electric)' });
        });
      } catch (e) {
        console.warn('[shop] load catalog failed:', e);
      }
      renderList(items);
    },
    populateHiddenEggSelect() { const sel = getShopDomElements().adminHiddenEgg; if (!sel) return; const current = sel.value; sel.innerHTML = `<option value="">— 非異獸蛋商品可忽略 —</option>` + Object.values(CONSTANTS.HIDDEN_EGGS).map(item => `<option value="${item.id}">${item.name} / ${CONSTANTS.ATTRIBUTES[item.requiredAttr]?.name || item.requiredAttr} / ★${item.points}</option>`).join(''); if (current) sel.value = current; },
    updateShopAdminFormState() {
      const { adminEffect: effect, adminHiddenEgg: egg, adminHint: hint, adminQty: qty, adminStudentVisible: studentVisible, adminStudentTradeMode: tradeMode } = getShopDomElements();
      const isHiddenEgg = effect && effect.value === 'hidden_egg';
      if (egg) { egg.disabled = !isHiddenEgg; egg.style.opacity = isHiddenEgg ? '1' : '0.6'; }
      if (qty && !qty.value && !currentState.editingShopProductId) qty.value = '1';
      if (tradeMode) tradeMode.disabled = !(studentVisible?.checked);
      if (hint) {
        const tradeHint = studentVisible?.checked
          ? `學生頁展示：${tradeMode?.value === 'direct' ? '預留交易模式' : (tradeMode?.value === 'request_only' ? '預留申請模式' : (tradeMode?.value === 'admin_only' ? '教師限定提示' : '展示模式'))}。`
          : '學生頁展示：關閉。';
        hint.textContent = isHiddenEgg
          ? `特殊異獸蛋已實裝；請選擇蛋種，並填入可販售數量。學生購買後會先進入孵化紀錄，完成養成才會轉成隱藏積分。${tradeHint}`
          : `一般商品可直接上架。若數量設為 0，學生商店會顯示灰色「售罄」。${tradeHint}`;
      }
      renderShopAdminImagePreview();
    },
    resetShopAdminForm() { const dom = getShopDomElements(); [dom.adminName, dom.adminCost, dom.adminDesc, dom.adminImageUrl].forEach(el => { if (el) el.value = ''; }); if (dom.adminQty) dom.adminQty.value = '1'; if (dom.adminEffect) dom.adminEffect.value = 'antidote'; if (dom.adminStudentTradeMode) dom.adminStudentTradeMode.value = 'preview'; if (dom.adminStudentVisible) dom.adminStudentVisible.checked = true; if (dom.adminActive) dom.adminActive.checked = true; if (dom.adminHiddenEgg) dom.adminHiddenEgg.value = ''; currentState.editingShopProductId = null; updateShopAdminFormState(); },
    resetShopGiftForm() { const dom = getShopDomElements(); if (dom.giftTargetSeq) dom.giftTargetSeq.value = ''; if (dom.giftNote) dom.giftNote.value = ''; if (dom.giftAttrSelect) dom.giftAttrSelect.value = 'metal'; if (dom.giftTargetInfo) dom.giftTargetInfo.innerHTML = '請先輸入卡序，確認要送禮的學生。'; },
    setShopAdminTab(tab = 'catalog') { currentState.shopAdminTab = tab; const { adminCatalogPane: catalogPane, adminGiftPane: giftPane, adminTabBtnCatalog: btnCatalog, adminTabBtnGift: btnGift } = getShopDomElements(); if (catalogPane) catalogPane.classList.toggle('hidden', tab !== 'catalog'); if (giftPane) giftPane.classList.toggle('hidden', tab !== 'gift'); if (btnCatalog) { btnCatalog.classList.toggle('btn-solid', tab === 'catalog'); btnCatalog.style.background = tab === 'catalog' ? 'var(--legendary-gold)' : 'transparent'; btnCatalog.style.color = tab === 'catalog' ? '#000' : 'var(--legendary-gold)'; btnCatalog.style.borderColor = 'var(--legendary-gold)'; } if (btnGift) { btnGift.classList.toggle('btn-solid', tab === 'gift'); btnGift.style.background = tab === 'gift' ? 'var(--cyan)' : 'transparent'; btnGift.style.color = tab === 'gift' ? '#041018' : 'var(--cyan)'; btnGift.style.borderColor = 'var(--cyan)'; } },
    getAdminGiftableShopItems() { return getBuiltInShopItems().map(item => ({ ...item, sourceId: `builtin:${item.id}` })); },
    async loadShopGiftOptions(preferredId = '') { const { giftItemSelect: sel, giftCatalogList: list } = getShopDomElements(); if (!sel || !list) return; sel.innerHTML = '<option value="">載入中...</option>'; list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>'; let items = getAdminGiftableShopItems(); try { const snap = await getDocs(collection(db, SHOP_COLLECTION)); snap.forEach(d => { const row = d.data() || {}; items.push({ id: d.id, sourceId: d.id, builtIn: false, name: row.name || '未命名商品', desc: row.desc || '', cost: Number(row.cost) || 0, quantity: Math.max(0, Number(row.quantity) || 0), active: row.active !== false, effectType: row.effectType || 'physical_reward', hiddenEggId: row.hiddenEggId || '' }); }); } catch (e) { console.warn('[shop gift] load options failed:', e); } sel.innerHTML = '<option value="">請選擇要贈送的物品</option>' + items.map(item => { const qty = item.builtIn ? null : Math.max(0, Number(item.quantity) || 0); const qtyText = qty === null ? '不限量' : `庫存 ${qty}`; const stateText = item.builtIn ? '內建' : (item.active === false ? '未上架' : (qty <= 0 ? '售罄' : '上架中')); return `<option value="${item.sourceId}" ${preferredId === item.sourceId ? 'selected' : ''}>${String(item.name || '未命名商品')}｜${getShopEffectLabel(item.effectType)}｜${qtyText}｜${stateText}</option>`; }).join(''); list.innerHTML = items.map(item => { const soldOut = !item.builtIn && Math.max(0, Number(item.quantity) || 0) <= 0; const inactive = !item.builtIn && item.active === false; const border = soldOut || inactive ? '#666' : 'var(--legendary-gold)'; const state = item.builtIn ? '內建' : (inactive ? '未上架' : (soldOut ? '售罄' : `庫存 ${Math.max(0, Number(item.quantity) || 0)}`)); return `<button class="btn" onclick="App.pickShopGiftItem('${item.sourceId}')" style="text-align:left; border-color:${border}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.62' : '1'};">${String(item.name || '未命名商品')}<br><div style="font-size:0.76em; color:${soldOut || inactive ? '#999' : '#ccc'}; margin-top:4px; font-family:'Noto Sans TC';">${getShopEffectLabel(item.effectType)} / ${state}</div></button>`; }).join('') || '<div style="color:var(--text-muted); text-align:center;">目前沒有可贈送商品</div>'; },
    pickShopGiftItem(sourceId) {
      const sel = getShopDomElements().giftItemSelect;
      if (sel) sel.value = sourceId || '';
      lookupShopGiftTarget();
    },
    fillShopGiftCurrentStudent() {
      const serial = normalizeSerialSafe(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid);
      const input = getShopDomElements().giftTargetSeq;
      if (!serial || !input) {
        UI.toast('目前尚未載入學生資料');
        return;
      }
      input.value = serial;
      lookupShopGiftTarget();
    },
    async lookupShopGiftTarget() {
      const { giftTargetSeq: input, giftTargetInfo: info } = getShopDomElements();
      const serial = normalizeSerialSafe(input?.value || '');
      if (!serial) {
        if (info) info.innerHTML = '<span style="color:var(--danger);">請先輸入正確卡序。</span>';
        return;
      }
      if (info) info.innerHTML = '查詢中...';
      try {
        const snap = await getDoc(doc(db, COLLECTION_NAME, serial));
        if (!snap.exists()) {
          if (info) info.innerHTML = `<span style="color:var(--danger);">查無卡序 ${serial}，請先確認學生資料已建檔。</span>`;
          return;
        }
        const d = migrateStudentData(snap.data() || {});
        const profileName = isCatProfileSafe(d) ? '貓咪版' : '山海版';
        if (info) info.innerHTML = `<div style="color:var(--legendary-gold); font-weight:bold;">${d.name || '未命名學生'}｜卡序 ${serial}</div><div style="margin-top:4px; color:#ddd;">${d.class_name || '未分班'} / ${profileName} / 總能量 ${Number(d.totalXP) || 0} / 金幣 ${Number(d.coins) || 0}</div>`;
      } catch (e) {
        console.error(e);
        if (info) info.innerHTML = '<span style="color:var(--danger);">查詢失敗，請稍後再試。</span>';
      }
    },
    async getShopGiftItemMeta(sourceId) {
      if (!sourceId) return null;
      if (String(sourceId).startsWith('builtin:')) {
        const builtId = String(sourceId).slice('builtin:'.length);
        const item = getBuiltInShopItems().find((x) => x.id === builtId);
        return item ? { ...item, sourceId, builtIn: true } : null;
      }
      const snap = await getDoc(doc(db, SHOP_COLLECTION, sourceId));
      if (!snap.exists()) return null;
      const row = snap.data() || {};
      return {
        id: sourceId,
        sourceId,
        builtIn: false,
        ...row,
        cost: Number(row.cost) || 0,
        quantity: Math.max(0, Number(row.quantity) || 0),
        active: row.active !== false,
        effectType: row.effectType || 'physical_reward',
        hiddenEggId: row.hiddenEggId || ''
      };
    },
    normalizeStudentShopMode(mode = '') {
      const normalized = String(mode || '').trim().toLowerCase();
      if (normalized === 'request_only' || normalized === 'direct' || normalized === 'admin_only') return normalized;
      return 'preview';
    },
    getStudentShopMode() {
      return this.normalizeStudentShopMode(currentState.studentShopMode || 'preview');
    },
    resolveStudentShopCardFooter(item = {}, mode = '') {
      const sectionMode = this.normalizeStudentShopMode(mode || this.getStudentShopMode());
      const tradeMode = this.normalizeStudentShopMode(item.studentTradeMode || 'preview');
      if (item.soldOut) {
        return {
          statusText: item.badge || '已兌換完畢',
          helperText: '目前已無剩餘數量，請等待老師後續補貨。',
          pillTone: '#999',
          actionState: 'sold_out'
        };
      }
      if (sectionMode === 'preview') {
        const helperByTradeMode = {
          direct: '已保留直購流程接口，未來可依設定開啟。',
          request_only: '已保留申請流程接口，未來可依設定開啟。',
          admin_only: '此商品目前僅供老師端管理，不對學生端開放交易。',
          preview: '目前僅供展示，尚未開放學生端直接兌換。'
        };
        return {
          statusText: tradeMode === 'admin_only' ? '教師專用' : '展示模式',
          helperText: helperByTradeMode[tradeMode] || helperByTradeMode.preview,
          pillTone: 'rgba(255,255,255,0.68)',
          actionState: 'preview'
        };
      }
      if (sectionMode === 'request_only') {
        return {
          statusText: tradeMode === 'admin_only' ? '教師專用' : '可申請兌換',
          helperText: tradeMode === 'admin_only' ? '此商品目前僅供老師端管理。' : '此商品未來可切換為申請制，由老師進行確認。',
          pillTone: 'var(--legendary-gold)',
          actionState: tradeMode === 'admin_only' ? 'preview' : 'request_only'
        };
      }
      if (sectionMode === 'direct') {
        return {
          statusText: tradeMode === 'admin_only' ? '教師專用' : '可切換為交易',
          helperText: tradeMode === 'admin_only' ? '此商品目前僅供老師端管理。' : '商品卡已保留交易欄位，未來可在不重做 UI 的情況下切換為交易模式。',
          pillTone: 'var(--color-electric)',
          actionState: tradeMode === 'admin_only' ? 'preview' : 'direct'
        };
      }
      return {
        statusText: '展示模式',
        helperText: '目前僅供展示，尚未開放學生端直接兌換。',
        pillTone: 'rgba(255,255,255,0.68)',
        actionState: 'preview'
      };
    },
    buildStudentShopSummaryData(data = {}, id = '') {
      const quantity = Math.max(0, Number(data.quantity) || 0);
      const name = String(data.name || '').trim();
      if (!name) return null;
      const desc = String(data.desc || data.description || '').trim();
      const visual = resolveVisualMetaSafe(data, { alt: name || '商品展示圖' });
      const image = visual.imageUrl || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      const studentTradeMode = this.normalizeStudentShopMode(
        data.student_trade_mode ||
        (data.student_enabled === true ? 'direct' : '') ||
        (data.requires_teacher_approval === true ? 'request_only' : '')
      );
      return {
        id: String(id || data.id || '').trim() || `shop-${name}`,
        name,
        desc,
        image,
        imageUrl: visual.imageUrl || '',
        imageAssetKey: visual.imageAssetKey || '',
        imageAlt: visual.imageAlt || name || '商品展示圖',
        cost: Math.max(0, Number(data.cost) || 0),
        quantity,
        active: data.active !== false,
        updatedAt: Number(data.updatedAt || data.updated_at) || 0,
        soldOut: quantity <= 0,
        studentTradeMode,
        badge: quantity <= 0 ? '已兌換完畢' : `剩餘 ${quantity} 份`
      };
    },
    normalizeStudentShopItem(data = {}, id = '') {
      const summary = this.buildStudentShopSummaryData(data, id);
      if (!summary || summary.active === false || summary.studentTradeMode === 'admin_only') return null;
      return summary;
    },
    async loadStudentShopCatalogSummary() {
      const snapshot = await getDocs(collection(db, SHOP_PUBLIC_COLLECTION));
      const items = [];
      snapshot.forEach((docSnap) => {
        const normalized = this.normalizeStudentShopItem(docSnap.data() || {}, docSnap.id);
        if (normalized) items.push(normalized);
      });
      items.sort((a, b) => {
        if (a.soldOut !== b.soldOut) return a.soldOut ? 1 : -1;
        if ((a.updatedAt || 0) !== (b.updatedAt || 0)) return (b.updatedAt || 0) - (a.updatedAt || 0);
        return String(a.name || '').localeCompare(String(b.name || ''), 'zh-Hant');
      });
      return items;
    },
    syncStudentShopCatalogSummaryForId(productId, preferredData = null) {
      const id = String(productId || '').trim();
      if (!id) return Promise.resolve(null);
      const runner = async () => {
        let source = preferredData && typeof preferredData === 'object' ? JSON.parse(JSON.stringify(preferredData || {})) : null;
        if (!source) {
          const shopSnap = await getDoc(doc(db, SHOP_COLLECTION, id));
          if (!shopSnap.exists()) return null;
          source = shopSnap.data() || {};
        }
        const summary = this.buildStudentShopSummaryData(source, id);
        if (!summary) {
          try { await deleteDoc(doc(db, SHOP_PUBLIC_COLLECTION, id)); } catch (_) {}
          return null;
        }
        await setDoc(doc(db, SHOP_PUBLIC_COLLECTION, id), summary, { merge: true });
        return summary;
      };
      return runner().catch((err) => {
        console.warn('[shop-summary] sync failed:', err?.message || err);
        return null;
      });
    },
    removeStudentShopCatalogSummaryForId(productId) {
      const id = String(productId || '').trim();
      if (!id) return Promise.resolve(false);
      return deleteDoc(doc(db, SHOP_PUBLIC_COLLECTION, id)).then(() => true).catch((err) => {
        console.warn('[shop-summary] delete failed:', err?.message || err);
        return false;
      });
    },
    backfillStudentShopCatalogSummaryEntries(rows = []) {
      const list = Array.isArray(rows) ? rows : [];
      if (!list.length) return Promise.resolve(0);
      const runner = async () => {
        const batch = writeBatch(db);
        let touched = 0;
        list.forEach((row) => {
          const id = String(row?.id || '').trim();
          if (!id) return;
          const summary = this.buildStudentShopSummaryData(row, id);
          if (!summary) return;
          batch.set(doc(db, SHOP_PUBLIC_COLLECTION, id), summary, { merge: true });
          touched += 1;
        });
        if (touched < 1) return 0;
        await batch.commit();
        return touched;
      };
      return runner().catch((err) => {
        console.warn('[shop-summary] backfill failed:', err?.message || err);
        return 0;
      });
    },
    renderStudentShopShowcaseCards(items = [], options = {}) {
      const safeText = (value = '') => String(value || '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch] || ch));
      const sectionMode = this.normalizeStudentShopMode(options.mode || this.getStudentShopMode());
      if ((!Array.isArray(items) || items.length < 1) && canUseAdminShopFallback()) {
        return '<div style="min-width:100%; padding:14px 12px; border:1px dashed rgba(255,255,255,0.18); border-radius:12px; color:var(--text-muted); font-size:0.8em; text-align:center; font-family:Noto Sans TC, sans-serif;">老師目前尚未上架可展示的商品。</div>';
      }
      return items.map((item) => {
        const soldOut = item.soldOut === true;
        const statusColor = soldOut ? '#999' : 'var(--legendary-gold)';
        const cardBorder = soldOut ? 'rgba(255,255,255,0.12)' : 'rgba(255,183,0,0.32)';
        const footer = this.resolveStudentShopCardFooter(item, sectionMode);
        const imageSrc = item.imageUrl || item.image || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        const assetAttr = !item.imageUrl && item.imageAssetKey ? ` data-asset="${safeText(item.imageAssetKey)}"` : '';
        return `
          <div class="student-shop-card" data-shop-item-id="${safeText(item.id)}" data-trade-mode="${safeText(item.studentTradeMode || 'preview')}" data-section-mode="${safeText(sectionMode)}" data-action-state="${safeText(footer.actionState || 'preview')}" style="flex:0 0 172px; scroll-snap-align:start; border:1px solid ${cardBorder}; border-radius:14px; padding:10px; background:linear-gradient(180deg, rgba(0,0,0,0.46), rgba(0,0,0,0.22)); box-shadow:0 0 18px rgba(0,0,0,0.16); opacity:${soldOut ? '0.72' : '1'}; display:flex; flex-direction:column;">
            <div style="height:112px; border-radius:10px; overflow:hidden; background:rgba(255,255,255,0.04); display:flex; align-items:center; justify-content:center; margin-bottom:10px;">
              <img src="${safeText(imageSrc)}"${assetAttr} alt="${safeText(item.imageAlt || item.name)}" loading="lazy" referrerpolicy="no-referrer" style="width:100%; height:100%; object-fit:cover; display:block;">
            </div>
            <div style="font-family:Noto Sans TC, sans-serif; font-weight:700; color:#fff; font-size:0.9em; line-height:1.35; min-height:2.45em;">${safeText(item.name)}</div>
            <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:6px;">
              <div class="tech-font" style="font-size:0.72em; color:${statusColor};">${safeText(item.badge)}</div>
              <div class="tech-font" style="font-size:0.74em; color:var(--legendary-gold); white-space:nowrap;">${safeText(`${Math.max(0, Number(item.cost) || 0)} 🪙`)}</div>
            </div>
            <div style="margin-top:8px; font-size:0.74em; color:var(--text-muted); line-height:1.5; min-height:4.4em; font-family:Noto Sans TC, sans-serif;">${safeText(item.desc || '目前僅供展示，尚未開放學生端直接兌換。')}</div>
            <div class="student-shop-card-action-slot" style="margin-top:auto; padding-top:10px; border-top:1px dashed rgba(255,255,255,0.12); display:flex; flex-direction:column; gap:6px;">
              <div class="tech-font" style="font-size:0.68em; color:${safeText(footer.pillTone || 'rgba(255,255,255,0.68)')}; letter-spacing:0.06em;">${safeText(footer.statusText || '展示模式')}</div>
              <div style="font-size:0.68em; color:var(--text-muted); line-height:1.45; font-family:Noto Sans TC, sans-serif; min-height:2.9em;">${safeText(footer.helperText || '目前僅供展示，尚未開放學生端直接兌換。')}</div>
            </div>
          </div>`;
      }).join('');
    },
    async warmStudentShopCatalog(options = {}) {
      const force = !!options.force;
      const maxAgeMs = Math.max(15000, Number(options.maxAgeMs) || 180000);
      const now = Date.now();
      if (!force && Array.isArray(currentState.studentShopCatalogCache) && currentState.studentShopCatalogCache.length && (now - (currentState.studentShopCatalogLoadedAt || 0)) < maxAgeMs) {
        return currentState.studentShopCatalogCache;
      }
      if (!force && currentState.studentShopCatalogPromise) return currentState.studentShopCatalogPromise;

      let loadPromise;
      loadPromise = (async () => {
        try {
          let items = [];
          let summaryErr = null;
          try {
            items = await this.loadStudentShopCatalogSummary();
          } catch (err) {
            summaryErr = err;
            console.warn('[warmStudentShopCatalog] shop_catalog_public failed, fallback to full scan:', err?.message || err);
          }
          if (!Array.isArray(items) || items.length < 1) {
            const snapshot = await getDocs(collection(db, SHOP_COLLECTION));
            const rows = [];
            snapshot.forEach((docSnap) => {
              rows.push({ id: docSnap.id, ...(docSnap.data() || {}) });
            });
            items = rows.map((row) => this.normalizeStudentShopItem(row, row.id)).filter(Boolean);
            items.sort((a, b) => {
              if (a.soldOut !== b.soldOut) return a.soldOut ? 1 : -1;
              if ((a.updatedAt || 0) !== (b.updatedAt || 0)) return (b.updatedAt || 0) - (a.updatedAt || 0);
              return String(a.name || '').localeCompare(String(b.name || ''), 'zh-Hant');
            });
            try { this.backfillStudentShopCatalogSummaryEntries(rows); } catch (_) {}
          }
          currentState.studentShopCatalogCache = items;
          currentState.studentShopCatalogLoadedAt = Date.now();
          currentState.studentShopCatalogLastError = summaryErr ? (summaryErr?.message || String(summaryErr)) : '';
          return items;
        } catch (err) {
          currentState.studentShopCatalogLastError = err?.message || String(err || '未知錯誤');
          if (Array.isArray(currentState.studentShopCatalogCache) && currentState.studentShopCatalogCache.length) {
            return currentState.studentShopCatalogCache;
          }
          throw err;
        } finally {
          if (currentState.studentShopCatalogPromise === loadPromise) currentState.studentShopCatalogPromise = null;
        }
      })();
      currentState.studentShopCatalogPromise = loadPromise;
      return loadPromise;
    },
    async renderStudentShopShowcase(options = {}) {
      if (currentState.viewMode !== 'student' && currentState.viewMode !== 'preview' && !options.force) {
        return Array.isArray(currentState.studentShopCatalogCache) ? currentState.studentShopCatalogCache : [];
      }
      const dom = getShopShowcaseDom();
      const section = dom.section;
      const statusEl = dom.status;
      const trackEl = dom.track;
      if (!section || !statusEl || !trackEl) return [];

      const sectionMode = this.normalizeStudentShopMode(options.mode || currentState.studentShopMode || 'preview');
      currentState.studentShopMode = sectionMode;
      section.dataset.mode = sectionMode;
      section.hidden = false;
      section.style.display = '';

      const modeLabelMap = {
        preview: '展示模式',
        request_only: '申請模式',
        direct: '交易模式',
        admin_only: '教師限定'
      };
      const formatStatus = (items = [], suffix = '') => {
        const availableCount = items.filter((item) => !item.soldOut).length;
        const parts = [`${availableCount} 項展示中`, modeLabelMap[sectionMode] || '展示模式'];
        if (suffix) parts.push(suffix);
        return `[ ${parts.join(' ｜ ')} ]`;
      };
      const hydrateShowcaseTrack = () => {
        try { hydrateStorageImages(trackEl, { rootMargin: '320px 0px', eagerLimit: 2 }); } catch (_) {}
      };

      const cached = Array.isArray(currentState.studentShopCatalogCache) ? currentState.studentShopCatalogCache : [];
      if (cached.length) {
        trackEl.innerHTML = this.renderStudentShopShowcaseCards(cached, { mode: sectionMode });
        hydrateShowcaseTrack();
        bindShopRailControls();
        refreshShopRailButtons();
        statusEl.textContent = formatStatus(cached);
      } else {
        trackEl.innerHTML = '<div style="min-width:100%; padding:14px 12px; border:1px dashed rgba(255,255,255,0.18); border-radius:12px; color:var(--text-muted); font-size:0.8em; text-align:center; font-family:Noto Sans TC, sans-serif;">商品展示區載入中…</div>';
        hydrateShowcaseTrack();
        bindShopRailControls();
        refreshShopRailButtons();
        statusEl.textContent = `[ 載入中 ｜ ${modeLabelMap[sectionMode] || '展示模式'} ]`;
      }

      const fetchPromise = this.warmStudentShopCatalog({ force: cached.length < 1, maxAgeMs: 180000, source: options.source || 'renderStudentShopShowcase' });
      const timeoutToken = Symbol('student-shop-timeout');
      try {
        const items = await Promise.race([
          fetchPromise,
          new Promise((resolve) => window.setTimeout(() => resolve(timeoutToken), 4500))
        ]);
        if (items === timeoutToken) {
          if (!cached.length) {
            statusEl.textContent = `[ 讀取較慢，背景同步中 ｜ ${modeLabelMap[sectionMode] || '展示模式'} ]`;
          }
          fetchPromise.then((fresh) => {
            const latestDom = getShopShowcaseDom();
            if (!latestDom.track || !latestDom.status || !latestDom.section || currentState.viewMode !== 'student') return;
            latestDom.section.dataset.mode = currentState.studentShopMode || sectionMode;
            latestDom.section.hidden = false;
            latestDom.track.innerHTML = this.renderStudentShopShowcaseCards(fresh, { mode: currentState.studentShopMode || sectionMode });
            try { hydrateStorageImages(latestDom.track, { rootMargin: '320px 0px', eagerLimit: 2 }); } catch (_) {}
            bindShopRailControls();
            refreshShopRailButtons();
            latestDom.status.textContent = formatStatus(fresh);
          }).catch((err) => {
            console.error('[student-shop-showcase] background refresh failed:', err);
            if (!cached.length) statusEl.textContent = `[ 商品資料讀取失敗 ｜ ${modeLabelMap[sectionMode] || '展示模式'} ]`;
          });
          return cached;
        }
        trackEl.innerHTML = this.renderStudentShopShowcaseCards(items, { mode: sectionMode });
        hydrateShowcaseTrack();
        bindShopRailControls();
        refreshShopRailButtons();
        statusEl.textContent = formatStatus(items);
        return items;
      } catch (err) {
        console.error('[student-shop-showcase] render failed:', err);
        if (!cached.length) {
          trackEl.innerHTML = '<div style="min-width:100%; padding:14px 12px; border:1px dashed rgba(255,255,255,0.18); border-radius:12px; color:var(--warning); font-size:0.8em; text-align:center; font-family:Noto Sans TC, sans-serif;">商品讀取較慢，請稍後再試。</div>';
          hydrateShowcaseTrack();
          bindShopRailControls();
          refreshShopRailButtons();
        }
        statusEl.textContent = `[ 商品資料讀取失敗 ｜ ${modeLabelMap[sectionMode] || '展示模式'} ]`;
        return cached;
      }
    },
    async applyAdminGiftEffect(data, itemMeta, targetSerial, selectedAttr = 'metal', note = '') {
      if (!data || !itemMeta) return { applied: false };
      if (!teacherActionsApi || typeof teacherActionsApi.runTeacherMutation !== 'function') {
        throw new Error('老師端保存鏈尚未就緒，請重新整理後再試。');
      }
      const resolvedAttr = ['metal', 'wood', 'water', 'fire', 'earth'].includes(selectedAttr)
        ? selectedAttr
        : (typeof getDominantElementFromData === 'function'
            ? (getDominantElementFromData(data || currentState.studentData || {}) || 'metal')
            : 'metal');
      const noteSuffix = note ? ` / 備註：${note}` : '';
      const mutationResult = await teacherActionsApi.runTeacherMutation.call(globalThis.App || teacherActionsApi, {
        preferredData: data,
        explicitSerial: targetSerial,
        source: 'shop-admin:apply-gift',
        action: 'apply-gift',
        failureTitle: '贈禮失敗',
        mutate: async (next) => {
          next = migrateStudentData(next || {});
          next.logs = Array.isArray(next.logs) ? next.logs : [];
          next.collection = Array.isArray(next.collection) ? next.collection : [];
          next.hidden_eggs = Array.isArray(next.hidden_eggs) ? next.hidden_eggs : [];
          if (itemMeta.effectType === 'physical_reward') {
            next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '實體兌換品'} 已指定發送${noteSuffix}` });
            return { applied: true, data: next };
          }
          if (itemMeta.effectType === 'antidote') {
            next.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
            next.debuffs_timestamp = null;
            next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '萬靈藥'}，已清除異常狀態${noteSuffix}` });
            return { applied: true, data: next };
          }
          if (itemMeta.effectType === 'evo_stone') {
            next.totalXP = Number(next.totalXP) || 0;
            next.totalXP += 30;
            addAttributeXPSafe(next, resolvedAttr, 30);
            const evolved = processEvolutionSafe(next);
            evolved.logs = Array.isArray(evolved.logs) ? evolved.logs : [];
            evolved.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化石'}（${CONSTANTS.ATTRIBUTES[resolvedAttr]?.name || resolvedAttr} +30 XP）${noteSuffix}` });
            return { applied: true, data: evolved };
          }
          if (itemMeta.effectType === 'wonder_stone') {
            next.collection.push({ type: 'material', element: resolvedAttr, name: `${CONSTANTS.ATTRIBUTES[resolvedAttr]?.name || resolvedAttr}系素材`, img: CONSTANTS.MEDIA.PLACEHOLDER_SVG, stats: { ...(next.attributes || {}) }, timestamp: Date.now() });
            next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化奇石'}（${CONSTANTS.ATTRIBUTES[resolvedAttr]?.name || resolvedAttr}系素材）${noteSuffix}` });
            return { applied: true, data: next };
          }
          if (itemMeta.effectType === 'hidden_egg') {
            const eggMeta = CONSTANTS.HIDDEN_EGGS[itemMeta.hiddenEggId || ''];
            if (!eggMeta) throw new Error('此特殊異獸蛋尚未設定完成。');
            const eggRecord = { type: 'hidden_egg', id: `${eggMeta.id}_${Date.now()}`, hiddenEggId: eggMeta.id, name: eggMeta.name, beastName: eggMeta.beastName || '', img: eggMeta.img, forms: eggMeta.forms || null, requiredAttr: eggMeta.requiredAttr, points: eggMeta.points, status: 'incubating', stats: { ...(next.attributes || {}) }, timestamp: Date.now() };
            next.hidden_eggs.push(eggRecord);
            next.collection.push({ ...eggRecord });
            if (!String(next.active_hidden_egg_id || '').trim()) {
              next.active_hidden_egg_id = eggMeta.id;
              next.active_hidden_egg = { ...eggRecord, status: 'active', activatedAt: Date.now() };
            }
            next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${eggMeta.name} 已加入孵化清單（需求屬性：${CONSTANTS.ATTRIBUTES[eggMeta.requiredAttr]?.name || eggMeta.requiredAttr}）${noteSuffix}` });
            return { applied: true, data: next };
          }
          next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '商城物品'}${noteSuffix}` });
          return { applied: true, data: next };
        }
      });
      return mutationResult ? { applied: true, saved: mutationResult.saved, serial: mutationResult.serial } : { applied: false };
    },
    async sendShopGift() {
      if (currentState.shopGiftSending) {
        UI.toast('上一筆贈禮尚在處理中，請稍候。');
        return;
      }
      const { giftTargetSeq: targetInput, giftItemSelect: itemSel, giftAttrSelect: attrSel, giftNote: noteEl } = getShopDomElements();
      const targetSerial = normalizeSerialSafe(targetInput?.value || '');
      const sourceId = itemSel?.value || '';
      const selectedAttr = attrSel?.value || 'metal';
      const note = (noteEl?.value || '').trim();
      if (!targetSerial) { UI.toast('請先輸入指定卡序'); return; }
      if (!sourceId) { UI.toast('請先選擇要贈送的物品'); return; }
      try {
        setShopGiftSending(true);
        const targetSnap = await getDoc(doc(db, COLLECTION_NAME, targetSerial));
        if (!targetSnap.exists()) {
          UI.alert('找不到指定卡序的學生資料。', '贈禮失敗');
          return;
        }
        const itemMeta = await getShopGiftItemMeta(sourceId);
        if (!itemMeta) {
          UI.alert('找不到此商城物品，請重新整理後再試。', '贈禮失敗');
          await loadShopGiftOptions();
          return;
        }
        if (!itemMeta.builtIn) {
          if (itemMeta.active === false) {
            UI.alert('此商品目前未上架，請先確認是否仍要保留在商城。', '贈禮失敗');
            return;
          }
          if ((Number(itemMeta.quantity) || 0) <= 0) {
            UI.alert('此商品目前已售罄。', '贈禮失敗');
            await loadShopGiftOptions(sourceId);
            return;
          }
        }
        const targetData = migrateStudentData(targetSnap.data() || {});
        const ok = await UI.confirm(`確定要將「${itemMeta.name || '商城物品'}」送給 ${targetData.name || '這位學生'}（卡序 ${targetSerial}）嗎？`, '確認送出贈禮');
        if (!ok) return;
        const result = await applyAdminGiftEffect(targetData, itemMeta, targetSerial, selectedAttr, note);
        if (!result || !result.applied) return;
        if (!itemMeta.builtIn) {
          try {
            const itemRef = doc(db, SHOP_COLLECTION, sourceId);
            const latest = await getDoc(itemRef);
            if (latest.exists()) {
              const latestQ = Math.max(0, Number(latest.data().quantity) || 0);
              await updateDoc(itemRef, { quantity: Math.max(0, latestQ - 1), updatedAt: Date.now() });
            }
          } catch (e) {
            console.warn('[shop gift] quantity update failed:', e);
          }
        }
        await loadShopAdminList();
        await loadShopGiftOptions(sourceId);
        await renderShopItems();
        await lookupShopGiftTarget();
        UI.toast(`已送出：${itemMeta.name || '商城物品'}`);
      } catch (e) {
        console.error(e);
        UI.alert(`贈禮失敗：${e.message || e}`, '贈禮失敗');
      } finally {
        setShopGiftSending(false);
      }
    },
    async openShopAdmin() { const dom = getShopDomElements(); if (!dom.adminModal) { UI.alert('找不到商城管理面板，請重新整理頁面後再試。', '系統異常'); return; } populateHiddenEggSelect(); resetShopAdminForm(); resetShopGiftForm(); const effect = dom.adminEffect; if (effect && !effect.dataset.boundChange) { effect.addEventListener('change', () => updateShopAdminFormState()); effect.dataset.boundChange = '1'; } const imageUrlInput = dom.adminImageUrl; if (imageUrlInput && !imageUrlInput.dataset.boundInput) { imageUrlInput.addEventListener('input', () => renderShopAdminImagePreview()); imageUrlInput.addEventListener('change', () => renderShopAdminImagePreview()); imageUrlInput.dataset.boundInput = '1'; } const studentVisible = dom.adminStudentVisible; if (studentVisible && !studentVisible.dataset.boundChange) { studentVisible.addEventListener('change', () => updateShopAdminFormState()); studentVisible.dataset.boundChange = '1'; } const tradeMode = dom.adminStudentTradeMode; if (tradeMode && !tradeMode.dataset.boundChange) { tradeMode.addEventListener('change', () => updateShopAdminFormState()); tradeMode.dataset.boundChange = '1'; } await loadShopAdminList(); await loadShopGiftOptions(); updateShopAdminFormState(); setShopAdminTab('catalog'); UI.showModal('shopAdminModal'); },
    async loadShopAdminList() { const list = getShopDomElements().adminList; if (!list) return; list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>'; try { const snap = await getDocs(collection(db, SHOP_COLLECTION)); if (snap.empty) { list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">目前沒有自訂商品。</div>'; return; } const rows = []; snap.forEach(d => rows.push({ id: d.id, ...(d.data() || {}) })); rows.sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''))); list.innerHTML = rows.map(item => { const soldOut = Math.max(0, Number(item.quantity) || 0) <= 0; const hiddenMeta = item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId] ? ` / ${escapeHtml(CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].name)}` : ''; const visibleState = item.student_visible === false ? '學生頁隱藏' : '學生頁展示'; const tradeMode = item.student_trade_mode === 'direct' ? '交易模式' : (item.student_trade_mode === 'request_only' ? '申請模式' : (item.student_trade_mode === 'admin_only' ? '教師限定' : '展示模式')); return `<div style="background:rgba(0,0,0,0.45); border:1px solid ${soldOut ? '#666' : 'var(--legendary-gold)'}; border-radius:10px; padding:10px;"><div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start;">${renderShopImageThumb(item, { size: 72 })}<div style="flex:1; min-width:0;"><div style="color:${soldOut ? '#aaa' : 'var(--legendary-gold)'}; font-weight:bold; font-family:'Noto Sans TC';">${escapeHtml(item.name || '未命名商品')}</div><div style="font-size:0.78em; color:#ccc; margin-top:4px; font-family:'Noto Sans TC';">${escapeHtml(getShopEffectLabel(item.effectType))}${hiddenMeta} / ${Number(item.cost) || 0} 🪙 / 庫存 ${Math.max(0, Number(item.quantity) || 0)} / ${item.active === false ? '未上架' : (soldOut ? '售罄' : '上架中')}</div><div style="font-size:0.74em; color:var(--text-muted); margin-top:4px; font-family:'Noto Sans TC'; line-height:1.5;">${escapeHtml(item.desc || '—')}</div><div class="tech-font" style="font-size:0.68em; color:rgba(255,255,255,0.56); margin-top:6px;">${visibleState} ｜ ${tradeMode}${getShopImageUrl(item) ? ' ｜ 已設定圖源' : ' ｜ 未設定圖源'}</div></div><div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;"><button class="btn" onclick="App.pickShopGiftItem('${escapeAttr(item.id)}'); App.setShopAdminTab('gift')" style="padding:4px 8px; border-color:var(--legendary-gold); color:var(--legendary-gold);">贈送</button><button class="btn" onclick="App.editShopProduct('${escapeAttr(item.id)}')" style="padding:4px 8px; border-color:var(--cyan); color:var(--cyan);">編輯</button><button class="btn" onclick="App.deleteShopProduct('${escapeAttr(item.id)}')" style="padding:4px 8px; border-color:var(--danger); color:var(--danger);">刪除</button></div></div></div>`; }).join(''); } catch (e) { console.error(e); list.innerHTML = '<div style="color:var(--danger); text-align:center;">商品讀取失敗</div>'; } },
    async editShopProduct(productId) { try { const snap = await getDoc(doc(db, SHOP_COLLECTION, productId)); if (!snap.exists()) { UI.toast('商品不存在'); return; } const form = getShopAdminFormElements(); if (!hasCompleteShopAdminForm(form)) { UI.alert('商城管理表單不完整，請重新整理頁面後再試。', '系統異常'); return; } const d = snap.data() || {}; form.name.value = d.name || ''; form.cost.value = Number(d.cost) || 0; form.desc.value = d.desc || ''; form.effect.value = d.effectType || 'antidote'; form.qty.value = Math.max(0, Number(d.quantity) || 0); form.imageUrl.value = String(d.image || d.imageUrl || d.img || '').trim(); form.studentTradeMode.value = d.student_trade_mode || (d.student_enabled === true ? 'direct' : (d.requires_teacher_approval === true ? 'request_only' : 'preview')); form.studentVisible.checked = d.student_visible !== false; form.hiddenEgg.value = d.hiddenEggId || ''; form.active.checked = d.active !== false; currentState.editingShopProductId = productId; updateShopAdminFormState(); UI.showModal('shopAdminModal'); } catch (e) { console.error(e); UI.toast('商品讀取失敗'); } },
    async saveShopProduct() {
      if (currentState.shopAdminSaving) { UI.toast('商品儲存中，請稍候'); return; }
      const form = getShopAdminFormElements();
      if (!hasCompleteShopAdminForm(form)) { UI.alert('商城管理表單不完整，請重新整理頁面後再試。', '系統異常'); return; }
      const name = (form.name.value || '').trim();
      const cost = Math.max(0, Number(form.cost.value) || 0);
      const rawDesc = (form.desc.value || '').trim();
      const effectType = form.effect.value || 'antidote';
      const quantity = Math.max(0, Number(form.qty.value) || 0);
      const imageUrl = normalizeShopImageUrl(form.imageUrl.value || '');
      const hiddenEggId = effectType === 'hidden_egg' ? (form.hiddenEgg.value || '') : '';
      const active = !!form.active.checked;
      const studentVisible = !!form.studentVisible.checked;
      const studentTradeMode = studentVisible ? (form.studentTradeMode.value || 'preview') : 'admin_only';
      if (!name) { UI.toast('請輸入商品名稱'); return; }
      if (!currentState.editingShopProductId && quantity <= 0) { UI.toast('新增商品請填入數量（至少 1），否則會直接顯示為售罄'); return; }
      if (effectType === 'hidden_egg' && !hiddenEggId) { UI.toast('請選擇特殊異獸蛋'); return; }
      const eggMeta = effectType === 'hidden_egg' ? CONSTANTS.HIDDEN_EGGS[hiddenEggId || ''] : null;
      const desc = rawDesc || (eggMeta ? eggMeta.desc : '');
      const payload = { name, cost, desc, effectType, quantity, hiddenEggId, active, image: imageUrl, imageUrl, student_visible: studentVisible, student_trade_mode: studentTradeMode, updatedAt: Date.now(), createdAt: Date.now() };
      try {
        setShopAdminSaving(true);
        let savedProductId = currentState.editingShopProductId || '';
        if (currentState.editingShopProductId) {
          const ref = doc(db, SHOP_COLLECTION, currentState.editingShopProductId);
          const old = await getDoc(ref);
          payload.createdAt = old.exists() ? (old.data().createdAt || Date.now()) : Date.now();
          await setDoc(ref, payload, { merge: true });
        } else {
          const id = `custom_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
          savedProductId = id;
          await setDoc(doc(db, SHOP_COLLECTION, id), payload, { merge: false });
        }
        try { await syncStudentShopCatalogSummary(savedProductId, { ...payload, id: savedProductId }); } catch (summaryErr) { console.warn('[shop] sync summary failed:', summaryErr); }
        resetShopAdminForm();
        await loadShopAdminList();
        await renderShopItems();
        try { await refreshStudentShopShowcase({ force: true, source: 'shop-admin-save' }); } catch (refreshErr) { console.warn('[shop] refresh student showcase failed:', refreshErr); }
        if (quantity <= 0) UI.alert(`商品已儲存：${name}
目前數量為 0，學生端會顯示為灰色「售罄」。`, '商品已儲存');
        else UI.toast(`商品已儲存：${name}`);
      } catch (e) {
        console.error(e);
        UI.alert(`商品儲存失敗：${e.message || e}`, '商品儲存失敗');
      } finally {
        setShopAdminSaving(false);
      }
    },
    async deleteShopProduct(productId) {
      if (!productId) return UI.toast('找不到商品 ID');
      if (currentState.shopAdminSaving) { UI.toast('商品作業進行中，請稍候'); return; }
      const ok = await UI.confirm('確定要刪除此商品嗎？售出紀錄不會被刪除。', '刪除商品');
      if (!ok) return;
      try {
        setShopAdminSaving(true);
        await deleteDoc(doc(db, SHOP_COLLECTION, productId));
        try { await removeStudentShopCatalogSummary(productId); } catch (summaryErr) { console.warn('[shop] remove summary failed:', summaryErr); }
        if (currentState.editingShopProductId === productId) resetShopAdminForm();
        await loadShopAdminList();
        await renderShopItems();
        try { await refreshStudentShopShowcase({ force: true, source: 'shop-admin-delete' }); } catch (refreshErr) { console.warn('[shop] refresh student showcase failed:', refreshErr); }
        UI.toast('商品已刪除');
      } catch (e) {
        console.error(e);
        UI.alert(`商品刪除失敗：${e.message || e}`, '商品刪除失敗');
      } finally {
        setShopAdminSaving(false);
      }
    },
    async openShop() {
      const flowDom = ensureShopFlowDom();
      if (!flowDom) return;
      UI.showModal('shopModal');
      const hasStudent = !!currentState.studentData;
      flowDom.shopCoins.innerText = hasStudent ? (currentState.studentData.coins || 0) : '...';
      await renderShopItems();
      if (!hasStudent) {
        if (currentState.currentUid) UI.toast('⏳ 學生資料載入中…');
        else UI.alert('請先掃描學生卡或查詢卡序，載入學生資料後才能兌換。', '需要學生資料');
      }
    },
    async applyShopEffect(data, itemMeta, cost) {
      const effectType = String(itemMeta?.effectType || '').trim();
      if (effectType === 'physical_reward') {
        const ok = await UI.confirm(`${itemMeta.name || '實體商品'}
需要在老師面前購買才能獲得，否則不算數。

請確認你正在老師面前購買？`, '實體獎勵確認');
        if (!ok) return { applied: false };
        data.coins -= cost;
        data.collection = Array.isArray(data.collection) ? data.collection : [];
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        const voucherTs = Date.now();
        data.collection.push(buildShopVoucherRecord(itemMeta, data, voucherTs));
        data.logs.push({ timestamp: voucherTs, action_type: 'shop', detail: `購買${itemMeta.name || '實體商品'}（已建立兌換憑證）` });
        const saved = await saveStudentData(data);
        if (!saved) {
          UI.alert('購買已送出，但憑證建立失敗，請通知老師確認。', '系統通知');
          return { applied: false };
        }
        UI.hideModal('shopModal');
        UI.alert(`已建立「${itemMeta.name || '實體商品'}」的購買憑證，請到收藏區出示給老師兌現。`, '已建立憑證');
        return { applied: true };
      }
      if (effectType === 'antidote') {
        data.coins -= cost;
        data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
        data.debuffs_timestamp = null;
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        data.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `購買${itemMeta.name || '萬靈藥'}` });
        await saveStudentData(data);
        UI.hideModal('shopModal');
        return { applied: true };
      }
      if (effectType === 'evo_stone' || effectType === 'wonder_stone') {
        UI.hideModal('shopModal');
        const flowDom = ensureAttrSelectDom();
        if (!flowDom) return { applied: false };
        flowDom.attrSelectTitle.innerText = effectType === 'evo_stone' ? '選擇目標屬性' : '選擇進化目標';
        UI.showModal('attrSelectModal');
        flowDom.confirmAttrSelectBtn.onclick = async () => {
          let freshData = migrateStudentData(currentState.studentData || data);
          const selectedAttr = flowDom.attrSelectDropdown.value;
          if ((Number(freshData.coins) || 0) < cost) {
            UI.alert('餘額不足！', '交易失敗');
            return;
          }
          freshData.coins -= cost;
          freshData.logs = Array.isArray(freshData.logs) ? freshData.logs : [];
          if (effectType === 'evo_stone') {
            freshData.totalXP = (Number(freshData.totalXP) || 0) + 30;
            addAttributeXPSafe(freshData, selectedAttr, 30);
            freshData.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `${itemMeta.name || '進化石'}（${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr} +30 XP）` });
            freshData = processEvolutionSafe(freshData);
          } else {
            freshData.collection = Array.isArray(freshData.collection) ? freshData.collection : [];
            freshData.collection.push({ type: 'material', element: selectedAttr, name: `${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr}系素材`, img: CONSTANTS.MEDIA.PLACEHOLDER_SVG, stats: { ...(freshData.attributes || {}) }, timestamp: Date.now() });
            freshData.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `${itemMeta.name || '進化奇石'}（${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr}系素材）` });
          }
          await saveStudentData(freshData);
          UI.hideModal('attrSelectModal');
          UI.toast('交易完成');
          await renderShopItems();
        };
        return { applied: true, deferred: true };
      }
      if (effectType === 'hidden_egg') {
        const eggMeta = CONSTANTS.HIDDEN_EGGS[itemMeta.hiddenEggId || ''];
        if (!eggMeta) {
          UI.alert('此特殊異獸蛋尚未設定完成。', '商品設定錯誤');
          return { applied: false };
        }
        data.coins -= cost;
        data.hidden_eggs = Array.isArray(data.hidden_eggs) ? data.hidden_eggs : [];
        data.collection = Array.isArray(data.collection) ? data.collection : [];
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        const eggRecord = {
          type: 'hidden_egg',
          id: `${eggMeta.id}_${Date.now()}`,
          hiddenEggId: eggMeta.id,
          name: eggMeta.name,
          beastName: eggMeta.beastName || '',
          img: eggMeta.img,
          forms: eggMeta.forms || null,
          requiredAttr: eggMeta.requiredAttr,
          points: eggMeta.points,
          status: 'incubating',
          stats: { ...(data.attributes || {}) },
          timestamp: Date.now()
        };
        data.hidden_eggs.push(eggRecord);
        data.collection.push({ ...eggRecord });
        if (!String(data.active_hidden_egg_id || '').trim()) {
          data.active_hidden_egg_id = eggMeta.id;
          data.active_hidden_egg = { ...eggRecord, status: 'active', activatedAt: Date.now() };
        }
        data.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `購買特殊異獸蛋：${eggMeta.name}（需求屬性：${CONSTANTS.ATTRIBUTES[eggMeta.requiredAttr]?.name || eggMeta.requiredAttr}）` });
        await saveStudentData(data);
        UI.hideModal('shopModal');
        return { applied: true };
      }
      UI.alert('此商品功能尚未支援。', '商品設定錯誤');
      return { applied: false };
    },
    async handleShopPurchase(itemId, cost, isBuiltIn = false) {
      if (currentState.shopBusy) { UI.toast('商城處理中，請稍候'); return; }
      if (!currentState.studentData) {
        UI.alert('請先掃描學生卡或查詢卡序，載入學生資料後才能兌換。', '需要學生資料');
        return;
      }
      try {
        setShopBusy(true);
        let data = migrateStudentData(currentState.studentData);
        data.coins = Number(data.coins) || 0;
        let itemMeta = null;
        let itemRef = null;
        if (isBuiltIn) {
          itemMeta = getBuiltInShopItems().find((x) => x.id === itemId) || null;
        } else {
          itemRef = doc(db, SHOP_COLLECTION, itemId);
          const snap = await getDoc(itemRef);
          if (!snap.exists()) {
            UI.alert('此商品已下架。', '交易失敗');
            await renderShopItems();
            return;
          }
          const d = snap.data() || {};
          itemMeta = { id: itemId, builtIn: false, ...d, cost: Number(d.cost) || 0, quantity: Math.max(0, Number(d.quantity) || 0) };
          cost = itemMeta.cost;
          if (itemMeta.active === false) {
            UI.alert('此商品尚未上架。', '交易失敗');
            await renderShopItems();
            return;
          }
          if (itemMeta.quantity <= 0) {
            UI.alert('此商品已售罄。', '交易失敗');
            await renderShopItems();
            return;
          }
        }
        if (!itemMeta) {
          UI.alert('找不到商品資料。', '交易失敗');
          return;
        }
        if (data.coins < cost) {
          UI.alert('您目前的金幣餘額不足！', '交易失敗');
          return;
        }
        const effectResult = await shopApi.applyShopEffect(data, itemMeta, cost);
        if (!effectResult || !effectResult.applied) return;
        if (!isBuiltIn && itemRef && !effectResult.deferred) {
          try {
            const latest = await getDoc(itemRef);
            if (latest.exists()) {
              const q = Math.max(0, Number(latest.data().quantity) || 0);
              await updateDoc(itemRef, { quantity: Math.max(0, q - 1), updatedAt: Date.now() });
            }
          } catch (e) {
            console.warn('[shop] quantity update failed:', e);
          }
        }
        if (!effectResult.deferred) {
          UI.toast('交易完成');
          await renderShopItems();
        }
      } catch (e) {
        console.error(e);
        UI.alert(`商城購買失敗：${e.message || e}`, '商城購買失敗');
      } finally {
        setShopBusy(false);
        try { await renderShopItems(); } catch (renderErr) { console.warn('[shop] render after purchase failed:', renderErr); }
      }
    }
  };
  const applyAdminGiftEffect = (...args) => shopApi.applyAdminGiftEffect(...args);
  const applyShopEffectLegacy = (...args) => shopApi.applyShopEffectLegacy(...args);
  const getAdminGiftableShopItems = (...args) => shopApi.getAdminGiftableShopItems(...args);
  const getBuiltInShopItems = (...args) => shopApi.getBuiltInShopItems(...args);
  const getShopButtonHtml = (...args) => shopApi.getShopButtonHtml(...args);
  const getShopEffectLabel = (...args) => shopApi.getShopEffectLabel(...args);
  const getShopGiftItemMeta = (...args) => shopApi.getShopGiftItemMeta(...args);
  const handleShopPurchaseLegacy = (...args) => shopApi.handleShopPurchaseLegacy(...args);
  const loadShopAdminList = (...args) => shopApi.loadShopAdminList(...args);
  const loadShopGiftOptions = (...args) => shopApi.loadShopGiftOptions(...args);
  const lookupShopGiftTarget = (...args) => shopApi.lookupShopGiftTarget(...args);
  const populateHiddenEggSelect = (...args) => shopApi.populateHiddenEggSelect(...args);
  const renderShopItems = (...args) => shopApi.renderShopItems(...args);
  const resetShopAdminForm = (...args) => shopApi.resetShopAdminForm(...args);
  const resetShopGiftForm = (...args) => shopApi.resetShopGiftForm(...args);
  const setShopAdminTab = (...args) => shopApi.setShopAdminTab(...args);
  const updateShopAdminFormState = (...args) => shopApi.updateShopAdminFormState(...args);

  return shopApi;
}
