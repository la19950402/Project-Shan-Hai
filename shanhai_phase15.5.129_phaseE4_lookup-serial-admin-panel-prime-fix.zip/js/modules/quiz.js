import { UI } from "../core/ui.js?v=phase15phase100fix12quizpoolsplit";
import { currentState, quizSession } from "../core/state.js?v=phase15phase100fix12quizpoolsplit";
import { db, collection, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc, writeBatch, query, where, limit } from "../core/firebase.js?v=phase15phase100fix12quizpoolsplit";
import { buildElementContract } from "../core/dom-contract.js?v=phase15phase100fix12quizpoolsplit";
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
import { beginPerfSpan, endPerfSpan, markPerfPoint } from "../core/prevalidation-perf.js?v=phase15phase129finalreleasegovernancereaudit";

export function createQuizModule({ isQuizEnabled, quizMatchesStudentGrade, getProfileLabels, isCatProfile, buildRewardEventId, formatLocalDateKey, getQuizManagerDom, resolveQuizImageMeta, updateQuizImagePreview, downloadCsvFile, downloadTextFile, scheduleQuizPoolSummaryRefresh, scheduleBackgroundTask, getStudentGradeInfo, QUIZ_POOL_COLLECTION }) {
  const BATTLE_TOWER_DOC_ID = '_BATTLE_TOWER_BOSS_';
  attachEmergencyFlagGlobals();
  const canUseAdminQuizFallback = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableStudentAdminCollectionFallback') && !isEmergencyFlagEnabled('disableStudentQuizAdminFallback');
  const canUseClientSummaryBackfill = () => currentState.isAdmin === true && currentState.viewMode !== 'student' && !isEmergencyFlagEnabled('disableClientSummaryBackfill');
  function normalizeQuizQuestionRecord(raw = {}, id = '') {
    const source = raw && typeof raw === 'object' ? raw : {};
    const normalized = { ...source, id: id || source.id || '' };
    normalized.question = String(source.question || source.questionText || source.q || source.title || source.prompt || source.stem || source.text || source.content || source.body || source.description || '').trim();

    const stripOptionPrefix = (value) => String(value ?? '').trim().replace(/^[A-Da-d1-4][\.|、:：\s\-_)）]*/, '').trim();
    const parseAnswerIndex = (value) => {
      if (typeof value === 'number' && Number.isFinite(value)) return value >= 1 && value <= 4 ? value - 1 : value;
      const str = String(value ?? '').trim();
      if (!str) return -1;
      if (/^[1-4]$/.test(str)) return Number(str) - 1;
      if (/^[A-Da-d]$/.test(str)) return str.toUpperCase().charCodeAt(0) - 65;
      if (/^option\s*[1-4]$/i.test(str)) return Number(str.replace(/\D+/g, '')) - 1;
      if (/^option\s*[A-D]$/i.test(str)) return str.toUpperCase().charCodeAt(str.length - 1) - 65;
      return -1;
    };

    let answerIndex = -1;
    const answerCandidates = [source.answer, source.correctAnswer, source.correct_option, source.correctOption, source.correctIndex, source.correctIdx, source.correct, source.correct_choice, source.correctChoice];
    for (const candidate of answerCandidates) {
      answerIndex = parseAnswerIndex(candidate);
      if (answerIndex >= 0) break;
    }

    const objectOptions = source.options && !Array.isArray(source.options) && typeof source.options === 'object'
      ? [source.options.A, source.options.B, source.options.C, source.options.D, source.options.a, source.options.b, source.options.c, source.options.d]
      : [];
    const stringOptions = typeof source.options === 'string'
      ? String(source.options).split(/\r?\n|\|/).map((part) => part.trim()).filter(Boolean)
      : [];
    const optionCandidates = Array.isArray(source.options)
      ? source.options
      : Array.isArray(source.choices)
        ? source.choices
        : Array.isArray(source.selections)
          ? source.selections
          : objectOptions.filter((value) => value != null && String(value).trim())
            .concat(stringOptions)
            .concat([source.option1, source.option2, source.option3, source.option4, source.optionA, source.optionB, source.optionC, source.optionD, source.a, source.b, source.c, source.d]);

    normalized.options = optionCandidates.slice(0, 4).map((opt, idx) => {
      if (typeof opt === 'string') return { text: stripOptionPrefix(opt), isCorrect: idx === answerIndex };
      return {
        text: stripOptionPrefix(opt?.text ?? opt?.label ?? opt?.content ?? opt?.value ?? opt ?? ''),
        isCorrect: !!opt?.isCorrect || idx === answerIndex
      };
    }).filter(opt => !!opt?.text);

    if (answerIndex < 0) {
      const answerTextCandidates = answerCandidates.map((candidate) => stripOptionPrefix(candidate)).filter(Boolean);
      if (answerTextCandidates.length) {
        const matchedIndex = normalized.options.findIndex((opt) => answerTextCandidates.includes(stripOptionPrefix(opt?.text || '')));
        if (matchedIndex >= 0) {
          normalized.options.forEach((opt, idx) => { opt.isCorrect = idx === matchedIndex; });
          answerIndex = matchedIndex;
        }
      }
    }

    const rawImage = String(source.imageUrl || source.image_url || source.questionImage || source.question_image || source.image || source.img || '').trim();
    const imageUrl = /^(https?:|data:image\/|blob:)/i.test(rawImage) ? rawImage : '';
    const imageAssetKey = String(source.imageAssetKey || source.image_asset_key || source.imageAsset || source.assetKey || source.img_file || (!imageUrl ? rawImage : '') || '').trim();
    normalized.imageUrl = imageUrl;
    normalized.image = imageUrl;
    normalized.imageAssetKey = imageAssetKey;
    normalized.imageAlt = String(source.imageAlt || source.image_alt || source.alt || normalized.question || '題目附圖').trim() || '題目附圖';
    if (!normalized.unit && source.category) normalized.unit = source.category;
    if (!normalized.grade && source.gradeName) normalized.grade = source.gradeName;
    return normalized;
  }

  function isQuestionLikeRecord(q = {}) {
    return !!String(q.question || '').trim() || (Array.isArray(q.options) && q.options.some(opt => String(opt?.text || '').trim()));
  }

  const setQuizBusy = (kind, flag = true) => { currentState[kind] = !!flag; };
  const isQuizBusy = () => !!(currentState.quizLoading || currentState.quizSaving || currentState.quizDeleting || currentState.quizToggling || currentState.quizExporting);
  const getQuizDom = () => (typeof getQuizManagerDom === 'function' ? (getQuizManagerDom() || {}) : getQuizManagerElements());
  const resolveImageMeta = (source = {}) => {
    if (typeof resolveQuizImageMeta === 'function') return resolveQuizImageMeta(source) || {};
    return {
      imageUrl: String(source?.imageUrl || source?.image || '').trim(),
      imageAssetKey: String(source?.imageAssetKey || source?.img_file || '').trim(),
      imageAlt: String(source?.imageAlt || source?.question || '題目附圖').trim() || '題目附圖'
    };
  };
  const refreshQuizPoolSummary = (reason = 'quiz-module') => {
    try { if (typeof scheduleQuizPoolSummaryRefresh === 'function') scheduleQuizPoolSummaryRefresh(reason); } catch (_) {}
  };
  const battleTowerConfigCache = { docId: '', data: null, loadedAt: 0, promise: null };
  const quizBankCacheState = () => ({
    loadedAt: Number(currentState.quizBankLoadedAt) || 0,
    promise: currentState.quizBankLoadPromise || null,
  });

  function normalizeQuizGradeTokenLocal(raw) {
    const str = String(raw || '').trim();
    if (!str) return '';
    const direct = str.match(/^([1-6])(?:年級)?$/);
    if (direct) return direct[1];
    const gradeLike = str.match(/([1-6])\s*[上下]?/);
    if (gradeLike) return gradeLike[1];
    return '';
  }

  function normalizeQuizPoolAudienceKey(raw = '', fallback = 'default') {
    const value = String(raw || '').trim().toLowerCase();
    if (!value) return fallback || 'default';
    if (value === 'support') return 'support';
    const gradeMatch = value.match(/^grade[_-]?([1-6])$/) || value.match(/^g([1-6])$/) || value.match(/^([1-6])$/);
    if (gradeMatch) return `grade${gradeMatch[1]}`;
    return fallback || 'default';
  }

  function getQuizPoolAudienceKeyForStudent(studentLike = null) {
    const info = typeof getStudentGradeInfo === 'function' ? getStudentGradeInfo(studentLike || currentState.studentData || {}) : {};
    return normalizeQuizPoolAudienceKey(info?.audienceKey || 'default');
  }


  function matchesBattleAudienceQuestion(question, gradeInfo = {}) {
    if (!question) return false;
    if (gradeInfo?.isSupportClass) return quizMatchesStudentGrade(question, '學習扶助班', true);
    return quizMatchesStudentGrade(question, gradeInfo?.gradeToken, false);
  }

  async function listAllPlayableBattleGatekeeperQuestions() {
    const snapshot = await getDocs(collection(db, 'quiz_bank'));
    const quizzes = [];
    snapshot.forEach((docSnap) => {
      if (docSnap.id === BATTLE_TOWER_DOC_ID) return;
      const normalized = normalizeQuizQuestionRecord(docSnap.data() || {}, docSnap.id);
      if (!isQuizEnabled(normalized) || !isPlayableQuizPoolQuestion(normalized)) return;
      quizzes.push(normalized);
    });
    quizzes.sort((a, b) => (b.timestamp || b.updatedAt || 0) - (a.timestamp || a.updatedAt || 0));
    return quizzes;
  }

  function parseQuizAnswerIndexLocal(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return value >= 1 && value <= 4 ? value - 1 : value;
    const str = String(value ?? '').trim();
    if (!str) return -1;
    if (/^[1-4]$/.test(str)) return Number(str) - 1;
    if (/^[A-Da-d]$/.test(str)) return str.toUpperCase().charCodeAt(0) - 65;
    return -1;
  }

  function buildQuizPoolQuestionSummary(raw = {}, id = '') {
    const source = raw && typeof raw === 'object' ? raw : {};
    const questionId = String(id || source.id || source.quizId || source.questionId || '').trim();
    const answerIndexCandidates = [
      source.answer,
      source.correctAnswer,
      source.correct_option,
      source.correctOption,
      source.correctIndex,
      source.correct,
      source.correct_choice,
      source.correctChoice
    ];
    let answerIndex = -1;
    answerIndexCandidates.some((candidate) => {
      const parsed = parseQuizAnswerIndexLocal(candidate);
      if (parsed >= 0) {
        answerIndex = parsed;
        return true;
      }
      return false;
    });
    const optionCandidates = Array.isArray(source.options)
      ? source.options
      : Array.isArray(source.choices)
        ? source.choices
        : Array.isArray(source.selections)
          ? source.selections
          : [source.option1, source.option2, source.option3, source.option4, source.a, source.b, source.c, source.d];
    const options = optionCandidates
      .slice(0, 4)
      .map((opt, idx) => {
        if (typeof opt === 'string') return { text: opt.trim(), isCorrect: idx === answerIndex };
        return {
          text: String(opt?.text ?? opt?.label ?? opt ?? '').trim(),
          isCorrect: !!opt?.isCorrect || idx === answerIndex
        };
      })
      .filter((opt) => !!opt.text);
    if (answerIndex < 0) {
      const answerTextCandidates = answerIndexCandidates
        .map((candidate) => String(candidate ?? '').trim())
        .filter(Boolean)
        .map((value) => value.replace(/^[A-Da-d][\.|、:：\s-]*/, '').trim());
      if (answerTextCandidates.length) {
        const matchedIndex = options.findIndex((opt) => answerTextCandidates.includes(String(opt?.text || '').trim()));
        if (matchedIndex >= 0) {
          options.forEach((opt, idx) => { opt.isCorrect = idx === matchedIndex; });
          answerIndex = matchedIndex;
        }
      }
    }
    const imageMeta = resolveImageMeta(source);
    return {
      id: questionId,
      question: String(source.question || source.questionText || source.q || source.title || source.prompt || source.stem || source.text || '').trim(),
      options,
      answer: source.answer ?? source.correctAnswer ?? source.correct_option ?? source.correctOption ?? source.correctIndex ?? source.correct ?? source.correct_choice ?? source.correctChoice ?? '',
      grade: String(source.grade || source.class_name || source.gradeName || '').trim(),
      class_name: String(source.class_name || '').trim(),
      gradeName: String(source.gradeName || '').trim(),
      unit: String(source.unit || source.category || '').trim(),
      imageUrl: imageMeta.imageUrl,
      image: imageMeta.imageUrl,
      imageAssetKey: imageMeta.imageAssetKey,
      imageAlt: imageMeta.imageAlt || '',
      timestamp: Number(source.timestamp || source.updatedAt || source.updated_at) || 0,
      updatedAt: Number(source.updatedAt || source.updated_at || source.timestamp) || 0,
      isActive: source.isActive !== false && source.active !== false && source.enabled !== false && String(source.status || '').trim() !== 'disabled'
    };
  }

  function isPlayableQuizPoolQuestion(question = {}) {
    if (!String(question?.question || '').trim()) return false;
    const options = Array.isArray(question?.options) ? question.options : [];
    if (options.length < 2) return false;
    if (!options.every((opt) => String(opt?.text || '').trim())) return false;
    return options.some((opt) => !!opt?.isCorrect);
  }

  function normalizeQuizPoolSummaryRecord(raw = {}, docId = '') {
    const normalized = buildQuizPoolQuestionSummary(raw, docId);
    if (!normalized.id) return null;
    if (!isQuizEnabled(normalized) || !isPlayableQuizPoolQuestion(normalized)) return null;
    return normalized;
  }

  function inspectQuizPoolQuestionRecord(raw = {}, docId = '') {
    const normalized = buildQuizPoolQuestionSummary(raw, docId);
    if (!normalized.id) return { normalized: null, reason: 'missing-id' };
    if (!isQuizEnabled(normalized)) return { normalized: null, reason: 'inactive-or-disabled' };
    if (!String(normalized?.question || '').trim()) return { normalized: null, reason: 'missing-question' };
    const options = Array.isArray(normalized?.options) ? normalized.options : [];
    if (options.length < 2) return { normalized: null, reason: 'insufficient-options' };
    if (!options.every((opt) => String(opt?.text || '').trim())) return { normalized: null, reason: 'empty-option-text' };
    if (!options.some((opt) => !!opt?.isCorrect)) return { normalized: null, reason: 'missing-correct-answer' };
    return { normalized, reason: '' };
  }

  function cloneQuizPoolDiagValue(value) {
    if (Array.isArray(value)) return value.map((entry) => cloneQuizPoolDiagValue(entry));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cloneQuizPoolDiagValue(entry)]));
    return value;
  }

  function getQuizPoolDiagnosticsBucket(audienceKey = 'default') {
    const root = currentState.quizPoolDiagnostics && typeof currentState.quizPoolDiagnostics === 'object'
      ? currentState.quizPoolDiagnostics
      : (currentState.quizPoolDiagnostics = { byAudience: {}, lastAudienceKey: '', updatedAt: 0 });
    if (!root.byAudience || typeof root.byAudience !== 'object') root.byAudience = {};
    const key = normalizeQuizPoolAudienceKey(audienceKey || 'default');
    if (!root.byAudience[key] || typeof root.byAudience[key] !== 'object') root.byAudience[key] = { audienceKey: key, events: [] };
    root.lastAudienceKey = key;
    root.updatedAt = Date.now();
    return root.byAudience[key];
  }

  function mergeQuizPoolDiagnostics(audienceKey = 'default', patch = {}) {
    const bucket = getQuizPoolDiagnosticsBucket(audienceKey);
    Object.assign(bucket, patch || {}, {
      audienceKey: normalizeQuizPoolAudienceKey(audienceKey || 'default'),
      updatedAt: Date.now()
    });
    return bucket;
  }

  function appendQuizPoolDiagEvent(audienceKey = 'default', event = {}) {
    const bucket = getQuizPoolDiagnosticsBucket(audienceKey);
    const events = Array.isArray(bucket.events) ? bucket.events : (bucket.events = []);
    events.push({ at: Date.now(), ...cloneQuizPoolDiagValue(event || {}) });
    if (events.length > 40) events.splice(0, events.length - 40);
    bucket.updatedAt = Date.now();
    return bucket;
  }

  function attachQuizPoolDiagnosticsGlobals() {
    try {
      if (typeof window === 'undefined') return;
      if (typeof window.__getQuizPoolDiagnostics !== 'function') {
        window.__getQuizPoolDiagnostics = () => cloneQuizPoolDiagValue(currentState.quizPoolDiagnostics || {});
      }
      if (typeof window.__printQuizPoolDiagnostics !== 'function') {
        window.__printQuizPoolDiagnostics = (audienceKey = '') => {
          const root = window.__getQuizPoolDiagnostics();
          const key = normalizeQuizPoolAudienceKey(audienceKey || root?.lastAudienceKey || 'default');
          const payload = root?.byAudience?.[key] || root || {};
          console.log('[quiz-pool][diag]', key, payload);
          return payload;
        };
      }
      if (typeof window.__getQuizPoolHealthAudit !== 'function') {
        window.__getQuizPoolHealthAudit = () => cloneQuizPoolDiagValue(currentState.quizPoolHealthAudit || {});
      }
      if (typeof window.__printQuizPoolHealthAudit !== 'function') {
        window.__printQuizPoolHealthAudit = (audienceKey = '') => {
          const audit = window.__getQuizPoolHealthAudit();
          const key = normalizeQuizPoolAudienceKey(audienceKey || audit?.lastAudienceKey || 'default');
          const payload = (Array.isArray(audit?.audiences) ? audit.audiences.find((entry) => entry?.audienceKey === key) : null) || audit || {};
          console.log('[quiz-pool][health-print]', key, payload);
          return payload;
        };
      }
      if (typeof window.__auditQuizPoolSummaryHealth !== 'function') {
        window.__auditQuizPoolSummaryHealth = async (audienceKey = '', options = {}) => {
          const normalized = String(audienceKey || '').trim();
          if (!normalized || normalized === '*' || /^all$/i.test(normalized)) {
            return quizApi.auditQuizPoolSummaryHealth({ ...options, audienceKey: '*' });
          }
          return quizApi.auditQuizPoolSummaryHealth({ ...options, audienceKey: normalized });
        };
      }
    } catch (_) {}
  }

  function getQuizPoolAudienceKeysForQuestion(question = {}) {
    const keys = new Set(['default']);
    if (quizMatchesStudentGrade(question, '學習扶助班', true)) keys.add('support');
    const gradeToken = normalizeQuizGradeTokenLocal(question?.grade || question?.class_name || question?.gradeName || '');
    if (gradeToken && /^[1-6]$/.test(gradeToken) && !/學習扶助/.test(String(question?.grade || question?.class_name || question?.gradeName || '').trim())) {
      keys.add(`grade${gradeToken}`);
    }
    return [...keys];
  }

  function shuffleCopy(list = []) {
    const pool = Array.isArray(list) ? [...list] : [];
    for (let idx = pool.length - 1; idx > 0; idx -= 1) {
      const swapIndex = Math.floor(Math.random() * (idx + 1));
      [pool[idx], pool[swapIndex]] = [pool[swapIndex], pool[idx]];
    }
    return pool;
  }

  function getQuizManagerElements() {
    const contract = buildElementContract({
      modal: 'quizManagerModal',
      formTitle: 'qmFormTitle',
      editId: 'qmEditId',
      saveBtn: 'qmSaveBtn',
      cancelBtn: 'qmCancelEditBtn',
      grade: 'qmGrade',
      unit: 'qmUnit',
      question: 'qmQuestion',
      opt0: 'qmOpt0',
      opt1: 'qmOpt1',
      opt2: 'qmOpt2',
      opt3: 'qmOpt3',
      filterGrade: 'qmFilterGrade',
      filterUnit: 'qmFilterUnit',
      listContainer: 'quizListContainer',
      selectedCount: 'qmSelectedCount',
      selectAll: 'qmSelectAll',
      totalCount: 'qmTotalCount'
    }, ['modal', 'formTitle', 'editId', 'saveBtn', 'cancelBtn', 'grade', 'unit', 'question', 'opt0', 'opt1', 'opt2', 'opt3', 'listContainer', 'selectedCount', 'selectAll', 'totalCount']);

    const elements = {
      ...contract.elements,
      options: [contract.elements.opt0, contract.elements.opt1, contract.elements.opt2, contract.elements.opt3].filter(Boolean),
      missing: contract.missing.slice(),
      ok: contract.ok
    };

    currentState.quizDomContract = {
      checkedAt: Date.now(),
      missing: contract.missing.slice(),
      ok: contract.ok
    };
    try {
      const diagBase = (globalThis.__BOOT_DIAG && typeof globalThis.__BOOT_DIAG === 'object') ? globalThis.__BOOT_DIAG : {};
      globalThis.__BOOT_DIAG = {
        ...diagBase,
        quizDomContract: {
          ok: contract.ok,
          missing: contract.missing.slice(),
          checkedAt: currentState.quizDomContract.checkedAt
        }
      };
    } catch (_) {}

    return elements;
  }

  function hasQuizFormStructure(elements = getQuizDom()) {
    return Boolean(elements?.grade && elements?.unit && elements?.question && Array.isArray(elements?.options) && elements.options.length === 4 && elements?.saveBtn && elements?.cancelBtn);
  }

  const quizApi = {
    resetQuizForm() {
      const els = getQuizDom();
      if (!hasQuizFormStructure(els)) return;
      if (els.formTitle) els.formTitle.innerText = '[ 新增題目 ]';
      if (els.editId) els.editId.value = '';
      if (els.saveBtn) {
        els.saveBtn.innerText = '儲存題目';
        els.saveBtn.setAttribute('onclick', 'App.saveNewQuiz()');
      }
      if (els.cancelBtn) els.cancelBtn.classList.add('hidden');
      if (els.grade) els.grade.value = '5上';
      if (els.unit) els.unit.value = '';
      if (els.question) els.question.value = '';
      if (els.imageUrl) els.imageUrl.value = '';
      if (els.imageAsset) els.imageAsset.value = '';
      els.options.forEach(el => { if (el) el.value = ''; });
      try { if (typeof updateQuizImagePreview === 'function') updateQuizImagePreview({}, { emptyHint: '未設定題圖時，作答畫面只顯示文字題目。' }); } catch (_) {}
      const firstRadio = (typeof els.getCorrectInputByValue === 'function' ? els.getCorrectInputByValue('0') : null) || document.querySelector('input[name="qmCorrect"][value="0"]');
      if (firstRadio) firstRadio.checked = true;
    },

    fillQuizForm(quizId, quizData = {}) {
      const els = getQuizDom();
      if (!hasQuizFormStructure(els)) return;
      if (els.formTitle) els.formTitle.innerText = '[ 修改題目 EDIT ENTRY ]';
      if (els.editId) els.editId.value = quizId || '';
      if (els.saveBtn) {
        els.saveBtn.innerText = 'UPDATE ENTRY (儲存修改)';
        els.saveBtn.setAttribute('onclick', 'App.saveEditedQuiz()');
      }
      if (els.cancelBtn) els.cancelBtn.classList.remove('hidden');
      if (els.grade) els.grade.value = quizData.grade || '5上';
      if (els.unit) els.unit.value = quizData.unit || '';
      if (els.question) els.question.value = quizData.question || '';
      const imageMeta = resolveImageMeta(quizData || {});
      if (els.imageUrl) els.imageUrl.value = imageMeta.imageUrl || '';
      if (els.imageAsset) els.imageAsset.value = imageMeta.imageAssetKey || '';
      try { if (typeof updateQuizImagePreview === 'function') updateQuizImagePreview({ ...imageMeta, imageAlt: quizData.question || '題目附圖' }); } catch (_) {}
      const options = Array.isArray(quizData.options) ? quizData.options : [];
      for (let i = 0; i < 4; i++) {
        const opt = options[i] || {};
        const input = els.options[i] || null;
        if (input) input.value = opt.text || '';
        const radio = (typeof els.getCorrectInputByValue === 'function' ? els.getCorrectInputByValue(String(i)) : null) || document.querySelector(`input[name="qmCorrect"][value="${i}"]`);
        if (radio) radio.checked = !!opt.isCorrect;
      }
      if (!((els.correctInputs || Array.from(document.querySelectorAll('input[name="qmCorrect"]')))).some(r => r.checked)) {
        const firstRadio = (typeof els.getCorrectInputByValue === 'function' ? els.getCorrectInputByValue('0') : null) || document.querySelector('input[name="qmCorrect"][value="0"]');
        if (firstRadio) firstRadio.checked = true;
      }
      const box = els.modalContent || els.modal?.querySelector('.modal-content');
      if (box) box.scrollTo({ top: 0, behavior: 'smooth' });
    },

    async openEditQuiz(id) {
      try {
        const snap = await getDoc(doc(db, 'quiz_bank', id));
        if (!snap.exists()) return UI.toast('找不到題目資料');
        quizApi.fillQuizForm(id, snap.data());
      } catch (e) {
        console.error(e);
        UI.toast('讀取題目失敗');
      }
    },

    cancelQuizEdit() {
      quizApi.resetQuizForm();
    },

    readQuizFormData() {
      const els = getQuizDom();
      if (!hasQuizFormStructure(els)) {
        UI.alert('題庫表單缺少必要欄位，請重新整理頁面後再試。', '系統異常');
        return null;
      }
      const qGrade = els.grade.value || '5上';
      const qUnit = els.unit.value.trim() || '未分類';
      const qText = els.question.value.trim() || '';
      const opts = els.options.map(el => (el.value || '').trim());
      const checked = typeof els.getCheckedCorrectInput === 'function' ? els.getCheckedCorrectInput() : document.querySelector('input[name="qmCorrect"]:checked');
      const correctVal = checked ? String(checked.value) : '0';
      if (!qText || opts.some(v => !v)) {
        UI.toast('請填寫完整題目！');
        return null;
      }
      const imageMeta = resolveImageMeta({ imageUrl: els.imageUrl?.value || '', imageAssetKey: els.imageAsset?.value || '', question: qText });
      return {
        grade: qGrade,
        unit: qUnit,
        question: qText,
        imageUrl: imageMeta.imageUrl || '',
        image: imageMeta.imageUrl || '',
        imageAssetKey: imageMeta.imageAssetKey || '',
        imageAlt: imageMeta.imageAlt || qText || '題目附圖',
        options: opts.map((text, idx) => ({ text, isCorrect: correctVal === String(idx) }))
      };
    },

    setQuizBusy(kind, flag = true) { setQuizBusy(kind, flag); },
    isQuizBusy() { return isQuizBusy(); },
    async importQuizBulk() {
      const { bulkImport: textarea } = getQuizDom();
      const raw = (textarea?.value || '').trim();
      if (!raw) return UI.toast('請先貼上題庫內容');
      const entries = [];
      try {
        if (raw.startsWith('[')) {
          const parsed = JSON.parse(raw);
          if (!Array.isArray(parsed)) throw new Error('JSON 必須是陣列');
          parsed.forEach((item, idx) => {
            const options = Array.isArray(item.options) ? item.options : [];
            if (!item.question || options.length < 4) throw new Error(`第 ${idx + 1} 筆 JSON 格式不完整`);
            let answerIndex = 0;
            if (typeof item.answer === 'number') answerIndex = item.answer >= 1 && item.answer <= 4 ? item.answer - 1 : item.answer;
            const normalizedOptions = options.slice(0, 4).map((opt, optIdx) => {
              if (typeof opt === 'string') return { text: opt.trim(), isCorrect: optIdx === answerIndex };
              return { text: String(opt?.text || '').trim(), isCorrect: !!opt?.isCorrect || optIdx === answerIndex };
            });
            const imageMeta = resolveImageMeta(item);
            entries.push({
              grade: String(item.grade || '5上').trim(),
              unit: String(item.unit || '未分類').trim(),
              question: String(item.question || '').trim(),
              imageUrl: imageMeta.imageUrl || '',
              image: imageMeta.imageUrl || '',
              imageAssetKey: imageMeta.imageAssetKey || '',
              imageAlt: imageMeta.imageAlt || String(item.question || '').trim() || '題目附圖',
              options: normalizedOptions,
              isActive: item.isActive === true,
            });
          });
        } else {
          const lines = raw.split(/\r?\n/).map(v => v.trim()).filter(Boolean);
          lines.forEach((line, idx) => {
            const cols = line.split('	');
            if (cols.length < 8) throw new Error(`第 ${idx + 1} 行欄位不足，需至少 8 欄`);
            const [grade, unit, question, o1, o2, o3, o4, answerRaw, imageRaw = '', imageAssetRaw = ''] = cols;
            const answer = Number(String(answerRaw).trim());
            if (!(answer >= 1 && answer <= 4)) throw new Error(`第 ${idx + 1} 行正解需填 1-4`);
            const imageMeta = resolveImageMeta({ imageUrl: imageRaw, imageAssetKey: imageAssetRaw, question });
            entries.push({
              grade: String(grade || '5上').trim(),
              unit: String(unit || '未分類').trim(),
              question: String(question || '').trim(),
              imageUrl: imageMeta.imageUrl || '',
              image: imageMeta.imageUrl || '',
              imageAssetKey: imageMeta.imageAssetKey || '',
              imageAlt: imageMeta.imageAlt || String(question || '').trim() || '題目附圖',
              options: [o1, o2, o3, o4].map((txt, optIdx) => ({ text: String(txt || '').trim(), isCorrect: optIdx === answer - 1 })),
              isActive: false,
            });
          });
        }
        const valid = entries.filter(item => item.question && Array.isArray(item.options) && item.options.length === 4 && item.options.every(opt => opt.text));
        if (!valid.length) return UI.toast('沒有可匯入的有效題目');
        for (const item of valid) {
          await addDoc(collection(db, 'quiz_bank'), { ...item, timestamp: Date.now() });
        }
        UI.toast(`✅ 已匯入 ${valid.length} 題`);
        if (textarea) textarea.value = '';
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('importQuizBulk');
      } catch (e) {
        console.error(e);
        UI.alert(`匯入失敗：${e.message || e}`, '題庫匯入失敗');
      }
    },
    async exportQuizBank(format = 'json') {
      if (currentState.quizExporting) return UI.toast('題庫下載準備中，請稍候...');
      currentState.quizExporting = true;
      try {
        const snapshot = await getDocs(collection(db, 'quiz_bank'));
        const quizzes = [];
        snapshot.forEach(docSnap => {
          if (docSnap.id !== '_BATTLE_TOWER_BOSS_') quizzes.push({ id: docSnap.id, ...docSnap.data() });
        });
        if (!quizzes.length) return UI.toast('題庫為空，無法下載');
        quizzes.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        if (String(format).toLowerCase() === 'csv') {
          const rows = [[ 'id', 'grade', 'unit', 'question', 'option1', 'option2', 'option3', 'option4', 'answer', 'imageUrl', 'imageAssetKey', 'isActive', 'timestamp' ]];
          quizzes.forEach(q => {
            const options = Array.isArray(q.options) ? q.options : [];
            let answerIndex = options.findIndex(opt => !!opt?.isCorrect);
            if (answerIndex < 0) answerIndex = 0;
            rows.push([
              q.id || '', q.grade || '', q.unit || '', q.question || '',
              options[0]?.text || '', options[1]?.text || '', options[2]?.text || '', options[3]?.text || '',
              String(answerIndex + 1), q.imageUrl || q.image || '', q.imageAssetKey || q.img_file || '', q.isActive === true ? 'true' : 'false', q.timestamp || ''
            ]);
          });
          if (typeof downloadCsvFile === 'function') downloadCsvFile(`quiz_bank_${formatLocalDateKey()}.csv`, rows);
        } else {
          const payload = quizzes.map(q => ({
            id: q.id || '', grade: q.grade || '', unit: q.unit || '', question: q.question || '',
            options: Array.isArray(q.options) ? q.options.map(opt => ({ text: String(opt?.text || ''), isCorrect: !!opt?.isCorrect })) : [],
            imageUrl: q.imageUrl || q.image || '', imageAssetKey: q.imageAssetKey || q.img_file || '', imageAlt: q.imageAlt || '',
            isActive: q.isActive === true, timestamp: q.timestamp || null, updatedAt: q.updatedAt || null
          }));
          if (typeof downloadTextFile === 'function') downloadTextFile(`quiz_bank_${formatLocalDateKey()}.json`, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8;');
        }
        UI.toast(`⬇️ 題庫已下載（${String(format).toUpperCase()}）`);
      } catch (e) {
        console.error(e);
        UI.alert(`題庫下載失敗：${e.message || e}`, '題庫下載失敗');
      } finally {
        currentState.quizExporting = false;
      }
    },

    updateQuizSelectionSummary(visibleIds = null) {
      const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
      const { selectedCount: counter, selectAll: allCheckbox } = getQuizDom();
      if (counter) counter.innerText = `已勾選 ${selectedIds.length} 題`;
      if (allCheckbox) {
        const visible = Array.isArray(visibleIds) ? visibleIds : [];
        const selectedVisible = visible.filter(id => selectedIds.includes(id)).length;
        allCheckbox.checked = visible.length > 0 && selectedVisible === visible.length;
        allCheckbox.indeterminate = selectedVisible > 0 && selectedVisible < visible.length;
      }
    },

    updateQuizFilterState() { return quizApi.updateQuizFilterStateLegacy ? quizApi.updateQuizFilterStateLegacy() : void 0; },
    getFilteredQuizzes() { return quizApi.getFilteredQuizzesLegacy ? quizApi.getFilteredQuizzesLegacy() : []; },

    toggleQuizSelection(id, checked) {
      const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
      if (checked) selected.add(id);
      else selected.delete(id);
      currentState.quizSelectedIds = Array.from(selected);
      const visibleIds = quizApi.getFilteredQuizzes().map(q => q.id);
      quizApi.updateQuizSelectionSummary(visibleIds);
    },

    toggleAllQuizSelections(checked) { return quizApi.toggleAllQuizSelectionsLegacy ? quizApi.toggleAllQuizSelectionsLegacy(checked) : void 0; },
    renderQuizBankList() { return quizApi.renderQuizBankListLegacy ? quizApi.renderQuizBankListLegacy() : void 0; },
    async batchSetQuizActive(active) {
      const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
      if (!selectedIds.length) return UI.toast('請先勾選要處理的題目');
      const actionText = active ? '批次佈題' : '批次下架';
      const confirmed = await UI.confirm(`確定要對 ${selectedIds.length} 題執行「${actionText}」嗎？`, actionText);
      if (!confirmed) return;
      try {
        const batch = writeBatch(db);
        selectedIds.forEach(id => batch.update(doc(db, 'quiz_bank', id), { isActive: !!active, updatedAt: Date.now() }));
        await batch.commit();
        UI.toast(`✅ 已完成 ${actionText}`);
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('batchSetQuizActive');
      } catch (e) {
        console.error(e);
        UI.toast(`${actionText}失敗`);
      }
    },
    async batchDeleteSelectedQuizzes() {
      const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
      if (!selectedIds.length) return UI.toast('請先勾選要刪除的題目');
      const confirmed = await UI.confirm(`確定要永久刪除 ${selectedIds.length} 題嗎？
(此操作無法復原)`, '批次刪除確認');
      if (!confirmed) return;
      try {
        const batch = writeBatch(db);
        selectedIds.forEach(id => batch.delete(doc(db, 'quiz_bank', id)));
        await batch.commit();
        UI.toast(`🗑️ 已刪除 ${selectedIds.length} 題`);
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('batchDeleteSelectedQuizzes');
      } catch (e) {
        console.error(e);
        UI.toast('批次刪除失敗');
      }
    },

    async loadQuizBank(options = {}) {
      const manager = getQuizDom();
      if (!manager.modal || !manager.listContainer) {
        UI.alert('找不到題庫管理面板，請重新整理頁面後再試。', '系統異常');
        return;
      }

      const forceRefresh = !!options.forceRefresh;
      const maxAgeMs = Math.max(5000, Number(options.maxAgeMs) || 90000);
      const container = manager.listContainer;
      const cachedQuizzes = Array.isArray(currentState.quizBankCache) ? currentState.quizBankCache : [];
      const cacheLoadedAt = Number(currentState.quizBankLoadedAt) || 0;
      const hasFreshCache = cachedQuizzes.length > 0 && (Date.now() - cacheLoadedAt) < maxAgeMs;

      UI.showModal('quizManagerModal');
      quizApi.resetQuizForm();
      currentState.quizSelectedIds = [];

      const renderCachedQuizBank = (quizzes = []) => {
        currentState.quizBankCache = Array.isArray(quizzes) ? quizzes : [];
        if (manager.totalCount) manager.totalCount.innerText = String(currentState.quizBankCache.length);
        if (!currentState.quizBankCache.length) {
          if (container) container.innerHTML = '<div style="text-align:center; color:#555;">題庫為空！</div>';
          try { quizApi.updateQuizFilterState(); } catch (_) {}
          quizApi.updateQuizSelectionSummary([]);
          return;
        }
        try { quizApi.updateQuizFilterState(); } catch (err) { console.warn('[quiz] updateQuizFilterState failed during cached render', err); }
        try { quizApi.renderQuizBankList(); } catch (err) {
          console.error('[quiz] renderQuizBankList failed during cached render', err);
          if (container) container.innerHTML = '<div style="text-align:center; color:var(--danger);">題庫快取已載入，但畫面渲染失敗</div>';
        }
      };

      if (cachedQuizzes.length) renderCachedQuizBank(cachedQuizzes);
      else if (container) container.innerHTML = '<div style="text-align:center;">載入中...</div>';

      if (!forceRefresh && hasFreshCache) return cachedQuizzes;
      if (currentState.quizLoading && !forceRefresh && currentState.quizBankLoadPromise) return await currentState.quizBankLoadPromise;

      currentState.quizBankLoadDiag = { startedAt: Date.now(), skipped: [], loaded: 0, totalDocs: 0, renderError: null, fetchError: null, usedCache: cachedQuizzes.length > 0 };

      let loadPromise;
      loadPromise = (async () => {
        try {
          setQuizBusy('quizLoading', true);
          const snapshot = await getDocs(collection(db, 'quiz_bank'));
          const quizzes = [];
          const skipped = [];
          currentState.quizBankLoadDiag.totalDocs = Number(snapshot?.size || 0);

          snapshot.forEach((docSnap) => {
            if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
            try {
              const raw = docSnap.data() || {};
              const normalized = normalizeQuizQuestionRecord(raw, docSnap.id);
              if (!isQuestionLikeRecord(normalized)) {
                skipped.push({ id: docSnap.id, reason: 'not-question-like' });
                return;
              }
              quizzes.push(normalized);
            } catch (err) {
              skipped.push({ id: docSnap.id, reason: err?.message || String(err) });
            }
          });

          quizzes.sort((a, b) => (b.timestamp || b.updatedAt || 0) - (a.timestamp || a.updatedAt || 0));
          currentState.quizBankCache = quizzes;
          currentState.quizBankLoadedAt = Date.now();
          currentState.quizBankLoadDiag.loaded = quizzes.length;
          currentState.quizBankLoadDiag.skipped = skipped;

          if (manager.totalCount) manager.totalCount.innerText = String(quizzes.length);
          if (skipped.length) console.warn('[quiz] skipped malformed or non-question docs', skipped);

          if (!quizzes.length) {
            if (container) container.innerHTML = '<div style="text-align:center; color:#555;">題庫為空！</div>';
            try { quizApi.updateQuizFilterState(); } catch (err) { console.warn('[quiz] updateQuizFilterState failed on empty quiz bank', err); }
            quizApi.updateQuizSelectionSummary([]);
            return quizzes;
          }

          renderCachedQuizBank(quizzes);
          return quizzes;
        } catch (e) {
          currentState.quizBankLoadDiag.fetchError = e?.message || String(e);
          console.error(e);
          if (!cachedQuizzes.length) {
            currentState.quizBankCache = [];
            if (container) container.innerHTML = '<div style="text-align:center; color:var(--danger);">題庫載入失敗</div>';
            quizApi.updateQuizSelectionSummary([]);
          } else {
            currentState.quizBankLoadDiag.usedCache = true;
            if (container) {
              const banner = typeof document !== 'undefined' && typeof document.createElement === 'function' ? document.createElement('div') : null;
              if (banner) {
                banner.style.cssText = 'margin-bottom:8px; padding:8px 10px; border:1px dashed rgba(255,165,0,0.55); border-radius:8px; color:#ffcc80;';
                banner.innerText = `題庫遠端更新失敗，先顯示上次快取資料：${e?.message || e}`;
                if (!container.firstChild || !String(container.firstChild.textContent || '').includes('題庫遠端更新失敗')) container.prepend(banner);
              }
            }
          }
          UI.alert(`題庫載入失敗：${e.message || e}`, '題庫載入失敗');
          throw e;
        } finally {
          if (currentState.quizBankLoadPromise === loadPromise) currentState.quizBankLoadPromise = null;
          setQuizBusy('quizLoading', false);
        }
      })();
      currentState.quizBankLoadPromise = loadPromise;
      return await loadPromise;
    },

    async saveNewQuiz() {
      if (currentState.quizSaving) { UI.toast('題庫儲存中，請稍候'); return; }
      const formData = quizApi.readQuizFormData();
      if (!formData) return;
      const newQuiz = { ...formData, isActive: false, timestamp: Date.now() };
      try {
        setQuizBusy('quizSaving', true);
        await addDoc(collection(db, 'quiz_bank'), newQuiz);
        UI.toast('✅ 新增成功！');
        quizApi.resetQuizForm();
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('saveNewQuiz');
      } catch (e) {
        console.error(e);
        UI.alert(`新增失敗：${e.message || e}`, '題庫新增失敗');
      } finally {
        setQuizBusy('quizSaving', false);
      }
    },

    async saveEditedQuiz() {
      if (currentState.quizSaving) { UI.toast('題庫儲存中，請稍候'); return; }
      const editId = document.getElementById('qmEditId')?.value;
      if (!editId) return UI.toast('找不到要修改的題目');
      const formData = quizApi.readQuizFormData();
      if (!formData) return;
      try {
        setQuizBusy('quizSaving', true);
        const oldSnap = await getDoc(doc(db, 'quiz_bank', editId));
        const oldData = oldSnap.exists() ? oldSnap.data() : {};
        await updateDoc(doc(db, 'quiz_bank', editId), { ...formData, isActive: oldData.isActive === true, timestamp: oldData.timestamp || Date.now(), updatedAt: Date.now() });
        UI.toast('✏️ 題目已更新');
        quizApi.resetQuizForm();
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('saveEditedQuiz');
      } catch (e) {
        console.error(e);
        UI.alert(`修改失敗：${e.message || e}`, '題庫修改失敗');
      } finally {
        setQuizBusy('quizSaving', false);
      }
    },

    async deleteQuiz(id) {
      if (currentState.quizDeleting) { UI.toast('刪除進行中，請稍候'); return; }
      const isConfirmed = await UI.confirm(`確定要永久刪除這筆資料嗎？\n(此操作無法復原)`, '刪除確認');
      if (!isConfirmed) return;
      try {
        setQuizBusy('quizDeleting', true);
        await deleteDoc(doc(db, 'quiz_bank', id));
        UI.toast('🗑️ 已刪除');
        quizApi.resetQuizForm();
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('deleteQuiz');
      } catch (e) {
        console.error(e);
        UI.alert(`刪除失敗：${e.message || e}`, '題庫刪除失敗');
      } finally {
        setQuizBusy('quizDeleting', false);
      }
    },

    async toggleQuizActive(id, currentStatus) {
      if (currentState.quizToggling) { UI.toast('狀態切換中，請稍候'); return; }
      try {
        setQuizBusy('quizToggling', true);
        await updateDoc(doc(db, 'quiz_bank', id), { isActive: !currentStatus, updatedAt: Date.now() });
        await quizApi.loadQuizBank({ forceRefresh: true });
        refreshQuizPoolSummary('toggleQuizActive');
      } catch (e) {
        console.error(e);
        UI.alert(`切換失敗：${e.message || e}`, '題庫切換失敗');
      } finally {
        setQuizBusy('quizToggling', false);
      }
    },


    normalizeQuizPoolAudienceKey(raw = '', fallback = 'default') {
      return normalizeQuizPoolAudienceKey(raw, fallback);
    },

    getQuizPoolAudienceKeyForStudent(studentLike = null) {
      return getQuizPoolAudienceKeyForStudent(studentLike);
    },

    parseQuizAnswerIndex(value) {
      return parseQuizAnswerIndexLocal(value);
    },

    buildQuizPoolQuestionSummary(raw = {}, id = '') {
      return buildQuizPoolQuestionSummary(raw, id);
    },

    isPlayableQuizPoolQuestion(question = {}) {
      return isPlayableQuizPoolQuestion(question);
    },

    normalizeQuizPoolSummaryRecord(raw = {}, docId = '') {
      return normalizeQuizPoolSummaryRecord(raw, docId);
    },

    getQuizPoolAudienceKeysForQuestion(question = {}) {
      return getQuizPoolAudienceKeysForQuestion(question);
    },

    buildQuizPoolAudiencePayloads(quizzes = [], options = {}) {
      const maxIds = Math.max(24, Math.min(240, Number(options.maxIds) || 180));
      const normalizedList = (Array.isArray(quizzes) ? quizzes : [])
        .map((quiz) => normalizeQuizPoolSummaryRecord(quiz, quiz?.id || quiz?.quizId || quiz?.questionId || ''))
        .filter(Boolean)
        .sort((a, b) => ((Number(b?.updatedAt) || Number(b?.timestamp) || 0) - (Number(a?.updatedAt) || Number(a?.timestamp) || 0)));

      const buckets = new Map();
      ['default', 'support', 'grade1', 'grade2', 'grade3', 'grade4', 'grade5', 'grade6'].forEach((key) => {
        buckets.set(key, { ids: [], sampleQuestions: [], updatedAt: 0 });
      });
      const ensureBucket = (key) => {
        if (!buckets.has(key)) buckets.set(key, { ids: [], sampleQuestions: [], updatedAt: 0 });
        return buckets.get(key);
      };

      normalizedList.forEach((quiz) => {
        getQuizPoolAudienceKeysForQuestion(quiz).forEach((audienceKey) => {
          const bucket = ensureBucket(audienceKey);
          if (bucket.ids.length < maxIds) bucket.ids.push(String(quiz.id));
          if (bucket.sampleQuestions.length < 12) {
            bucket.sampleQuestions.push({
              id: String(quiz.id),
              question: String(quiz.question || '').slice(0, 80),
              grade: String(quiz.grade || ''),
              unit: String(quiz.unit || ''),
              imageUrl: String(quiz.imageUrl || '')
            });
          }
          bucket.updatedAt = Math.max(bucket.updatedAt, Number(quiz.updatedAt || quiz.timestamp || 0));
        });
      });

      return Object.fromEntries([...buckets.entries()].map(([audienceKey, bucket]) => [audienceKey, {
        audienceKey,
        question_ids: [...new Set(bucket.ids)].slice(0, maxIds),
        question_count: bucket.ids.length,
        sample_questions: bucket.sampleQuestions,
        updated_at: bucket.updatedAt || Date.now(),
        source: String(options.source || 'quiz_pool_backfill')
      }]));
    },

    async loadQuizPoolAudienceDoc(audienceKey = 'default') {
      const key = normalizeQuizPoolAudienceKey(audienceKey || 'default');
      beginPerfSpan('quiz', 'load-summary-doc', { audienceKey: key });
      const snap = await getDoc(doc(db, QUIZ_POOL_COLLECTION, key));
      if (!snap.exists()) {
        mergeQuizPoolDiagnostics(key, {
          summaryExists: false,
          summaryQuestionCount: 0,
          summaryQuestionIdsCount: 0,
          summarySampleCount: 0,
          summaryUpdatedAt: 0,
          summarySource: 'missing'
        });
        appendQuizPoolDiagEvent(key, { stage: 'load-summary', status: 'missing' });
        endPerfSpan('quiz', 'load-summary-doc', { audienceKey: key, status: 'missing', questionIdsCount: 0 });
        return null;
      }
      const raw = snap.data() || {};
      const questionIds = Array.isArray(raw?.question_ids)
        ? raw.question_ids
        : (Array.isArray(raw?.questions) ? raw.questions.map((q) => q?.id) : []);
      const normalizedQuestionIds = [...new Set((Array.isArray(questionIds) ? questionIds : []).map((id) => String(id || '').trim()).filter(Boolean))];
      const payload = {
        audienceKey: key,
        questionIds: normalizedQuestionIds,
        questionCount: Number(raw?.question_count) || 0,
        sampleQuestions: Array.isArray(raw?.sample_questions) ? raw.sample_questions : [],
        updatedAt: Number(raw?.updated_at || raw?.updatedAt) || 0
      };
      mergeQuizPoolDiagnostics(key, {
        summaryExists: true,
        summaryQuestionCount: payload.questionCount,
        summaryQuestionIdsCount: payload.questionIds.length,
        summarySampleCount: payload.sampleQuestions.length,
        summaryUpdatedAt: payload.updatedAt,
        summarySource: 'quiz_pool_public'
      });
      appendQuizPoolDiagEvent(key, {
        stage: 'load-summary',
        status: 'ok',
        questionCount: payload.questionCount,
        questionIdsCount: payload.questionIds.length,
        sampleCount: payload.sampleQuestions.length
      });
      console.log('[quiz-pool][summary]', key, {
        questionCount: payload.questionCount,
        questionIdsCount: payload.questionIds.length,
        sampleCount: payload.sampleQuestions.length,
        updatedAt: payload.updatedAt
      });
      endPerfSpan('quiz', 'load-summary-doc', { audienceKey: key, status: 'ok', questionIdsCount: payload.questionIds.length, questionCount: payload.questionCount });
      return payload;
    },

    pickQuizPoolCandidateIds(questionIds = [], desiredCount = 18) {
      return shuffleCopy([...new Set((Array.isArray(questionIds) ? questionIds : []).map((id) => String(id || '').trim()).filter(Boolean))]).slice(0, Math.max(1, Number(desiredCount) || 18));
    },

    sampleQuizPoolQuestions(quizzes = [], desiredCount = 18) {
      return shuffleCopy(quizzes).slice(0, Math.max(1, Number(desiredCount) || 18));
    },

    async inspectQuizQuestionsByIds(ids = [], options = {}) {
      const uniqueIds = [...new Set((Array.isArray(ids) ? ids : []).map((id) => String(id || '').trim()).filter(Boolean))];
      const audienceKey = normalizeQuizPoolAudienceKey(options.audienceKey || 'default');
      beginPerfSpan('quiz', 'load-question-docs', { audienceKey, requestedCount: uniqueIds.length });
      if (!uniqueIds.length) {
        const emptyResult = {
          audienceKey,
          requestedIds: [],
          rows: [],
          missingIds: [],
          invalidIds: [],
          invalidReasonCounts: {},
          fetchFailures: [],
          inspectedAt: Date.now()
        };
        mergeQuizPoolDiagnostics(audienceKey, {
          requestedQuestionIdsCount: 0,
          requestedQuestionIdsPreview: [],
          resolvedQuestionCount: 0,
          resolvedQuestionIdsPreview: [],
          missingQuestionIds: [],
          invalidQuestionIds: [],
          invalidQuestionReasons: {},
          fetchFailureIds: []
        });
        appendQuizPoolDiagEvent(audienceKey, { stage: 'load-by-id', status: 'empty-request' });
        endPerfSpan('quiz', 'load-question-docs', { audienceKey, status: 'empty-request', requestedCount: 0, resolvedCount: 0 });
        return emptyResult;
      }
      const fetchFailures = [];
      const snapshots = await Promise.all(uniqueIds.map(async (id) => {
        try {
          return await getDoc(doc(db, 'quiz_bank', id));
        } catch (err) {
          fetchFailures.push({ id, message: err?.message || String(err || '') });
          console.warn('[quiz-pool] load question by id failed:', id, err?.message || err);
          return null;
        }
      }));
      const rows = [];
      const missingIds = [];
      const invalidIds = [];
      const invalidReasonCounts = {};
      snapshots.forEach((snap, idx) => {
        const requestedId = uniqueIds[idx];
        if (!snap?.exists?.()) {
          missingIds.push(requestedId);
          return;
        }
        const inspected = inspectQuizPoolQuestionRecord(snap.data() || {}, snap.id || requestedId);
        if (inspected.normalized) {
          rows.push(inspected.normalized);
          return;
        }
        invalidIds.push(requestedId);
        const reason = inspected.reason || 'invalid-question';
        invalidReasonCounts[reason] = Number(invalidReasonCounts[reason] || 0) + 1;
      });
      const result = {
        audienceKey,
        requestedIds: uniqueIds,
        rows,
        missingIds,
        invalidIds,
        invalidReasonCounts,
        fetchFailures,
        inspectedAt: Date.now()
      };
      mergeQuizPoolDiagnostics(audienceKey, {
        requestedQuestionIdsCount: uniqueIds.length,
        requestedQuestionIdsPreview: uniqueIds.slice(0, 12),
        resolvedQuestionCount: rows.length,
        resolvedQuestionIdsPreview: rows.slice(0, 12).map((row) => String(row?.id || '')).filter(Boolean),
        missingQuestionIds: missingIds.slice(0, 20),
        invalidQuestionIds: invalidIds.slice(0, 20),
        invalidQuestionReasons: invalidReasonCounts,
        fetchFailureIds: fetchFailures.slice(0, 20),
        fetchFailureCount: fetchFailures.length
      });
      appendQuizPoolDiagEvent(audienceKey, {
        stage: 'load-by-id',
        status: 'ok',
        requestedCount: uniqueIds.length,
        resolvedCount: rows.length,
        missingCount: missingIds.length,
        invalidCount: invalidIds.length,
        fetchFailureCount: fetchFailures.length
      });
      console.log('[quiz-pool][ids]', audienceKey, {
        requestedCount: uniqueIds.length,
        resolvedCount: rows.length,
        missingCount: missingIds.length,
        invalidCount: invalidIds.length,
        fetchFailureCount: fetchFailures.length,
        invalidReasonCounts
      });
      endPerfSpan('quiz', 'load-question-docs', { audienceKey, status: 'ok', requestedCount: uniqueIds.length, resolvedCount: rows.length, missingCount: missingIds.length, invalidCount: invalidIds.length, fetchFailureCount: fetchFailures.length });
      return result;
    },

    async loadQuizQuestionsByIds(ids = [], options = {}) {
      const inspected = await quizApi.inspectQuizQuestionsByIds(ids, options);
      markPerfPoint('quiz', 'resolved-question-rows', {
        audienceKey: normalizeQuizPoolAudienceKey(options.audienceKey || 'default'),
        requestedCount: Array.isArray(ids) ? ids.length : 0,
        resolvedCount: Array.isArray(inspected?.rows) ? inspected.rows.length : 0
      });
      return Array.isArray(inspected?.rows) ? inspected.rows : [];
    },

    async auditQuizPoolSummaryHealth(options = {}) {
      if (!canUseAdminQuizFallback()) {
        const report = {
          ok: false,
          ranAt: Date.now(),
          audienceKey: String(options?.audienceKey || '*'),
          error: 'admin-required'
        };
        currentState.quizPoolHealthAudit = report;
        console.warn('[quiz-pool][health] admin runtime required');
        return report;
      }

      const requestedAudience = String(options?.audienceKey || '').trim();
      let audienceKeys = [];
      if (requestedAudience && requestedAudience !== '*' && !/^all$/i.test(requestedAudience)) {
        audienceKeys = [normalizeQuizPoolAudienceKey(requestedAudience, requestedAudience)];
      } else {
        try {
          const snapshot = await getDocs(collection(db, QUIZ_POOL_COLLECTION));
          snapshot.forEach((docSnap) => {
            const key = normalizeQuizPoolAudienceKey(docSnap.id || 'default', docSnap.id || 'default');
            if (key) audienceKeys.push(key);
          });
        } catch (err) {
          console.warn('[quiz-pool][health] list summary docs failed:', err?.message || err);
        }
        audienceKeys = [...new Set(['default', 'support', ...audienceKeys])];
      }

      const audiences = [];
      for (const audienceKey of audienceKeys) {
        const key = normalizeQuizPoolAudienceKey(audienceKey || 'default', audienceKey || 'default');
        const summaryDoc = await quizApi.loadQuizPoolAudienceDoc(key);
        const sampleQuestionIds = Array.isArray(summaryDoc?.sampleQuestions)
          ? [...new Set(summaryDoc.sampleQuestions.map((entry) => String(entry?.id || entry?.docId || entry?.question_id || '').trim()).filter(Boolean))]
          : [];
        if (!summaryDoc) {
          const missingReport = {
            audienceKey: key,
            status: 'missing-summary',
            summaryExists: false,
            summaryQuestionCount: 0,
            summaryQuestionIdsCount: 0,
            playableQuestionCount: 0,
            missingIdsCount: 0,
            invalidIdsCount: 0,
            fetchFailureCount: 0,
            healthScore: 0,
            issues: ['missing-summary'],
            checkedAt: Date.now()
          };
          audiences.push(missingReport);
          console.log('[quiz-pool][health]', key, missingReport);
          continue;
        }

        const inspected = await quizApi.inspectQuizQuestionsByIds(summaryDoc.questionIds || [], { audienceKey: key });
        const issues = [];
        if (Number(summaryDoc.questionCount || 0) !== Number((summaryDoc.questionIds || []).length || 0)) issues.push('summary-count-mismatch');
        if (inspected.fetchFailures.length) issues.push('fetch-failures');
        if (inspected.missingIds.length) issues.push('missing-question-docs');
        if (inspected.invalidIds.length) issues.push('invalid-question-docs');
        if ((summaryDoc.questionIds || []).length && !inspected.rows.length) issues.push('all-summary-ids-unusable');
        const sampleOutsideSummary = sampleQuestionIds.filter((id) => !(summaryDoc.questionIds || []).includes(id));
        if (sampleOutsideSummary.length) issues.push('sample-not-in-question-ids');
        const playableRatio = (summaryDoc.questionIds || []).length ? (inspected.rows.length / (summaryDoc.questionIds || []).length) : 0;
        const healthScore = Math.max(0, Math.round(playableRatio * 100) - (inspected.fetchFailures.length * 10) - (inspected.missingIds.length * 5) - (inspected.invalidIds.length * 3) - (sampleOutsideSummary.length * 2));
        const report = {
          audienceKey: key,
          status: issues.length ? 'issues-found' : 'healthy',
          summaryExists: true,
          summaryQuestionCount: Number(summaryDoc.questionCount || 0),
          summaryQuestionIdsCount: Number((summaryDoc.questionIds || []).length || 0),
          sampleQuestionCount: Number((summaryDoc.sampleQuestions || []).length || 0),
          sampleQuestionIdsCount: sampleQuestionIds.length,
          playableQuestionCount: inspected.rows.length,
          playableQuestionIdsPreview: inspected.rows.slice(0, 12).map((row) => String(row?.id || '')).filter(Boolean),
          missingIdsCount: inspected.missingIds.length,
          missingIdsPreview: inspected.missingIds.slice(0, 20),
          invalidIdsCount: inspected.invalidIds.length,
          invalidIdsPreview: inspected.invalidIds.slice(0, 20),
          invalidReasonCounts: inspected.invalidReasonCounts,
          fetchFailureCount: inspected.fetchFailures.length,
          fetchFailurePreview: inspected.fetchFailures.slice(0, 12),
          sampleOutsideSummaryCount: sampleOutsideSummary.length,
          sampleOutsideSummaryPreview: sampleOutsideSummary.slice(0, 12),
          playableRatio,
          healthScore,
          issues,
          checkedAt: Date.now(),
          summaryUpdatedAt: Number(summaryDoc.updatedAt || 0)
        };
        audiences.push(report);
        console.log('[quiz-pool][health]', key, report);
      }

      const aggregate = {
        ok: true,
        ranAt: Date.now(),
        audienceKey: requestedAudience || '*',
        lastAudienceKey: audiences[audiences.length - 1]?.audienceKey || normalizeQuizPoolAudienceKey(requestedAudience || 'default'),
        totalAudiences: audiences.length,
        healthyAudiences: audiences.filter((entry) => entry?.status === 'healthy').length,
        unhealthyAudiences: audiences.filter((entry) => entry?.status !== 'healthy').length,
        audiences,
        issueCounts: audiences.reduce((acc, entry) => {
          (Array.isArray(entry?.issues) ? entry.issues : []).forEach((issue) => {
            acc[issue] = Number(acc[issue] || 0) + 1;
          });
          return acc;
        }, {})
      };
      currentState.quizPoolHealthAudit = aggregate;
      console.log('[quiz-pool][health-summary]', aggregate);
      return aggregate;
    },

    async backfillQuizPoolSummaryEntries(quizzes = [], options = {}) {
      if (!canUseClientSummaryBackfill()) { guardLog('quiz-summary-backfill', 'blocked by emergency flag', { count: Array.isArray(quizzes) ? quizzes.length : 0 }); return 0; }
      const payloads = quizApi.buildQuizPoolAudiencePayloads(quizzes, options);
      const audienceKeys = Object.keys(payloads);
      if (!audienceKeys.length) return 0;
      const batch = writeBatch(db);
      audienceKeys.forEach((audienceKey) => {
        batch.set(doc(db, QUIZ_POOL_COLLECTION, audienceKey), payloads[audienceKey], { merge: true });
      });
      await batch.commit();
      return audienceKeys.length;
    },

    syncQuizPoolSummaryFromQuizBank(options = {}) {
      if (!canUseClientSummaryBackfill()) { guardLog('quiz-summary-sync', 'blocked by emergency flag'); return Promise.resolve(0); }
      if (currentState.quizPoolSummarySyncPromise && !options.force) return currentState.quizPoolSummarySyncPromise;
      let runnerPromise = null;
      runnerPromise = (async () => {
        try {
          let snapshot = null;
          let usedFullScan = false;
          try {
            snapshot = await getDocs(query(collection(db, 'quiz_bank'), where('isActive', '==', true), limit(240)));
          } catch (queryErr) {
            console.warn('[quiz-pool] active summary query failed, fallback to full scan:', queryErr?.message || queryErr);
            snapshot = await getDocs(collection(db, 'quiz_bank'));
            usedFullScan = true;
          }
          const quizzes = [];
          snapshot.forEach((docSnap) => {
            if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
            const normalized = normalizeQuizPoolSummaryRecord(docSnap.data() || {}, docSnap.id);
            if (normalized) quizzes.push(normalized);
          });
          if (!usedFullScan && quizzes.length < 12) {
            const fullSnapshot = await getDocs(collection(db, 'quiz_bank'));
            quizzes.length = 0;
            fullSnapshot.forEach((docSnap) => {
              if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
              const normalized = normalizeQuizPoolSummaryRecord(docSnap.data() || {}, docSnap.id);
              if (normalized) quizzes.push(normalized);
            });
          }
          const touched = await quizApi.backfillQuizPoolSummaryEntries(quizzes, { source: String(options.source || 'syncQuizPoolSummaryFromQuizBank') });
          currentState.quizPoolSummarySyncedAt = Date.now();
          currentState.quizPoolSummaryLastError = '';
          return { touched, count: quizzes.length };
        } catch (err) {
          currentState.quizPoolSummaryLastError = err?.message || String(err || '未知錯誤');
          throw err;
        } finally {
          if (currentState.quizPoolSummarySyncPromise === runnerPromise) currentState.quizPoolSummarySyncPromise = null;
        }
      })();
      currentState.quizPoolSummarySyncPromise = runnerPromise;
      return runnerPromise.catch((err) => {
        console.warn('[quiz-pool] summary sync failed:', err?.message || err);
        return { touched: 0, count: 0 };
      });
    },

    scheduleQuizPoolSummaryRefresh(reason = 'manual') {
      if (!canUseClientSummaryBackfill()) { guardLog('quiz-summary-refresh', 'blocked by emergency flag', { reason }); return; }
      try {
        if (currentState.quizPoolSummaryRefreshTimer) window.clearTimeout(currentState.quizPoolSummaryRefreshTimer);
      } catch (_) {}
      currentState.quizPoolSummaryRefreshTimer = window.setTimeout(() => {
        try {
          if (typeof scheduleBackgroundTask === 'function') {
            scheduleBackgroundTask(`quiz-pool-summary:${reason}`, () => quizApi.syncQuizPoolSummaryFromQuizBank({ source: reason }));
          } else {
            void quizApi.syncQuizPoolSummaryFromQuizBank({ source: reason });
          }
        } catch (_) {}
      }, 240);
    },

    async warmStudentQuizPool(options = {}) {
      const force = !!options.force;
      const maxAgeMs = Math.max(15000, Number(options.maxAgeMs) || 180000);
      const desiredCount = Math.max(10, Math.min(24, Number(options.desiredCount) || 18));
      const audienceKey = normalizeQuizPoolAudienceKey(options.audienceKey || getQuizPoolAudienceKeyForStudent(options.studentData || currentState.studentData));
      const now = Date.now();
      const cacheMap = currentState.studentQuizPoolCacheByAudience || (currentState.studentQuizPoolCacheByAudience = {});
      const loadedAtMap = currentState.studentQuizPoolLoadedAtByAudience || (currentState.studentQuizPoolLoadedAtByAudience = {});
      const promiseMap = currentState.studentQuizPoolPromiseByAudience || (currentState.studentQuizPoolPromiseByAudience = {});

      mergeQuizPoolDiagnostics(audienceKey, {
        audienceKey,
        desiredCount,
        force,
        lastStartAt: now,
        usedCachedPool: false,
        usedAdminFallback: false,
        summaryError: '',
        finalQuizCount: 0,
        finalSource: 'starting'
      });
      beginPerfSpan('quiz', 'warm-student-quiz-pool', { audienceKey, desiredCount, force, maxAgeMs });
      appendQuizPoolDiagEvent(audienceKey, { stage: 'warm-start', desiredCount, force });

      if (!force && Array.isArray(cacheMap[audienceKey]) && cacheMap[audienceKey].length && (now - (loadedAtMap[audienceKey] || 0)) < maxAgeMs) {
        currentState.studentQuizPoolCache = cacheMap[audienceKey];
        currentState.studentQuizPoolLoadedAt = loadedAtMap[audienceKey] || Date.now();
        mergeQuizPoolDiagnostics(audienceKey, {
          usedCachedPool: true,
          cacheHitCount: cacheMap[audienceKey].length,
          cacheLoadedAt: loadedAtMap[audienceKey] || 0,
          finalQuizCount: cacheMap[audienceKey].length,
          finalSource: 'cache'
        });
        appendQuizPoolDiagEvent(audienceKey, { stage: 'warm-return-cache', count: cacheMap[audienceKey].length });
        endPerfSpan('quiz', 'warm-student-quiz-pool', { audienceKey, status: 'cache-hit', finalCount: cacheMap[audienceKey].length });
        return cacheMap[audienceKey];
      }
      if (!force && promiseMap[audienceKey]) return promiseMap[audienceKey];

      let loadPromise;
      loadPromise = (async () => {
        try {
          let quizzes = [];
          let summaryErr = null;
          try {
            const summaryDoc = await quizApi.loadQuizPoolAudienceDoc(audienceKey);
            let questionIds = Array.isArray(summaryDoc?.questionIds) ? summaryDoc.questionIds.slice() : [];
            mergeQuizPoolDiagnostics(audienceKey, {
              initialSummaryQuestionIdsCount: questionIds.length,
              initialSummaryQuestionCount: Number(summaryDoc?.questionCount || 0)
            });
            if (questionIds.length < desiredCount && audienceKey !== 'default') {
              const defaultDoc = await quizApi.loadQuizPoolAudienceDoc('default');
              const defaultIds = Array.isArray(defaultDoc?.questionIds) ? defaultDoc.questionIds : [];
              questionIds = [...new Set([...questionIds, ...defaultIds])];
              mergeQuizPoolDiagnostics(audienceKey, {
                mergedDefaultQuestionIdsCount: defaultIds.length,
                mergedQuestionIdsCount: questionIds.length
              });
              appendQuizPoolDiagEvent(audienceKey, {
                stage: 'merge-default-summary',
                defaultCount: defaultIds.length,
                mergedCount: questionIds.length
              });
            }
            if (questionIds.length) {
              const selectedIds = quizApi.pickQuizPoolCandidateIds(questionIds, desiredCount);
              mergeQuizPoolDiagnostics(audienceKey, {
                selectedQuestionIdsCount: selectedIds.length,
                selectedQuestionIdsPreview: selectedIds.slice(0, 12)
              });
              appendQuizPoolDiagEvent(audienceKey, {
                stage: 'select-question-ids',
                selectedCount: selectedIds.length,
                selectedIdsPreview: selectedIds.slice(0, 8)
              });
              quizzes = await quizApi.loadQuizQuestionsByIds(selectedIds, { audienceKey });
            } else {
              appendQuizPoolDiagEvent(audienceKey, { stage: 'select-question-ids', status: 'no-summary-ids' });
            }
          } catch (err) {
            summaryErr = err;
            mergeQuizPoolDiagnostics(audienceKey, {
              summaryError: err?.message || String(err || '未知錯誤')
            });
            appendQuizPoolDiagEvent(audienceKey, {
              stage: 'load-summary',
              status: 'error',
              message: err?.message || String(err || '未知錯誤')
            });
            console.warn('[warmStudentQuizPool] quiz_pool_public failed:', err?.message || err);
          }

          if ((!Array.isArray(quizzes) || quizzes.length < Math.min(8, desiredCount)) && canUseAdminQuizFallback()) {
            mergeQuizPoolDiagnostics(audienceKey, { usedAdminFallback: true });
            appendQuizPoolDiagEvent(audienceKey, { stage: 'admin-fallback-start' });
            let snapshot = null;
            let usedFullScan = false;
            try {
              snapshot = await getDocs(query(collection(db, 'quiz_bank'), where('isActive', '==', true), limit(240)));
            } catch (queryErr) {
              console.warn('[warmStudentQuizPool] active-query failed, fallback to full scan:', queryErr?.message || queryErr);
              snapshot = await getDocs(collection(db, 'quiz_bank'));
              usedFullScan = true;
            }
            const activeQuizzes = [];
            snapshot.forEach((docSnap) => {
              if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
              const normalized = normalizeQuizPoolSummaryRecord(docSnap.data() || {}, docSnap.id);
              if (normalized) activeQuizzes.push(normalized);
            });
            if (!usedFullScan && activeQuizzes.length < 12) {
              const fullSnapshot = await getDocs(collection(db, 'quiz_bank'));
              activeQuizzes.length = 0;
              fullSnapshot.forEach((docSnap) => {
                if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
                const normalized = normalizeQuizPoolSummaryRecord(docSnap.data() || {}, docSnap.id);
                if (normalized) activeQuizzes.push(normalized);
              });
            }

            const gradeInfo = typeof getStudentGradeInfo === 'function' ? getStudentGradeInfo(options.studentData || currentState.studentData || {}) : {};
            const exactAudience = activeQuizzes.filter((question) => {
              if (audienceKey === 'support') return quizMatchesStudentGrade(question, '學習扶助班', true);
              if (/^grade[1-6]$/.test(audienceKey)) return quizMatchesStudentGrade(question, audienceKey.replace('grade', ''), false);
              return true;
            });
            const fallbackAudience = activeQuizzes.filter((question) => !/學習扶助/.test(String(question.grade || question.class_name || question.gradeName || '').trim()));
            quizzes = quizApi.sampleQuizPoolQuestions(exactAudience.length ? exactAudience : (gradeInfo?.isSupportClass ? activeQuizzes : (fallbackAudience.length ? fallbackAudience : activeQuizzes)), desiredCount);
            mergeQuizPoolDiagnostics(audienceKey, {
              adminFallbackCount: activeQuizzes.length,
              adminFallbackUsedFullScan: usedFullScan
            });
            appendQuizPoolDiagEvent(audienceKey, {
              stage: 'admin-fallback-done',
              sourceCount: activeQuizzes.length,
              usedFullScan,
              finalCount: quizzes.length
            });
            try { quizApi.backfillQuizPoolSummaryEntries(activeQuizzes, { source: 'warmStudentQuizPool:fallback' }); } catch (_) {}
          }

          cacheMap[audienceKey] = quizzes;
          loadedAtMap[audienceKey] = Date.now();
          currentState.studentQuizPoolCache = quizzes;
          currentState.studentQuizPoolLoadedAt = loadedAtMap[audienceKey];
          currentState.studentQuizPoolLastError = summaryErr ? (summaryErr?.message || String(summaryErr)) : '';
          mergeQuizPoolDiagnostics(audienceKey, {
            finalQuizCount: Array.isArray(quizzes) ? quizzes.length : 0,
            finalQuizIdsPreview: (Array.isArray(quizzes) ? quizzes : []).slice(0, 12).map((quiz) => String(quiz?.id || '')).filter(Boolean),
            finalSource: canUseAdminQuizFallback() && (!Array.isArray(quizzes) || quizzes.length < Math.min(8, desiredCount)) ? 'admin-fallback' : 'summary-by-id',
            summaryError: summaryErr ? (summaryErr?.message || String(summaryErr)) : ''
          });
          appendQuizPoolDiagEvent(audienceKey, {
            stage: 'warm-finish',
            finalCount: Array.isArray(quizzes) ? quizzes.length : 0,
            finalSource: (!summaryErr ? 'summary-by-id' : (canUseAdminQuizFallback() ? 'admin-fallback' : 'summary-error'))
          });
          console.log('[quiz-pool][warm]', audienceKey, {
            desiredCount,
            finalCount: Array.isArray(quizzes) ? quizzes.length : 0,
            summaryError: summaryErr ? (summaryErr?.message || String(summaryErr)) : '',
            diagnostics: cloneQuizPoolDiagValue((currentState.quizPoolDiagnostics || {}).byAudience?.[audienceKey] || {})
          });
          endPerfSpan('quiz', 'warm-student-quiz-pool', { audienceKey, status: 'ok', finalCount: Array.isArray(quizzes) ? quizzes.length : 0, finalSource: (!summaryErr ? 'summary-by-id' : (canUseAdminQuizFallback() ? 'admin-fallback' : 'summary-error')) });
          return quizzes;
        } catch (err) {
          currentState.studentQuizPoolLastError = err?.message || String(err || '未知錯誤');
          mergeQuizPoolDiagnostics(audienceKey, {
            finalSource: 'error',
            finalError: err?.message || String(err || '未知錯誤')
          });
          appendQuizPoolDiagEvent(audienceKey, {
            stage: 'warm-error',
            message: err?.message || String(err || '未知錯誤')
          });
          endPerfSpan('quiz', 'warm-student-quiz-pool', { audienceKey, status: 'error', message: err?.message || String(err || '未知錯誤') });
          if (Array.isArray(cacheMap[audienceKey]) && cacheMap[audienceKey].length) {
            currentState.studentQuizPoolCache = cacheMap[audienceKey];
            currentState.studentQuizPoolLoadedAt = loadedAtMap[audienceKey] || Date.now();
            mergeQuizPoolDiagnostics(audienceKey, {
              usedCachedPool: true,
              cacheHitCount: cacheMap[audienceKey].length,
              finalQuizCount: cacheMap[audienceKey].length,
              finalSource: 'cache-after-error'
            });
            return cacheMap[audienceKey];
          }
          if (Array.isArray(currentState.studentQuizPoolCache) && currentState.studentQuizPoolCache.length) return currentState.studentQuizPoolCache;
          throw err;
        } finally {
          if (promiseMap[audienceKey] === loadPromise) promiseMap[audienceKey] = null;
          if (currentState.studentQuizPoolPromise === loadPromise) currentState.studentQuizPoolPromise = null;
        }
      })();
      promiseMap[audienceKey] = loadPromise;
      currentState.studentQuizPoolPromise = loadPromise;
      return loadPromise;
    },


    async loadBattleTowerConfigDoc(docId = BATTLE_TOWER_DOC_ID, options = {}) {
      const normalizedDocId = String(docId || BATTLE_TOWER_DOC_ID);
      const force = !!options.force;
      const maxAgeMs = Math.max(5000, Number(options.maxAgeMs) || 60000);
      const now = Date.now();
      if (!force && battleTowerConfigCache.docId === normalizedDocId && battleTowerConfigCache.data && (now - battleTowerConfigCache.loadedAt) < maxAgeMs) {
        return JSON.parse(JSON.stringify(battleTowerConfigCache.data));
      }
      if (!force && battleTowerConfigCache.docId === normalizedDocId && battleTowerConfigCache.promise) {
        return await battleTowerConfigCache.promise;
      }
      let loadPromise;
      loadPromise = (async () => {
        try {
          const snap = await getDoc(doc(db, 'quiz_bank', normalizedDocId));
          const payload = snap.exists() ? (snap.data() || {}) : null;
          battleTowerConfigCache.docId = normalizedDocId;
          battleTowerConfigCache.data = payload ? JSON.parse(JSON.stringify(payload)) : null;
          battleTowerConfigCache.loadedAt = Date.now();
          return payload ? JSON.parse(JSON.stringify(payload)) : null;
        } finally {
          if (battleTowerConfigCache.promise === loadPromise) battleTowerConfigCache.promise = null;
        }
      })();
      battleTowerConfigCache.docId = normalizedDocId;
      battleTowerConfigCache.promise = loadPromise;
      return await loadPromise;
    },

    async saveBattleTowerAudienceConfig(audiencePayload = {}, options = {}) {
      const audienceKey = String(options.audienceKey || audiencePayload?.audienceKey || 'default');
      const ref = doc(db, 'quiz_bank', BATTLE_TOWER_DOC_ID);
      const snap = await getDoc(ref);
      const normalized = normalizeBattleTowerDoc(snap.exists() ? (snap.data() || {}) : {});
      const payloadDoc = normalizeBattleTowerDoc({ audiences: { [audienceKey]: audiencePayload } });
      const normalizedAudience = payloadDoc?.audiences?.[audienceKey] || { ...audiencePayload, audienceKey };
      normalized.version = 'battle_tower_v2';
      normalized.audiences = normalized.audiences || {};
      normalized.audiences[audienceKey] = normalizedAudience;
      if (audienceKey === 'default') Object.assign(normalized, normalizedAudience);
      await setDoc(ref, normalized);
      battleTowerConfigCache.docId = BATTLE_TOWER_DOC_ID;
      battleTowerConfigCache.data = JSON.parse(JSON.stringify(normalized));
      battleTowerConfigCache.loadedAt = Date.now();
      battleTowerConfigCache.promise = null;
      return normalized;
    },

    async clearBattleTowerAudienceConfig(audienceKey = 'default') {
      const normalizedAudienceKey = String(audienceKey || 'default');
      const ref = doc(db, 'quiz_bank', BATTLE_TOWER_DOC_ID);
      const snap = await getDoc(ref);
      const normalized = normalizeBattleTowerDoc(snap.exists() ? (snap.data() || {}) : {});
      if (normalized.audiences && normalized.audiences[normalizedAudienceKey]) delete normalized.audiences[normalizedAudienceKey];
      if (normalizedAudienceKey === 'default') {
        delete normalized.id;
        delete normalized.bossId;
        delete normalized.name;
        delete normalized.img;
        delete normalized.typeKey;
        delete normalized.gatekeeperQuizId;
        delete normalized.bossDiceCount;
        delete normalized.timestamp;
        delete normalized.audienceKey;
        delete normalized.audienceLabel;
      }
      if (!Object.keys(normalized.audiences || {}).length) {
        await deleteDoc(ref);
        battleTowerConfigCache.docId = BATTLE_TOWER_DOC_ID;
        battleTowerConfigCache.data = null;
        battleTowerConfigCache.loadedAt = Date.now();
        battleTowerConfigCache.promise = null;
        return normalizeBattleTowerDoc({});
      }
      await setDoc(ref, normalized);
      battleTowerConfigCache.docId = BATTLE_TOWER_DOC_ID;
      battleTowerConfigCache.data = JSON.parse(JSON.stringify(normalized));
      battleTowerConfigCache.loadedAt = Date.now();
      battleTowerConfigCache.promise = null;
      return normalized;
    },

    async listBattleGatekeeperQuestions(audienceKey = 'default') {
      const quizzes = await listAllPlayableBattleGatekeeperQuestions();
      const audience = String(audienceKey || 'default');
      if (audience === 'default') return quizzes;
      const desiredGrade = audience.startsWith('grade') ? audience.replace('grade', '') : '';
      const isSupportClass = audience === 'support';
      const filtered = quizzes.filter((question) => {
        if (isSupportClass) return quizMatchesStudentGrade(question, '學習扶助班', true);
        return quizMatchesStudentGrade(question, desiredGrade, false) || !String(question.grade || question.class_name || question.gradeName || '').trim();
      });
      return filtered.length ? filtered : quizzes;
    },

    async pickBattleGatekeeperQuestion(options = {}) {
      const gradeInfo = options.gradeInfo || (typeof getStudentGradeInfo === 'function' ? getStudentGradeInfo(options.studentData || currentState.studentData || {}) : {});
      try {
        const audienceKey = String(options.audienceKey || gradeInfo?.audienceKey || 'default');
        const preloaded = await quizApi.warmStudentQuizPool({
          source: 'battleGatekeeper',
          audienceKey,
          desiredCount: Math.max(12, Number(options.desiredCount) || 12),
          maxAgeMs: Number(options.maxAgeMs) || 180000,
          force: !!options.force,
          studentData: options.studentData || currentState.studentData || {}
        });
        const pool = [];
        const fallback = [];
        (Array.isArray(preloaded) ? preloaded : []).forEach((rawQuestion) => {
          const normalized = normalizeQuizQuestionRecord(rawQuestion || {}, rawQuestion?.id || '');
          if (!isQuizEnabled(normalized) || !isPlayableQuizPoolQuestion(normalized)) return;
          if (matchesBattleAudienceQuestion(normalized, gradeInfo)) pool.push(normalized);
          else if (!/學習扶助/.test(String(normalized.grade || normalized.class_name || normalized.gradeName || '').trim())) fallback.push(normalized);
        });
        const cachedPool = pool.length ? pool : fallback;
        if (cachedPool.length) return cachedPool[Math.floor(Math.random() * cachedPool.length)] || null;
      } catch (err) {
        console.warn('[quiz] warmStudentQuizPool gatekeeper preload failed, fallback to direct scan:', err?.message || err);
      }

      if (!canUseAdminQuizFallback()) return null;

      const quizzes = await quizApi.listBattleGatekeeperQuestions(options.audienceKey || gradeInfo?.audienceKey || 'default');
      if (Array.isArray(quizzes) && quizzes.length) return quizzes[Math.floor(Math.random() * quizzes.length)] || null;

      const permissivePool = await quizApi.listBattleGatekeeperQuestions('default');
      return Array.isArray(permissivePool) && permissivePool.length ? permissivePool[Math.floor(Math.random() * permissivePool.length)] : null;
    },

    async loadBattleGatekeeperQuestion(gatekeeperQuizId = 'random', options = {}) {
      const normalizedId = String(gatekeeperQuizId || 'random').trim() || 'random';
      if (normalizedId === 'random') return quizApi.pickBattleGatekeeperQuestion(options);
      const snap = await getDoc(doc(db, 'quiz_bank', normalizedId));
      if (snap.exists()) {
        const normalized = normalizeQuizQuestionRecord(snap.data() || {}, snap.id || normalizedId);
        if (isQuizEnabled(normalized) && isPlayableQuizPoolQuestion(normalized)) return normalized;
      }
      console.warn('[quiz] configured gatekeeper quiz is missing or invalid, fallback to random', normalizedId);
      return quizApi.pickBattleGatekeeperQuestion(options);
    },

    async startDailyQuest() { return quizApi.startDailyQuestLegacy ? quizApi.startDailyQuestLegacy() : UI.toast('每日歷練流程仍保留於主系統'); },
    renderQuizQuestion() { return quizApi.renderQuizQuestionLegacy ? quizApi.renderQuizQuestionLegacy() : void 0; },
    async selectQuizOption(selectedIndex, isCorrect) { return quizApi.selectQuizOptionLegacy ? quizApi.selectQuizOptionLegacy(selectedIndex, isCorrect) : void 0; }
  };

  attachQuizPoolDiagnosticsGlobals();
  return quizApi;
}
