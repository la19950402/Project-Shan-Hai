import { UI } from "../core/ui.js?v=phase15phase95fix7legendarysplit";
import { currentState } from "../core/state.js?v=phase15phase95fix7legendarysplit";
import { db, collection, doc, getDoc, getDocs, addDoc, deleteDoc, updateDoc } from "../core/firebase.js?v=phase15phase95fix7legendarysplit";

export function createLegendaryModule({
  COLLECTION_NAME,
  STUDENT_PAGE_COLLECTION,
  CONSTANTS,
  getLegendaryAdminDom,
  getLegendaryStudentDom,
  getProfileLabels,
  getProfileAttributeInfo,
  isCatProfile,
  fillProfileTemplate,
  setTeacherAvatar,
  applyDataMigration,
  saveToDB
}) {
  const LEGENDARY_COLLECTION = 'legendary_bank';

  const cloneData = (value = {}) => JSON.parse(JSON.stringify(value || {}));
  const migrateStudentData = (data = {}) => typeof applyDataMigration === 'function'
    ? applyDataMigration(cloneData(data || {}))
    : cloneData(data || {});
  const saveStudentData = async (data) => {
    if (typeof saveToDB !== 'function') throw new Error('saveToDB helper unavailable');
    return await saveToDB(data);
  };
  const isHologram = (value) => value === true || value === 'true';
  const legendaryItemsCache = { items: null, loadedAt: 0, promise: null };

  async function fetchLegendaryItems(options = {}) {
    const force = !!options.force;
    const maxAgeMs = Math.max(15000, Number(options.maxAgeMs) || 180000);
    const now = Date.now();
    if (!force && Array.isArray(legendaryItemsCache.items) && (now - legendaryItemsCache.loadedAt) < maxAgeMs) {
      return cloneData(legendaryItemsCache.items);
    }
    if (!force && legendaryItemsCache.promise) return await legendaryItemsCache.promise;

    let loadPromise;
    loadPromise = (async () => {
      try {
        const snap = await getDocs(collection(db, LEGENDARY_COLLECTION));
        const items = [];
        snap.forEach((entry) => items.push({ id: entry.id, ...(entry.data() || {}) }));
        legendaryItemsCache.items = items;
        legendaryItemsCache.loadedAt = Date.now();
        return cloneData(items);
      } finally {
        if (legendaryItemsCache.promise === loadPromise) legendaryItemsCache.promise = null;
      }
    })();
    legendaryItemsCache.promise = loadPromise;
    return await loadPromise;
  }

  const api = {
    async loadLegendaryAdmin() {
      const dom = typeof getLegendaryAdminDom === 'function' ? getLegendaryAdminDom() : {};
      if (!dom.adminModal || !dom.activeList) {
        UI.alert('異獸管理面板缺少必要欄位，請重新整理頁面後再試。', '系統異常');
        return;
      }
      UI.showModal('legendaryAdminModal');
      const listDiv = dom.activeList;
      listDiv.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入資料中...</div>';
      try {
        const items = await fetchLegendaryItems();
        if (items.length === 0) {
          listDiv.innerHTML = '<div style="color:#555; text-align:center;">目前無開放任何兌換。</div>';
          return;
        }
        listDiv.innerHTML = items.map((item) => {
          const legInfo = CONSTANTS.LEGENDARIES.find((legend) => legend.id === item.legendaryId) || {};
          const attrInfo = (typeof getProfileAttributeInfo === 'function' ? getProfileAttributeInfo(item.reqAttr, currentState.studentData) : null) || {};
          const reqLabel = (CONSTANTS.DRAGON_NAMES && CONSTANTS.DRAGON_NAMES[item.reqAttr]) ? CONSTANTS.DRAGON_NAMES[item.reqAttr] : `${attrInfo.name || item.reqAttr || '未知'}龍獸`;
          return `
            <div style="background:rgba(255,183,0,0.1); border:1px solid var(--legendary-gold); border-radius:6px; padding:10px; display:flex; align-items:center; gap:10px;">
              <img src="${legInfo.img || item.img || ''}" style="width:50px; height:50px; object-fit:contain; filter:drop-shadow(0 0 5px var(--legendary-gold));">
              <div style="flex:1;">
                <div style="color:var(--legendary-gold); font-weight:bold; font-family:Noto Sans TC, sans-serif; font-size:1.1em;">${item.name} <span class="tech-font" style="font-size:0.7em;">(★ ${item.points})</span></div>
                <div style="color:#ccc; font-size:0.8em; font-family:Noto Sans TC, sans-serif; margin-top:4px;">需求: ${item.reqCount} 隻 ${attrInfo.icon || ''}${reqLabel}</div>
              </div>
              <button onclick="App.deleteLegendary('${item.id}')" style="background:none; border:1px solid var(--danger); color:var(--danger); padding:4px 8px; border-radius:4px; cursor:pointer;">移除</button>
            </div>`;
        }).join('');
      } catch (error) {
        console.error(error);
        listDiv.innerHTML = '<div style="color:red; text-align:center;">讀取失敗</div>';
      }
    },

    async publishLegendary() {
      const { selectId: legIdEl, pointsInput: pointsEl, reqAttrSelect: reqAttrEl, reqCountInput: reqCountEl, addModal } = typeof getLegendaryAdminDom === 'function' ? getLegendaryAdminDom() : {};
      if (!legIdEl || !pointsEl || !reqAttrEl || !reqCountEl || !addModal) {
        UI.alert('異獸發布表單缺少必要欄位，請重新整理頁面後再試。', '系統異常');
        return;
      }
      const legId = legIdEl.value;
      const points = parseInt(pointsEl.value, 10) || 0;
      const reqAttr = reqAttrEl.value;
      const reqCount = parseInt(reqCountEl.value, 10) || 1;
      const legInfo = CONSTANTS.LEGENDARIES.find((legend) => legend.id === legId);
      if (!legInfo) return;
      const payload = { legendaryId: legId, name: legInfo.name, img: legInfo.img, points, reqAttr, reqCount, timestamp: Date.now() };
      try {
        await addDoc(collection(db, LEGENDARY_COLLECTION), payload);
        UI.toast('✅ 發布成功！');
        UI.hideModal('legendaryAddModal');
        legendaryItemsCache.items = null;
        legendaryItemsCache.loadedAt = 0;
        await api.loadLegendaryAdmin();
      } catch (error) {
        console.error(error);
        UI.alert('發布失敗', '資料庫錯誤');
      }
    },

    async deleteLegendary(docId) {
      const isConfirmed = await UI.confirm('確定要將此異獸從兌換列表移除嗎？\n(已兌換的學生不會受影響)', '移除確認');
      if (!isConfirmed) return;
      try {
        await deleteDoc(doc(db, LEGENDARY_COLLECTION, docId));
        UI.toast('已移除');
        legendaryItemsCache.items = null;
        legendaryItemsCache.loadedAt = 0;
        await api.loadLegendaryAdmin();
      } catch (error) {
        console.error(error);
        UI.alert('移除失敗', '資料庫錯誤');
      }
    },

    async loadActiveLegendariesForStudent() {
      const { list: listDiv, speechText: speechDiv, teacherAvatar } = typeof getLegendaryStudentDom === 'function' ? getLegendaryStudentDom() : {};
      if (!listDiv || !speechDiv || !teacherAvatar) {
        console.warn('[legendary] missing student legendary DOM');
        return;
      }
      if (typeof setTeacherAvatar === 'function') setTeacherAvatar(teacherAvatar);
      try {
        const items = await fetchLegendaryItems();
        const labels = typeof getProfileLabels === 'function' ? getProfileLabels(currentState.studentData) : {};
        if (items.length === 0) {
          speechDiv.innerHTML = `<span style="color:#ccc;">${labels.legendaryEmptySpeech || '研究站仍在整理線索，這週暫時沒有發現新的稀有異獸。請繼續培育你的龍獸，等待下一次探索成果吧！'}</span>`;
          listDiv.innerHTML = '';
          return;
        }

        const legNames = items.map((item) => `<span style="color:var(--legendary-gold); font-weight:bold;">${typeof isCatProfile === 'function' && isCatProfile(currentState.studentData) ? '特殊品種夥伴' : item.name}</span>`).join('、');
        speechDiv.innerHTML = typeof fillProfileTemplate === 'function'
          ? fillProfileTemplate(labels.legendarySpeechPrefix, { names: legNames })
          : legNames;

        const stuCol = Array.isArray(currentState.studentData?.collection) ? currentState.studentData.collection : [];
        listDiv.innerHTML = items.map((item) => {
          const currentCount = stuCol.filter((entry) => entry?.type === `${item.reqAttr}_legacy` && !isHologram(entry?.isHologram)).length;
          const isReady = currentCount >= item.reqCount;
          const attrInfo = CONSTANTS.ATTRIBUTES[item.reqAttr] || {};
          const btnHtml = isReady
            ? `<button class="btn btn-solid" style="background:var(--legendary-gold); padding:5px; font-size:0.8em; color:#000;" onclick="App.exchangeLegendary('${item.id}', '${item.reqAttr}', ${item.reqCount})">${labels.legendaryExchange || '進行交換'}</button>`
            : `<button class="btn" disabled style="padding:5px; font-size:0.8em;">${labels.legendaryInsufficient || '條件不足'}</button>`;
          return `
            <div style="background:rgba(0,0,0,0.6); border:1px solid ${isReady ? 'var(--legendary-gold)' : '#333'}; border-radius:6px; padding:10px; display:flex; align-items:center; gap:10px; opacity:${isReady ? 1 : 0.6}; transition:0.3s;">
              <img src="${item.img || ''}" style="width:40px; height:40px; object-fit:contain; filter:drop-shadow(0 0 5px ${isReady ? 'var(--legendary-gold)' : '#555'});">
              <div style="flex:1;">
                <div style="color:${isReady ? 'var(--legendary-gold)' : '#aaa'}; font-weight:bold; font-family:Noto Sans TC, sans-serif; font-size:0.95em;">${typeof isCatProfile === 'function' && isCatProfile(currentState.studentData) ? '特殊品種夥伴' : item.name}</div>
                <div style="color:var(--text-muted); font-size:0.7em; font-family:Noto Sans TC, sans-serif; margin-top:2px;">${typeof fillProfileTemplate === 'function' ? fillProfileTemplate(labels.legendaryRequirement, { current: currentCount, need: item.reqCount, attrName: attrInfo.name }) : `${currentCount} / ${item.reqCount}`}</div>
              </div>
              ${btnHtml}
            </div>`;
        }).join('');
      } catch (error) {
        console.error(error);
        listDiv.innerHTML = '<div style="color:red; text-align:center;">讀取失敗</div>';
      }
    },

    async exchangeLegendary(docId, reqAttrFromUI, reqCountFromUI) {
      try {
        const legRef = doc(db, LEGENDARY_COLLECTION, docId);
        const legSnap = await getDoc(legRef);
        if (!legSnap.exists()) {
          UI.alert('兌換失敗：異獸不存在或已被移除', '兌換失敗');
          return;
        }
        const legData = legSnap.data() || {};
        const reqAttr = legData.reqAttr || reqAttrFromUI;
        const reqCount = Number(legData.reqCount ?? reqCountFromUI) || 0;
        const name = legData.name || '未知異獸';
        if (!reqAttr || reqCount <= 0) {
          UI.alert('兌換失敗：異獸需求資料異常', '系統錯誤');
          return;
        }

        const stuRef = (currentState.viewMode === 'student' && currentState.currentToken)
          ? doc(db, STUDENT_PAGE_COLLECTION, currentState.currentToken)
          : doc(db, COLLECTION_NAME, currentState.currentUid);
        const stuSnap = await getDoc(stuRef);
        if (!stuSnap.exists()) {
          UI.alert('兌換失敗：找不到學生資料', '資料遺失');
          return;
        }
        const data = migrateStudentData(stuSnap.data() || {});
        data.collection = Array.isArray(data.collection) ? data.collection : [];
        data.display_team = Array.isArray(data.display_team) ? data.display_team : [];
        data.logs = Array.isArray(data.logs) ? data.logs : [];

        const owned = data.collection.filter((item) => item && item.type === `${reqAttr}_legacy` && !isHologram(item.isHologram)).length;
        if (owned < reqCount) {
          UI.alert(`條件不足：你目前只有 ${owned} 隻 ${reqAttr} 龍獸，需求為 ${reqCount} 隻。`, '條件不符');
          return;
        }

        const isConfirmed = await UI.confirm(`確認要進行基因交換嗎？\n作為材料的 ${reqCount} 隻 ${reqAttr} 龍獸素材將化為全息投影（無法作為排行榜展示），並獲得異獸：${name}`, '基因交換確認');
        if (!isConfirmed) return;

        let foundCount = 0;
        for (let i = 0; i < data.collection.length && foundCount < reqCount; i += 1) {
          if (data.collection[i]?.type === `${reqAttr}_legacy` && !isHologram(data.collection[i]?.isHologram)) {
            data.collection[i].isHologram = true;
            foundCount += 1;
          }
        }
        if (foundCount < reqCount) {
          UI.alert('兌換失敗：材料在處理時不足（可能資料剛同步，請重試）', '系統錯誤');
          return;
        }

        data.collection.push({
          type: 'legendary',
          legendaryId: legData.legendaryId || legData.legendaryType || docId,
          name,
          img: legData.img || '',
          points: legData.points || 0,
          timestamp: Date.now()
        });
        data.display_team = data.display_team.filter((idx) => data.collection[idx] && !isHologram(data.collection[idx].isHologram));
        data.logs.push({ timestamp: Date.now(), action_type: 'exchange_legendary', detail: `兌換異獸：${name}` });

        await saveStudentData(data);

        try {
          const exchanged = Number(legData.exchangedCount || 0) || 0;
          await updateDoc(legRef, { exchangedCount: exchanged + 1 });
        } catch (error) {
          console.warn('[legendary_bank] exchangedCount update failed:', error);
        }

        UI.toast(`✅ 兌換成功：${name}`);
        await api.loadActiveLegendariesForStudent();
      } catch (error) {
        console.error(error);
        UI.alert(`兌換失敗：${error.message || error}`, '系統異常');
      }
    }
  };

  return api;
}
