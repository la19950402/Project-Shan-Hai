import { currentState, quizSession } from "../core/state.js?v=phase15phase96fix8quizsessionformal";
import { UI } from "../core/ui.js?v=phase15phase96fix8quizsessionformal";
import { buildElementContract } from "../core/dom-contract.js?v=phase15phase96fix8quizsessionformal";
import { beginBattleQuizSession } from "../core/quiz-session-utils.js?v=phase15phase96fix8quizsessionformal";

export function createBattleModule(deps = {}) {
  const BATTLE_TOWER_DOC_ID = '_BATTLE_TOWER_BOSS_';

  function normalizeQuizQuestionRecord(raw = {}, id = '') {
    const source = raw && typeof raw === 'object' ? raw : {};
    const normalized = { ...source, id: id || source.id || '' };
    normalized.question = String(source.question || source.questionText || source.q || source.title || source.prompt || source.stem || source.text || source.content || source.body || source.description || '').trim();

    const stripOptionPrefix = (value) => String(value ?? '').trim().replace(/^[A-Da-d1-4][\.|、:：\s\-_)）]*/, '').trim();
    const parseAnswerIndex = (value) => {
      if (typeof value === 'number' && Number.isFinite(value)) {
        return value >= 1 && value <= 4 ? value - 1 : value;
      }
      const str = String(value ?? '').trim();
      if (!str) return -1;
      if (/^[1-4]$/.test(str)) return Number(str) - 1;
      if (/^[A-Da-d]$/.test(str)) return str.toUpperCase().charCodeAt(0) - 65;
      if (/^option\s*[1-4]$/i.test(str)) return Number(str.replace(/\D+/g, '')) - 1;
      if (/^option\s*[A-D]$/i.test(str)) return str.toUpperCase().charCodeAt(str.length - 1) - 65;
      return -1;
    };

    let answerIndex = -1;
    const answerCandidates = [
      source.answer,
      source.correctAnswer,
      source.correct_option,
      source.correctOption,
      source.correctIndex,
      source.correctIdx,
      source.correct,
      source.correct_choice,
      source.correctChoice
    ];
    for (const candidate of answerCandidates) {
      answerIndex = parseAnswerIndex(candidate);
      if (answerIndex >= 0) break;
    }

    const objectOptions = source.options && !Array.isArray(source.options) && typeof source.options === 'object'
      ? [source.options.A, source.options.B, source.options.C, source.options.D, source.options.a, source.options.b, source.options.c, source.options.d]
      : [];
    const stringOptions = typeof source.options === 'string'
      ? String(source.options).split(/\r?\n|\|/).map((part) => part.trim()).filter(Boolean)
      : [];
    const optionCandidates = Array.isArray(source.options)
      ? source.options
      : Array.isArray(source.choices)
        ? source.choices
        : Array.isArray(source.selections)
          ? source.selections
          : objectOptions.filter((value) => value != null && String(value).trim())
            .concat(stringOptions)
            .concat([source.option1, source.option2, source.option3, source.option4, source.optionA, source.optionB, source.optionC, source.optionD, source.a, source.b, source.c, source.d]);

    normalized.options = optionCandidates
      .slice(0, 4)
      .map((opt, idx) => {
        if (typeof opt === 'string') return { text: stripOptionPrefix(opt), isCorrect: idx === answerIndex };
        return {
          text: stripOptionPrefix(opt?.text ?? opt?.label ?? opt?.content ?? opt?.value ?? opt ?? ''),
          isCorrect: !!opt?.isCorrect || idx === answerIndex
        };
      })
      .filter((opt) => !!opt.text);
    if (answerIndex < 0) {
      const answerTextCandidates = answerCandidates
        .map((candidate) => stripOptionPrefix(candidate))
        .filter(Boolean);
      if (answerTextCandidates.length) {
        const matchedIndex = normalized.options.findIndex((opt) => answerTextCandidates.includes(stripOptionPrefix(opt?.text || '')));
        if (matchedIndex >= 0) {
          normalized.options.forEach((opt, idx) => { opt.isCorrect = idx === matchedIndex; });
          answerIndex = matchedIndex;
        }
      }
    }

    const rawImage = String(source.imageUrl || source.image_url || source.questionImage || source.question_image || source.image || source.img || '').trim();
    const imageUrl = /^(https?:|data:image\/|blob:)/i.test(rawImage) ? rawImage : '';
    const imageAssetKey = String(source.imageAssetKey || source.image_asset_key || source.imageAsset || source.assetKey || source.img_file || (!imageUrl ? rawImage : '') || '').trim();
    normalized.imageUrl = imageUrl;
    normalized.image = imageUrl;
    normalized.imageAssetKey = imageAssetKey;
    normalized.imageAlt = String(source.imageAlt || source.image_alt || source.alt || normalized.question || '題目附圖').trim();
    if (!normalized.unit && source.category) normalized.unit = source.category;
    return normalized;
  }

  function isPlayableQuizQuestion(q = {}) {
    if (!String(q.question || '').trim()) return false;
    const options = Array.isArray(q.options) ? q.options : [];
    if (options.length < 2) return false;
    if (!options.every((opt) => String(opt?.text || '').trim())) return false;
    return options.some((opt) => !!opt?.isCorrect);
  }


  function matchesBattleAudienceQuestion(q, gradeInfo) {
    if (!q) return false;
    if (gradeInfo?.isSupportClass) {
      return quizMatchesStudentGrade(q, '學習扶助班', true);
    }
    return quizMatchesStudentGrade(q, gradeInfo?.gradeToken, false);
  }

  async function pickRandomGatekeeperQuestion(gradeInfo) {
    if (typeof pickBattleGatekeeperQuestionFromQuizApi === 'function') {
      return await pickBattleGatekeeperQuestionFromQuizApi({
        gradeInfo,
        audienceKey: String(gradeInfo?.audienceKey || 'default'),
        studentData: currentState.studentData || {},
        battleTowerDocId: BATTLE_TOWER_DOC_ID
      });
    }
    return null;
  }

  const {
    db,
    getDocs,
    collection,
    writeBatch,
    CONSTANTS,
    TYPE_INFO,
    COLLECTION_NAME,
    STUDENT_PAGE_COLLECTION,
    hasBattleAttemptRemaining,
    buildBattleTeamForStudent,
    getDragonVisual,
    splitBattleVisualRef,
    buildCollectionDisplayItem,
    getProfileAttributeInfo,
    getBattleMonDiceCount,
    getBattleStageLabel,
    getBattleMonStage,
    isDirectVisualSource,
    hydrateStorageImages,
    getStudentGradeInfo,
    isQuizEnabled,
    quizMatchesStudentGrade,
    isCatProfile,
    getProfileLabels,
    normalizeBossDiceCount,
    createBattleDiceFaces,
    applyProfileStaticTexts,
    fillProfileTemplate,
    getBattleResetAnchor,
    getDailyResetAnchor,
    formatCountdown,
    getNextNoonTimestamp,
    getBattleBossConfigForStudent,
    getBattleAudienceOptions,
    getBattleBossConfigForAudience,
    normalizeBattleTowerDoc,
    getCatBossVisualByType,
    __updateLegendarySelectPreview,
    normalizeSerial,
    applyDataMigration,
    saveToDB,
    settleRewardViaServer,
    buildBattleRewardEventId,
    resolveBattleRecordBase,
    buildBattleOutcomeRecord,
    getBattleRewardDisplay,
    refreshStudentRewardPanel,
    isCurrentUserAdmin,
    ensureStudentDataReady,
    warmStudentQuizPool,
    loadBattleTowerConfigDoc,
    listBattleGatekeeperQuestions,
    pickBattleGatekeeperQuestion: pickBattleGatekeeperQuestionFromQuizApi,
    loadBattleGatekeeperQuestion,
    saveBattleTowerAudienceConfig,
    clearBattleTowerAudienceConfig,
    renderQuizQuestion,
    beginQuizSession
  } = deps;


  const normalizeSerialSafe = (value = '') => {
    if (typeof normalizeSerial === 'function') return normalizeSerial(value);
    const digits = String(value || '').replace(/\D+/g, '');
    return digits ? digits.padStart(3, '0').slice(-3) : '';
  };
  const applyDataMigrationSafe = (data = {}) => (
    typeof applyDataMigration === 'function'
      ? applyDataMigration(data)
      : data
  );
  const saveStudentData = async (data, serial) => {
    if (typeof saveToDB !== 'function') throw new Error('saveToDB helper unavailable');
    return await saveToDB(data, serial);
  };
  const settleRewardViaServerSafe = async (...args) => {
    if (typeof settleRewardViaServer !== 'function') throw new Error('settleRewardViaServer helper unavailable');
    return await settleRewardViaServer(...args);
  };
  const buildBattleRewardEventIdSafe = (...args) => (
    typeof buildBattleRewardEventId === 'function' ? buildBattleRewardEventId(...args) : ''
  );
  const resolveBattleRecordBaseSafe = async (...args) => {
    if (typeof resolveBattleRecordBase !== 'function') return applyDataMigrationSafe(JSON.parse(JSON.stringify(currentState.studentData || {})));
    return await resolveBattleRecordBase(...args);
  };
  const buildBattleOutcomeRecordSafe = (...args) => {
    if (typeof buildBattleOutcomeRecord !== 'function') throw new Error('buildBattleOutcomeRecord helper unavailable');
    return buildBattleOutcomeRecord(...args);
  };
  const getBattleRewardDisplaySafe = (...args) => {
    if (typeof getBattleRewardDisplay !== 'function') {
      return { coins: 5, xp: 5, attrName: '主屬性', xpUnit: isCatProfile(currentState.studentData) ? '成長能量' : '進化能量' };
    }
    return getBattleRewardDisplay(...args);
  };
  const refreshStudentRewardPanelSafe = (...args) => {
    if (typeof refreshStudentRewardPanel === 'function') return refreshStudentRewardPanel(...args);
    return undefined;
  };
  const isCurrentUserAdminSafe = async (...args) => (
    typeof isCurrentUserAdmin === 'function' ? await isCurrentUserAdmin(...args) : false
  );
  const ensureStudentDataReadySafe = async (...args) => {
    if (typeof ensureStudentDataReady === 'function') return await ensureStudentDataReady(...args);
    return currentState.studentData || null;
  };

  const getBattleSelectionDom = () => {
    const contract = buildElementContract({
      modal: 'battleSelectionModal',
      grid: 'bsGrid'
    }, ['modal', 'grid']);
    return Object.freeze({
      ...contract,
      confirmBtn: contract.elements.modal?.querySelector?.('.btn-solid') || null
    });
  };

  const getBattleArenaDom = () => {
    const contract = buildElementContract({
      modal: 'battleArenaModal',
      playerImg: 'baPlayerImg',
      playerType: 'baPlayerType',
      playerLabel: 'baPlayerLabel',
      bossImg: 'baBossImg',
      bossType: 'baBossType',
      bossLabel: 'baBossLabel',
      rewardSummary: 'baRewardSummary',
      confirmBtn: 'baConfirmBtn',
      mainStage: 'baMainStage',
      settlementPanel: 'baSettlementPanel',
      settlementTitle: 'baSettlementTitle',
      settlementDesc: 'baSettlementDesc',
      settlementResult: 'baSettlementResult',
      settlementReward: 'baSettlementReward',
      settlementCoins: 'baSettlementCoins',
      settlementXP: 'baSettlementXP',
      settlementLog: 'baSettlementLog',
      settlementXpLabel: 'baSettlementXpLabel',
      actionBtn: 'baActionBtn',
      resultText: 'baResultText',
      playerMult: 'baPlayerMult',
      playerScore: 'baPlayerScore',
      bossMult: 'baBossMult',
      bossScore: 'baBossScore'
    }, ['modal', 'actionBtn', 'mainStage', 'settlementPanel']);
    return Object.freeze({
      ...contract,
      arenaDice: contract.elements.modal?.querySelectorAll?.('.dice') || [],
      playerDice: contract.elements.modal?.querySelectorAll?.('#baPlayerDice .dice') || [],
      bossDice: contract.elements.modal?.querySelectorAll?.('#baBossDice .dice') || []
    });
  };

  const getQuizPlayDom = () => {
    const contract = buildElementContract({
      modal: 'quizPlayModal',
      playArea: 'quizPlayArea',
      title: 'quizPlayTitle'
    }, ['modal', 'playArea']);
    return Object.freeze({
      ...contract,
      modalContent: contract.elements.modal?.querySelector?.('.modal-content') || null
    });
  };

  const getBattleTowerStudentDom = () => buildElementContract({
    area: 'stuBattleTowerArea',
    bossName: 'btBossName',
    bossImg: 'btBossImg',
    bossType: 'btBossType',
    challengeBtn: 'btChallengeBtn',
    statusText: 'btStatusText'
  }, ['area']);

  const getBattleTowerAdminDom = () => buildElementContract({
    modal: 'battleTowerAdminModal',
    setQuiz: 'btSetQuiz',
    audienceSelect: 'btAudienceSelect',
    audienceStatus: 'btAudienceStatus',
    setBoss: 'btSetBoss',
    setType: 'btSetType',
    setBossDiceCount: 'btSetBossDiceCount',
    bossPreviewImg: 'btBossPreviewImg',
    bossPreviewName: 'btBossPreviewName'
  }, ['modal']);

  const hasBattleSelectionDom = () => getBattleSelectionDom().ok;
  const hasBattleArenaDom = () => getBattleArenaDom().ok;
  const hasQuizPlayDom = () => getQuizPlayDom().ok;

  let battleApi = null;
  const callBattleMethod = (name, ...args) => (
    typeof battleApi?.[name] === 'function' ? battleApi[name](...args) : undefined
  );

  battleApi = {
    async startBattleChallenge() {
      let studentData = currentState.studentData;
      if (!studentData) {
        try {
          studentData = await ensureStudentDataReadySafe({ source: 'battle:start', timeoutMs: 7000 });
        } catch (err) {
          UI.alert('學生資料仍在同步中，請稍候 2～3 秒後再試。', '無法挑戰');
          return;
        }
      }
      if (!studentData) {
        UI.alert('尚未載入學生資料，請重新整理後再試。', '無法挑戰');
        return;
      }
      if (typeof buildBattleTeamForStudent !== 'function') {
        UI.alert('戰鬥模組初始化不完整，請重新整理頁面後再試。', '系統異常');
        return;
      }
      if (!hasBattleAttemptRemaining(studentData)) {
        UI.alert('今日 BOSS 挑戰次數已用完，將於中午 12:00 重置。若老師已手動重置，請重新整理後再試。', '今日挑戰已用完');
        callBattleMethod('updateBattleTowerStatus', studentData);
        return;
      }
      try {
        await callBattleMethod('updateBattleTowerStatus', studentData);
      } catch (e) {
        console.warn('[startBattleChallenge] refresh status failed:', e);
      }
      if (!currentState.currentBattleBoss) {
        UI.alert('目前沒有可挑戰的 Boss 設定。請先確認老師端已發布今日 Boss，或重新整理後再試。', '無法挑戰');
        return;
      }
      if (!hasBattleSelectionDom()) { UI.alert('找不到 Boss 選角面板，請重新整理頁面後再試。', '系統異常'); return; }
      const { elements: selectionEls } = getBattleSelectionDom();
      const g = selectionEls.grid;
      g.innerHTML = '';

      const builtTeam = buildBattleTeamForStudent(studentData);
      const team = Array.isArray(builtTeam) ? builtTeam : [];
      const selectableTeam = team.filter(i => i && !i.isHologram && i.type !== 'dead_dragon');
      if (!selectableTeam.length) {
        UI.alert('目前沒有可出戰的龍獸或夥伴，請先確認圖鑑中有可用成員。', '無法挑戰');
        return;
      }

      team.forEach((m) => {
        if (m && m.type === 'dragon' && !m.img_file) {
          try {
            const vis = getDragonVisual({
              dragon_path: m.path || m.dragon_path,
              dragon_stage: m.stage ?? m.dragon_stage,
              attributes: m.stats || m.attributes || {}
            });
            const visualRef = splitBattleVisualRef(vis?.file, vis?.img || m.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
            if (!m.img_file && visualRef.img_file) m.img_file = visualRef.img_file;
            if (!m.img && visualRef.img) m.img = visualRef.img;
          } catch (e) {}
        }
      });

      team.forEach((i, idx) => {
        if (!i || i.isHologram || i.type === 'dead_dragon') return;
        const tk = i.type === 'legendary' ? 'neutral' : (i.typeKey || i.element || i.path || 'neutral');
        let disp = buildCollectionDisplayItem(i, studentData);
        if (!disp && i.type === 'hidden_egg') {
          const hiddenMeta = CONSTANTS.HIDDEN_EGGS[String(i.hiddenEggId || '')] || studentData?.active_hidden_egg || {};
          const hiddenAttr = getProfileAttributeInfo(hiddenMeta.requiredAttr || tk, studentData);
          disp = { title: i.name || (hiddenMeta.beastName ? `${hiddenMeta.beastName}｜當前出戰` : (hiddenMeta.name || '特殊異獸蛋')), color: hiddenAttr.color, img: i.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG };
        }
        const src = (disp && disp.img) || i.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        const nm = (disp && disp.title) || i.name || '---';
        const cColor = TYPE_INFO[tk] ? TYPE_INFO[tk].color : '#ccc';
        const diceCount = getBattleMonDiceCount(i, studentData);
        const stageLabel = getBattleStageLabel(getBattleMonStage(i, studentData), studentData);
        const fileBase = i.img_file || '';
        const useAsset = fileBase && !isDirectVisualSource(fileBase);
        const imgSrc = useAsset ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (src || fileBase || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
        const dataAttr = useAsset ? ('data-asset="' + String(fileBase).replace(/"/g, '&quot;') + '"') : '';
        g.innerHTML += `<div class="team-item-btn" id="bsItem_${idx}" onclick="App.selectBattleMon(${idx})" style="border-color:${cColor};"><img src="${imgSrc}" ${dataAttr}><span style="font-size:0.7em; color:${cColor}; margin-top:5px; text-align:center;">${nm}<br><small style="opacity:0.8;">${stageLabel}｜${diceCount}骰</small></span></div>`;
      });

      currentState.currentBattleTeam = team;
      currentState.selectedBattleMonIndex = -1;
      try { hydrateStorageImages(g); } catch (e) { console.warn('[startBattleChallenge] hydrate images failed:', e); }
      UI.showModal('battleSelectionModal');
    },

    selectBattleMon(idx) {
      currentState.selectedBattleMonIndex = idx;
      currentState.selectedBattleMon = Array.isArray(currentState.currentBattleTeam) ? currentState.currentBattleTeam[idx] || null : null;
      const { elements: selectionEls } = getBattleSelectionDom();
      selectionEls.grid?.querySelectorAll?.('.team-item-btn').forEach(e => e.style.background = 'rgba(0,0,0,0.6)');
      const item = selectionEls.grid?.querySelector?.(`#bsItem_${idx}`);
      if (item) item.style.background = 'rgba(255,0,85,0.3)';
    },

    async confirmBattleSelection() {
      if (!hasBattleAttemptRemaining(currentState.studentData)) {
        UI.alert('今日 BOSS 挑戰次數已用完，請勿重複點擊。', '今日挑戰已用完');
        callBattleMethod('updateBattleTowerStatus');
        return;
      }
      if (currentState.selectedBattleMonIndex === -1) return UI.toast('請選擇出戰龍獸！');
      const { confirmBtn: btn } = getBattleSelectionDom();
      if (!btn) {
        UI.alert('找不到出戰確認按鈕，請重新整理頁面後再試。', '系統異常');
        return;
      }
      btn.disabled = true;
      btn.innerText = '讀取中...';

      try {
        let b = currentState.currentBattleBoss;
        if (!b) {
          try {
            await callBattleMethod('checkBattleTowerStatus', currentState.studentData);
            b = currentState.currentBattleBoss;
          } catch (e) {
            console.warn('[confirmBattleSelection] refresh boss failed:', e);
          }
        }
        if (!b) {
          UI.hideModal('battleSelectionModal');
          UI.alert('目前沒有可挑戰的 Boss，請稍後重新整理再試。', '無法挑戰');
          return;
        }
        const selectedMon = Array.isArray(currentState.currentBattleTeam) ? currentState.currentBattleTeam[currentState.selectedBattleMonIndex] : null;
        if (!selectedMon || selectedMon.isHologram || selectedMon.type === 'dead_dragon') {
          UI.toast('請先選擇有效的出戰成員！');
          return;
        }
        let qD = null;
        const gatekeeperQuizId = String(b.gatekeeperQuizId || b.quizId || b.quiz_id || b.questionId || 'random');
        const gradeInfo = getStudentGradeInfo(currentState.studentData || {});
        if (typeof loadBattleGatekeeperQuestion === 'function') {
          qD = await loadBattleGatekeeperQuestion(gatekeeperQuizId, {
            gradeInfo,
            audienceKey: gradeInfo?.audienceKey || 'default',
            studentData: currentState.studentData || {},
            battleTowerDocId: BATTLE_TOWER_DOC_ID
          });
        } else {
          qD = typeof pickBattleGatekeeperQuestionFromQuizApi === 'function'
            ? await pickBattleGatekeeperQuestionFromQuizApi({
                gradeInfo,
                audienceKey: gradeInfo?.audienceKey || 'default',
                studentData: currentState.studentData || {},
                battleTowerDocId: BATTLE_TOWER_DOC_ID,
                force: gatekeeperQuizId === 'random' || !gatekeeperQuizId ? false : true
              })
            : await pickRandomGatekeeperQuestion(gradeInfo);
        }


        UI.hideModal('battleSelectionModal');
        if (!qD) return UI.alert('題庫中沒有可用的 Boss 題目，或目前指定題目格式不相容。\n請老師先確認題庫題目與 Boss 指定設定。', '挑戰失敗');
        if (!hasQuizPlayDom()) { UI.alert('找不到戰鬥答題面板，請重新整理頁面後再試。', '系統異常'); return; }

        if (typeof beginQuizSession === 'function') {
          beginQuizSession('battle', { questions: [qD], currentIndex: 0, score: 0 });
        } else {
          beginBattleQuizSession(qD, 'battle');
        }

        const quizPlayDom = getQuizPlayDom();
        const titleEl = quizPlayDom.elements.title;
        if (titleEl) {
          titleEl.innerText = isCatProfile(currentState.studentData) ? '🐾 領域防衛問答' : '⚔️ 守門員挑戰 ⚔️';
          titleEl.style.color = 'var(--danger)';
        }
        const modalContent = quizPlayDom.modalContent;
        if (modalContent) modalContent.style.borderColor = 'var(--danger)';

        UI.hide('quizResultArea');
        UI.show('quizPlayArea');
        UI.showModal('quizPlayModal');
        if (typeof renderQuizQuestion === 'function') {
          renderQuizQuestion();
        } else {
          throw new Error('renderQuizQuestion helper unavailable');
        }
      } catch (e) {
        console.error(e);
        UI.alert('載入戰鬥發生錯誤：' + e.message, '系統異常');
      } finally {
        btn.disabled = false;
        btn.innerText = '確認出戰，前往答題';
      }
    },

    async handleBattleQuizAnswer(isCorrect) {
      if (quizSession.aborted) return;
      if (quizSession.answerPending) return;
      const expectedToken = quizSession.sessionToken;
      quizSession.answerPending = true;
      try {
        const { optionsArea } = getQuizPlayDom();
        const btns = Array.from(optionsArea?.querySelectorAll?.('button') || []);
        btns.forEach((btn) => { btn.disabled = true; });

        UI.hideModal('quizPlayModal');
        if (expectedToken && quizSession.sessionToken !== expectedToken) return;

        if (isCorrect) {
          UI.toast('✅ 答題正確！進入戰鬥！');
          callBattleMethod('prepareBattleArena');
        } else {
          UI.alert('答錯了！守門員將你擊退。\n（已消耗今日挑戰次數，請明日再來！）', '挑戰失敗');
          const data = JSON.parse(JSON.stringify(currentState.studentData || {}));
          data.last_battle_time = Date.now();
          try {
            const saved = await saveStudentData(data);
            refreshStudentRewardPanelSafe(saved || data, true);
          } catch (e) {
            console.error('[handleBattleQuizAnswer] save failed:', e);
            refreshStudentRewardPanelSafe(currentState.studentData || data, true);
            UI.toast('戰鬥結果保存失敗，請通知老師協助處理');
          }
        }
      } finally {
        quizSession.answerPending = false;
      }
    },

    prepareBattleArena() {
      if (!hasBattleArenaDom()) { UI.alert('找不到戰鬥結算面板，請重新整理頁面後再試。', '系統異常'); return; }
      const b = currentState.currentBattleBoss;
      if (!b) {
        UI.alert('目前找不到 Boss 設定，請重新整理後再試。', '無法開始戰鬥');
        return;
      }
      const pI = currentState.selectedBattleMonIndex;
      const team = Array.isArray(currentState.currentBattleTeam) && currentState.currentBattleTeam.length
        ? currentState.currentBattleTeam
        : buildBattleTeamForStudent(currentState.studentData);
      const fallbackTeam = typeof buildBattleTeamForStudent === 'function' ? (buildBattleTeamForStudent(currentState.studentData) || []) : [];
      const pM = (currentState.selectedBattleMon || team[pI] || team[0] || fallbackTeam[0]);
      if (!pM) {
        UI.alert('目前找不到可出戰的成員，請重新選擇後再試。', '無法開始戰鬥');
        return;
      }
      const labels = getProfileLabels(currentState.studentData);

      const pTk = (pM.type === 'legendary') ? 'neutral' : (pM.typeKey || pM.element || pM.path || 'neutral');
      const playerDiceCount = getBattleMonDiceCount(pM, currentState.studentData);
      const bossDiceCount = normalizeBossDiceCount(b?.bossDiceCount, 3);

      const battleArenaDom = getBattleArenaDom();
      const { elements: arenaEls, arenaDice, playerDice, bossDice } = battleArenaDom;
      const pImgEl = arenaEls.playerImg;
      if (pImgEl) {
        pImgEl.removeAttribute('data-asset');
        const disp = buildCollectionDisplayItem(pM, currentState.studentData);
        const fileBase = String(pM.img_file || '').trim();
        let pSrc = (disp && disp.img) || pM.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        if (fileBase && !isDirectVisualSource(fileBase)) {
          pSrc = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          pImgEl.setAttribute('data-asset', fileBase);
        } else if (fileBase && isDirectVisualSource(fileBase)) {
          pSrc = fileBase;
        }
        pImgEl.src = pSrc;
      }

      const pInfo = getProfileAttributeInfo(pTk, currentState.studentData);
      const pTypeEl = arenaEls.playerType;
      if (pTypeEl) {
        pTypeEl.innerText = pInfo?.name || '無';
        pTypeEl.style.color = pInfo?.color || '#fff';
      }
      const playerLabel = arenaEls.playerLabel;
      if (playerLabel) playerLabel.innerText = `${isCatProfile(currentState.studentData) ? '我的夥伴' : '我的龍獸'}（${playerDiceCount}骰）`;

      const bImgEl = arenaEls.bossImg;
      if (bImgEl) {
        bImgEl.removeAttribute('data-asset');
        const catBossVis = isCatProfile(currentState.studentData) ? getCatBossVisualByType(b?.typeKey || 'metal') : null;
        const fileBase = String(b?.img_file || '').trim();
        let bSrc = isCatProfile(currentState.studentData) ? (catBossVis?.file || catBossVis?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG) : (b?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
        if (fileBase && !isDirectVisualSource(fileBase) && !isCatProfile(currentState.studentData)) {
          bSrc = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          bImgEl.setAttribute('data-asset', fileBase);
        } else if (fileBase && isDirectVisualSource(fileBase)) {
          bSrc = fileBase;
        }
        bImgEl.src = bSrc;
      }

      const bInfo = getProfileAttributeInfo(b?.typeKey || 'neutral', currentState.studentData);
      const bTypeEl = arenaEls.bossType;
      if (bTypeEl) {
        bTypeEl.innerText = bInfo?.name || '無';
        bTypeEl.style.color = bInfo?.color || '#fff';
      }
      const bossLabel = arenaEls.bossLabel;
      if (bossLabel) bossLabel.innerText = `${labels.bossLabel || '塔中首領'}（${bossDiceCount}骰）`;

      createBattleDiceFaces('baPlayerDice', playerDiceCount);
      createBattleDiceFaces('baBossDice', bossDiceCount);
      Array.from(arenaDice || []).forEach(d => { d.innerText = '?'; d.classList.remove('rolling'); });
      const defaults = ['baPlayerMult', 'baPlayerScore', 'baBossMult', 'baBossScore', 'baResultText'];
      const values = { baPlayerMult: '1.0x', baPlayerScore: '0', baBossMult: '1.0x', baBossScore: '0', baResultText: '---' };
      defaults.forEach(id => {
        const keyMap = {
          baPlayerMult: 'playerMult',
          baPlayerScore: 'playerScore',
          baBossMult: 'bossMult',
          baBossScore: 'bossScore',
          baResultText: 'resultText'
        };
        const el = arenaEls[keyMap[id]];
        if (el) el.innerText = values[id];
      });
      const rewardSummaryEl = arenaEls.rewardSummary;
      if (rewardSummaryEl) { rewardSummaryEl.style.display = 'none'; rewardSummaryEl.innerHTML = ''; }
      const confirmBtn = arenaEls.confirmBtn;
      if (confirmBtn) { confirmBtn.style.display = 'none'; confirmBtn.disabled = false; }
      const mainStage = arenaEls.mainStage;
      if (mainStage) mainStage.style.display = 'block';
      const settlementPanel = arenaEls.settlementPanel;
      if (settlementPanel) settlementPanel.style.display = 'none';
      const settlementTitle = arenaEls.settlementTitle;
      if (settlementTitle) settlementTitle.innerText = isCatProfile(currentState.studentData) ? '🐾 防衛結果結算' : '🏆 討伐獎勵結算';
      const settlementDesc = arenaEls.settlementDesc;
      if (settlementDesc) settlementDesc.innerText = isCatProfile(currentState.studentData) ? '請確認本次領域防衛結果與獎勵，再退出返回學生面板。' : '請確認本次 Boss 討伐結果與獎勵，再退出返回學生面板。';
      ['settlementResult', 'settlementReward', 'settlementCoins', 'settlementXP', 'settlementLog'].forEach(key => {
        const el = arenaEls[key];
        if (el) el.innerText = key === 'settlementCoins' || key === 'settlementXP' ? '0' : '---';
      });
      const xpLabel = arenaEls.settlementXpLabel;
      if (xpLabel) xpLabel.innerText = `目前${getProfileLabels(currentState.studentData).xp || (isCatProfile(currentState.studentData) ? '成長能量' : '進化能量')}`;
      applyProfileStaticTexts(currentState.studentData, true);

      currentState.battleData = {
        playerRoll: 0,
        bossRoll: 0,
        pType: pTk,
        bType: b?.typeKey || 'neutral',
        playerDiceCount,
        bossDiceCount
      };

      const arenaElsReady = getBattleArenaDom().elements;
      const actionBtn = arenaElsReady.actionBtn;
      if (actionBtn) { actionBtn.style.display = 'block'; actionBtn.disabled = false; }
      const confirmBtn2 = arenaElsReady.confirmBtn;
      if (confirmBtn2) { confirmBtn2.style.display = 'none'; confirmBtn2.disabled = false; }

      UI.showModal('battleArenaModal');
      try { hydrateStorageImages(arenaElsReady.modal); } catch (_) {}
    },

    rollDice() {
      const labels = getProfileLabels(currentState.studentData);
      const battleArenaDom = getBattleArenaDom();
      const { elements: arenaEls, arenaDice, playerDice, bossDice } = battleArenaDom;
      const actionBtn = arenaEls.actionBtn;
      if (actionBtn) actionBtn.style.display = 'none';
      Array.from(arenaDice || []).forEach(d => d.classList.add('rolling'));
      const resultEl = arenaEls.resultText;
      if (resultEl) resultEl.innerText = labels.battleComputing || '靈力流動中...';

      setTimeout(async () => {
        Array.from(arenaDice || []).forEach(d => d.classList.remove('rolling'));

        let pR = 0;
        Array.from(playerDice || []).forEach(d => { const v = Math.floor(Math.random() * 6) + 1; d.innerText = v; pR += v; });
        let bR = 0;
        Array.from(bossDice || []).forEach(d => { const v = Math.floor(Math.random() * 6) + 1; d.innerText = v; bR += v; });

        const getE = () => 1.0;
        const pM = getE(currentState.battleData.pType, currentState.battleData.bType);
        const bM = getE(currentState.battleData.bType, currentState.battleData.pType);
        const pF = Math.floor(pR * pM);
        const bF = Math.floor(bR * bM);
        const gD = (m) => m === 2 ? '效果絕佳(x2)' : m === 0.5 ? '效果不好(x0.5)' : m === 0 ? '沒有效果(x0)' : '正常(x1)';

        const playerMultEl = arenaEls.playerMult;
        const playerScoreEl = arenaEls.playerScore;
        const bossMultEl = arenaEls.bossMult;
        const bossScoreEl = arenaEls.bossScore;
        if (playerMultEl) playerMultEl.innerText = fillProfileTemplate(labels.battleStat, { roll: pR, detail: gD(pM) });
        if (playerScoreEl) playerScoreEl.innerText = pF;
        if (bossMultEl) bossMultEl.innerText = fillProfileTemplate(labels.battleStat, { roll: bR, detail: gD(bM) });
        if (bossScoreEl) bossScoreEl.innerText = bF;

        if (pF === bF) {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${labels.battleTie || '靈力平手！重新判定！'}</span>`;
          setTimeout(() => callBattleMethod('rollDice'), 2000);
        } else if (pF > bF) {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--cyan)'>${labels.battleWin || '🎉 討伐成功！'}</span>`;
          await callBattleMethod('endBattle', true);
        } else {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${labels.battleLose || '💀 討伐失敗...'}</span>`;
          await callBattleMethod('endBattle', false);
        }
      }, 1500);
    },

    showBattleSettlement() {
      const { elements: arenaEls } = getBattleArenaDom();
      const mainStage = arenaEls.mainStage;
      const settlement = arenaEls.settlementPanel;
      if (mainStage) mainStage.style.display = 'none';
      if (settlement) settlement.style.display = 'block';
    },

    backToBattleResult() {
      const { elements: arenaEls } = getBattleArenaDom();
      const mainStage = arenaEls.mainStage;
      const settlement = arenaEls.settlementPanel;
      if (settlement) settlement.style.display = 'none';
      if (mainStage) mainStage.style.display = 'block';
    },

    closeBattleArenaAndRefresh() {
      const latest = applyDataMigrationSafe(JSON.parse(JSON.stringify(currentState.studentData || {})));
      UI.hideModal('battleArenaModal');
      UI.updatePanel(latest, true);
    },

    async endBattle(isWin) {
      const { elements: arenaEls } = getBattleArenaDom();
      const baselineData = applyDataMigrationSafe(JSON.parse(JSON.stringify(currentState.studentData || {})));
      let d = applyDataMigrationSafe(JSON.parse(JSON.stringify(baselineData)));
      const resultEl = arenaEls.resultText;
      const rewardSummaryEl = arenaEls.rewardSummary;
      if (rewardSummaryEl) { rewardSummaryEl.style.display = 'none'; rewardSummaryEl.innerHTML = ''; }
      let battleSaveSucceeded = false;
      let pendingToast = '';
      let settlementRewardText = '本次未獲得獎勵';
      let settlementLogText = '';
      let settlementResultText = isWin ? (isCatProfile(d) ? '領域防衛成功' : 'Boss 討伐成功') : (isCatProfile(d) ? '領域防衛失敗' : 'Boss 討伐失敗');
      let settlementResultColor = isWin ? 'var(--color-grass)' : 'var(--danger)';

      const bossKey = currentState.currentBattleBoss?.id || currentState.currentBattleBoss?.legendaryId || currentState.currentBattleBoss?.name || 'boss';
      const monKey = currentState.selectedBattleMonIndex;
      const serial = normalizeSerialSafe(d.card_seq || d.serial || currentState.currentUid || '000') || '000';
      const eventId = buildBattleRewardEventIdSafe(d, bossKey, monKey);

      try {
        if (isWin) {
          let settle = null;
          let settleErrorMessage = '';
          try {
            settle = await settleRewardViaServerSafe('boss_win', {
              eventId,
              source: 'battle_tower',
              bossId: bossKey,
              battleMonIndex: monKey,
              serial,
              battleResetAnchor: getBattleResetAnchor(d, Date.now())
            });
          } catch (settleErr) {
            settleErrorMessage = String(settleErr?.message || settleErr || '獎勵結算失敗').trim();
            settle = { ok: false, applied: false, message: settleErrorMessage };
          }

          const recordBase = settle?.student
            ? applyDataMigrationSafe(JSON.parse(JSON.stringify(settle.student)))
            : await resolveBattleRecordBaseSafe(serial, baselineData);

          const recordPayload = buildBattleOutcomeRecordSafe(recordBase, {
            isWin: true,
            settle,
            saveStatus: 'pending',
            eventId,
            bossKey,
            monKey,
            errorMessage: settleErrorMessage
          });
          const savedBattleData = await saveStudentData(recordPayload);
          if (savedBattleData) {
            battleSaveSucceeded = true;
            d = applyDataMigrationSafe(JSON.parse(JSON.stringify(savedBattleData)));
            currentState.studentData = d;
            refreshStudentRewardPanelSafe(d, true);
          } else {
            d = recordPayload;
            currentState.studentData = applyDataMigrationSafe(JSON.parse(JSON.stringify(recordBase || baselineData)));
            refreshStudentRewardPanelSafe(currentState.studentData, true);
          }

          const rewardDisplay = getBattleRewardDisplaySafe(d, settle);
          settlementRewardText = settle?.ok && settle?.applied
            ? `+${rewardDisplay.coins} 金幣・+${rewardDisplay.xp} ${rewardDisplay.attrName}${rewardDisplay.xpUnit}`
            : (settle?.ok ? '本次未新增獎勵' : '獎勵結算失敗');

          if (settle?.ok && settle?.applied && battleSaveSucceeded) {
            const labels = getProfileLabels(d);
            const rewardSummary = `${rewardDisplay.coins} 金幣、${rewardDisplay.xp} 點${rewardDisplay.attrName}${rewardDisplay.xpUnit}`;
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--color-grass)'>${fillProfileTemplate(labels.battleReward, { reward: rewardSummary })}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `目前金幣：<b>${Number(d.coins) || 0}</b>　｜　目前${rewardDisplay.xpUnit}：<b>${Number(d.totalXP) || 0}</b>`;
            }
            pendingToast = `${isCatProfile(d) ? '領域防衛成功' : '對戰塔討伐成功'}：+${rewardDisplay.coins}🪙 +${rewardDisplay.xp} 點${rewardDisplay.attrName}${rewardDisplay.xpUnit}`;
            settlementLogText = '已完成結算：本次戰鬥獎勵與戰鬥紀錄都已寫入學生資料。';
          } else if (settle?.ok && !settle?.applied && battleSaveSucceeded) {
            const msg = settle?.message || '戰鬥已判定成功，但本次沒有新增獎勵。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `<span style="color:var(--warning)">${msg}</span>`;
            }
            pendingToast = msg;
            settlementResultColor = 'var(--warning)';
            settlementLogText = '戰鬥結果已記錄，但本次沒有新增獎勵。';
          } else if (!settle?.ok && battleSaveSucceeded) {
            const msg = settle?.message || '獎勵結算失敗，請稍後重新整理確認是否入帳。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `<span style="color:var(--warning)">${msg}<br>戰鬥結果已記錄，獎勵狀態請稍後確認。</span>`;
            }
            pendingToast = `戰鬥結果已記錄，但獎勵結算失敗：${msg}`;
            settlementResultColor = 'var(--warning)';
            settlementLogText = `戰鬥結果已記錄，但獎勵結算失敗：${msg}`;
          } else {
            const msg = settle?.message || '戰鬥結果保存失敗，請通知老師協助處理。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = '<span style="color:var(--danger)">戰鬥結果與獎勵狀態未能完整保存，請通知老師協助處理。</span>';
            }
            settlementResultColor = 'var(--danger)';
            settlementLogText = `戰鬥結果保存失敗：${msg}`;
          }
        } else {
          const recordPayload = buildBattleOutcomeRecordSafe(d, {
            isWin: false,
            settle: null,
            saveStatus: 'pending',
            eventId,
            bossKey,
            monKey
          });
          const savedBattleData = await saveStudentData(recordPayload);
          if (savedBattleData) {
            battleSaveSucceeded = true;
            d = applyDataMigrationSafe(JSON.parse(JSON.stringify(savedBattleData)));
            currentState.studentData = d;
            refreshStudentRewardPanelSafe(d, true);
          } else {
            currentState.studentData = baselineData;
            refreshStudentRewardPanelSafe(baselineData, true);
          }
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${getProfileLabels(baselineData).battleConsume || '💀 討伐失敗，本日挑戰機會已消耗。'}</span>`;
          settlementLogText = battleSaveSucceeded
            ? '本次戰鬥未獲得獎勵，今日挑戰次數已消耗，可於下次重置後再次挑戰。'
            : '本次戰鬥結果未能成功保存，請通知老師協助處理。';
        }
      } catch (battleErr) {
        console.error('[endBattle] failed:', battleErr);
        const msg = String(battleErr?.message || battleErr || '戰鬥結算失敗').trim();
        if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${msg}</span>`;
        if (rewardSummaryEl) {
          rewardSummaryEl.style.display = 'block';
          rewardSummaryEl.innerHTML = '<span style="color:var(--danger)">戰鬥結算失敗，請稍後重試或通知老師協助處理。</span>';
        }
        settlementResultText = 'Boss 結算失敗';
        settlementResultColor = 'var(--danger)';
        settlementRewardText = '未完成結算';
        settlementLogText = `戰鬥結算失敗：${msg}`;
        currentState.studentData = baselineData;
        refreshStudentRewardPanelSafe(baselineData, true);
      }

      const arenaElsEnd = getBattleArenaDom().elements;
      const actionBtn = arenaElsEnd.actionBtn;
      if (actionBtn) actionBtn.style.display = 'none';
      const confirmBtn = arenaEls.confirmBtn;
      if (confirmBtn) {
        confirmBtn.style.display = 'block';
        confirmBtn.innerText = '查看結算';
      }
      if (pendingToast) UI.toast(pendingToast);
      if (!isWin && rewardSummaryEl) {
        const xpUnit = getProfileLabels(d).xp || (isCatProfile(d) ? '成長能量' : '進化能量');
        rewardSummaryEl.style.display = 'block';
        rewardSummaryEl.innerHTML = `目前金幣：<b>${Number(d.coins) || 0}</b>　｜　目前${xpUnit}：<b>${Number(d.totalXP) || 0}</b>`;
      }

      const settlementResult = arenaElsEnd.settlementResult;
      if (settlementResult) {
        settlementResult.innerText = settlementResultText;
        settlementResult.style.color = settlementResultColor;
      }
      const settlementReward = arenaElsEnd.settlementReward;
      if (settlementReward) {
        settlementReward.innerText = settlementRewardText;
        settlementReward.style.color = isWin && battleSaveSucceeded ? 'var(--color-grass)' : (settlementResultColor === 'var(--danger)' ? 'var(--danger)' : 'var(--text-muted)');
      }
      const settlementCoins = arenaElsEnd.settlementCoins;
      if (settlementCoins) settlementCoins.innerText = String(Number(d.coins) || 0);
      const settlementXP = arenaElsEnd.settlementXP;
      if (settlementXP) settlementXP.innerText = String(Number(d.totalXP) || 0);
      const settlementLog = arenaElsEnd.settlementLog;
      if (settlementLog) settlementLog.innerText = settlementLogText;
    },

    async checkBattleTowerStatus(studentData) {
      try {
        if (!studentData) {
          currentState.currentBattleBoss = null;
          UI.hide('stuBattleTowerArea');
          return;
        }
        const rawBossDoc = typeof loadBattleTowerConfigDoc === 'function'
          ? await loadBattleTowerConfigDoc(BATTLE_TOWER_DOC_ID)
          : null;
        if (!rawBossDoc) {
          UI.hide('stuBattleTowerArea');
          currentState.currentBattleBoss = null;
          return;
        }
        const boss = getBattleBossConfigForStudent(studentData, rawBossDoc);
        if (!boss) {
          UI.hide('stuBattleTowerArea');
          currentState.currentBattleBoss = null;
          return;
        }
        currentState.currentBattleBoss = boss;
        UI.show('stuBattleTowerArea');

        const typeInfo = getProfileAttributeInfo(boss.typeKey, studentData) || null;
        const labels = getProfileLabels(studentData);
        const catBossVis = isCatProfile(studentData) ? getCatBossVisualByType(boss.typeKey) : null;
        const gradeInfo = getStudentGradeInfo(studentData);
        const audienceText = boss.audienceLabel || (gradeInfo.isSupportClass ? '學習扶助班' : (gradeInfo.gradeToken ? `${gradeInfo.gradeToken}年級` : '全體'));
        const { elements: towerEls } = getBattleTowerStudentDom();
        const nameEl = towerEls.bossName;
        if (nameEl) nameEl.innerText = isCatProfile(studentData) ? `${catBossVis?.breedName || labels.bossName || '入侵浪貓'}（${audienceText}）` : `${labels.bossName || boss.name || '---'}｜${audienceText}`;
        const imgEl = towerEls.bossImg;
        if (imgEl) imgEl.src = isCatProfile(studentData) ? (catBossVis?.file || catBossVis?.img || '') : (boss.img || '');
        const typeEl = towerEls.bossType;
        if (typeEl) {
          typeEl.innerText = typeInfo ? typeInfo.name : '未知';
          typeEl.style.color = typeInfo ? typeInfo.color : '#fff';
          typeEl.style.borderColor = typeInfo ? typeInfo.color : '#555';
        }

        const btn = towerEls.challengeBtn;
        const st = towerEls.statusText;

        if (!hasBattleAttemptRemaining(studentData)) {
          if (btn) { btn.disabled = true; btn.style.background = '#333'; btn.style.borderColor = '#555'; }
          if (st) st.innerText = fillProfileTemplate(labels.battleCooldown, { countdown: formatCountdown(getNextNoonTimestamp(Date.now()) - Date.now()) });
        } else {
          if (btn) { btn.disabled = false; btn.style.background = 'var(--danger)'; btn.style.borderColor = 'var(--danger)'; }
          if (st) st.innerText = `${labels.battleReady || '狀態就緒，點擊發起挑戰！（每日中午 12:00 重置）'}｜本日對應群組：${audienceText}。`;
        }
      } catch (e) {
        console.error('對戰塔狀態檢查失敗:', e);
      }
    },

    async updateBattleTowerStatus(studentData) {
      return callBattleMethod('checkBattleTowerStatus', studentData || currentState.studentData);
    },

    async resetDailyAndBattleChallenges() {
      let hasAdmin = !!currentState.isAdmin;
      if (!hasAdmin) {
        try {
          hasAdmin = await isCurrentUserAdminSafe();
          currentState.isAdmin = !!hasAdmin;
        } catch (e) {
          console.warn('[resetDailyAndBattleChallenges] admin recheck failed:', e);
        }
      }
      if (!hasAdmin) {
        UI.alert('請先以管理員身分登入後再操作。', '無法重置');
        return;
      }

      const confirmed = await UI.confirm(
        '此操作會將所有學生的「今日歷練」與「BOSS 挑戰」重置為可再次計算。\n\n已獲得的金幣、經驗與既有紀錄不會被回收。\n\n確定要執行嗎？',
        '確認重置今日挑戰'
      );
      if (!confirmed) return;

      const now = Date.now();
      const targets = [COLLECTION_NAME, STUDENT_PAGE_COLLECTION];
      let touched = 0;

      try {
        for (const colName of targets) {
          const snap = await getDocs(collection(db, colName));
          const docs = [];
          snap.forEach(docSnap => docs.push(docSnap));

          for (let i = 0; i < docs.length; i += 400) {
            const batch = writeBatch(db);
            const chunk = docs.slice(i, i + 400);

            chunk.forEach(docSnap => {
              const raw = docSnap.data ? (docSnap.data() || {}) : {};
              const previousDailyAnchor = typeof getDailyResetAnchor === 'function' ? getDailyResetAnchor(raw, now - 1) : 0;
              const previousBattleAnchor = getBattleResetAnchor(raw, now - 1);
              const rewardEvents = Array.isArray(raw.reward_events) ? raw.reward_events : [];
              const keptRewardEvents = rewardEvents.filter(evt => {
                if (!evt || typeof evt !== 'object') return false;
                const ts = Number(evt.timestamp) || 0;
                if (evt.type === 'daily_correct' && ts >= previousDailyAnchor) return false;
                if (evt.type === 'boss_win' && ts >= previousBattleAnchor) return false;
                return true;
              }).slice(-200);

              const payload = {
                daily_reset_override_at: now,
                battle_reset_override_at: now,
                today_quiz_reward_count: 0,
                today_quiz_reward_date: now,
                today_battle_used: false,
                today_battle_date: now,
                last_practice_time: 0,
                last_battle_time: 0,
                reward_events: keptRewardEvents,
                reward_settled_ids: [],
                updatedAt: now
              };

              const logs = Array.isArray(raw.logs) ? raw.logs.slice(-49) : [];
              logs.push({
                timestamp: now,
                action_type: 'system',
                detail: '[教師操作] 已手動重置今日歷練與 BOSS 挑戰次數（含每日十題上限、當日結算旗標與挑戰紀錄）'
              });
              payload.logs = logs;

              batch.set(docSnap.ref, payload, { merge: true });
            });

            await batch.commit();
            touched += chunk.length;
          }
        }

        if (currentState.studentData) {
          currentState.studentData.daily_reset_override_at = now;
          currentState.studentData.battle_reset_override_at = now;
          currentState.studentData.today_quiz_reward_count = 0;
          currentState.studentData.today_quiz_reward_date = now;
          currentState.studentData.today_battle_used = false;
          currentState.studentData.today_battle_date = now;
          currentState.studentData.last_practice_time = 0;
          currentState.studentData.last_battle_time = 0;
          currentState.studentData.reward_settled_ids = [];
          refreshStudentRewardPanelSafe(currentState.studentData, true);
          try { if (typeof UI.updateDailyQuestTimer === 'function') UI.updateDailyQuestTimer(); } catch (e) {}
          try { await callBattleMethod('checkBattleTowerStatus', currentState.studentData); } catch (e) {}
        }

        UI.alert(`已完成重置。\n\n共更新 ${touched} 筆資料（students + student_pages）。\n學生重新整理頁面後，今日歷練與 BOSS 挑戰都會重新開放。`, '重置完成');
      } catch (e) {
        console.error('[resetDailyAndBattleChallenges] failed:', e);
        UI.alert(`重置失敗：${e?.message || e}`, '重置失敗');
      }
    },

    async populateBattleQuizOptions(audienceKey = 'default') {
      const { elements: adminEls } = getBattleTowerAdminDom();
      const quizSelect = adminEls.setQuiz;
      if (!quizSelect) return [];
      quizSelect.innerHTML = '<option value="">載入題庫中...</option>';
      const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
      const finalList = typeof listBattleGatekeeperQuestions === 'function'
        ? await listBattleGatekeeperQuestions(audienceKey || 'default')
        : [];
      quizSelect.innerHTML = '<option value="random">(隨機) 依群組自動抽題</option>';
      finalList.forEach(q => {
        const gradeText = q.grade ? (/^[1-6][上下]$/.test(String(q.grade)) ? `${String(q.grade).charAt(0)}年級(${String(q.grade).slice(1)})` : String(q.grade)) : '';
        const unitText = q.unit || '';
        const prefix = [gradeText, unitText].filter(Boolean).join(' | ');
        let qShort = (q.question || '').replace(/\s+/g, ' ').trim();
        if (qShort.length > 26) qShort = qShort.slice(0, 26) + '…';
        quizSelect.innerHTML += `<option value="${esc(q.id)}">${prefix ? `[${esc(prefix)}] ` : ''}${esc(qShort)}</option>`;
      });
      return finalList;
    },

    updateBattleTowerAdminAudienceView(rawDoc = {}) {
      const { elements: adminEls } = getBattleTowerAdminDom();
      const audienceSel = adminEls.audienceSelect;
      const audienceKey = String(audienceSel?.value || 'grade4');
      const statusEl = adminEls.audienceStatus;
      const cfg = getBattleBossConfigForAudience(rawDoc, audienceKey);
      if (statusEl) {
        statusEl.innerHTML = cfg
          ? `已設定：<span style="color:#fff; font-weight:bold;">${cfg.name || '未命名 Boss'}</span><br>題目：${cfg.gatekeeperQuizId === 'random' ? '隨機抽題' : '指定題目'}<br>Boss骰數：${normalizeBossDiceCount(cfg.bossDiceCount, 3)}${cfg.timestamp ? `<br><span style="color:var(--text-muted);">更新：${new Date(cfg.timestamp).toLocaleString()}</span>` : ''}`
          : '此群組目前尚未設定，學生會改用「全體通用（備援）」設定。';
      }
      const bossSel = adminEls.setBoss;
      const typeSel = adminEls.setType;
      const quizSel = adminEls.setQuiz;
      const diceInput = adminEls.setBossDiceCount;
      if (bossSel) bossSel.value = String(cfg?.bossId || cfg?.id || '');
      if (typeSel) typeSel.value = String(cfg?.typeKey || '');
      if (quizSel) quizSel.value = String(cfg?.gatekeeperQuizId || 'random');
      if (diceInput) diceInput.value = String(normalizeBossDiceCount(cfg?.bossDiceCount, 3));
      if (typeof __updateLegendarySelectPreview === 'function') __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName');
    },

    async openBattleTowerSetup() {
      UI.showModal('battleTowerAdminModal');
      const { elements: adminEls } = getBattleTowerAdminDom();
      const audienceSel = adminEls.audienceSelect;
      if (audienceSel && !audienceSel.dataset.bound) {
        audienceSel.dataset.bound = '1';
        audienceSel.addEventListener('change', async () => {
          try {
            await callBattleMethod('populateBattleQuizOptions', audienceSel.value || 'default');
            const rawDoc = typeof loadBattleTowerConfigDoc === 'function' ? await loadBattleTowerConfigDoc(BATTLE_TOWER_DOC_ID) : null;
            callBattleMethod('updateBattleTowerAdminAudienceView', rawDoc || {});
          } catch (e) {
            console.error('[battle tower] audience change failed:', e);
          }
        });
      }
      if (audienceSel && !audienceSel.value) audienceSel.value = 'grade4';
      try {
        await callBattleMethod('populateBattleQuizOptions', audienceSel?.value || 'grade4');
        const cur = typeof loadBattleTowerConfigDoc === 'function' ? await loadBattleTowerConfigDoc(BATTLE_TOWER_DOC_ID) : null;
        callBattleMethod('updateBattleTowerAdminAudienceView', cur || {});
      } catch (e) {
        console.error(e);
        const { elements: adminEls } = getBattleTowerAdminDom();
        const quizSelect = adminEls.setQuiz;
        if (quizSelect) quizSelect.innerHTML = '<option value="random">(隨機) 依群組自動抽題</option>';
        UI.alert('載入題庫失敗：' + (e.message || e), '系統異常');
      }
    },

    async publishBattleBoss() {
      const { elements: adminEls } = getBattleTowerAdminDom();
      const audienceKey = String(adminEls.audienceSelect?.value || 'grade4');
      const audienceMeta = getBattleAudienceOptions().find(item => item.key === audienceKey) || { key: audienceKey, label: audienceKey };
      const bossId = adminEls.setBoss ? adminEls.setBoss.value : '';
      const typeKey = adminEls.setType ? adminEls.setType.value : '';
      const quizId = adminEls.setQuiz ? adminEls.setQuiz.value : '';
      const bossDiceCount = normalizeBossDiceCount(adminEls.setBossDiceCount ? adminEls.setBossDiceCount.value : 3, 3);
      const gatekeeperQuizId = quizId || 'random';

      if (!bossId || !typeKey) return UI.alert('請先選擇 Boss 與屬性。', '發布失敗');

      if (gatekeeperQuizId !== 'random') {
        const configuredQuestions = typeof listBattleGatekeeperQuestions === 'function'
          ? await listBattleGatekeeperQuestions(audienceKey || 'default')
          : [];
        const configuredQuestion = configuredQuestions.find((question) => String(question?.id || '').trim() === String(gatekeeperQuizId).trim());
        if (!configuredQuestion || !isQuizEnabled(configuredQuestion) || !isPlayableQuizQuestion(configuredQuestion)) {
          return UI.alert('指定的守門題不存在、未啟用，或目前題目格式無法作答。請重新選擇有效題目，或改用隨機抽題。', '發布失敗');
        }
      }

      const bossInfo = (CONSTANTS.LEGENDARIES || []).find(l => String(l.id) === String(bossId));
      if (!bossInfo) return UI.alert('找不到對應的 Boss 資料。', '系統錯誤');

      const audiencePayload = {
        id: String(bossId),
        bossId: String(bossId),
        name: bossInfo.name,
        img: bossInfo.img,
        typeKey: String(typeKey),
        gatekeeperQuizId: String(gatekeeperQuizId),
        bossDiceCount,
        timestamp: Date.now(),
        audienceKey,
        audienceLabel: audienceMeta.label
      };

      try {
        const normalized = typeof saveBattleTowerAudienceConfig === 'function'
          ? await saveBattleTowerAudienceConfig(audiencePayload, { audienceKey })
          : null;
        UI.toast(`✅ ${audienceMeta.label} Boss 已更新`);
        callBattleMethod('updateBattleTowerAdminAudienceView', normalized);
        if (currentState.studentData) callBattleMethod('checkBattleTowerStatus', currentState.studentData);
      } catch (e) {
        console.error(e);
        UI.alert('發布失敗：' + (e.message || e), '系統異常');
      }
    },

    async clearBattleBoss() {
      const { elements: adminEls } = getBattleTowerAdminDom();
      const audienceKey = String(adminEls.audienceSelect?.value || 'grade4');
      const audienceMeta = getBattleAudienceOptions().find(item => item.key === audienceKey) || { label: audienceKey };
      const isConfirmed = await UI.confirm(`確定要清除此群組（${audienceMeta.label}）的對戰塔設定嗎？\n\n學生之後會改用全體通用設定；若全體通用也沒設定，則暫時無法進入對戰塔。`, '清除群組 Boss 設定');
      if (!isConfirmed) return;

      try {
        const normalized = typeof clearBattleTowerAudienceConfig === 'function'
          ? await clearBattleTowerAudienceConfig(audienceKey)
          : normalizeBattleTowerDoc({});
        UI.toast(`✅ 已清除 ${audienceMeta.label} 設定`);
        callBattleMethod('updateBattleTowerAdminAudienceView', normalized);
        currentState.currentBattleBoss = null;
        if (currentState.studentData) await callBattleMethod('checkBattleTowerStatus', currentState.studentData);
        else UI.hide('stuBattleTowerArea');
      } catch (e) {
        console.error(e);
        UI.alert('清除失敗：' + (e.message || e), '系統異常');
      }
    }
  };

  return battleApi;
}
