import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "../core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
import { beginPerfSpan, endPerfSpan, markPerfPoint } from "../core/prevalidation-perf.js?v=phase15phase129finalreleasegovernancereaudit";

export function createStudentAccessModule(deps = {}) {
  attachEmergencyFlagGlobals();
  const {
    db, auth, collection, doc, getDoc, getDocs, setDoc, writeBatch, query, where, limit,
    UI, currentState, CONSTANTS, COLLECTION_NAME, TOKEN_COLLECTION, STUDENT_PAGE_COLLECTION,
    getAccountMgmtDom, getRegistrationDom, getBulkProgressDom, getBulkSerialRange,
    hasWebNfcSupport, createNdefReaderOrThrow, App
  } = deps;

  const callAppMethod = (name, ...args) => (typeof App?.[name] === 'function' ? App[name](...args) : undefined);
  const normalizeSerial = (value) => callAppMethod('normalizeSerial', value) || '';
  const normalizeUid = (value) => callAppMethod('normalizeUid', value) || null;
  const applyDataMigrationSafe = (data) => callAppMethod('applyDataMigration', data) || data;
  const mergeStudentRecordsSafe = (primary, secondary, serial) => callAppMethod('mergeStudentRecords', primary, secondary, serial) || applyDataMigrationSafe(primary || secondary || {});
  const scheduleBackgroundTask = (label, task) => callAppMethod('scheduleBackgroundTask', label, task);
  const syncLeaderboardSummaryForSerial = (...args) => callAppMethod('syncLeaderboardSummaryForSerial', ...args);
  const enterScanMode = (...args) => callAppMethod('enterScanMode', ...args);
  const loadStudentData = (...args) => callAppMethod('loadStudentData', ...args);
  const startWebNfc = (...args) => callAppMethod('startWebNfc', ...args);
  const stopWebNfc = (...args) => callAppMethod('stopWebNfc', ...args);
  const clone = (value) => JSON.parse(JSON.stringify(value || {}));
  const isAdminRuntime = () => currentState.isAdmin === true && currentState.viewMode !== 'student';
  const shouldDisableStudentMasterMerge = () => isEmergencyFlagEnabled('disableStudentMasterMerge');
  const scheduleLeaderboardSummarySyncIfAdmin = (label, serial, data) => {
    if (!isAdminRuntime()) return;
    scheduleBackgroundTask(label, () => syncLeaderboardSummaryForSerial(serial, data));
  };

  const cloneAuditValue = (value) => {
    if (Array.isArray(value)) return value.map((entry) => cloneAuditValue(entry));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cloneAuditValue(entry)]));
    return value;
  };

  const getTokenBindingAuditRoot = () => {
    const root = currentState.studentTokenBindingAudit && typeof currentState.studentTokenBindingAudit === 'object'
      ? currentState.studentTokenBindingAudit
      : (currentState.studentTokenBindingAudit = { bySerial: {}, lastSerial: '', updatedAt: 0, lastRun: null });
    if (!root.bySerial || typeof root.bySerial !== 'object') root.bySerial = {};
    return root;
  };

  const setTokenBindingAuditEntry = (serial, entry = {}) => {
    const normalized = normalizeSerial(serial);
    const root = getTokenBindingAuditRoot();
    if (!normalized) return entry;
    root.bySerial[normalized] = {
      ...(root.bySerial[normalized] || {}),
      ...cloneAuditValue(entry || {}),
      serial: normalized,
      updatedAt: Date.now()
    };
    root.lastSerial = normalized;
    root.updatedAt = Date.now();
    return root.bySerial[normalized];
  };

  const setTokenBindingAuditRun = (payload = {}) => {
    const root = getTokenBindingAuditRoot();
    root.lastRun = { ...cloneAuditValue(payload || {}), ranAt: Date.now() };
    root.updatedAt = Date.now();
    return root.lastRun;
  };

  const attachStudentTokenAuditGlobals = () => {
    try {
      if (typeof window === 'undefined') return;
      if (typeof window.__getStudentTokenBindingAudit !== 'function') {
        window.__getStudentTokenBindingAudit = () => cloneAuditValue(currentState.studentTokenBindingAudit || {});
      }
      if (typeof window.__printStudentTokenBindingAudit !== 'function') {
        window.__printStudentTokenBindingAudit = (serial = '') => {
          const audit = window.__getStudentTokenBindingAudit();
          const key = normalizeSerial(serial || audit?.lastSerial || '');
          const payload = key ? (audit?.bySerial?.[key] || {}) : (audit || {});
          console.log('[token-audit][print]', key || '(aggregate)', payload);
          return payload;
        };
      }
      if (typeof window.__auditStudentTokenBindingHealth !== 'function') {
        window.__auditStudentTokenBindingHealth = async (serialOrOptions = '', options = {}) => {
          if (serialOrOptions && typeof serialOrOptions === 'object' && !Array.isArray(serialOrOptions)) {
            return studentAccessApi.auditStudentTokenBindingHealth(serialOrOptions);
          }
          const serial = String(serialOrOptions || '').trim();
          if (serial) return studentAccessApi.auditStudentTokenBindingHealth({ ...options, serial });
          return studentAccessApi.auditStudentTokenBindingHealth(options || {});
        };
      }
    } catch (_) {}
  };

  const studentAccessApi = {
    auditStudentTokenBindingHealth: async function auditStudentTokenBindingHealth(options = {}) {
      attachStudentTokenAuditGlobals();
      if (!isAdminRuntime()) {
        const report = { ok: false, error: 'admin-required', ranAt: Date.now(), serial: normalizeSerial(options?.serial || '') || '' };
        currentState.studentTokenBindingAudit = { ...(currentState.studentTokenBindingAudit || {}), lastRun: report, updatedAt: Date.now() };
        console.warn('[token-audit] admin runtime required');
        return report;
      }

      const requestedSerial = normalizeSerial(options?.serial || options?.cardSeq || options?.uid || '');
      const scanAll = !requestedSerial && (options?.all === true || options?.scanAll === true);
      const maxRows = Math.max(1, Math.min(500, Number(options?.limit || options?.maxRows || (scanAll ? 200 : 50)) || (scanAll ? 200 : 50)));

      const serials = [];
      if (requestedSerial) {
        serials.push(requestedSerial);
      } else {
        try {
          const studentQuery = query(collection(db, COLLECTION_NAME), limit(maxRows));
          const snapshot = await getDocs(studentQuery);
          snapshot.forEach((docSnap) => {
            const serial = normalizeSerial(docSnap.id || docSnap.data()?.card_seq || docSnap.data()?.serial || '');
            if (serial) serials.push(serial);
          });
        } catch (err) {
          const report = { ok: false, error: 'list-failed', message: err?.message || String(err || ''), ranAt: Date.now() };
          setTokenBindingAuditRun(report);
          console.warn('[token-audit] list students failed:', err?.message || err);
          return report;
        }
      }

      const uniqueSerials = [...new Set(serials.filter(Boolean))];
      const rows = [];

      for (const serial of uniqueSerials) {
        const issues = [];
        const row = {
          serial,
          status: 'healthy',
          issues,
          checkedAt: Date.now(),
          studentExists: false,
          studentUid: '',
          studentHintToken: '',
          activeTokenIds: [],
          tokenDocs: {},
          pageDocs: {},
          expectedAliases: {},
          missingAliases: [],
          healthScore: 100
        };

        let studentData = null;
        try {
          const studentSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
          row.studentExists = !!studentSnap?.exists?.();
          if (studentSnap?.exists?.()) {
            studentData = studentSnap.data() || {};
            row.studentUid = normalizeUid(studentData.uid || '') || '';
            row.studentHintToken = String(studentData.active_token || studentData.page_token || studentData.token || '').trim();
            row.studentPageToken = String(studentData.page_token || '').trim();
          } else {
            issues.push('missing-student-record');
          }
        } catch (err) {
          issues.push('student-read-failed');
          row.studentReadError = err?.message || String(err || '');
        }

        let activeTokenIds = [];
        try {
          const tokenSnap = await getDocs(query(collection(db, TOKEN_COLLECTION), where('serial', '==', serial), where('active', '==', true), limit(Math.max(1, Math.min(25, Number(options?.tokenLimit || 10) || 10)))));
          activeTokenIds = tokenSnap?.docs?.map((entry) => String(entry.id || '').trim()).filter(Boolean) || [];
        } catch (err) {
          issues.push('active-token-query-failed');
          row.activeTokenQueryError = err?.message || String(err || '');
        }
        row.activeTokenIds = activeTokenIds;
        if (!activeTokenIds.length) issues.push('no-active-token-doc');
        if (activeTokenIds.length > 1) issues.push('multiple-active-tokens');

        const candidateTokenIds = [...new Set([
          row.studentHintToken,
          row.studentPageToken,
          ...activeTokenIds,
          serial,
          row.studentUid
        ].map((value) => String(value || '').trim()).filter(Boolean))];

        for (const tokenId of candidateTokenIds) {
          try {
            const tokenSnap = await getDoc(doc(db, TOKEN_COLLECTION, tokenId));
            const tokenData = tokenSnap?.exists?.() ? (tokenSnap.data() || {}) : null;
            row.tokenDocs[tokenId] = {
              exists: !!tokenSnap?.exists?.(),
              serial: normalizeSerial(tokenData?.serial || ''),
              active: tokenData?.active !== false && !!tokenSnap?.exists?.(),
              replacedBy: String(tokenData?.replacedBy || '').trim(),
              replacedToken: String(tokenData?.replacedToken || '').trim(),
              issuedAt: Number(tokenData?.issuedAt || 0) || 0
            };
          } catch (err) {
            row.tokenDocs[tokenId] = { exists: false, readError: err?.message || String(err || '') };
          }

          try {
            const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, tokenId));
            const pageData = pageSnap?.exists?.() ? (pageSnap.data() || {}) : null;
            row.pageDocs[tokenId] = {
              exists: !!pageSnap?.exists?.(),
              serial: normalizeSerial(pageData?.serial || pageData?.card_seq || ''),
              activeToken: String(pageData?.active_token || '').trim(),
              pageToken: String(pageData?.page_token || '').trim(),
              uid: normalizeUid(pageData?.uid || '') || ''
            };
          } catch (err) {
            row.pageDocs[tokenId] = { exists: false, readError: err?.message || String(err || '') };
          }
        }

        const hintMeta = row.studentHintToken ? row.tokenDocs[row.studentHintToken] : null;
        if (row.studentHintToken && !hintMeta?.exists) issues.push('hint-token-missing-doc');
        if (row.studentHintToken && hintMeta?.exists && hintMeta?.active === false) issues.push('hint-token-inactive');
        if (row.studentHintToken && hintMeta?.exists && hintMeta?.serial && hintMeta.serial !== serial) issues.push('hint-token-serial-mismatch');

        const canonicalToken = (row.studentHintToken && hintMeta?.exists && hintMeta?.active !== false && (!hintMeta?.serial || hintMeta.serial === serial))
          ? row.studentHintToken
          : (activeTokenIds[0] || '');
        row.canonicalToken = canonicalToken;
        row.expectedAliases = { serialAlias: serial, uidAlias: row.studentUid || '' };

        if (canonicalToken) {
          const canonicalPage = row.pageDocs[canonicalToken];
          if (!canonicalPage?.exists) issues.push('missing-canonical-student-page');
          if (canonicalPage?.exists && canonicalPage?.serial && canonicalPage.serial !== serial) issues.push('canonical-page-serial-mismatch');
        } else {
          issues.push('missing-canonical-token');
        }

        const serialAliasToken = row.tokenDocs[serial];
        const serialAliasPage = row.pageDocs[serial];
        if (!serialAliasToken?.exists) row.missingAliases.push('serial-token');
        if (!serialAliasPage?.exists) row.missingAliases.push('serial-page');
        if (row.studentUid) {
          const uidAliasToken = row.tokenDocs[row.studentUid];
          const uidAliasPage = row.pageDocs[row.studentUid];
          if (!uidAliasToken?.exists) row.missingAliases.push('uid-token');
          if (!uidAliasPage?.exists) row.missingAliases.push('uid-page');
        }
        if (row.missingAliases.length) issues.push('missing-alias-bindings');

        if (row.studentUid) {
          try {
            const cardSnap = await getDoc(doc(db, 'cards', row.studentUid));
            row.cardExists = !!cardSnap?.exists?.();
            if (cardSnap?.exists?.()) {
              const cardData = cardSnap.data() || {};
              row.cardSerial = normalizeSerial(cardData.serial || cardData.card_seq || '');
              row.cardActive = cardData.active !== false;
              if (row.cardSerial && row.cardSerial !== serial) issues.push('card-serial-mismatch');
              if (cardData.active === false) issues.push('uid-card-inactive');
            } else {
              issues.push('missing-uid-card-doc');
            }
          } catch (err) {
            issues.push('uid-card-read-failed');
            row.cardReadError = err?.message || String(err || '');
          }
        }

        row.status = issues.length ? 'issues-found' : 'healthy';
        row.healthScore = Math.max(0, 100
          - (issues.includes('missing-canonical-token') ? 40 : 0)
          - (issues.includes('missing-canonical-student-page') ? 25 : 0)
          - (issues.includes('multiple-active-tokens') ? 20 : 0)
          - (issues.includes('hint-token-serial-mismatch') ? 20 : 0)
          - (issues.includes('missing-alias-bindings') ? Math.min(20, row.missingAliases.length * 5) : 0)
          - ((issues.length - Number(issues.includes('missing-alias-bindings'))) * 4));

        setTokenBindingAuditEntry(serial, row);
        rows.push(row);
        console.log('[token-audit][serial]', serial, row);
      }

      const aggregate = {
        ok: true,
        ranAt: Date.now(),
        requestedSerial: requestedSerial || '',
        totalStudents: rows.length,
        healthyStudents: rows.filter((entry) => entry?.status === 'healthy').length,
        unhealthyStudents: rows.filter((entry) => entry?.status !== 'healthy').length,
        issueCounts: rows.reduce((acc, entry) => {
          (Array.isArray(entry?.issues) ? entry.issues : []).forEach((issue) => {
            acc[issue] = Number(acc[issue] || 0) + 1;
          });
          return acc;
        }, {}),
        rows
      };
      setTokenBindingAuditRun(aggregate);
      console.log('[token-audit][summary]', aggregate);
      return aggregate;
    },

    buildStudentUrlFromToken(token) {
      const t = encodeURIComponent(String(token || '').trim());
      const origin = globalThis?.location?.origin || window.location.origin;
      const path = globalThis?.location?.pathname || window.location.pathname;
      return `${origin}${path}?view=student#t=${t}`;
    },

    generateBase62Token(len = 16) {
      const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      const n = Math.max(8, Math.min(32, Number(len) || 16));
      let out = '';
      try {
        const bytes = new Uint8Array(n);
        const cryptoApi = globalThis?.crypto || window?.crypto;
        if (cryptoApi?.getRandomValues) cryptoApi.getRandomValues(bytes);
        else bytes.forEach((_, i) => { bytes[i] = Math.floor(Math.random() * 256); });
        for (let i = 0; i < n; i += 1) out += alphabet[bytes[i] % 62];
        return out;
      } catch (_) {
        for (let i = 0; i < n; i += 1) out += alphabet[Math.floor(Math.random() * 62)];
        return out;
      }
    },

    async resolveSerialFromToken(token, requireActive = true) {
      const tok = String(token || '').trim();
      if (!tok) return null;
      try {
        const tokenSnap = await getDoc(doc(db, TOKEN_COLLECTION, tok));
        if (!tokenSnap.exists()) return null;
        const data = tokenSnap.data() || {};
        if (requireActive && data.active === false) return null;
        return normalizeSerial(data.serial);
      } catch (e) {
        console.warn('[token] resolve failed:', e);
        return null;
      }
    },

    async getActiveTokenForSerial(serial) {
      const s = normalizeSerial(serial);
      if (!s) return null;

      if (currentState.currentToken) {
        const curSerial = normalizeSerial(currentState.currentUid || currentState.studentData?.card_seq || currentState.studentData?.serial);
        if (curSerial && curSerial === s) return currentState.currentToken;
      }

      try {
        const studentSnap = await getDoc(doc(db, COLLECTION_NAME, s));
        if (studentSnap.exists()) {
          const studentData = studentSnap.data() || {};
          const hinted = String(studentData.active_token || studentData.page_token || studentData.token || '').trim();
          if (hinted) return hinted;
        }
      } catch (e) {
        console.warn('[token] read student token hint failed:', e);
      }

      try {
        const q = query(collection(db, TOKEN_COLLECTION), where('serial', '==', s), where('active', '==', true), limit(1));
        const qs = await getDocs(q);
        if (qs && !qs.empty) return qs.docs[0].id;
      } catch (e) {
        console.warn('[token] active token query failed:', e);
      }
      return null;
    },

    async ensureActiveTokenForSerial(serial, options = {}) {
      const s = normalizeSerial(serial);
      if (!s) return null;
      const { createIfMissing = false, setAsCurrent = false } = options || {};

      let token = await this.getActiveTokenForSerial(s);
      if (!token && createIfMissing) {
        token = this.generateBase62Token(16);
        await setDoc(doc(db, TOKEN_COLLECTION, token), {
          serial: s,
          active: true,
          issuedAt: Date.now(),
          issuedBy: auth.currentUser ? auth.currentUser.uid : null
        });
        await setDoc(doc(db, COLLECTION_NAME, s), { active_token: token, page_token: token }, { merge: true });
      }

      if (token && setAsCurrent) currentState.currentToken = token;
      return token;
    },

    async writeCurrentStudentUrlToCard(options = {}) {
      const { shouldRestartScan = false } = options || {};
      if (!hasWebNfcSupport()) throw new Error('裝置不支援 Web NFC。');
      if (!(globalThis?.isSecureContext || window?.isSecureContext)) throw new Error('Web NFC 需要在 HTTPS 安全環境下使用。');

      const serial = normalizeSerial(currentState.currentUid || currentState.studentData?.card_seq || currentState.studentData?.serial || '');
      if (!serial) throw new Error('無法取得當前卡序！');

      stopWebNfc();
      const token = await this.ensureActiveTokenForSerial(serial, { createIfMissing: !!currentState.isAdmin, setAsCurrent: true });
      if (!token) throw new Error('找不到可用的 Token，請先完成註冊或使用補發流程。');

      const ndef = createNdefReaderOrThrow();
      const stuUrl = this.buildStudentUrlFromToken(token);
      await ndef.write({ records: [{ recordType: 'url', data: stuUrl }] });

      if (shouldRestartScan) {
        try { await startWebNfc(false); } catch (_) {}
      }
      return { serial, token, url: stuUrl };
    },

    async seedPreviewStudent(cardSeqStr) {
      const serial = normalizeSerial(cardSeqStr) || String(cardSeqStr || '1000');
      try {
        const ref = doc(db, COLLECTION_NAME, serial);
        const snap = await getDoc(ref);
        if (snap.exists()) return;
      } catch (_) {
        // 被 rules 擋住時維持 fallback，讓預覽仍可直接顯示
      }

      const sample = applyDataMigrationSafe(
        clone(callAppMethod('buildPreviewStudentData', serial) || { card_seq: serial, serial })
      );

      try {
        await setDoc(doc(db, COLLECTION_NAME, serial), sample, { merge: false });
      } catch (e) {
        console.warn('preview seed write failed:', e);
        currentState.currentUid = serial;
        currentState.studentData = sample;
        UI.updatePanel(sample, true);
        UI.toast('⚠️ 預覽資料無法寫入/讀取 Firestore，已使用本機假資料顯示（請檢查 Rules / 登入狀態）。');
      }
    },

    async saveCanonicalStudentPayload(payload, explicitUid = null) {
      const serial = normalizeSerial(explicitUid || payload?.card_seq || payload?.serial || currentState.currentUid);
      const localPayload = applyDataMigrationSafe(clone(payload || {}));
      if (!serial) return localPayload;
      localPayload.card_seq = serial;
      localPayload.serial = serial;
      await setDoc(doc(db, COLLECTION_NAME, serial), localPayload, { merge: true });
      const merged = await this.syncStudentMirrorForSerial(serial, localPayload);
      if (merged && currentState.currentUid && normalizeSerial(currentState.currentUid) === serial) currentState.studentData = merged;
      return merged || localPayload;
    },

    buildStudentWritablePayload(dataObj = {}, serial = '', token = '') {
      const src = clone(dataObj || {});
      const clean = {};
      const fields = [
        'card_seq', 'serial', 'active_token', 'page_token',
        'name', 'class_name', 'seat_number',
        'boss_win_total', 'daily_correct_total',
        'coins', 'totalXP', 'attributes', 'streaks', 'attr_event_counts',
        'attribute_first_gain_order', 'attribute_gain_order',
        'logs', 'display_team',
        'free_rename_available',
        'reward_events', 'reward_settled_ids',
        'updatedAt', 'lastSeenAt',
        'last_practice_time', 'last_battle_time',
        'dailyChallengeProgress', 'battleState',
        'today_battle_used', 'today_quiz_reward_count',
        'today_quiz_reward_date', 'today_battle_date',
        'battle_result', 'battle_summary',
        'daily_reset_override_at', 'battle_reset_override_at',
        'active_hidden_egg_id', 'active_hidden_egg',
        'hidden_eggs', 'collection', 'dragon_stage', 'dragon_path',
        'lap', 'trainerRankIndex', 'best_rate',
        'debuffs', 'debuffs_timestamp', 'status', 'status_timestamp',
        'content_profile_id', 'ui_variant', 'profile_flags',
        'guide_mode', 'guide_mode_locked'
      ];
      fields.forEach((key) => {
        if (src[key] !== undefined) clean[key] = src[key];
      });
      if (serial) {
        clean.card_seq = serial;
        clean.serial = serial;
      }
      if (token) {
        clean.active_token = token;
        clean.page_token = token;
      }
      if (clean.attribute_first_gain_order === undefined && clean.attribute_gain_order !== undefined) {
        clean.attribute_first_gain_order = clean.attribute_gain_order;
      }
      delete clean.attribute_gain_order;
      const maxLogs = 200;
      if (Array.isArray(clean.logs) && clean.logs.length > maxLogs) clean.logs = clean.logs.slice(-maxLogs);
      if (!Array.isArray(clean.reward_events)) clean.reward_events = [];
      if (!Array.isArray(clean.reward_settled_ids)) clean.reward_settled_ids = [];
      if (!Array.isArray(clean.hidden_eggs)) clean.hidden_eggs = [];
      if (!Array.isArray(clean.collection)) clean.collection = [];
      if (!Array.isArray(clean.display_team)) clean.display_team = [];
      const normalizeAttrMap = (srcMap) => ({
        metal: Number(srcMap?.metal) || 0,
        wood: Number(srcMap?.wood) || 0,
        water: Number(srcMap?.water) || 0,
        fire: Number(srcMap?.fire) || 0,
        earth: Number(srcMap?.earth) || 0
      });
      if (!clean.attributes || typeof clean.attributes !== 'object') clean.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      if (!clean.streaks || typeof clean.streaks !== 'object') clean.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      if (!clean.attr_event_counts || typeof clean.attr_event_counts !== 'object') clean.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      clean.attributes = normalizeAttrMap(clean.attributes);
      clean.streaks = normalizeAttrMap(clean.streaks);
      clean.attr_event_counts = normalizeAttrMap(clean.attr_event_counts);
      const orderSrc = (clean.attribute_first_gain_order && typeof clean.attribute_first_gain_order === 'object') ? clean.attribute_first_gain_order : {};
      clean.attribute_first_gain_order = {
        metal: Number.isFinite(Number(orderSrc.metal)) && Number(orderSrc.metal) > 0 ? Number(orderSrc.metal) : null,
        wood: Number.isFinite(Number(orderSrc.wood)) && Number(orderSrc.wood) > 0 ? Number(orderSrc.wood) : null,
        water: Number.isFinite(Number(orderSrc.water)) && Number(orderSrc.water) > 0 ? Number(orderSrc.water) : null,
        fire: Number.isFinite(Number(orderSrc.fire)) && Number(orderSrc.fire) > 0 ? Number(orderSrc.fire) : null,
        earth: Number.isFinite(Number(orderSrc.earth)) && Number(orderSrc.earth) > 0 ? Number(orderSrc.earth) : null
      };
      clean.debuffs = {
        Poison: Number(clean.debuffs?.Poison) || 0,
        Frozen: Number(clean.debuffs?.Frozen) || 0,
        Paralyzed: Number(clean.debuffs?.Paralyzed) || 0,
        Confusion: Number(clean.debuffs?.Confusion) || 0
      };
      clean.debuffs_timestamp = Number(clean.debuffs_timestamp) || null;
      clean.status = String(clean.status || 'Healthy');
      clean.status_timestamp = Number(clean.status_timestamp) || null;
      clean.lap = Number(clean.lap) || 1;
      clean.trainerRankIndex = Number(clean.trainerRankIndex) || 0;
      clean.best_rate = Number(clean.best_rate) || Number(callAppMethod('getRateFromRankIndex', clean.trainerRankIndex)) || 0;
      clean.profile_flags = Object.assign({ hide_fantasy: false, use_cat_theme: false, use_safe_random_label: false }, clean.profile_flags || {});
      clean.guide_mode = String(clean.guide_mode || (clean.content_profile_id === 'cat' ? 'lingmao' : 'baize'));
      clean.guide_mode_locked = clean.guide_mode_locked !== false;
      clean.free_rename_available = clean.free_rename_available === true;
      clean.boss_win_total = Math.max(0, Math.floor(Number(clean.boss_win_total) || 0));
      clean.daily_correct_total = Math.max(0, Math.floor(Number(clean.daily_correct_total) || 0));
      return clean;
    },

    async ensureStudentDataReady(options = {}) {
      if (currentState.studentData) return currentState.studentData;

      const timeoutMs = Math.max(1500, Number(options.timeoutMs) || 6500);
      const source = String(options.source || 'ensureStudentDataReady');
      const token = String(options.token || currentState.currentToken || '').trim();
      const serial = normalizeSerial(options.serial || currentState.currentUid || currentState.studentData?.card_seq || currentState.studentData?.serial || '');
      const timeoutPromise = new Promise((_, reject) => window.setTimeout(() => reject(new Error('學生資料載入逾時')), timeoutMs));
      beginPerfSpan('student', 'ensure-student-data-ready', { source, token: token ? '[present]' : '', serial, timeoutMs, viewMode: currentState.viewMode || '' });

      currentState.studentHydrationPending = true;
      currentState.studentHydrationError = '';

      try {
        if (token && currentState.viewMode === 'student') {
          const fetchPromise = (async () => {
            const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, token));
            if (!pageSnap.exists()) throw new Error('查無 student_pages 資料');
            let data = applyDataMigrationSafe(pageSnap.data() || {});
            const resolvedSerial = normalizeSerial(data.card_seq || data.serial || serial || '');
            if (resolvedSerial) currentState.currentUid = resolvedSerial;
            currentState.currentToken = token;
            data.active_token = token;
            data.page_token = token;
            currentState.studentData = data;
            currentState.studentDataReadyAt = Date.now();
            markPerfPoint('student', 'ensure-student-data-ready-hit-student-page', { source, serial: resolvedSerial || serial || '', token: token ? '[present]' : '' });
            currentState.studentDataLastSource = source;
            if (currentState.studentLocked) callAppMethod('unlockStudentAccess');
            if (resolvedSerial && currentState.viewMode !== 'student' && !shouldDisableStudentMasterMerge()) {
              void (async () => {
                try {
                  const masterSnap = await getDoc(doc(db, COLLECTION_NAME, resolvedSerial));
                  if (!masterSnap.exists()) return;
                  const masterData = applyDataMigrationSafe(masterSnap.data() || {});
                  const merged = mergeStudentRecordsSafe(currentState.studentData || data, masterData, resolvedSerial);
                  if (!merged) return;
                  if (currentState.currentToken) {
                    merged.active_token = currentState.currentToken;
                    merged.page_token = currentState.currentToken;
                  }
                  currentState.studentData = merged;
                  currentState.studentDataReadyAt = Date.now();
                  currentState.studentDataLastSource = `${source}:master-merge`;
                  if (currentState.viewMode === 'student') UI.updatePanel(merged, true);
                } catch (mergeErr) {
                  console.warn('[ensureStudentDataReady] merge master record failed:', mergeErr?.message || mergeErr);
                }
              })();
            }
            try { callAppMethod('deferStudentViewWarm', { source, reason: 'student-hydration' }); } catch (_) {}
            return data;
          })();
          return await Promise.race([fetchPromise, timeoutPromise]);
        }

        if (serial) {
          const fetchPromise = (async () => {
            const masterSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
            if (!masterSnap.exists()) throw new Error('查無 students 資料');
            const data = applyDataMigrationSafe(masterSnap.data() || {});
            currentState.currentUid = serial;
            currentState.studentData = data;
            currentState.studentDataReadyAt = Date.now();
            markPerfPoint('student', 'ensure-student-data-ready-hit-student-page', { source, serial: resolvedSerial || serial || '', token: token ? '[present]' : '' });
            currentState.studentDataLastSource = source;
            return data;
          })();
          return await Promise.race([fetchPromise, timeoutPromise]);
        }

        throw new Error('目前尚未綁定學生資料');
      } catch (err) {
        currentState.studentHydrationError = err?.message || String(err || '學生資料載入失敗');
        throw err;
      } finally {
        currentState.studentHydrationPending = false;
      }
    },

    async saveStudentTokenPayload(dataObj, explicitUid = null) {
      const payload = applyDataMigrationSafe(clone(dataObj || {}));
      if (currentState.currentToken) {
        payload.active_token = currentState.currentToken;
        payload.page_token = currentState.currentToken;
      }
      const serial = normalizeSerial(payload.card_seq || payload.serial || explicitUid || currentState.currentUid);
      const token = String(currentState.currentToken || '').trim();
      if (serial && token) {
        const writable = this.buildStudentWritablePayload(payload, serial, token);
        await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), writable, { merge: true });

        if (shouldDisableStudentMasterMerge()) {
          const normalized = applyDataMigrationSafe(clone(writable));
          currentState.studentData = normalized;
          guardLog('student-save', 'skip students mirror/readback by emergency flag', { serial, token });
          scheduleLeaderboardSummarySyncIfAdmin('leaderboard-summary:student-token-save', serial, normalized);
          return normalized;
        }

        try {
          await setDoc(doc(db, COLLECTION_NAME, serial), writable, { merge: true });
        } catch (mirrorErr) {
          console.warn('[student-save] mirror to students failed, page saved as source of truth:', mirrorErr?.message || mirrorErr);
        }

        const studentSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
        const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, token));
        const merged = mergeStudentRecordsSafe(
          pageSnap.exists() ? (pageSnap.data() || {}) : writable,
          studentSnap.exists() ? (studentSnap.data() || {}) : {},
          serial
        );
        const normalized = applyDataMigrationSafe(merged || writable);
        currentState.studentData = normalized;
        scheduleLeaderboardSummarySyncIfAdmin('leaderboard-summary:student-token-save', serial, normalized);
        return normalized;
      }

      if (token) {
        const writable = this.buildStudentWritablePayload(payload, '', token);
        await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), writable, { merge: true });
        currentState.studentData = applyDataMigrationSafe(writable);
        return currentState.studentData;
      }
      return payload;
    },

    async saveFastAdminStudentPayload(payload, explicitUid = null) {
      const serial = normalizeSerial(explicitUid || payload?.card_seq || payload?.serial || currentState.currentUid);
      if (!serial) return applyDataMigrationSafe(clone(payload || {}));
      const localPayload = applyDataMigrationSafe(clone(payload || {}));
      localPayload.card_seq = serial;
      localPayload.serial = serial;
      return await callAppMethod('enqueueSerialSave', serial, async () => {
        await setDoc(doc(db, COLLECTION_NAME, serial), localPayload, { merge: true });
        try {
          const token = String(localPayload.active_token || localPayload.page_token || await this.getActiveTokenForSerial(serial) || '').trim();
          if (token) await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...localPayload, active_token: token, page_token: token }, { merge: true });
        } catch (mirrorErr) {
          console.warn('[fast-admin-save] mirror failed:', mirrorErr?.message || mirrorErr);
        }
        const normalized = applyDataMigrationSafe(clone(localPayload));
        if (currentState.currentUid && normalizeSerial(currentState.currentUid) === serial) currentState.studentData = normalized;
        scheduleBackgroundTask('leaderboard-summary:fast-admin-save', () => syncLeaderboardSummaryForSerial(serial, normalized));
        return normalized;
      });
    },

    isFastAdminSaveMode(explicitUid = null) {
      if (currentState.viewMode === 'student') return false;
      if (!explicitUid) return false;
      return ['batch', 'support-batch', 'science-batch'].includes(String(currentState.scanIntention || ''));
    },

    async saveToDB(dataObj, explicitUid = null) {
      const isStudentTokenMode = (currentState.viewMode === 'student' && !!currentState.currentToken);
      if (currentState.viewMode === 'student' && !currentState.currentTokenValidated) {
        UI.toast('此操作需要有效卡片驗證');
        return null;
      }

      try {
        const payload = applyDataMigrationSafe(clone(dataObj || {}));
        if (currentState.currentToken) {
          payload.active_token = currentState.currentToken;
          payload.page_token = currentState.currentToken;
        }
        const maxLogs = 200;
        if (Array.isArray(payload.logs) && payload.logs.length > maxLogs) payload.logs = payload.logs.slice(-maxLogs);

        if (isStudentTokenMode) {
          return await this.saveStudentTokenPayload(payload, explicitUid);
        }

        const serial = normalizeSerial(explicitUid || payload.card_seq || payload.serial || currentState.currentUid);
        if (!serial) return payload;
        payload.card_seq = serial;
        payload.serial = serial;

        if (this.isFastAdminSaveMode(explicitUid || serial)) {
          return await this.saveFastAdminStudentPayload(payload, serial);
        }

        return await this.saveCanonicalStudentPayload(payload, serial);
      } catch (e) {
        console.error(e);
        UI.toast(`DB SYNC FAILED：${e.message || e}`);
        return null;
      }
    },

    async syncStudentMirrorForSerial(serial, preferredData = null) {
      const s = normalizeSerial(serial);
      if (!s) return preferredData ? applyDataMigrationSafe(preferredData) : null;
      const studentRef = doc(db, COLLECTION_NAME, s);
      const token = await this.getActiveTokenForSerial(s);
      const preferred = preferredData ? applyDataMigrationSafe(clone(preferredData)) : null;
      let studentSnapData = null;
      const studentSnap = await getDoc(studentRef);
      if (studentSnap.exists()) studentSnapData = applyDataMigrationSafe(clone(studentSnap.data() || {}));
      let pageData = null;
      if (token) {
        const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, token));
        if (pageSnap.exists()) pageData = applyDataMigrationSafe(clone(pageSnap.data() || {}));
      }
      if (!preferred && !studentSnapData && !pageData) return null;
      const primaryData = preferred || pageData || studentSnapData || {};
      const secondaryData = preferred ? (pageData || studentSnapData || {}) : ((primaryData === pageData) ? (studentSnapData || {}) : (pageData || {}));
      const merged = mergeStudentRecordsSafe(primaryData, secondaryData, s);
      if (token) {
        merged.active_token = token;
        merged.page_token = token;
      }
      await setDoc(studentRef, merged, { merge: true });
      if (token) {
        await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...merged, card_seq: s, serial: s, active_token: token, page_token: token }, { merge: true });
      }
      scheduleBackgroundTask('leaderboard-summary:mirror-sync', () => syncLeaderboardSummaryForSerial(s, merged));
      return merged;
    },

    async bulkRepairStudentPages() {
      const range = typeof getBulkSerialRange === 'function' ? getBulkSerialRange() : null;
      if (!range) {
        UI.toast('請輸入有效的起訖卡序');
        return;
      }
      const [start, end] = range;
      const dom = typeof getBulkProgressDom === 'function' ? getBulkProgressDom() : {};
      const result = dom?.result;
      if (result) result.innerText = '修復同步中...';
      try {
        const snap = await getDocs(collection(db, COLLECTION_NAME));
        const targets = [];
        snap.forEach((row) => {
          const sid = normalizeSerial(row.id);
          if (sid && sid >= start && sid <= end) targets.push(sid);
        });
        let repaired = 0;
        for (const sid of targets) {
          await this.syncStudentMirrorForSerial(sid);
          repaired += 1;
        }
        if (result) result.innerText = `已修復 ${repaired} 筆學生頁同步（卡序 ${start} ~ ${end}）。`;
        UI.toast(`已修復 ${repaired} 筆同步`);
      } catch (e) {
        console.error(e);
        if (result) result.innerText = `修復失敗：${e.message || e}`;
        UI.toast('修復失敗');
      }
    },

    async generateUniqueName() {
      const usedNames = new Set();
      try {
        const snapshot = await getDocs(collection(db, COLLECTION_NAME));
        snapshot.forEach((row) => {
          if (row.data().name) usedNames.add(row.data().name);
        });
      } catch (error) {
        console.warn('無法取得全校名單權限', error);
      }

      const codes = CONSTANTS.ANONYMOUS_CODES || ['星塵', '光年', '矩陣'];
      if (usedNames.size === 0) {
        const picked = codes[Math.floor(Math.random() * codes.length)];
        return `匿名學員-${picked}_${Math.floor(Math.random() * 1000)}`;
      }

      const available = codes.filter((code) => !usedNames.has(`匿名學員-${code}`));
      if (available.length === 0) return `匿名學員-極限_${Math.floor(Math.random() * 1000)}`;
      const picked = available[Math.floor(Math.random() * available.length)];
      return `匿名學員-${picked}`;
    },

    async rollRegistrationName() {
      const dom = typeof getRegistrationDom === 'function' ? getRegistrationDom() : {};
      const display = dom.randomNameDisplay;
      const submitWriteBtn = dom.submitWriteBtn;
      const submitBtn = dom.submitBtn;
      if (!display) {
        UI.alert('找不到註冊顯示區塊，請重新整理頁面後再試。', '系統異常');
        return;
      }
      display.innerText = '運算比對中...';
      const newName = await this.generateUniqueName();
      display.innerText = newName;
      currentState.tempRegName = newName;
      if (submitWriteBtn) submitWriteBtn.disabled = false;
      if (submitBtn) submitBtn.disabled = false;
    },

    async registerNewStudent(autoWriteNfc = false) {
      const dom = typeof getRegistrationDom === 'function' ? getRegistrationDom() : {};
      const gradeEl = dom.gradeSelect;
      const seqEl = dom.cardSeqInput;
      if (!gradeEl || !seqEl) {
        UI.alert('註冊表單缺少必要欄位，請重新整理頁面後再試。', '系統異常');
        return;
      }
      const cGrade = gradeEl.value;
      const cName = currentState.tempRegName;
      const cSeqRaw = (seqEl.value || '').trim();

      if (!cName) { UI.toast('請先點擊按鈕抽取代號！'); return; }
      if (!currentState.currentCardUid) { UI.toast('卡片 UID 遺失，請重新感應卡片。'); return; }
      if (!cSeqRaw) { UI.toast('請輸入卡序！'); return; }

      const cardSeqDigits = String(cSeqRaw || '').replace(/[^0-9]/g, '');
      if (!cardSeqDigits) { UI.toast('卡序格式錯誤'); return; }
      const cardSeqStr = cardSeqDigits.padStart(3, '0');
      const normalizedUid = normalizeUid(currentState.currentCardUid);

      const seqRef = doc(db, COLLECTION_NAME, cardSeqStr);
      const seqSnap = await getDoc(seqRef);
      if (seqSnap.exists()) {
        UI.alert(`卡序 #${cardSeqStr} 已被使用，請確認是否輸入錯誤或改用補辦流程。`, '卡序衝突');
        return;
      }

      const cardRef = doc(db, 'cards', normalizedUid);
      const cardSnap = await getDoc(cardRef);
      if (cardSnap.exists()) {
        UI.alert(`此卡片已綁定卡序 #${cardSnap.data().serial || cardSnap.data().card_seq || '未知'}`, '註冊衝突');
        return;
      }

      const token = this.generateBase62Token(16);
      const newData = {
        uid: normalizedUid,
        card_seq: cardSeqStr,
        class_name: cGrade,
        seat_number: '匿名',
        name: cName,
        totalXP: 0,
        coins: 0,
        free_rename_available: true,
        lap: 1,
        trainerRankIndex: 0,
        best_rate: 5,
        last_practice_time: 0,
        display_team: [],
        status: 'Healthy',
        status_timestamp: null,
        debuffs: { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 },
        debuffs_timestamp: null,
        attributes: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 },
        streaks: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 },
        attr_event_counts: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 },
        attribute_first_gain_order: { metal: null, wood: null, water: null, fire: null, earth: null },
        dragon_stage: -1,
        dragon_path: null,
        collection: [],
        logs: [{ timestamp: Date.now(), action_type: 'registration', points_added: 0, detail: '匿名晶片初始化完成' }],
        content_profile_id: 'shanhai',
        ui_variant: 'default',
        profile_flags: { hide_fantasy: false, use_cat_theme: false, use_safe_random_label: false },
        guide_mode: 'baize',
        guide_mode_locked: true,
        boss_win_total: 0,
        daily_correct_total: 0,
        active_token: token,
        page_token: token
      };

      try {
        await setDoc(seqRef, newData);
        await setDoc(cardRef, { serial: cardSeqStr, createdAt: Date.now(), active: true });
        await setDoc(doc(db, TOKEN_COLLECTION, token), { serial: cardSeqStr, active: true, issuedAt: Date.now(), issuedBy: (auth.currentUser ? auth.currentUser.uid : null) });
        await setDoc(seqRef, { active_token: token, page_token: token }, { merge: true });
        await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...newData, serial: cardSeqStr }, { merge: false });
        scheduleBackgroundTask('leaderboard-summary:registration', () => syncLeaderboardSummaryForSerial(cardSeqStr, newData));
        currentState.currentToken = token;
        UI.hideModal('regModal');

        if (autoWriteNfc) {
          if (!hasWebNfcSupport()) {
            UI.alert(`裝置不支援 Web NFC，已完成純資料綁定。(卡序 #${cardSeqStr})`, '通知');
          } else {
            UI.toast('⏳ 請將卡片再次貼近手機背面以寫入網址...');
            try {
              stopWebNfc();
              const ndef = createNdefReaderOrThrow();
              const stuUrl = this.buildStudentUrlFromToken(token);
              await ndef.write({ records: [{ recordType: 'url', data: stuUrl }] });
              UI.toast(`✅ 綁定與專屬網址寫入完成！(卡序 #${cardSeqStr})`);
            } catch (e) {
              console.error(e);
              UI.alert(`寫入 NFC 失敗，但資料已成功建檔。(卡序 #${cardSeqStr})\n您可事後於面板重新手動寫入。`, '寫入異常');
            }
          }
        } else {
          UI.toast(`✅ 匿名初始化綁定成功！(卡序 #${cardSeqStr})`);
        }

        enterScanMode('read');
        loadStudentData(cardSeqStr, 'admin');
      } catch (e) {
        console.error(e);
        const code = e?.code ? String(e.code) : '';
        const message = e?.message ? String(e.message) : String(e);
        if (code === 'permission-denied' || /permission|insufficient/i.test(message)) {
          UI.alert(
            `Firestore 權限不足（permission-denied）。\n\n請檢查 Firestore Rules 是否允許寫入：\n- ${COLLECTION_NAME}/{卡序}\n- cards/{UID}\n- ${TOKEN_COLLECTION}/{token}\n- ${STUDENT_PAGE_COLLECTION}/{token}\n\n並確認目前登入帳號已具備管理員權限。`,
            '建檔失敗'
          );
        } else {
          UI.alert(`匿名初始化失敗：${message}`, '建檔失敗');
        }
      }
    },

    async amLookupSerial() {
      const { lookupMsg: msg, serialLookupInput } = (typeof getAccountMgmtDom === 'function' ? getAccountMgmtDom() : {});
      const raw = (serialLookupInput?.value || '').trim();
      const seq = normalizeSerial(raw);
      if (!seq) {
        if (msg) msg.textContent = '⚠️ 請輸入正確卡序';
        return;
      }
      if (msg) msg.textContent = '查詢中...';
      try {
        const studentSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
        if (!studentSnap.exists()) {
          if (msg) msg.textContent = '❌ 查無此卡序（尚未註冊）';
          return;
        }
        if (msg) msg.textContent = '✅ 已找到，正在開啟...';
        const studentData = applyDataMigrationSafe(clone(studentSnap.data() || {}));
        UI.hideModal('accountMgmtModal');
        enterScanMode('read');
        loadStudentData(seq, 'admin', { preloadedData: studentData, primeView: true, serial: seq, source: 'amLookupSerial' });
        try {
          scheduleBackgroundTask('student-mirror:autoheal:amLookupSerial', () => this.syncStudentMirrorForSerial(seq, studentData));
        } catch (_) {}
      } catch (e) {
        console.error(e);
        if (msg) msg.textContent = '❌ 查詢失敗，請稍後重試';
      }
    },

    async amLoadReissue() {
      const { reissueSerialInput, reissueMsg: msg, reissueInfo: info, reissueStartBtn: btn } = (typeof getAccountMgmtDom === 'function' ? getAccountMgmtDom() : {});
      const raw = (reissueSerialInput?.value || '').trim();
      const seq = normalizeSerial(raw);
      if (!seq) {
        if (msg) msg.textContent = '⚠️ 請輸入正確卡序';
        return;
      }
      if (msg) msg.textContent = '查詢中...';
      try {
        const studentSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
        if (!studentSnap.exists()) {
          if (msg) msg.textContent = '❌ 查無此卡序（尚未註冊）';
          if (btn) { btn.disabled = true; btn.style.opacity = 0.6; }
          return;
        }
        const data = studentSnap.data() || {};
        const oldUid = data.uid ? normalizeUid(data.uid) : null;
        const oldToken = await this.getActiveTokenForSerial(seq);
        currentState.reissueDraft = { serial: seq, oldUid, oldToken };

        if (info) {
          info.innerHTML = `
              <div><b>卡序：</b>#${seq}</div>
              <div><b>學生：</b>${data.name || '未命名'}</div>
              <div><b>班級：</b>${data.class_name || '-'}</div>
              <div><b>目前UID：</b>${oldUid ? oldUid : '<span style="color:var(--text-muted);">（未記錄）</span>'}</div>
              <div><b>目前Token：</b>${oldToken ? oldToken : '<span style="color:var(--text-muted);">（未建立）</span>'}</div>
              <div style="margin-top:6px; font-size:0.85em; color:var(--text-muted);">補發會停用舊卡（舊UID/舊Token 失效），資料不變。</div>
            `;
        }
        if (btn) { btn.disabled = false; btn.style.opacity = 1; }
        if (msg) msg.textContent = '✅ 已載入，請點「一鍵補發」並感應新卡';
      } catch (e) {
        console.error(e);
        if (msg) msg.textContent = '❌ 載入失敗，請稍後重試';
        if (btn) { btn.disabled = true; btn.style.opacity = 0.6; }
      }
    },

    normalizeScanKey(uid) {
      let rawKey = String(uid || '').trim();
      const isTokenKey = rawKey.length >= 2 && rawKey[1] === ':' && (rawKey[0] === 'T' || rawKey[0] === 't');
      if (isTokenKey) return 'T:' + rawKey.slice(2).trim();
      return rawKey.toUpperCase().replace(/:/g, '').replace(/\s+/g, '');
    },

    async resolveSerialFromCardUid(uidLike) {
      const uidKey = normalizeUid(uidLike);
      if (!uidKey) return null;
      try {
        const cSnap = await getDoc(doc(db, 'cards', uidKey));
        if (!cSnap.exists()) return null;
        const cd = cSnap.data() || {};
        if (cd.active === false) return null;
        const sRaw = cd.serial || cd.card_seq;
        const digits = (sRaw == null) ? '' : String(sRaw).replace(/[^0-9]/g, '');
        return digits ? digits.padStart(3, '0') : null;
      } catch (_) {
        return null;
      }
    },

    async resolveSerialFromScanKey(key, options = {}) {
      const normalizedKey = this.normalizeScanKey(key);
      if (!normalizedKey) return null;

      const {
        requireActive = true,
        allowAdminUidFallback = true,
        setCurrentToken = true,
        notifyUidFallback = false
      } = options || {};

      if (normalizedKey.startsWith('T:')) {
        const token = normalizedKey.slice(2).trim();
        const serial = await this.resolveSerialFromToken(token, requireActive);
        if (serial) {
          if (setCurrentToken) currentState.currentToken = token;
          return serial;
        }

        if (currentState.isAdmin && currentState.lastNfcSerialNumber && allowAdminUidFallback) {
          const fallbackSerial = await this.resolveSerialFromCardUid(currentState.lastNfcSerialNumber);
          if (fallbackSerial) {
            if (notifyUidFallback) UI.toast('⚠️ Token 無效，已改用 UID 對照查詢');
            return fallbackSerial;
          }
        }
        return null;
      }

      const digits = normalizedKey.replace(/[^0-9]/g, '');
      const isPureDigits = !!digits && digits.length === normalizedKey.length;
      if (isPureDigits) return digits.padStart(3, '0');

      if (currentState.isAdmin && allowAdminUidFallback) {
        return await this.resolveSerialFromCardUid(normalizedKey);
      }
      return null;
    },

    async getActionCardPayload(rawKey) {
      const normalizedKey = this.normalizeScanKey(rawKey);
      if (!normalizedKey) return null;
      const snap = await getDoc(doc(db, 'action_cards', normalizedKey));
      if (!snap.exists()) return null;
      return clone(snap.data() || {});
    },

    async getStudentRecord(serial) {
      const normalizedSerial = normalizeSerial(serial);
      if (!normalizedSerial) return null;
      const snap = await getDoc(doc(db, COLLECTION_NAME, normalizedSerial));
      if (!snap.exists()) return null;
      const data = applyDataMigrationSafe(clone(snap.data() || {}));
      data.card_seq = normalizeSerial(data.card_seq || data.serial || normalizedSerial);
      data.serial = data.card_seq;
      return data;
    },

    async resolveStudentRecordFromScanKey(rawKey, options = {}) {
      const serial = await this.resolveSerialFromScanKey(rawKey, options);
      if (!serial) return { serial: null, data: null };
      const data = await this.getStudentRecord(serial);
      return { serial, data };
    },

    async bindPendingForgeActionCard(rawKey) {
      if (!currentState.pendingForgeData) throw new Error('鑄造資料遺失');
      const normalizedKey = this.normalizeScanKey(rawKey);
      if (!normalizedKey) throw new Error('無法辨識卡片');
      await setDoc(doc(db, 'action_cards', normalizedKey), currentState.pendingForgeData);
      return normalizedKey;
    },

    async inspectRegistrationScanKey(rawKey) {
      const normalizedKey = this.normalizeScanKey(rawKey);
      if (!normalizedKey) return { status: 'invalid', rawKey: normalizedKey };

      if (normalizedKey.startsWith('T:')) {
        const serial = await this.resolveSerialFromScanKey(normalizedKey, {
          requireActive: true,
          allowAdminUidFallback: true,
          setCurrentToken: false,
          notifyUidFallback: false
        });
        return {
          status: serial ? 'token-bound' : 'token-invalid',
          rawKey: normalizedKey,
          serial
        };
      }

      const digits = normalizedKey.replace(/[^0-9]/g, '');
      const isPureDigits = !!digits && digits.length === normalizedKey.length;
      if (isPureDigits) {
        const serial = digits.padStart(3, '0');
        const data = await this.getStudentRecord(serial);
        return {
          status: data ? 'serial-exists' : 'serial-missing',
          rawKey: normalizedKey,
          serial,
          data
        };
      }

      const uid = normalizeUid(normalizedKey);
      if (!uid) return { status: 'invalid', rawKey: normalizedKey };

      const cardSnap = await getDoc(doc(db, 'cards', uid));
      if (cardSnap.exists()) {
        const cardData = cardSnap.data() || {};
        const serial = normalizeSerial(cardData.serial || cardData.card_seq || '');
        return {
          status: 'uid-bound',
          rawKey: normalizedKey,
          uid,
          serial: serial || '未知',
          cardData: clone(cardData)
        };
      }

      return {
        status: 'blank-uid',
        rawKey: normalizedKey,
        uid
      };
    },


    async amStartReissue() {
      const { reissueMsg: msg } = (typeof getAccountMgmtDom === 'function' ? getAccountMgmtDom() : {});
      const draft = currentState.reissueDraft;
      if (!draft || !draft.serial) {
        if (msg) msg.textContent = '⚠️ 請先載入學生資料';
        return;
      }
      currentState.reissueState = { ...draft };
      currentState.scanIntention = 'reissue';
      if (msg) msg.textContent = '📡 請感應「新卡」以完成補發...';
      try {
        await startWebNfc(true);
      } catch (_) {}
    },

    async executeReissue(serial, oldToken, oldUid, newUid) {
      const seq = normalizeSerial(serial);
      const { reissueMsg: msg } = (typeof getAccountMgmtDom === 'function' ? getAccountMgmtDom() : {});
      if (!seq) {
        UI.alert('卡序格式錯誤', '補發失敗');
        return;
      }
      if (!currentState.isAdmin) {
        UI.alert('需要老師登入後才能補發。', '權限不足');
        return;
      }

      if (msg) msg.textContent = '⏳ 補發處理中...';
      const newToken = this.generateBase62Token(16);
      const now = Date.now();
      const normOldUid = oldUid ? normalizeUid(oldUid) : null;
      const normNewUid = newUid ? normalizeUid(newUid) : null;

      try {
        const batch = writeBatch(db);
        batch.set(doc(db, TOKEN_COLLECTION, newToken), {
          serial: seq,
          active: true,
          issuedAt: now,
          issuedBy: auth.currentUser ? auth.currentUser.uid : null,
          replacedToken: oldToken || null
        });

        if (oldToken) {
          batch.set(doc(db, TOKEN_COLLECTION, oldToken), { active: false, revokedAt: now, replacedBy: newToken }, { merge: true });
        }

        if (normNewUid) {
          batch.set(doc(db, COLLECTION_NAME, seq), { uid: normNewUid, active_token: newToken, page_token: newToken }, { merge: true });
          batch.set(doc(db, 'cards', normNewUid), { serial: seq, createdAt: now, active: true, replacedUid: normOldUid || null }, { merge: true });
        }

        batch.set(doc(db, COLLECTION_NAME, seq), { active_token: newToken, page_token: newToken }, { merge: true });

        if (normOldUid && (!normNewUid || normOldUid !== normNewUid)) {
          batch.set(doc(db, 'cards', normOldUid), { active: false, revokedAt: now, replacedBy: normNewUid || null }, { merge: true });
        }

        await batch.commit();
        currentState.currentToken = newToken;

        try {
          const studentSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
          if (studentSnap.exists()) {
            const seeded = applyDataMigrationSafe(clone(studentSnap.data() || {}));
            const serialDigits = String(seeded.card_seq || seeded.serial || seq || '').replace(/[^0-9]/g, '');
            const normalized = serialDigits ? serialDigits.padStart(3, '0') : String(seq);
            seeded.card_seq = normalized;
            seeded.serial = normalized;
            await setDoc(doc(db, STUDENT_PAGE_COLLECTION, newToken), seeded, { merge: false });
          }
        } catch (e) {
          console.warn('[student_pages] seed on reissue failed:', e?.message || e);
        }

        let writeOk = false;
        const stuUrl = this.buildStudentUrlFromToken(newToken);
        try {
          if (!hasWebNfcSupport()) throw new Error('裝置不支援 Web NFC');
          if (!(globalThis?.isSecureContext || window?.isSecureContext)) throw new Error('Web NFC 需要 HTTPS');
          stopWebNfc();
          const ndef = createNdefReaderOrThrow();
          await ndef.write({ records: [{ recordType: 'url', data: stuUrl }] });
          writeOk = true;
        } catch (e) {
          console.warn('[reissue] nfc write failed:', e);
        }

        currentState.scanIntention = 'read';
        currentState.reissueState = null;
        currentState.reissueDraft = null;

        if (writeOk) {
          if (msg) msg.textContent = '✅ 補發完成（已寫入新卡）';
          UI.toast(`✅ 補發完成：卡序 #${seq}`);
        } else {
          UI.alert(`寫入 NFC 失敗，但補發資料已完成。\n請改用其他工具手動寫入以下網址：\n${stuUrl}`, '寫入異常');
          if (msg) msg.textContent = '⚠️ 補發完成，但寫入失敗（需手動寫入）';
        }

        UI.hideModal('accountMgmtModal');
        enterScanMode('read');
        loadStudentData(seq, 'admin');
      } catch (e) {
        console.error(e);
        currentState.scanIntention = 'read';
        if (msg) msg.textContent = '❌ 補發失敗，請稍後重試';
        UI.alert('補發寫入資料庫失敗，請檢查權限/網路/規則設定。', '補發失敗');
      }
    }
  };

  attachStudentTokenAuditGlobals();
  return studentAccessApi;
}
