
export function createBatchModule(deps = {}) {
  const {
    db,
    getDocs,
    collection,
    COLLECTION_NAME,
    CONSTANTS,
    addAttributeXP,
    getProfileLabels,
    startWebNfc,
    saveToDB,
    syncStudentMirrorForSerial,
    applyDataMigration,
    getActiveTokenForSerial,
    checkDeathTrigger,
    processEvolution,
    normalizeSerial,
    getRateFromRankIndex,
    getBulkProgressDom,
    getBatchModeDom,
    currentState,
    batchState,
    UI
  } = deps;

  const readBatchModeDom = () => (typeof getBatchModeDom === 'function' ? (getBatchModeDom() || {}) : {});

  function updateBatchHeader(data) {
    const { classText: cls, nameText: name, xpText: xp } = readBatchModeDom();
    if (cls) cls.innerText = `${data.class_name}`;
    if (name) name.innerText = data.name;
    if (xp) xp.innerText = `${data.totalXP} 點`;
  }

  function updateBatchStatus(data) {
    const { statusText: statusEl } = readBatchModeDom();
    if (!statusEl) return;
    const hasDebuff = Object.values(data.debuffs || {}).some(v => Number(v) > 0);
    statusEl.innerText = hasDebuff ? '異常狀態' : '健康';
    statusEl.style.color = hasDebuff ? 'var(--danger)' : 'var(--color-grass)';
  }

  function setBatchPhase(phaseText, phaseSubtext = '', accent = 'var(--warning)') {
    const { phaseTextEl: phaseEl, phaseSubtextEl: subEl, readyChip: chipEl } = readBatchModeDom();
    if (phaseEl) phaseEl.innerText = phaseText || '等待學生卡感應中';
    if (subEl) subEl.innerText = phaseSubtext || '學生卡 → 道具卡 → 即時寫入';
    if (chipEl) {
      chipEl.innerText = phaseText || 'TARGET LOCKED';
      chipEl.style.color = accent;
      chipEl.style.borderColor = accent;
      chipEl.style.boxShadow = `0 0 12px ${accent}`;
    }
  }

  function setBatchPanelFlash(color) {
    const { panel } = readBatchModeDom();
    if (!panel) return;
    panel.style.color = color;
    panel.classList.remove('batch-flash');
    void panel.offsetWidth;
    panel.classList.add('batch-flash');
    panel.style.borderColor = color;
  }

  function triggerBatchBurst(text, color = 'var(--warning)') {
    const { valueBurst: burst } = readBatchModeDom();
    if (!burst || !text) return;
    burst.innerText = text;
    burst.style.color = color;
    burst.classList.remove('is-active');
    void burst.offsetWidth;
    burst.classList.add('is-active');
  }

  function setBatchFeedback(payload = {}) {
    const {
      title = '等待目標鎖定',
      value = 'SCAN',
      detail = '請先感應學生卡，再感應加分或扣分道具卡。',
      badge = 'BATCH READY',
      color = 'var(--warning)',
      burst = ''
    } = payload || {};

    const {
      feedbackArea: area,
      actionText,
      valueText,
      resultMeta: metaText,
      resultBadge: badgeText
    } = readBatchModeDom();

    if (area) area.style.color = color;
    if (actionText) {
      actionText.innerText = title;
      actionText.style.color = '#fff';
    }
    if (valueText) {
      valueText.innerText = value;
      valueText.style.color = color;
    }
    if (metaText) metaText.innerText = detail;
    if (badgeText) {
      badgeText.innerText = badge;
      badgeText.style.color = color;
      badgeText.style.borderColor = color;
      badgeText.style.boxShadow = `0 0 12px ${color}`;
    }
    if (burst) triggerBatchBurst(burst, color);
  }

  function setBatchComboDisplay(color = 'var(--warning)') {
    const { comboText: combo } = readBatchModeDom();
    if (!combo) return;
    combo.innerText = batchState.comboCount > 1 ? `連續加成 x${batchState.comboCount}` : '連擊待命';
    combo.style.color = color;
  }

  function updateTimerVisual(timeLeftMs) {
    const { timerBar: bar, timerSec: sec } = readBatchModeDom();
    const ratio = Math.max(0, Math.min(1, timeLeftMs / 10000));
    const color = ratio <= 0.25 ? 'var(--danger)' : (ratio <= 0.55 ? 'var(--warning)' : 'var(--cyan)');
    if (bar) {
      bar.style.width = (ratio * 100) + '%';
      bar.style.background = color;
      bar.style.boxShadow = `0 0 18px ${color}`;
    }
    if (sec) {
      sec.innerText = (timeLeftMs / 1000).toFixed(1);
      sec.style.color = color;
      sec.style.textShadow = `0 0 10px ${color}`;
    }
  }

  function cloneStudentData(data) {
    return JSON.parse(JSON.stringify(data || {}));
  }

  function getBulkSerialRange() {
    const dom = typeof getBulkProgressDom === 'function' ? getBulkProgressDom() : {};
    const startEl = dom?.startSerialInput;
    const endEl = dom?.endSerialInput;
    if (!startEl || !endEl) {
      UI.alert('批次調整表單缺少卡序欄位，請重新整理頁面後再試。', '系統異常');
      return null;
    }
    const start = typeof normalizeSerial === 'function' ? normalizeSerial(startEl.value) : (startEl.value || '').trim();
    const end = typeof normalizeSerial === 'function' ? normalizeSerial(endEl.value) : (endEl.value || '').trim();
    if (!start || !end) return null;
    return [start, end].sort();
  }

  function resetGameplayState(data) {
    const next = applyDataMigration(cloneStudentData(data));
    next.totalXP = 0;
    next.coins = 0;
    next.last_practice_time = 0;
    next.last_battle_time = 0;
    next.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
    next.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
    next.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
    next.attribute_first_gain_order = { metal: null, wood: null, water: null, fire: null, earth: null };
    next.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
    next.debuffs_timestamp = null;
    next.dragon_stage = -1;
    next.dragon_path = null;
    next.collection = [];
    next.hidden_eggs = [];
    next.logs = [...(Array.isArray(next.logs) ? next.logs.slice(-20) : []), { timestamp: Date.now(), action_type: 'system', detail: '[批次調整] 遊戲進度已重置（保留 UID / TOKEN / 卡序 / 姓名）' }];
    next.trainerRankIndex = 0;
    next.best_rate = typeof getRateFromRankIndex === 'function' ? getRateFromRankIndex(next.trainerRankIndex || 0) : 99;
    return next;
  }

  async function bulkUpdateProgressAndGrade() {
    const range = getBulkSerialRange();
    if (!range) { UI.toast('請輸入有效的起訖卡序'); return; }
    const [start, end] = range;
    const dom = typeof getBulkProgressDom === 'function' ? getBulkProgressDom() : {};
    const gradeEl = dom?.gradeSelect;
    const rankEl = dom?.rankSelect;
    const resetEl = dom?.resetCheckbox;
    if (!gradeEl || !rankEl || !resetEl) {
      UI.alert('批次調整表單缺少必要欄位，請重新整理頁面後再試。', '系統異常');
      return;
    }
    const newGrade = gradeEl.value || '';
    const newRank = rankEl.value;
    const shouldReset = !!resetEl.checked;
    const result = dom?.result;
    if (result) result.innerText = '批次更新中...';
    try {
      const snap = await getDocs(collection(db, COLLECTION_NAME));
      const docs = [];
      snap.forEach((row) => {
        const sid = typeof normalizeSerial === 'function' ? normalizeSerial(row.id) : row.id;
        if (sid && sid >= start && sid <= end) docs.push({ id: sid, data: row.data() || {} });
      });
      let updated = 0;
      for (const row of docs) {
        let data = applyDataMigration(cloneStudentData(row.data || {}));
        if (shouldReset) data = resetGameplayState(data);
        if (newGrade) data.class_name = newGrade;
        if (newRank !== '') data.trainerRankIndex = Number(newRank);
        data.best_rate = Math.min(Number(data.best_rate) || 99, typeof getRateFromRankIndex === 'function' ? getRateFromRankIndex(data.trainerRankIndex) : 99);
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: `[批次調整] 年級=${newGrade || '不變'} / 階級=${newRank === '' ? '不變' : (CONSTANTS.TRAINER_RANKS[Number(newRank)] || newRank)} / 進度重置=${shouldReset ? '是' : '否'}` });
        const merged = await syncStudentMirrorForSerial(row.id, data);
        if (currentState.currentUid && (typeof normalizeSerial === 'function' ? normalizeSerial(currentState.currentUid) : currentState.currentUid) === row.id) currentState.studentData = merged || data;
        updated += 1;
      }
      if (result) result.innerText = `已更新 ${updated} 筆資料（卡序 ${start} ~ ${end}）。`;
      UI.toast(`已更新 ${updated} 筆資料`);
    } catch (e) {
      console.error(e);
      if (result) result.innerText = `批次調整失敗：${e.message || e}`;
      UI.toast('批次調整失敗');
    }
  }

  const batchApi = {
    enterBatchMode() {
      currentState.scanIntention = 'batch';
      UI.hide('dashboardView');
      UI.show('batchModeView');
      batchApi.resetBatchState();
      setBatchPhase('等待學生卡感應中', '學生卡 → 道具卡 → 即時寫入', 'var(--warning)');
      setBatchFeedback({
        title: '等待目標鎖定',
        value: 'SCAN',
        detail: '請先感應學生卡，再感應加分或扣分道具卡。',
        badge: 'BATCH READY',
        color: 'var(--warning)'
      });
      readBatchModeDom().scannerInput?.focus?.();
      typeof startWebNfc === 'function' ? startWebNfc(true) : undefined;
    },

    exitBatchMode() {
      batchApi.resetBatchState();
      UI.hide('batchModeView');
      UI.show('dashboardView');
    },

    resetGameplayState,

    openBulkProgressModal() {
      const dom = typeof getBulkProgressDom === 'function' ? getBulkProgressDom() : {};
      if (dom?.result) dom.result.innerText = '可批次調整年級、階級與遊戲進度，或只修復學生頁同步。';
      UI.showModal('bulkProgressModal');
    },

    getBulkSerialRange,

    bulkUpdateProgressAndGrade,

    async setBatchStudent(uid, data) {
      if (batchState.activeStudentUid && batchState.activeStudentUid !== uid && currentState.studentData) {
        await saveToDB(currentState.studentData, batchState.activeStudentUid);
      }
      batchState.activeStudentUid = uid;
      batchState.comboCount = 0;
      currentState.currentToken = null;
      currentState.currentTokenValidated = false;
      const merged = await syncStudentMirrorForSerial(uid, data);
      const nextData = applyDataMigration(merged || data);
      currentState.currentUid = uid;
      currentState.studentData = nextData;
      currentState.currentToken = await getActiveTokenForSerial(uid);
      currentState.currentTokenValidated = !!currentState.currentToken;
      UI.hide('batchWaitStatus');
      UI.show('batchStudentArea');
      updateBatchHeader(nextData);
      updateBatchStatus(nextData);
      setBatchPanelFlash('var(--warning)');
      setBatchPhase('TARGET LOCKED', `已鎖定 ${nextData.name}，請感應道具卡`, 'var(--warning)');
      setBatchFeedback({
        title: '學生已鎖定',
        value: nextData.name,
        detail: '倒數已重新開始，現在可直接感應加分或扣分道具卡。',
        badge: 'STUDENT READY',
        color: 'var(--warning)',
        burst: 'LOCKED'
      });
      setBatchComboDisplay('var(--warning)');
      batchApi.startBatchTimer();
    },

    startBatchTimer() {
      clearInterval(batchState.timerInterval);
      batchState.timeLeftMs = 10000;
      updateTimerVisual(batchState.timeLeftMs);
      batchState.timerInterval = setInterval(() => {
        batchState.timeLeftMs -= 100;
        updateTimerVisual(batchState.timeLeftMs);
        if (batchState.timeLeftMs <= 0) {
          clearInterval(batchState.timerInterval);
          batchApi.endBatchSession();
        }
      }, 100);
    },

    async endBatchSession() {
      if (batchState.activeStudentUid && currentState.studentData) {
        await saveToDB(currentState.studentData, batchState.activeStudentUid);
        UI.toast(`✅ 已儲存 ${currentState.studentData.name} 的更新`);
      }
      batchApi.resetBatchState();
    },

    resetBatchState() {
      clearInterval(batchState.timerInterval);
      batchState.activeStudentUid = null;
      batchState.comboCount = 0;
      currentState.currentUid = null;
      currentState.currentToken = null;
      currentState.currentTokenValidated = false;
      currentState.studentData = null;
      UI.hide('batchStudentArea');
      UI.show('batchWaitStatus');
      const { panel } = readBatchModeDom();
      if (panel) {
        panel.style.borderColor = 'var(--warning)';
        panel.style.color = 'var(--warning)';
      }
      setBatchPhase('等待學生卡感應中', '學生卡 → 道具卡 → 即時寫入', 'var(--warning)');
      setBatchFeedback({
        title: '等待目標鎖定',
        value: 'SCAN',
        detail: '請先感應學生卡，再感應加分或扣分道具卡。',
        badge: 'BATCH READY',
        color: 'var(--warning)'
      });
      setBatchComboDisplay('var(--warning)');
      updateTimerVisual(10000);
    },

    async persistBatchStudentData(data, uid) {
      currentState.studentData = data;
      const targetUid = uid || batchState.activeStudentUid || currentState.currentUid;
      if (!targetUid) {
        UI.toast('⚠️ 無法辨識批量模式學生');
        return false;
      }
      await saveToDB(data, targetUid);
      return true;
    },

    async executeBatchAction(action) {
      if (!batchState.activeStudentUid || !currentState.studentData) {
        UI.toast('⚠️ 尚未鎖定學生！');
        return;
      }

      let data = cloneStudentData(currentState.studentData);

      if (action && (action.type === 'debuff' || action.debuffKey)) {
        const debuffKey = action.debuffKey || action.statusKey || action.debuff || 'Poison';
        const stacksRaw = parseInt(action.stacks, 10);
        const stacks = Math.max(1, Math.min(5, Number.isFinite(stacksRaw) ? stacksRaw : 1));
        if (!data.debuffs) data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
        if (!Array.isArray(data.logs)) data.logs = [];
        data.debuffs[debuffKey] = (data.debuffs[debuffKey] || 0) + stacks;
        data.debuffs_timestamp = Date.now();
        const info = CONSTANTS.DEBUFF_INFO[debuffKey] || { name: debuffKey, color: 'var(--danger)' };
        data.logs.push({ timestamp: Date.now(), action_type: 'batch_debuff', points_added: 0, detail: `[批量狀態] ${action.name} -> ${info.name} +${stacks}` });

        if (checkDeathTrigger(data, debuffKey)) {
          currentState.studentData = data;
          updateBatchHeader(data);
          const { statusText: statusEl } = readBatchModeDom();
          if (statusEl) {
            statusEl.innerText = '健康';
            statusEl.style.color = 'var(--color-grass)';
          }
          setBatchPanelFlash('var(--danger)');
          setBatchPhase('STATUS SEALED', '型態已封存，請切換其他解除流程', 'var(--danger)');
          setBatchFeedback({
            title: `[ ${action.name} ] 觸發封存`,
            value: 'TYPE SEALED',
            detail: '此型態已封存，狀態已同步寫入。',
            badge: 'DEBUFF LOCK',
            color: 'var(--danger)',
            burst: 'SEALED'
          });
          setBatchComboDisplay('var(--danger)');
          batchApi.startBatchTimer();
          await batchApi.persistBatchStudentData(data, batchState.activeStudentUid);
          return;
        }

        currentState.studentData = data;
        updateBatchStatus(data);
        updateBatchHeader(data);
        const uiColor = info.color || 'var(--danger)';
        setBatchPanelFlash(uiColor);
        setBatchPhase('DEBUFF APPLIED', `已套用 ${info.name}，層數 +${stacks}`, uiColor);
        setBatchFeedback({
          title: `[ ${action.name} ] 狀態已疊加`,
          value: `+${stacks} ${info.name}`,
          detail: '感應成功，異常狀態已同步寫入學生資料。',
          badge: 'DEBUFF SUCCESS',
          color: uiColor,
          burst: `+${stacks}`
        });
        setBatchComboDisplay(uiColor);
        batchApi.startBatchTimer();
        await batchApi.persistBatchStudentData(data, batchState.activeStudentUid);
        return;
      }

      const baseAttr = action.attr;
      const baseVal = Number(action.val) || 0;
      if (!data.streaks) data.streaks = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
      if (!data.attributes) data.attributes = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
      if (!Array.isArray(data.logs)) data.logs = [];

      let actualAttr = baseAttr;
      if (data.debuffs?.Confusion > 0) {
        const keys = Object.keys(CONSTANTS.ATTRIBUTES || {});
        actualAttr = keys[Math.floor(Math.random() * keys.length)];
      }

      const prevStreak = (data.streaks && data.streaks[actualAttr] != null) ? (Number(data.streaks[actualAttr]) || 0) : 0;
      const simStreak = prevStreak + 1;
      let bonus = simStreak === 3 ? 5 : (simStreak === 5 ? 10 : 0);
      let actualVal = baseVal + bonus;
      if (data.debuffs?.Poison > 0) actualVal = Math.floor(actualVal / Math.pow(2, data.debuffs.Poison));

      if (data.streaks && data.streaks[actualAttr] != null) {
        for (const key in data.streaks) data.streaks[key] = 0;
        data.streaks[actualAttr] = simStreak === 5 ? 0 : simStreak;
        batchState.comboCount = simStreak;
      } else {
        batchState.comboCount = 0;
      }

      data.totalXP += actualVal;
      if (data.totalXP < 0) data.totalXP = 0;
      if (actualAttr !== 'random') addAttributeXP(data, actualAttr, baseVal);

      if (!data.attr_event_counts) data.attr_event_counts = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
      if (actualAttr && data.attr_event_counts[actualAttr] != null) {
        data.attr_event_counts[actualAttr] = (Number(data.attr_event_counts[actualAttr]) || 0) + 1;
      }
      data.logs.push({ timestamp: Date.now(), action_type: 'batch_action', points_added: actualVal, detail: `[批量加分] ${action.name} -> +${actualVal}XP (${CONSTANTS.ATTRIBUTES[actualAttr]?.name || '特殊'})` });
      data = processEvolution(data);

      currentState.studentData = data;
      updateBatchHeader(data);
      const attrInfo = CONSTANTS.ATTRIBUTES[actualAttr] || {};
      const attrName = attrInfo.name || '特殊';
      const isPenalty = actualVal < 0;
      const uiColor = isPenalty ? 'var(--danger)' : (attrInfo.color || 'var(--warning)');
      const xpLabel = getProfileLabels(data).xp || '成長能量';
      const signVal = actualVal > 0 ? `+${actualVal}` : `${actualVal}`;
      setBatchPanelFlash(uiColor);
      setBatchPhase(isPenalty ? 'PENALTY APPLIED' : 'BOOST APPLIED', `${action.name}｜${attrName}`, uiColor);
      setBatchFeedback({
        title: `[ ${action.name} ] ${isPenalty ? '已判定' : '已觸發'}`,
        value: `${signVal} 點${xpLabel}`,
        detail: `${isPenalty ? '扣分' : '加分'}感應成功｜屬性：${attrName}${bonus > 0 ? `｜連續加成 +${bonus}` : ''}`,
        badge: isPenalty ? 'PENALTY SUCCESS' : 'XP SUCCESS',
        color: uiColor,
        burst: signVal
      });
      setBatchComboDisplay(uiColor);
      batchApi.startBatchTimer();
      await batchApi.persistBatchStudentData(data, batchState.activeStudentUid);
    }
  };

  return batchApi;
}
