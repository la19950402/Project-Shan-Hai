import { UI } from "../core/ui.js?v=phase15phase91fix3teachersavecheck";
import { currentState } from "../core/state.js?v=phase15phase91fix3teachersavecheck";

const AI_GUIDE_ENABLED = false;

export function createContentProfileModule({ COLLECTION_NAME, STUDENT_PAGE_COLLECTION, CONSTANTS, normalizeSerial, getActiveTokenForSerial, applyDataMigration, saveToDB, refreshStudentRewardPanel }) {
  const contentProfileApi = {
    getProfilePayloadFromForm() {
      const profileId = document.getElementById('profileSelect')?.value || 'shanhai';
      const uiVariant = document.getElementById('profileVariantSelect')?.value || (profileId === 'cat' ? 'muslim_friendly' : 'default');
      const currentGuideMode = String(currentState.studentData?.guide_mode || '').trim() || (profileId === 'cat' ? 'cat' : 'baize');
      const currentGuideModeLocked = currentState.studentData?.guide_mode_locked !== false;
      const guideMode = AI_GUIDE_ENABLED
        ? (document.getElementById('guideModeSelect')?.value || (profileId === 'cat' ? 'cat' : 'baize'))
        : currentGuideMode;
      const guideModeLocked = AI_GUIDE_ENABLED
        ? (document.getElementById('guideModeLocked')?.checked !== false)
        : currentGuideModeLocked;
      return {
        content_profile_id: profileId,
        ui_variant: uiVariant,
        guide_mode: guideMode,
        guide_mode_locked: guideModeLocked,
        profile_flags: {
          hide_fantasy: !!document.getElementById('flagHideFantasy')?.checked,
          use_cat_theme: !!document.getElementById('flagUseCatTheme')?.checked,
          use_safe_random_label: !!document.getElementById('flagSafeRandom')?.checked
        }
      };
    },
    async applyCurrentStudentProfile() {
      const serial = normalizeSerial(currentState.currentUid || currentState.studentData?.card_seq);
      if (!serial) return UI.toast('請先讀取學生資料');
      const payload = contentProfileApi.getProfilePayloadFromForm();
      try {
        const baseData = applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || {})));
        const next = Object.assign({}, baseData, payload, { card_seq: serial, serial });
        const saved = await saveToDB(next, serial);
        const normalized = applyDataMigration(saved || next);
        currentState.studentData = normalized;
        UI.updatePanel(normalized, currentState.viewMode === 'student');
        UI.toast(`✅ 已套用${payload.content_profile_id === 'cat' ? '貓咪版' : '山海版'}顯示設定`);
      } catch (e) {
        console.error(e);
        UI.alert('寫入顯示設定失敗：' + (e.message || e), '設定失敗');
      }
    },
    quickApplyCatProfile() {
      const sel = document.getElementById('profileSelect'); if (sel) sel.value = 'cat';
      const variant = document.getElementById('profileVariantSelect'); if (variant) variant.value = 'muslim_friendly';
      if (AI_GUIDE_ENABLED) {
        const guideSel = document.getElementById('guideModeSelect'); if (guideSel) guideSel.value = 'cat';
        const guideLocked = document.getElementById('guideModeLocked'); if (guideLocked) guideLocked.checked = true;
      }
      const f1 = document.getElementById('flagHideFantasy'); if (f1) f1.checked = true;
      const f2 = document.getElementById('flagUseCatTheme'); if (f2) f2.checked = true;
      const f3 = document.getElementById('flagSafeRandom'); if (f3) f3.checked = true;
    },
    quickApplyShanhaiProfile() {
      const sel = document.getElementById('profileSelect'); if (sel) sel.value = 'shanhai';
      const variant = document.getElementById('profileVariantSelect'); if (variant) variant.value = 'default';
      if (AI_GUIDE_ENABLED) {
        const guideSel = document.getElementById('guideModeSelect'); if (guideSel) guideSel.value = 'baize';
        const guideLocked = document.getElementById('guideModeLocked'); if (guideLocked) guideLocked.checked = true;
      }
      const f1 = document.getElementById('flagHideFantasy'); if (f1) f1.checked = false;
      const f2 = document.getElementById('flagUseCatTheme'); if (f2) f2.checked = false;
      const f3 = document.getElementById('flagSafeRandom'); if (f3) f3.checked = false;
    },
    async activateHiddenEggFromArchive() {
      try {
        const index = Number(currentState.archiveIndex);
        const col = Array.isArray(currentState.studentData?.collection) ? currentState.studentData.collection : [];
        const item = Number.isFinite(index) ? col[index] : null;
        if (!item || item.type !== 'hidden_egg') {
          UI.toast('請先在收藏區選擇一顆特殊異獸蛋');
          return;
        }
        const eggKey = String(item.hiddenEggId || item.id || '').trim();
        const eggMeta = CONSTANTS.HIDDEN_EGGS[eggKey] || item;
        const confirmed = await UI.confirm(`要將「${eggMeta.name || '特殊異獸蛋'}」設為目前正在孵化的蛋嗎？

這會取代目前畫面上的一般龍蛋外觀，但會沿用你現在已有的經驗、成長階段與進化節奏。`, '切換目前蛋');
        if (!confirmed) return;
        let data = applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || {})));
        data.hidden_eggs = Array.isArray(data.hidden_eggs) ? data.hidden_eggs : [];
        data.collection = Array.isArray(data.collection) ? data.collection : [];
        data.active_hidden_egg_id = eggKey;
        const normalizedEgg = { ...item, hiddenEggId: eggKey, forms: eggMeta.forms || item.forms || null, img: item.img || eggMeta.img || '', status: 'active', activatedAt: Date.now() };
        data.active_hidden_egg = normalizedEgg;
        let matched = false;
        data.hidden_eggs = data.hidden_eggs.map(entry => {
          const same = String(entry.hiddenEggId || entry.id || '') === eggKey;
          if (same) matched = true;
          return same ? { ...entry, ...normalizedEgg, status: 'active', activatedAt: Date.now() } : { ...entry, status: entry.status === 'active' ? 'incubating' : entry.status };
        });
        if (!matched) data.hidden_eggs.push(normalizedEgg);
        data.collection = data.collection.map((entry) => {
          if (!entry || entry.type !== 'hidden_egg') return entry;
          const same = String(entry.hiddenEggId || entry.id || '') === eggKey;
          return same ? { ...entry, ...normalizedEgg, status: 'active', activatedAt: Date.now() } : { ...entry, status: entry.status === 'active' ? 'incubating' : entry.status };
        });
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        data.logs.push({ timestamp: Date.now(), action_type: 'hidden_egg', detail: `[特殊異獸蛋] 已將 ${eggMeta.name || '特殊異獸蛋'} 設為目前孵化中的蛋` });
        const saved = await saveToDB(data);
        if (!saved) {
          UI.alert('切換失敗', '特殊異獸蛋外觀沒有成功寫入資料庫，請稍後再試或通知老師。');
          return;
        }
        if (typeof refreshStudentRewardPanel === 'function') refreshStudentRewardPanel(saved, true);
        UI.updateCollectionGallery(saved, 'collectionGallery');
        UI.hideModal('archiveModal');
        UI.toast(`已切換為 ${eggMeta.name || '特殊異獸蛋'}`);
      } catch (e) {
        console.error('[activateHiddenEggFromArchive] failed:', e);
        UI.alert('切換失敗', e?.message || '未知錯誤');
      }
    }
  };

  return contentProfileApi;
}

