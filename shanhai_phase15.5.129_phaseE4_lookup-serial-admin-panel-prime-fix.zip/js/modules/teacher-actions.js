import { currentState } from "../core/state.js?v=phase15phase91fix3teachersavecheck";
import { UI } from "../core/ui.js?v=phase15phase91fix3teachersavecheck";
import { pickElementsById } from "../core/dom-contract.js?v=phase15phase91fix3teachersavecheck";

export function createTeacherActionsModule({ CONSTANTS, ELEMENT_KEYS, auth, db, doc, getDoc, buildRewardEventId, applyRewardEventToData, getProfileLabels, addAttributeXP, saveToDB, processEvolution, isCurrentUserAdmin, normalizeSerial, applyDataMigration, refreshStudentIdentityLabels, refreshStudentRewardPanel, startWebNfc, backToDashboard, validateEvolutionTree, getActionCardPayload, bindPendingForgeActionCard, resolveStudentRecordFromScanKey }) {
  function resetCardForgeUi(app) {
    currentState.pendingForgeData = null;
    currentState.cardForgeMode = 'xp';
    const nameEl = document.getElementById('cfName');
    const valueEl = document.getElementById('cfValue');
    const debuffNameEl = document.getElementById('cfDebuffName');
    const debuffStacksEl = document.getElementById('cfDebuffStacks');
    const debuffKeyEl = document.getElementById('cfDebuffKey');
    if (nameEl) nameEl.value = '';
    if (valueEl) valueEl.value = '5';
    if (debuffNameEl) debuffNameEl.value = '';
    if (debuffStacksEl) debuffStacksEl.value = '1';
    if (debuffKeyEl) debuffKeyEl.value = 'Poison';
    if (typeof app.initCardForgePresets === 'function') app.initCardForgePresets();
    if (typeof app.setCardForgeMode === 'function') app.setCardForgeMode('xp');
  }

  function cloneData(data) {
    return JSON.parse(JSON.stringify(data || {}));
  }

  function ensureLogs(data) {
    if (!Array.isArray(data.logs)) data.logs = [];
    return data.logs;
  }

  function ensureDebuffs(data) {
    if (!data.debuffs || typeof data.debuffs !== 'object') {
      data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
    }
    return data.debuffs;
  }

  function getTeacherActionDom() {
    return pickElementsById({
      confirmBtn: 'confirmActionBtn',
      cancelBtn: 'cancelActionBtn',
      forgeModal: 'cardForgeModal',
      forgeStartBtn: 'cfStartBtn',
      forgeCancelBtn: 'cfCancelBtn',
      previewText: 'previewText'
    });
  }

  function setActionButtonsDisabled(disabled) {
    const { confirmBtn, cancelBtn } = getTeacherActionDom();
    if (confirmBtn) confirmBtn.disabled = !!disabled;
    if (cancelBtn) cancelBtn.disabled = !!disabled;
  }

  function setForgeButtonsDisabled(disabled) {
    const { forgeStartBtn, forgeCancelBtn } = getTeacherActionDom();
    if (forgeStartBtn) forgeStartBtn.disabled = !!disabled;
    if (forgeCancelBtn) forgeCancelBtn.disabled = !!disabled;
  }

  function getTeacherActiveSerial() {
    return normalizeSerial(
      currentState.teacherTargetContext?.serial ||
      currentState.teacherTargetContext?.currentUid ||
      currentState.currentUid ||
      currentState.studentData?.card_seq ||
      currentState.studentData?.serial
    );
  }

  function clearStaleTeacherActionState(nextSerial = null) {
    const normalizedNext = normalizeSerial(nextSerial);
    const pendingSerial = normalizeSerial(currentState.pendingAction?.targetSerial);
    if (pendingSerial && normalizedNext && pendingSerial !== normalizedNext) {
      closePreviewState();
    }
    const forgeSerial = normalizeSerial(currentState.pendingForgeData?.targetSerial);
    if (forgeSerial && normalizedNext && forgeSerial !== normalizedNext) {
      currentState.pendingForgeData = null;
      if (currentState.scanIntention === 'forge') currentState.scanIntention = 'read';
      try { UI.hideModal('cardForgeModal'); } catch (_) {}
      try { UI.hide('cfWaitArea'); UI.show('cfFormArea'); } catch (_) {}
    }
  }

  function isFirestoreOfflineLikeError(err) {
    const code = String(err?.code || '').toLowerCase();
    const msg = String(err?.message || err || '').toLowerCase();
    return (
      code === 'unavailable' ||
      msg.includes('client is offline') ||
      msg.includes('could not reach cloud firestore backend') ||
      msg.includes('transport errored')
    );
  }

  function canApplyTeacherTargetResult(serial, { allowEmptyActive = true } = {}) {
    const normalized = normalizeSerial(serial);
    if (!normalized) return false;
    const activeSerial = getTeacherActiveSerial();
    if (!activeSerial) return !!allowEmptyActive;
    return activeSerial === normalized;
  }

  function applyTeacherTargetSelection(data, options = {}) {
    const normalized = normalizeTeacherTargetData(applyDataMigration({ ...(data || {}) }));
    const serial = resolveTeacherTargetSerial(normalized, options.serial || null);
    if (!normalized || !serial) return null;
    const prevSerial = getTeacherActiveSerial();
    if (prevSerial && prevSerial !== serial) clearStaleTeacherActionState(serial);
    currentState.scanIntention = options.scanIntention || 'read';
    currentState.currentUid = serial;
    currentState.studentData = normalized;
    syncTeacherTargetContext(normalized, {
      source: options.source || 'teacher-actions:select-target',
      action: options.action || 'select-target',
      serial,
      hydrated: options.hydrated != null ? !!options.hydrated : true,
      lookup: options.lookup === true,
      clearError: options.clearError !== false
    });
    if (options.showAdminPanel !== false) UI.show('adminStudentPanel');
    if (options.updatePanel !== false) UI.updatePanel(normalized, false);
    if (options.refreshIdentity !== false) {
      try {
        if (typeof refreshStudentIdentityLabels === 'function') refreshStudentIdentityLabels(normalized);
      } catch (refreshErr) {
        console.warn('[teacher-actions] applyTeacherTargetSelection refreshStudentIdentityLabels failed:', refreshErr?.message || refreshErr);
      }
    }
    if (options.initActionGrid !== false) {
      try {
        if (typeof UI.initActionGrid === 'function') UI.initActionGrid();
      } catch (gridErr) {
        console.warn('[teacher-actions] applyTeacherTargetSelection initActionGrid failed:', gridErr?.message || gridErr);
      }
    }
    return normalized;
  }

  async function lookupTeacherTargetBySerial(rawSerial, options = {}) {
    if (currentState.teacherActionSubmitting && options.allowDuringSubmit !== true) {
      UI.toast('上一筆老師端保存尚在進行中，請稍候。');
      return null;
    }
    const serial = normalizeSerial(String(rawSerial || '').trim());
    if (!serial) {
      if (options.silent !== true) UI.toast('卡序格式錯誤');
      return null;
    }
    const source = options.source || 'teacher-actions:lookup-by-serial';
    const action = options.action || 'lookup-by-serial';
    try {
      const snap = await getDoc(doc(db, 'students', serial));
      if (!snap.exists()) {
        syncTeacherTargetContext(null, { source, action: `${action}-miss`, serial, hydrated: false, hasStudentData: false, lookup: true, error: `student-not-found:${serial}` });
        if (options.silent !== true) UI.alert(`查無卡序 #${serial} 的學生資料。`, '查無學生');
        return null;
      }
      const selectedData = normalizeTeacherTargetData(applyDataMigration({ serial, card_seq: serial, ...(snap.data() || {}) }));
      if (!selectedData) return null;
      if (options.deferSelection === true) {
        const prevSerial = getTeacherActiveSerial();
        if (prevSerial && prevSerial !== serial) clearStaleTeacherActionState(serial);
        currentState.scanIntention = options.scanIntention || 'read';
        syncTeacherTargetContext(selectedData, {
          source,
          action: `${action}-resolved`,
          serial,
          hydrated: true,
          lookup: true,
          clearError: true
        });
        if (options.showAdminPanel === true) UI.show('adminStudentPanel');
        return selectedData;
      }
      const selected = applyTeacherTargetSelection(selectedData, {
        serial,
        source,
        action: `${action}-success`,
        hydrated: true,
        lookup: true,
        showAdminPanel: options.showAdminPanel !== false,
        updatePanel: options.updatePanel !== false,
        refreshIdentity: options.refreshIdentity !== false,
        initActionGrid: options.initActionGrid !== false,
        clearError: true
      });
      return selected;
    } catch (e) {
      console.error('[teacher-actions] lookupTeacherTargetBySerial failed:', e);
      if (isFirestoreOfflineLikeError(e)) {
        const liveSerial = normalizeSerial(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid || '');
        const fallbackData = liveSerial && liveSerial === serial ? currentState.studentData : null;
        syncTeacherTargetContext(fallbackData || currentState.studentData, {
          source,
          action: `${action}-offline`,
          serial,
          hydrated: Boolean(fallbackData || currentState.studentData),
          hasStudentData: Boolean(fallbackData || currentState.studentData),
          lookup: true,
          error: 'firestore-offline'
        });
        if (options.silent !== true) UI.toast('目前網路或 Firestore 連線異常，暫停查卡序。');
        return fallbackData || null;
      }
      syncTeacherTargetContext(currentState.studentData, { source, action: `${action}-error`, serial, hydrated: Boolean(currentState.studentData), hasStudentData: Boolean(currentState.studentData), lookup: true, error: e?.message || e });
      if (options.silent !== true) UI.alert(e?.message || '查詢時發生錯誤，請稍後再試。', '查詢失敗');
      return null;
    }
  }

  async function adoptTeacherSavedResult(app, saved, serial, options = {}) {
    const normalizedSerial = normalizeSerial(serial || resolveTeacherTargetSerial(saved));
    const normalizedSaved = teacherApi.ensureTeacherTargetData(saved) || saved;
    if (!normalizedSaved || !normalizedSerial) return null;
    const canBind = options.forceBind === true || canApplyTeacherTargetResult(normalizedSerial, { allowEmptyActive: true });
    if (canBind) {
      currentState.currentUid = normalizedSerial;
      currentState.studentData = normalizedSaved;
      syncTeacherTargetContext(normalizedSaved, {
        source: options.source || 'teacher-actions:adopt-saved-result',
        action: options.action || 'adopt-saved-result',
        serial: normalizedSerial,
        hydrated: true,
        saved: options.saved !== false,
        clearError: true
      });
      await refreshTeacherViews(app, currentState.studentData, { isStudentMode: currentState.viewMode === 'student' });
      return currentState.studentData;
    }
    console.info(`[teacher-actions] saved result preserved for #${normalizedSerial}, active target already switched.`);
    return normalizedSaved;
  }

  function getTeacherTargetContextBase() {
    const base = currentState.teacherTargetContext;
    if (base && typeof base === 'object') return base;
    currentState.teacherTargetContext = {
      serial: null,
      currentUid: null,
      studentName: '',
      source: '',
      action: '',
      hydrated: false,
      hasStudentData: false,
      activeToken: null,
      lastResolvedAt: 0,
      lastLookupAt: 0,
      lastHydratedAt: 0,
      lastSavedAt: 0,
      lastError: ''
    };
    return currentState.teacherTargetContext;
  }

  function syncTeacherTargetDiagnostics(snapshot) {
    try {
      const diagBase = (window.__BOOT_DIAG && typeof window.__BOOT_DIAG === 'object') ? window.__BOOT_DIAG : {};
      window.__BOOT_DIAG = {
        ...diagBase,
        teacherTargetContext: {
          serial: snapshot.serial || '',
          currentUid: snapshot.currentUid || '',
          studentName: snapshot.studentName || '',
          source: snapshot.source || '',
          action: snapshot.action || '',
          hydrated: Boolean(snapshot.hydrated),
          hasStudentData: Boolean(snapshot.hasStudentData),
          activeToken: snapshot.activeToken || '',
          lastResolvedAt: Number(snapshot.lastResolvedAt) || 0,
          lastLookupAt: Number(snapshot.lastLookupAt) || 0,
          lastHydratedAt: Number(snapshot.lastHydratedAt) || 0,
          lastSavedAt: Number(snapshot.lastSavedAt) || 0,
          lastError: snapshot.lastError || ''
        }
      };
    } catch (_) {}
  }

  function normalizeTeacherTargetData(data) {
    const src = data;
    if (!src || typeof src !== 'object') return null;
    if (!src.attributes || typeof src.attributes !== 'object') src.attributes = {};
    if (!src.streaks || typeof src.streaks !== 'object') src.streaks = {};
    if (!src.logs || !Array.isArray(src.logs)) src.logs = [];
    if (!src.debuffs || typeof src.debuffs !== 'object') src.debuffs = {};
    if (!src.attr_event_counts || typeof src.attr_event_counts !== 'object') {
      src.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
    }
    for (const key of ELEMENT_KEYS) {
      src.attributes[key] = Number(src.attributes[key]) || 0;
      src.streaks[key] = Number(src.streaks[key]) || 0;
      if (src.attr_event_counts[key] == null) src.attr_event_counts[key] = 0;
    }
    src.totalXP = Number(src.totalXP) || 0;
    src.coins = Number(src.coins) || 0;
    return src;
  }

  function syncTeacherTargetContext(data = null, options = {}) {
    const base = getTeacherTargetContextBase();
    const serial = normalizeSerial(
      options.serial ||
      data?.card_seq ||
      data?.serial ||
      base.serial ||
      currentState.currentUid ||
      currentState.studentData?.card_seq ||
      currentState.studentData?.serial
    );
    const currentUid = normalizeSerial(options.currentUid || currentState.currentUid || serial || base.currentUid);
    const now = Number(options.timestamp) || Date.now();
    const source = String(options.source || base.source || '').trim();
    const action = String(options.action || base.action || '').trim();
    const studentName = String(options.studentName || data?.name || currentState.studentData?.name || base.studentName || '').trim();
    const hasStudentData = options.hasStudentData != null ? !!options.hasStudentData : Boolean(data || currentState.studentData);
    const hydrated = options.hydrated != null ? !!options.hydrated : (Boolean(data) || Boolean(base.hydrated));
    const snapshot = {
      serial: serial || null,
      currentUid: currentUid || null,
      studentName,
      source,
      action,
      hydrated,
      hasStudentData,
      activeToken: options.activeToken != null ? options.activeToken : (currentState.currentToken || base.activeToken || null),
      lastResolvedAt: options.touch === false ? (Number(base.lastResolvedAt) || 0) : now,
      lastLookupAt: options.lookup ? now : (Number(base.lastLookupAt) || 0),
      lastHydratedAt: options.hydrated ? now : (Number(base.lastHydratedAt) || 0),
      lastSavedAt: options.saved ? now : (Number(base.lastSavedAt) || 0),
      lastError: String(options.error != null ? options.error : (options.clearError ? '' : (base.lastError || ''))).trim()
    };
    currentState.teacherTargetContext = snapshot;
    syncTeacherTargetDiagnostics(snapshot);
    return snapshot;
  }

  function resolveTeacherTargetSerial(data, explicitSerial = null) {
    return normalizeSerial(
      explicitSerial ||
      data?.card_seq ||
      data?.serial ||
      currentState.teacherTargetContext?.serial ||
      currentState.teacherTargetContext?.currentUid ||
      currentState.studentData?.card_seq ||
      currentState.studentData?.serial ||
      currentState.currentUid
    );
  }

  function resolveTeacherMutationSerial(preferredData = null, explicitSerial = null) {
    return normalizeSerial(
      explicitSerial ||
      currentState.teacherTargetContext?.serial ||
      currentState.teacherTargetContext?.currentUid ||
      currentState.studentLoadActiveSerial ||
      preferredData?.card_seq ||
      preferredData?.serial ||
      currentState.studentData?.card_seq ||
      currentState.studentData?.serial ||
      currentState.currentUid ||
      currentState.studentLoadRequestedUid
    );
  }

  async function waitForStudentHydrationTarget(serial, { timeoutMs = 900 } = {}) {
    const normalized = normalizeSerial(serial);
    if (!normalized || !currentState.studentHydrationPending) return false;
    const activeLoadSerial = normalizeSerial(currentState.studentLoadActiveSerial || currentState.studentLoadRequestedUid || '');
    const activeContextSerial = normalizeSerial(currentState.teacherTargetContext?.serial || currentState.teacherTargetContext?.currentUid || '');
    if (activeLoadSerial && activeLoadSerial !== normalized && activeContextSerial && activeContextSerial !== normalized) {
      return false;
    }
    const startedAt = Date.now();
    while (Date.now() - startedAt < Math.max(200, Number(timeoutMs) || 900)) {
      const liveSerial = normalizeSerial(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid || '');
      if (!currentState.studentHydrationPending && liveSerial === normalized) return true;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    return false;
  }

  async function hydrateTeacherTargetData(preferredData = null, { silent = false, explicitSerial = null, source = 'teacher-actions:hydrate', action = 'hydrate', lookup = false } = {}) {
    const requestedSerial = normalizeSerial(explicitSerial || '');
    const existing = normalizeTeacherTargetData(preferredData || currentState.studentData);
    const existingOwnSerial = normalizeSerial(existing?.card_seq || existing?.serial || '');
    const canReuseExisting = Boolean(existing && existingOwnSerial && (!requestedSerial || existingOwnSerial === requestedSerial));
    if (canReuseExisting) {
      if (canApplyTeacherTargetResult(existingOwnSerial, { allowEmptyActive: true })) {
        currentState.currentUid = existingOwnSerial;
        currentState.studentData = existing;
      }
      syncTeacherTargetContext(existing, { source, action, serial: existingOwnSerial, hydrated: true, lookup, clearError: true });
      return existing;
    }

    const serial = requestedSerial || resolveTeacherTargetSerial(preferredData, null);
    if (!serial) {
      syncTeacherTargetContext(preferredData || null, { source, action, serial: explicitSerial, hydrated: false, hasStudentData: false, error: 'missing-serial' });
      if (!silent) UI.alert('請先感應或讀取學生卡片，再進行老師端操作。', '尚未載入學生');
      return null;
    }

    try {
      const snap = await getDoc(doc(db, 'students', serial));
      if (!snap.exists()) {
        syncTeacherTargetContext(preferredData || null, { source, action, serial, hydrated: false, hasStudentData: false, error: `student-not-found:${serial}` });
        if (!silent) UI.alert(`查無卡序 #${serial} 的學生資料。`, '查無學生');
        return null;
      }
      const hydrated = normalizeTeacherTargetData(applyDataMigration({ serial, card_seq: serial, ...(snap.data() || {}) }));
      if (!hydrated) return null;
      if (canApplyTeacherTargetResult(serial, { allowEmptyActive: true })) {
        currentState.currentUid = serial;
        currentState.studentData = hydrated;
      }
      syncTeacherTargetContext(hydrated, { source, action, serial, hydrated: true, lookup, clearError: true });
      return hydrated;
    } catch (e) {
      console.error('[teacher-actions] hydrateTeacherTargetData failed:', e);
      syncTeacherTargetContext(preferredData || null, { source, action, serial, hydrated: false, hasStudentData: Boolean(preferredData || currentState.studentData), error: e?.message || e });
      if (!silent) UI.alert(e?.message || '重新讀取學生資料失敗，請稍後再試。', '讀取失敗');
      return null;
    }
  }


  async function persistTeacherData(data, explicitSerial = null, options = {}) {
    const serial = normalizeSerial(explicitSerial || resolveTeacherTargetSerial(data) || currentState.currentUid);
    if (!serial) throw new Error('找不到學生卡序，無法保存老師端操作。');
    const saved = await saveToDB(data, serial);
    if (saved && typeof saved === 'object') {
      const normalizedSaved = teacherApi.ensureTeacherTargetData(saved) || saved;
      const canBind = options.forceBind === true || canApplyTeacherTargetResult(serial, { allowEmptyActive: true });
      if (canBind) {
        currentState.currentUid = serial;
        currentState.studentData = normalizedSaved;
        syncTeacherTargetContext(currentState.studentData, {
          source: options.source || 'teacher-actions:persist',
          action: options.action || 'save',
          serial,
          hydrated: true,
          saved: true,
          clearError: true
        });
      } else {
        console.info(`[teacher-actions] persistTeacherData saved #${serial} without rebinding active view.`);
      }
      return normalizedSaved;
    }
    syncTeacherTargetContext(data, {
      source: options.source || 'teacher-actions:persist',
      action: options.action || 'save',
      serial,
      hydrated: Boolean(data),
      saved: true,
      clearError: true
    });
    return saved;
  }
  function closePreviewState() {
    UI.hideModal('previewPanel');
    currentState.pendingAction = null;
  }

  function getAttrInfo(attr) {
    return CONSTANTS.ATTRIBUTES?.[attr] || { name: attr || '未知屬性', color: 'var(--cyan)' };
  }


  async function runTeacherMutation(app, options = {}) {
    const {
      preferredData = null,
      explicitSerial = null,
      source = 'teacher-actions:run-mutation',
      action = 'run-mutation',
      failureTitle = '保存失敗',
      successToast = '',
      forceBind = false,
      silentHydrate = false,
      mutate = null,
      afterSave = null
    } = options || {};
    if (currentState.teacherActionSubmitting) {
      UI.toast('上一筆老師端保存尚在進行中，請稍候。');
      return null;
    }
    if (typeof mutate !== 'function') {
      throw new Error('缺少老師端 mutation callback。');
    }
    currentState.teacherActionSubmitting = true;
    try {
      const resolvedSerial = resolveTeacherMutationSerial(preferredData || currentState.studentData, explicitSerial);
      if (resolvedSerial && currentState.studentHydrationPending) {
        await waitForStudentHydrationTarget(resolvedSerial, { timeoutMs: 900 });
      }
      const base = await hydrateTeacherTargetData(preferredData || currentState.studentData, {
        explicitSerial: resolvedSerial || explicitSerial,
        silent: silentHydrate,
        source,
        action
      });
      if (!base) return null;
      const serial = normalizeSerial(resolvedSerial || explicitSerial || resolveTeacherTargetSerial(base));
      if (!serial) throw new Error('找不到學生卡序，無法保存老師端操作。');
      syncTeacherTargetContext(base, {
        source,
        action,
        serial,
        hydrated: true,
        clearError: true,
        activeToken: currentState.studentLoadToken || currentState.currentToken || null
      });
      let working = cloneData(base);
      const mutationResult = await mutate(working, { base, serial, source, action, app });
      if (mutationResult === false || mutationResult?.applied === false) return null;
      if (mutationResult && typeof mutationResult === 'object' && mutationResult.data && mutationResult.data !== working) {
        working = cloneData(mutationResult.data);
      }
      const normalizedWorking = teacherApi.ensureTeacherTargetData(working) || working;
      const saved = await persistTeacherData(normalizedWorking, serial, { source, action, forceBind });
      if (!saved) throw new Error('資料未成功寫入，請稍後再試。');
      const adopted = await adoptTeacherSavedResult(app, saved, serial, { source, action, forceBind });
      if (typeof afterSave === 'function') {
        await afterSave(adopted || saved, {
          base,
          serial,
          source,
          action,
          mutationResult,
          app,
          saved
        });
      }
      const toastText = typeof successToast === 'function'
        ? successToast({ base, serial, saved: adopted || saved, mutationResult })
        : String(successToast || '').trim();
      if (toastText) UI.toast(toastText);
      return { applied: true, serial, saved: adopted || saved, mutationResult };
    } catch (e) {
      console.error('[teacher-actions] runTeacherMutation failed:', e);
      UI.alert(e?.message || '未知錯誤', failureTitle);
      return null;
    } finally {
      currentState.teacherActionSubmitting = false;
    }
  }

  async function refreshTeacherViews(app, latestData, opts = {}) {
    const data = latestData && typeof latestData === 'object' ? latestData : currentState.studentData;
    if (!data || typeof data !== 'object') return;
    const isStudentMode = opts.isStudentMode != null ? !!opts.isStudentMode : currentState.viewMode === 'student';
    try {
      if (typeof refreshStudentIdentityLabels === 'function') refreshStudentIdentityLabels(data);
      else if (typeof app.refreshStudentIdentityLabels === 'function') app.refreshStudentIdentityLabels(data);
    } catch (e) {
      console.warn('[teacher-actions] refreshStudentIdentityLabels failed:', e?.message || e);
    }
    try {
      if (typeof refreshStudentRewardPanel === 'function') {
        refreshStudentRewardPanel(data, isStudentMode);
      } else if (typeof app.refreshStudentRewardPanel === 'function') {
        app.refreshStudentRewardPanel(data, isStudentMode);
      } else if (typeof UI.updatePanel === 'function') {
        UI.updatePanel(data, isStudentMode);
      }
    } catch (e) {
      console.warn('[teacher-actions] reward/panel refresh failed:', e?.message || e);
    }
    try {
      if (typeof UI.updateCollectionGallery === 'function') UI.updateCollectionGallery(data, 'collectionGallery');
    } catch (e) {
      console.warn('[teacher-actions] collection refresh failed:', e?.message || e);
    }
  }

  const teacherApi = {
    setCardForgeMode(mode) {
      currentState.cardForgeMode = (mode === 'debuff') ? 'debuff' : 'xp';
      const xpBtn = document.getElementById('cfTabXpBtn');
      const debBtn = document.getElementById('cfTabDebuffBtn');
      const xpForm = document.getElementById('cfXpForm');
      const debForm = document.getElementById('cfDebuffForm');
      if (!xpBtn || !debBtn || !xpForm || !debForm) return;
      if (currentState.cardForgeMode === 'xp') {
        UI.show('cfXpForm');
        UI.hide('cfDebuffForm');
        teacherApi.initCardForgePresets();
        if (typeof validateEvolutionTree === 'function') validateEvolutionTree();
        xpBtn.style.background = 'var(--color-grass)';
        xpBtn.style.color = '#000';
        debBtn.style.background = 'transparent';
        debBtn.style.color = 'var(--danger)';
        debBtn.style.borderColor = 'var(--danger)';
        xpBtn.style.borderColor = 'var(--color-grass)';
      } else {
        UI.hide('cfXpForm');
        UI.show('cfDebuffForm');
        debBtn.style.background = 'var(--danger)';
        debBtn.style.color = '#000';
        xpBtn.style.background = 'transparent';
        xpBtn.style.color = 'var(--color-grass)';
        xpBtn.style.borderColor = 'var(--color-grass)';
        debBtn.style.borderColor = 'var(--danger)';
      }
    },

    initCardForgePresets() {
      const presetSel = document.getElementById('cfXpPreset');
      if (presetSel) {
        presetSel.innerHTML = '';
        try {
          const entries = Object.entries(CONSTANTS.ACTION_LIST || {});
          for (const [attr, list] of entries) {
            const info = CONSTANTS.ATTRIBUTES[attr] || { icon: '✨', name: attr };
            const og = document.createElement('optgroup');
            og.label = `${info.icon} ${info.name}`;
            (list || []).forEach((act, idx) => {
              const opt = document.createElement('option');
              opt.value = `${attr}:${idx}`;
              opt.dataset.attr = attr;
              opt.dataset.val = String(act.val);
              opt.dataset.desc = String(act.desc || '');
              opt.textContent = `${act.desc} (+${act.val})`;
              og.appendChild(opt);
            });
            presetSel.appendChild(og);
          }
        } catch (e) {
          console.error(e);
        }
        presetSel.onchange = () => teacherApi.applyForgeXpPreset();
        teacherApi.applyForgeXpPreset();
      }
      const attrEl = document.getElementById('cfAttr');
      const valEl = document.getElementById('cfValue');
      if (attrEl) attrEl.disabled = true;
      if (valEl) valEl.disabled = true;
      const debKeyEl = document.getElementById('cfDebuffKey');
      const debNameEl = document.getElementById('cfDebuffName');
      const debStacksEl = document.getElementById('cfDebuffStacks');
      const autoDebuffName = () => {
        if (!debNameEl) return;
        const cur = (debNameEl.value || '').trim();
        if (cur) return;
        const key = debKeyEl ? debKeyEl.value : 'Poison';
        const zh = (CONSTANTS.DEBUFF_INFO[key] && CONSTANTS.DEBUFF_INFO[key].name) ? CONSTANTS.DEBUFF_INFO[key].name : key;
        debNameEl.value = `${zh}注入`;
      };
      if (debKeyEl) debKeyEl.onchange = autoDebuffName;
      if (debStacksEl) debStacksEl.oninput = autoDebuffName;
      autoDebuffName();
    },

    applyForgeXpPreset() {
      const presetSel = document.getElementById('cfXpPreset');
      if (!presetSel) return;
      const opt = presetSel.selectedOptions && presetSel.selectedOptions[0] ? presetSel.selectedOptions[0] : null;
      if (!opt) return;
      const attr = opt.dataset.attr;
      const val = opt.dataset.val;
      const desc = opt.dataset.desc;
      const nameEl = document.getElementById('cfName');
      const attrEl = document.getElementById('cfAttr');
      const valEl = document.getElementById('cfValue');
      if (attrEl && attr) attrEl.value = attr;
      if (valEl && val != null) valEl.value = val;
      if (nameEl) nameEl.value = desc || nameEl.value;
    },

    getTeacherTargetContext() {
      const snapshot = currentState.teacherTargetContext && typeof currentState.teacherTargetContext === 'object'
        ? { ...currentState.teacherTargetContext }
        : { ...getTeacherTargetContextBase() };
      return Object.freeze(snapshot);
    },

    syncTeacherTargetContext(data, options = {}) {
      return syncTeacherTargetContext(data, options);
    },

    applyTeacherTargetSelection(data, options = {}) {
      return applyTeacherTargetSelection(data, options);
    },

    async lookupTeacherTargetBySerial(rawSerial, options = {}) {
      return await lookupTeacherTargetBySerial(rawSerial, options);
    },

    clearTeacherTargetContext(reason = 'manual-clear') {
      return syncTeacherTargetContext(null, {
        source: `teacher-actions:${String(reason || 'manual-clear').trim() || 'manual-clear'}`,
        action: 'clear-target',
        serial: null,
        currentUid: null,
        hydrated: false,
        hasStudentData: false,
        activeToken: null,
        error: '',
        clearError: true
      });
    },

    diagnoseTeacherTarget(options = {}) {
      return Object.freeze({
        ...syncTeacherTargetContext(options.data || currentState.studentData || null, {
          source: options.source || 'teacher-actions:diagnose',
          action: options.action || 'diagnose-target',
          serial: options.serial || null,
          hydrated: options.hydrated != null ? !!options.hydrated : Boolean(options.data || currentState.studentData),
          hasStudentData: options.hasStudentData != null ? !!options.hasStudentData : Boolean(options.data || currentState.studentData),
          touch: false,
          error: options.error != null ? options.error : undefined,
          clearError: options.clearError === true
        })
      });
    },

    ensureTeacherTargetData(data) {
      const src = normalizeTeacherTargetData(data || currentState.studentData);
      if (!src) {
        UI.alert('請先感應或讀取學生卡片，再進行老師端加分。', '尚未載入學生');
        return null;
      }
      return src;
    },

    async openCardForge() {
      try {
        const target = await hydrateTeacherTargetData(currentState.studentData, { source: 'teacher-actions:openCardForge', action: 'open-card-forge' });
        if (!target) return false;
        syncTeacherTargetContext(target, { source: 'teacher-actions:openCardForge', action: 'open-card-forge', hydrated: true, clearError: true });
        const dom = getTeacherActionDom();
        if (!dom.forgeModal) {
          UI.alert('找不到巡堂加分視窗，請重新整理後再試。', '介面異常');
          return false;
        }
        UI.show('cfFormArea');
        UI.hide('cfWaitArea');
        resetCardForgeUi(this);
        UI.showModal('cardForgeModal');
        return false;
      } catch (e) {
        console.error('[card forge] open failed:', e);
        UI.alert(`加分框開啟失敗：${e?.message || e}`, '系統通知');
        return false;
      }
    },

    async startCardForge() {
      const target = await hydrateTeacherTargetData(currentState.studentData, { source: 'teacher-actions:startCardForge', action: 'start-card-forge' });
      if (!target) return;
      const targetSerial = resolveTeacherTargetSerial(target);
      syncTeacherTargetContext(target, { source: 'teacher-actions:startCardForge', action: 'start-card-forge', serial: targetSerial, hydrated: true, clearError: true });
      const mode = currentState.cardForgeMode || 'xp';
      setForgeButtonsDisabled(true);
      try {
        if (mode === 'debuff') {
          const keyEl = document.getElementById('cfDebuffKey');
          const stacksEl = document.getElementById('cfDebuffStacks');
          const nameEl = document.getElementById('cfDebuffName');
          const debuffKey = keyEl ? keyEl.value : 'Poison';
          const stacksRaw = stacksEl ? parseInt(stacksEl.value, 10) : 1;
          const stacks = Math.max(1, Math.min(5, Number.isFinite(stacksRaw) ? stacksRaw : 1));
          let nameVal = (nameEl ? nameEl.value : '').trim();
          if (!nameVal) {
            const zh = (CONSTANTS.DEBUFF_INFO[debuffKey] && CONSTANTS.DEBUFF_INFO[debuffKey].name) ? CONSTANTS.DEBUFF_INFO[debuffKey].name : debuffKey;
            nameVal = `${zh}注入`;
          }
          currentState.scanIntention = 'forge';
          currentState.pendingForgeData = { type: 'debuff', name: nameVal, debuffKey, stacks, targetSerial, targetName: String(target?.name || '').trim(), timestamp: Date.now() };
        } else {
          const nameVal = document.getElementById('cfName')?.value?.trim() || '';
          const attrVal = document.getElementById('cfAttr')?.value || '';
          const rawVal = parseInt(document.getElementById('cfValue')?.value || '0', 10) || 0;
          if (!nameVal) {
            UI.toast('請輸入動作名稱！');
            return;
          }
          if (!ELEMENT_KEYS.includes(attrVal)) {
            UI.alert('找不到有效屬性，請重新選擇加分動作後再試。', '參數錯誤');
            return;
          }
          if (!Number.isFinite(rawVal) || rawVal <= 0) {
            UI.alert('請輸入有效的加分數值。', '參數錯誤');
            return;
          }
          currentState.scanIntention = 'forge';
          currentState.pendingForgeData = {
            type: 'xp',
            name: nameVal,
            attr: attrVal,
            val: rawVal,
            targetSerial,
            targetName: String(target?.name || '').trim(),
            timestamp: Date.now()
          };
        }
        UI.hide('cfFormArea');
        UI.show('cfWaitArea');
        document.getElementById('usbScannerInput')?.focus();
        if (typeof startWebNfc === 'function') startWebNfc(true);
      } finally {
        setForgeButtonsDisabled(false);
      }
    },

    cancelCardForge() {
      currentState.scanIntention = 'read';
      currentState.pendingForgeData = null;
      syncTeacherTargetContext(currentState.studentData, { source: 'teacher-actions:cancelCardForge', action: 'cancel-card-forge', hydrated: Boolean(currentState.studentData), clearError: true });
      UI.hideModal('cardForgeModal');
      if (typeof backToDashboard === 'function') backToDashboard();
    },

    async handleForgeScan(rawKey) {
      if (!currentState.pendingForgeData) {
        UI.alert('鑄造資料遺失，請重新操作。', '系統異常');
        return false;
      }
      try {
        if (typeof bindPendingForgeActionCard !== 'function') {
          throw new Error('找不到 action card 綁定器');
        }
        await bindPendingForgeActionCard(rawKey);
        UI.hideModal('cardForgeModal');
        UI.toast('✅ 道具卡鑄造綁定成功！');
        if (typeof backToDashboard === 'function') backToDashboard();
        return true;
      } catch (e) {
        console.error('[teacher-actions] handleForgeScan failed:', e);
        UI.alert('寫入資料庫失敗！', '鑄造失敗');
        return false;
      }
    },

    async startStudentPropScan() {
      currentState.scanIntention = 'student_prop';
      const ok = typeof startWebNfc === 'function' ? await startWebNfc(true) : false;
      if (ok) UI.toast('🔮 巡堂道具模式已啟動，請直接感應道具卡！');
      return ok;
    },

    async handleStudentPropScan(rawKey) {
      const actionData = typeof getActionCardPayload === 'function' ? await getActionCardPayload(rawKey) : null;
      if (actionData) {
        await teacherApi.executeStudentPropAction.call(this, actionData);
        return true;
      }
      const resolved = typeof resolveStudentRecordFromScanKey === 'function'
        ? await resolveStudentRecordFromScanKey(rawKey, {
            requireActive: true,
            allowAdminUidFallback: true,
            setCurrentToken: true,
            notifyUidFallback: true
          })
        : { serial: null, data: null };
      if (resolved.serial && resolved.data) {
        UI.toast(`🔄 切換至學生：${resolved.data.name}`);
        window.history.replaceState(null, '', `?view=student&serial=${resolved.serial}`);
        if (typeof this.loadStudentData === 'function') {
          this.loadStudentData(resolved.serial, 'student', {
            preloadedData: resolved.data,
            primeView: true,
            serial: resolved.serial,
            source: 'teacher-actions:handleStudentPropScan'
          });
        }
        return true;
      }
      UI.toast('❌ 未知的卡片！');
      return false;
    },

    async executeStudentPropAction(action) {
      if (!currentState.studentData) return null;
      let data = cloneData(currentState.studentData);
      ensureLogs(data);

      if (action && (action.type === 'debuff' || action.debuffKey)) {
        const debuffKey = action.debuffKey || action.statusKey || action.debuff || 'Poison';
        const stacksRaw = parseInt(action.stacks, 10);
        const stacks = Math.max(1, Math.min(5, Number.isFinite(stacksRaw) ? stacksRaw : 1));
        ensureDebuffs(data);
        data.debuffs[debuffKey] = (data.debuffs[debuffKey] || 0) + stacks;
        data.debuffs_timestamp = Date.now();
        const info = CONSTANTS.DEBUFF_INFO[debuffKey] || { name: debuffKey, color: 'var(--danger)' };
        data.logs.push({ timestamp: Date.now(), action_type: 'prop_debuff', points_added: 0, detail: `[巡堂狀態] ${action.name} -> ${info.name} +${stacks}` });
        if (await teacherApi.checkDeathTrigger.call(this, data, debuffKey)) return currentState.studentData;
        const saved = await saveToDB(data);
        UI.toast(`⚠️ [${action.name}] 已疊加：${info.name} +${stacks}`);
        return saved;
      }

      let actualAttr = action?.attr;
      let actualVal = Number(action?.val) || 0;
      if (data.debuffs?.Confusion > 0) {
        const keys = Object.keys(CONSTANTS.ATTRIBUTES || {});
        if (keys.length) actualAttr = keys[Math.floor(Math.random() * keys.length)];
      }
      if (data.debuffs?.Poison > 0) actualVal = Math.floor(actualVal / Math.pow(2, data.debuffs.Poison));

      data.totalXP = Math.max(0, (Number(data.totalXP) || 0) + actualVal);
      if (actualAttr !== 'random') addAttributeXP(data, actualAttr, action?.val);
      if (!data.attr_event_counts) data.attr_event_counts = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
      if (actualAttr && data.attr_event_counts[actualAttr] != null) {
        data.attr_event_counts[actualAttr] = (Number(data.attr_event_counts[actualAttr]) || 0) + 1;
      }
      data.logs.push({ timestamp: Date.now(), action_type: 'prop_action', points_added: actualVal, detail: `[巡堂道具] ${action.name} -> +${actualVal}XP (${CONSTANTS.ATTRIBUTES?.[actualAttr]?.name || '特殊'})` });
      data = processEvolution(data);
      const saved = await saveToDB(data);

      const uiColor = CONSTANTS.ATTRIBUTES?.[actualAttr] ? CONSTANTS.ATTRIBUTES[actualAttr].color : 'var(--cyan)';
      UI.toast(`🌟 [${action.name}] 觸發成功！ +${actualVal} XP`);
      const panel = document.getElementById('studentView')?.querySelector?.('.tech-panel');
      if (panel) {
        const oldBoxShadow = panel.style.boxShadow;
        const oldBorderColor = panel.style.borderColor;
        panel.style.boxShadow = `0 0 50px ${uiColor}`;
        panel.style.borderColor = uiColor;
        setTimeout(() => {
          panel.style.boxShadow = oldBoxShadow;
          panel.style.borderColor = oldBorderColor;
        }, 800);
      }
      return saved;
    },

    async prepareActionFromButton(buttonEl) {
      if (!buttonEl) return;
      const attr = String(buttonEl.dataset.attr || '').trim();
      const baseVal = Number(buttonEl.dataset.val) || 0;
      const desc = String(buttonEl.dataset.desc || '');
      return teacherApi.prepareAction(attr, baseVal, desc);
    },

    async prepareAction(attr, baseVal, desc) {
      if (currentState.teacherActionSubmitting) {
        UI.toast('上一筆加分尚在保存中，請稍候。');
        return;
      }
      const data = await hydrateTeacherTargetData(currentState.studentData, { source: 'teacher-actions:prepareAction', action: 'prepare-action' });
      if (!data) return;
      const targetSerial = resolveTeacherTargetSerial(data);
      syncTeacherTargetContext(data, { source: 'teacher-actions:prepareAction', action: 'prepare-action', serial: targetSerial, hydrated: true, clearError: true });
      if (!ELEMENT_KEYS.includes(attr)) {
        UI.alert('找不到可用的屬性事件，請重新整理老師面板後再試。', '加分資料異常');
        return;
      }
      let actualAttr = attr;
      let actualVal = Number(baseVal) || 0;
      const safeDesc = String(desc || '').trim() || '老師手動加分';
      const attrInfo = getAttrInfo(attr);
      let msg = `[${attrInfo.name}] ${safeDesc} +${actualVal}`;
      if (data.debuffs?.Confusion > 0) {
        const keys = ELEMENT_KEYS.filter(Boolean);
        if (keys.length) actualAttr = keys[Math.floor(Math.random() * keys.length)];
        msg = `😵 混亂跳轉 -> [${getAttrInfo(actualAttr).name}]`;
      }
      const simStreak = ((data.streaks && data.streaks[actualAttr]) ? Number(data.streaks[actualAttr]) || 0 : 0) + 1;
      const bonus = simStreak === 3 ? 5 : (simStreak === 5 ? 10 : 0);
      actualVal += bonus;
      if (bonus > 0) msg += `<br><span style="color:var(--warning); font-size:0.8em;">🌟 連續加成 ${simStreak} 連擊 +${bonus}</span>`;
      if (data.debuffs?.Poison > 0) {
        actualVal = Math.floor(actualVal / Math.pow(2, data.debuffs.Poison));
        msg += `<br><span style="color:var(--color-psychic); font-size:0.8em;">🟣 受到中毒影響，獲得的能量減少了。</span>`;
      }
      if (!Number.isFinite(actualVal) || actualVal <= 0) {
        UI.alert('本次加分在狀態計算後沒有有效數值，請檢查狀態後再試。', '無可套用能量');
        return;
      }
      const xpLabel = getProfileLabels(data).xp || '成長能量';
      const { previewText } = getTeacherActionDom();
      if (!previewText) {
        UI.alert('找不到加分確認面板，請重新整理後再試。', '介面異常');
        return;
      }
      previewText.innerHTML = `<div style="font-family:'Noto Sans TC'; font-size:0.85em; margin-bottom:10px;">${msg}</div><span style="font-size:1.6em; color:var(--cyan); font-weight:bold;">本次總計：+${actualVal} 點${xpLabel}</span>`;
      currentState.pendingAction = { originalAttr: attr, actualAttr, amount: actualVal, baseAmount: Number(baseVal) || 0, simStreak, desc: safeDesc, targetSerial, targetName: String(data?.name || '').trim() };
      UI.showModal('previewPanel');
    },

    async commitAction() {
      if (!currentState.pendingAction) return null;
      if (currentState.teacherActionSubmitting) return null;
      const pendingTargetSerial = normalizeSerial(currentState.pendingAction?.targetSerial);
      const base = await hydrateTeacherTargetData(currentState.studentData, {
        explicitSerial: pendingTargetSerial,
        source: 'teacher-actions:commitAction',
        action: 'commit-action'
      });
      if (!base) return null;
      syncTeacherTargetContext(base, { source: 'teacher-actions:commitAction', action: 'commit-action', serial: pendingTargetSerial || resolveTeacherTargetSerial(base), hydrated: true, clearError: true });
      currentState.teacherActionSubmitting = true;
      setActionButtonsDisabled(true);
      try {
        let data = cloneData(base);
        const p = currentState.pendingAction;
        if (!ELEMENT_KEYS.includes(p.actualAttr)) {
          throw new Error('加分屬性資料異常，請重新開啟確認視窗後再試。');
        }
        if (!data.streaks) data.streaks = {};
        if (!data.attributes) data.attributes = {};
        ensureLogs(data);
        for (const key of ELEMENT_KEYS) {
          data.streaks[key] = 0;
          data.attributes[key] = Number(data.attributes[key]) || 0;
        }
        data.streaks[p.actualAttr] = (p.simStreak === 5) ? 0 : p.simStreak;
        data.totalXP = (Number(data.totalXP) || 0) + (Number(p.amount) || 0);
        addAttributeXP(data, p.actualAttr, Number(p.baseAmount) || 0);
        if (!data.attr_event_counts || typeof data.attr_event_counts !== 'object') {
          data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
        }
        for (const key of ELEMENT_KEYS) {
          if (data.attr_event_counts[key] == null) data.attr_event_counts[key] = 0;
        }
        if (p.actualAttr && data.attr_event_counts[p.actualAttr] != null) {
          data.attr_event_counts[p.actualAttr] = (Number(data.attr_event_counts[p.actualAttr]) || 0) + 1;
        }
        data.logs.push({ timestamp: Date.now(), action_type: 'add_xp', points_added: Number(p.amount) || 0, detail: `ACTION: ${p.desc} -> +${Number(p.amount) || 0}XP (${getAttrInfo(p.actualAttr).name || p.actualAttr})` });
        data = processEvolution(data);
        const savedSerial = normalizeSerial(p.targetSerial || resolveTeacherTargetSerial(data));
        const saved = await persistTeacherData(data, savedSerial, { source: 'teacher-actions:commitAction', action: 'commit-action' });
        if (!saved || typeof saved !== 'object') {
          throw new Error('資料未成功寫入，請稍後再試。');
        }
        const adopted = await adoptTeacherSavedResult(this, saved, savedSerial, { source: 'teacher-actions:commitAction', action: 'commit-action' });
        closePreviewState();
        UI.toast(adopted && canApplyTeacherTargetResult(savedSerial, { allowEmptyActive: true }) ? 'ACTION CONFIRMED' : `ACTION CONFIRMED (#${savedSerial})`);
        return adopted || saved;
      } catch (e) {
        console.error('[teacher-actions] commitAction failed:', e);
        UI.alert(e?.message || '未知錯誤', '保存失敗');
        return null;
      } finally {
        currentState.teacherActionSubmitting = false;
        setActionButtonsDisabled(false);
      }
    },

    async redeemCollectionVoucher(index) {
      if (!currentState.studentData) return null;
      const collection = Array.isArray(currentState.studentData.collection) ? currentState.studentData.collection : [];
      const item = collection[index];
      if (!item || item.type !== 'voucher') return null;
      if (item.status === 'redeemed') {
        UI.toast('此憑證已兌現');
        return null;
      }
      const ok = await UI.confirm(`確定將「${item.name || '兌換憑證'}」標記為已兌現嗎？

兌現後，學生收藏區將不再顯示此憑證。`, '老師兌現確認');
      if (!ok) return null;
      const result = await teacherApi.runTeacherMutation.call(this, {
        preferredData: currentState.studentData,
        explicitSerial: normalizeSerial(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid),
        source: 'teacher:voucher-redeem',
        action: 'voucher-redeem',
        failureTitle: '兌現失敗',
        mutate: async (data) => {
          data.collection = Array.isArray(data.collection) ? data.collection : [];
          const voucher = data.collection[index];
          if (!voucher || voucher.type !== 'voucher') throw new Error('找不到要兌現的憑證，請重新打開收藏後再試。');
          if (voucher.status === 'redeemed') throw new Error('此憑證已兌現。');
          voucher.status = 'redeemed';
          voucher.redeemedAt = Date.now();
          voucher.redeemedBy = auth.currentUser?.email || auth.currentUser?.uid || 'teacher';
          data.logs = Array.isArray(data.logs) ? data.logs : [];
          data.logs.push({ timestamp: Date.now(), action_type: 'voucher_redeem', detail: `[老師兌現] ${voucher.name || '兌換憑證'} 已完成領取` });
          return { applied: true, data };
        },
        afterSave: async () => {
          UI.hideModal('archiveModal');
        },
        successToast: '已完成兌現'
      });
      return result?.saved || null;
    },
    async checkDeathTrigger(data, triggerStatusKey) {
      const stacks = Number(data?.debuffs?.[triggerStatusKey] || 0) || 0;
      if (stacks < 5) return false;
      const zhName = (CONSTANTS.DEBUFF_INFO?.[triggerStatusKey]?.name) || triggerStatusKey;
      data.collection = Array.isArray(data.collection) ? data.collection : [];
      ensureLogs(data);
      data.collection.push({ type: 'dead_dragon', cause: triggerStatusKey, stats: { ...data.attributes }, timestamp: Date.now() });
      data.totalXP = 0;
      data.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
      data.debuffs_timestamp = null;
      data.dragon_stage = -1;
      data.dragon_path = null;
      data.dragon_reissued_at = Date.now();
      data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: `[死亡] 累積滿 5 次【${zhName}】導致死亡；系統已補發新的初始龍蛋，請從頭培養。` });
      try {
        const targetSerial = resolveTeacherTargetSerial(data);
        syncTeacherTargetContext(data, { source: 'teacher-actions:death-reset', action: 'death-reset', serial: targetSerial, hydrated: true, clearError: true });
        const saved = await persistTeacherData(data, targetSerial, { source: 'teacher-actions:death-reset', action: 'death-reset' });
        if (saved && typeof saved === 'object') {
          await adoptTeacherSavedResult(this, saved, targetSerial, { source: 'teacher-actions:death-reset', action: 'death-reset' });
        }
      } catch (e) {
        console.error('[teacher-actions] checkDeathTrigger save failed:', e);
        UI.alert(e?.message || '未知錯誤', '死亡重置保存失敗');
        return false;
      }
      UI.alert(`⚠️ 死亡警告 ⚠️
龍獸因【${zhName}】狀態累積 5 次導致死亡。
系統已補發一枚新的初始龍蛋，請從頭培養。`, '此型態已封存');
      return true;
    },

    async forceDebuff(statusName) {
      if (currentState.teacherActionSubmitting) {
        UI.toast('上一筆老師端保存尚在進行中，請稍候。');
        return null;
      }
      currentState.teacherActionSubmitting = true;
      try {
        const baseTarget = await hydrateTeacherTargetData(currentState.studentData, { source: 'teacher-actions:forceDebuff', action: 'force-debuff' });
        if (!baseTarget) return null;
        syncTeacherTargetContext(baseTarget, { source: 'teacher-actions:forceDebuff', action: 'force-debuff', serial: resolveTeacherTargetSerial(baseTarget), hydrated: true, clearError: true });
        let data = cloneData(baseTarget);
        data = teacherApi.ensureTeacherTargetData(data);
        if (!data) return null;
        ensureDebuffs(data);
        ensureLogs(data);
        if (statusName === 'Healthy') {
          data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
          data.debuffs_timestamp = null;
          data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: '強制清除異常狀態' });
          syncTeacherTargetContext(data, { source: 'teacher-actions:forceDebuff', action: 'clear-debuff', serial: resolveTeacherTargetSerial(data), hydrated: true, clearError: true });
          const targetSerial = resolveTeacherTargetSerial(data);
          const saved = await persistTeacherData(data, targetSerial, { source: 'teacher-actions:forceDebuff', action: 'clear-debuff' });
          if (!saved) throw new Error('狀態清除未成功寫入。');
          const adopted = await adoptTeacherSavedResult(this, saved, targetSerial, { source: 'teacher-actions:forceDebuff', action: 'clear-debuff' });
          UI.hideModal('debuffModal');
          UI.toast('狀態已清除');
          return adopted || saved;
        }
        data.debuffs[statusName] = (Number(data.debuffs[statusName]) || 0) + 1;
        data.debuffs_timestamp = Date.now();
        if (await teacherApi.checkDeathTrigger(data, statusName)) {
          UI.hideModal('debuffModal');
          return currentState.studentData;
        }
        data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: `強制賦予：${CONSTANTS.DEBUFF_INFO[statusName]?.name || statusName} x${data.debuffs[statusName]}` });
        syncTeacherTargetContext(data, { source: 'teacher-actions:forceDebuff', action: 'apply-debuff', serial: resolveTeacherTargetSerial(data), hydrated: true, clearError: true });
        const targetSerial = resolveTeacherTargetSerial(data);
        const saved = await persistTeacherData(data, targetSerial, { source: 'teacher-actions:forceDebuff', action: 'apply-debuff' });
        if (!saved) throw new Error('狀態附加未成功寫入。');
        const adopted = await adoptTeacherSavedResult(this, saved, targetSerial, { source: 'teacher-actions:forceDebuff', action: 'apply-debuff' });
        UI.hideModal('debuffModal');
        UI.toast('已附加狀態');
        return adopted || saved;
      } catch (e) {
        console.error('[teacher-actions] forceDebuff failed:', e);
        UI.alert(e?.message || '未知錯誤', '狀態調整失敗');
        return null;
      } finally {
        currentState.teacherActionSubmitting = false;
      }
    },

    async runTeacherMutation(options = {}) {
      return await runTeacherMutation(this, options);
    },

    async applyTeacherCompensation(type) {
      if (currentState.teacherActionSubmitting) {
        UI.toast('上一筆老師端保存尚在進行中，請稍候。');
        return null;
      }
      currentState.teacherActionSubmitting = true;
      try {
        if (!currentState.isAdmin) {
          const ok = await isCurrentUserAdmin();
          currentState.isAdmin = !!ok;
        }
        if (!currentState.isAdmin) {
          UI.alert('需要管理員權限才能補發。', '權限不足');
          return null;
        }
        const inputEl = document.getElementById('rewardCompSerial');
        const serial = normalizeSerial((inputEl?.value || '').trim());
        if (!serial) {
          UI.alert('請先輸入要補發的學生卡序。', '缺少卡序');
          return null;
        }
        const ref = doc(db, 'students', serial);
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          UI.alert(`找不到卡序 #${serial} 的學生資料。`, '查無學生');
          return null;
        }
        let data = applyDataMigration({ serial, card_seq: serial, ...(snap.data() || {}) });
        const eventType = String(type || '').trim();
        const eventLabel = eventType === 'teacher_boss_compensate' ? 'BOSS 補發 +5' : '每日補發 +1';
        const ts = Date.now();
        const eventResult = applyRewardEventToData(data, eventType, {
          timestamp: ts,
          eventId: buildRewardEventId(eventType, [serial, ts]),
          scopeParts: [serial, ts],
          source: 'teacher_manual',
          meta: { serial, operatorUid: auth.currentUser?.uid || '' }
        });
        if (!eventResult?.applied) {
          UI.alert('這筆補發沒有成功套用，請稍後再試。', '補發失敗');
          return null;
        }
        if (canApplyTeacherTargetResult(serial, { allowEmptyActive: true })) {
          syncTeacherTargetContext(eventResult.data, { source: 'teacher-actions:applyCompensation', action: 'teacher-compensation', serial, hydrated: true, clearError: true });
        }
        const saved = await persistTeacherData(eventResult.data, serial, { source: 'teacher-actions:applyCompensation', action: 'teacher-compensation' });
        if (!saved) {
          UI.alert(`已判定需要補發，但資料庫未成功寫入。
請稍後再試，或檢查 Rules / 網路狀態。`, '補發未完成');
          return null;
        }
        if (inputEl) inputEl.value = serial;
        const adopted = await adoptTeacherSavedResult(this, saved, serial, { source: 'teacher-actions:applyCompensation', action: 'teacher-compensation' });
        UI.toast(`已為 #${serial} 補發：${eventLabel}`);
        return adopted || saved;
      } catch (e) {
        console.error('[applyTeacherCompensation] failed:', e);
        UI.alert(e?.message || '未知錯誤', '補發失敗');
        return null;
      } finally {
        currentState.teacherActionSubmitting = false;
      }
    }
  };

  return teacherApi;
}

