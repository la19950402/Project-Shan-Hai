import { app, db, auth, functions, storage, firebaseConfig, collection, doc, getDoc, getDocs, writeBatch, setDoc, onSnapshot, updateDoc, addDoc, deleteDoc, query, where, orderBy, limit, onAuthStateChanged, signInWithEmailAndPassword, signInAnonymously, signOut, httpsCallable, storageRef, getDownloadURL, updateMetadata } from "./core/firebase.js?v=phase15phase129finalreleasegovernancereaudit";
    import { createAuthModule } from "./modules/auth.js?v=phase15phase129finalreleasegovernancereaudit";
    import { createStudentModule } from "./modules/student.js?v=phase15phase129finalreleasegovernancereaudit";
import { createStudentAccessModule } from "./modules/student-access.js?v=phase15phase129finalreleasegovernancereaudit";
import { currentState, batchState, quizSession, radarChartInstances, initializeState } from "./core/state.js?v=phase15phase129finalreleasegovernancereaudit";
import { clearQuizAdvanceTimer as clearQuizAdvanceTimerCore, beginQuizSession as beginQuizSessionCore, beginDailyQuizSession as beginDailyQuizSessionCore, abortQuizSession as abortQuizSessionCore, scheduleQuizAdvance as scheduleQuizAdvanceCore, resetQuizSession as resetQuizSessionCore } from "./core/quiz-session-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { UI as baseUI } from "./core/ui.js?v=phase15phase129finalreleasegovernancereaudit";
import { createTeacherActionsModule } from "./modules/teacher-actions.js?v=phase15phase129finalreleasegovernancereaudit";
import { createBatchModule } from "./modules/batch.js?v=phase15phase129finalreleasegovernancereaudit";
import { createBattleModule } from "./modules/battle.js?v=phase15phase129finalreleasegovernancereaudit";
import { createShopModule } from "./modules/shop.js?v=phase15phase129finalreleasegovernancereaudit";
import { createQuizModule } from "./modules/quiz.js?v=phase15phase129finalreleasegovernancereaudit";
import { createRankingModule } from "./modules/ranking.js?v=phase15phase129finalreleasegovernancereaudit";
import { createContentProfileModule } from "./modules/content-profile.js?v=phase15phase129finalreleasegovernancereaudit";
import { createZonesModule } from "./modules/zones.js?v=phase15phase129finalreleasegovernancereaudit";
import { createLegendaryModule } from "./modules/legendary.js?v=phase15phase129finalreleasegovernancereaudit";
import { createEvolutionModule } from "./modules/evolution.js?v=phase15phase129finalreleasegovernancereaudit";
import { mountAppFacade, exposeGlobalFacade, APP_FACADE_METHODS } from "./core/app-facade.js?v=phase15phase129finalreleasegovernancereaudit";
import { DEBUG_FLAGS, RUNTIME_ENV, DEBUG_MARKERS } from "./core/debug-flags.js?v=phase15phase129finalreleasegovernancereaudit";
import { isEmergencyFlagEnabled, guardLog, attachEmergencyFlagGlobals } from "./core/emergency-flags.js?v=phase15phase129finalreleasegovernancereaudit";
import { attachPrevalidationPerfGlobals, beginPerfSpan, endPerfSpan, markPerfPoint } from "./core/prevalidation-perf.js?v=phase15phase129finalreleasegovernancereaudit";
import { createForceOpenCardForgeBridge, exposeLegacyGlobals, buildSystemNamespace } from "./core/global-bridge.js?v=phase15phase129finalreleasegovernancereaudit";
import { buildGlobalSurfaceInventory, attachSurfaceMetadata, logSurfaceWarnings } from "./core/api-surface.js?v=phase15phase129finalreleasegovernancereaudit";
import { buildElementContract } from "./core/dom-contract.js?v=phase15phase129finalreleasegovernancereaudit";
import { colorToRgba, fillProfileTemplate, formatLocalDateKey, formatLocalDateTime, downloadCsvFile, downloadTextFile, makeBadgeSvg, getMostRecentNoonTimestamp, getNextNoonTimestamp, isSameNoonWindow, getDailyResetAnchor, getBattleResetAnchor, getTodayDailyRewardCount, getTodayDailyRemaining, hasBattleAttemptRemaining, formatCountdown } from "./core/runtime-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { getStudentTeamPanelKeyFromData, getActionPanelConfigForData, getMaxElementFromAttributes as getMaxElementFromAttributesCore, inferElementKeyFromText, ensureAttributeFirstGainOrder as ensureAttributeFirstGainOrderCore, markAttributeGain as markAttributeGainCore, addAttributeXP as addAttributeXPCore, getDominantElementFromData as getDominantElementFromDataCore } from "./core/profile-state-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { getCatVisual as getCatVisualCore, getProfileVisual as getProfileVisualCore, getRadarLabelsForData as getRadarLabelsForDataCore, buildCollectionDisplayItem as buildCollectionDisplayItemCore, getEggVisual as getEggVisualCore, getDragonVisual as getDragonVisualCore, isDirectVisualSource as isDirectVisualSourceCore, splitBattleVisualRef as splitBattleVisualRefCore } from "./core/profile-visual-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { isDirectVisualSource as isDirectVisualSourceAssetCore, splitBattleVisualRef as splitBattleVisualRefAssetCore, buildAssetObjectPaths, getCachedAssetUrlFromFileBaseName } from "./core/asset-fallback-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { ensureRewardEventState as ensureRewardEventStateCore, buildRewardEventId as buildRewardEventIdCore, applyRewardEventToData as applyRewardEventToDataCore, dedupeLogs as dedupeLogsCore, dedupeCollection as dedupeCollectionCore } from "./core/reward-event-utils.js?v=phase15phase129finalreleasegovernancereaudit";
import { normalizeQuizGradeToken as normalizeQuizGradeTokenCore, isQuizEnabled as isQuizEnabledCore, quizMatchesStudentGrade as quizMatchesStudentGradeCore, getStudentGradeInfo as getStudentGradeInfoCore, getBattleAudienceOptions as getBattleAudienceOptionsCore, normalizeBossDiceCount as normalizeBossDiceCountCore, normalizeBattleTowerDoc as normalizeBattleTowerDocCore, getBattleBossConfigForAudience as getBattleBossConfigForAudienceCore, getBattleBossConfigForStudent as getBattleBossConfigForStudentCore, getBattleMonStage as getBattleMonStageCore, getBattleMonDiceCount as getBattleMonDiceCountCore, getBattleStageLabel as getBattleStageLabelCore } from "./core/quiz-battle-config-utils.js?v=phase15phase129finalreleasegovernancereaudit";
    const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';
    attachEmergencyFlagGlobals();
    attachPrevalidationPerfGlobals();
    markPerfPoint('boot', 'script-loaded', { build: BUILD_TAG });
    let authApi = null; // @phase9-split:auth-api
    let studentApi = null; // @phase9-split:student-api
    let studentAccessApi = null; // @phase15.5.104-split:student-access-api
    let teacherActionsApi = null; // @phase10-split:teacher-actions-api
    let batchApi = null; // @phase11-split:batch-api
    let battleApi = null; // @phase12-split:battle-api
    let shopApi = null; // @phase13-split:shop-api
    let quizApi = null; // @phase13-split:quiz-api
    let rankingApi = null; // @phase13-split:ranking-api
    let contentProfileApi = null; // @phase13-split:content-profile-api
    let zonesApi = null; // @phase13-split:zones-api
    let legendaryApi = null; // @phase14-split:legendary-api
    let evolutionApi = null; // @phase15.5.111-split:evolution-api
    const APP_CONFIG = Object.freeze({
      version: '4.4-split-bridge-1',
      eventPrefix: 'shanhai',
      collections: Object.freeze({
        students: 'students',
        tokens: 'tag_tokens',
        shop: 'shop_catalog',
        shopPublic: 'shop_catalog_public',
        studentPages: 'student_pages',
        supportZone: 'support_zone_records',
        scienceZone: 'science_zone_records',
        leaderboard: 'leaderboard_public',
        quizPool: 'quiz_pool_public'
      }),
      splitBridge: Object.freeze({
        enabled: true,
        allowModuleRegistration: true,
        useSafeBootstrap: true
      })
    });

    const AI_GUIDE_RUNTIME = Object.freeze({
      enabled: false,
      disabledReason: 'AI 導引功能已停用，學生面板不再提供白澤／智者貓咪互動。'
    });

    const COLLECTION_NAME = APP_CONFIG.collections.students;
    const TOKEN_COLLECTION = APP_CONFIG.collections.tokens;
    const SHOP_COLLECTION = APP_CONFIG.collections.shop;
    const SHOP_PUBLIC_COLLECTION = APP_CONFIG.collections.shopPublic;
    const STUDENT_PAGE_COLLECTION = APP_CONFIG.collections.studentPages;
    const SUPPORT_ZONE_COLLECTION = APP_CONFIG.collections.supportZone;
    const SCIENCE_ZONE_COLLECTION = APP_CONFIG.collections.scienceZone;
    const LEADERBOARD_COLLECTION = APP_CONFIG.collections.leaderboard;

    const QUIZ_POOL_COLLECTION = APP_CONFIG.collections.quizPool;
    const getNdefReaderCtor = () => globalThis?.NDEFReader || globalThis?.window?.NDEFReader || null;
    const hasWebNfcSupport = () => typeof getNdefReaderCtor() === 'function';
    const createNdefReaderOrThrow = () => {
      if (!hasWebNfcSupport()) throw new Error('裝置不支援 Web NFC');
      if (!(globalThis?.isSecureContext || globalThis?.window?.isSecureContext)) throw new Error('Web NFC 需要在 HTTPS 安全環境下使用。');
      const NdefReaderCtor = getNdefReaderCtor();
      return new NdefReaderCtor();
    };
const TYPE_INFO = {
      neutral: { name: '無', color: '#9aa0a6' },
      metal:  { name: '金', color: 'var(--color-metal)' },
      wood:   { name: '木', color: 'var(--color-wood)' },
      water:  { name: '水', color: 'var(--color-water)' },
      fire:   { name: '火', color: 'var(--color-fire)' },
      earth:  { name: '土', color: 'var(--color-earth)' }
    };



    const CONTENT_PROFILES = {
      shanhai: {
        id: 'shanhai',
        labels: {
          xp: '進化能量',
          collection: '幻獸繪卷',
          journey: '龍蛋的成長旅程',
          dailyQuestButton: '⚔️ 前往修練場（今日歷練）',
          dailyQuestReady: '[ 狀態就緒 ] 今日歷練已重置，可再次出發（每日中午 12:00）',
          dailyQuestCooldown: '[ 系統冷卻中 ] 今日歷練將於中午 12:00 重置，尚需 {countdown}',
          dailyQuestLogPrefix: '歷練紀錄',
          dailyQuestSummary: '今日歷練完成！你答對 {earned} 題，獲得 {earned} 枚金幣，並為目前最高的五行屬性注入 {earned} 點進化能量。',
          battleTitle: '⚔️ [ 對戰塔 ] 今日討伐任務',
          battleSelectionTitle: '⚔️ 選擇出戰的龍獸',
          battleSelectionDesc: '請從圖鑑中挑選一隻龍獸，迎戰今日鎮守高塔的異獸首領！<br/><span style="color:var(--warning);">(注意：答錯題目或戰敗，都會消耗今日機會)</span>',
          battleArenaHeading: '⚔️ 討伐開始 ⚔️',
          battleArenaDesc: '雙方各進行 3 次靈力判定，累積的靈力總值再乘上屬性相剋倍率，就會形成最終戰鬥力！',
          battleAction: '開始靈力判定',
          battleComputing: '靈力流動中...',
          battleStat: '靈力總值 {roll}（{detail}）',
          battleTie: '靈力不分上下，再判定一次！',
          battleWin: '🎉 討伐成功！',
          battleLose: '💀 討伐失利...',
          battleConsume: '💀 討伐失利，本日挑戰機會已消耗。',
          battleReward: '🎉 討伐成功！獲得 {reward}',
          battleRewardAlertTitle: '對戰塔討伐獎勵',
          battleReady: '狀態就緒，點擊發起今日討伐任務！（每日中午 12:00 重置）',
          battleCooldown: '今日挑戰次數已用完，將於中午 12:00 重置（尚需 {countdown}）。',
          bossName: null,
          playerLabel: '我的龍獸',
          bossLabel: '塔中首領',
          statusHealthy: '狀態穩定',
          legendaryEmptySpeech: '這週暫時沒有新的稀有異獸線索。先繼續培育你的龍獸，等研究站有新發現時，再一起迎接下一位夥伴吧！',
          legendarySpeechPrefix: '研究站最近追蹤到 {names} 的蹤跡！如果你願意提供對應屬性的龍獸素材 <span class="speech-highlight">協助研究</span>，就有機會迎來新的異獸夥伴。',
          legendaryRequirement: '[ 研究需求 ] {current} / {need} 份 {attrName}屬性龍獸素材',
          legendaryExchange: '進行交換',
          legendaryInsufficient: '條件不足',
          galleryEmpty: '尚未建立圖鑑紀錄'
        },
        attributes: {
          metal: { icon: '🛡️', name: '金', color: 'var(--color-metal)', char: '精準守時', desc: '金象徵凝鍊與規範，像打磨後的金屬一樣俐落明確。能守時、重視步驟、做事有條理，就會慢慢累積金屬性的力量。' },
          wood:  { icon: '🌿', name: '木', color: 'var(--color-wood)', char: '探究成長', desc: '木象徵生長與延伸，像樹木向上伸展枝葉。願意觀察、提問、分享發現，並持續探索新知，木屬性就會穩穩成長。' },
          water: { icon: '🌊', name: '水', color: 'var(--color-water)', char: '關懷協作', desc: '水象徵流動與滋養，能讓周遭變得平順而有力量。願意整理環境、照顧器材、和同伴友善合作，就是在培養水屬性的力量。' },
          fire:  { icon: '🔥', name: '火', color: 'var(--color-fire)', char: '熱情精進', desc: '火象徵熱力與光亮，會在努力中越燃越旺。主動投入學習、勇敢接受挑戰、展現亮眼成果，都能點燃火屬性的能量。' },
          earth: { icon: '⛰️', name: '土', color: 'var(--color-earth)', char: '沉著自律', desc: '土象徵穩定與承載，像大地一樣可靠厚實。能長時間專注、按步驟完成任務、保持自律與耐心，就會累積土屬性的根基。' },
          neutral: { icon: '🥚', name: '無', color: '#9aa0a6', char: '尚待覺醒', desc: '龍蛋仍在安靜吸收力量。只要你在日常學習中持續累積好表現，屬性的方向就會一點一點清楚起來。' }
        },
        debuffs: {
          Poison: { name: '中毒', color: 'var(--color-psychic)', desc: '龍獸處於中毒狀態。結算時獲得的總經驗值，將依據『中毒層數』大幅減少。' },
          Frozen: { name: '冰凍', color: 'var(--color-ice)', desc: '龍獸處於冰凍狀態。狀態解除前，即使經驗值達到 100 也無法進行進化結算。' },
          Paralyzed: { name: '麻痺', color: 'var(--color-electric)', desc: '龍獸處於麻痺狀態。結算進化金幣時，金幣轉換比例將依據『麻痺層數』大幅降低！' },
          Confusion: { name: '混亂', color: 'var(--danger)', desc: '龍獸處於混亂狀態。操作加分時，獲取的分數將不受控制，完全隨機分配至非目標的其他屬性上。' }
        },
        builtInShop: {
          antidote: { name: '💊 萬靈藥', desc: '清除所有負面狀態' },
          evo_stone: { name: '✨ 各系進化石', desc: '指定屬性直接 +30 XP' },
          wonder_stone: { name: '🌟 進化奇石', desc: '指定屬性素材 +1' },
          hidden_egg: { name: '特殊異獸蛋', desc: '完成後可轉化為隱藏異獸' }
        }
      },
      cat: {
        id: 'cat',
        labels: {
          xp: '成長能量',
          collection: '貓咪寄宿系統',
          journey: '小貓的成長歷程',
          dailyQuestButton: '🐈 進入後院 (每日抓老鼠)',
          dailyQuestReady: '[ 狀態就緒 ] 後院巡查已重置（每日中午 12:00）',
          dailyQuestCooldown: '[ 系統冷卻中 ] 後院巡查將於中午 12:00 重置，尚需 {countdown}',
          dailyQuestLogPrefix: '後院巡查',
          dailyQuestSummary: '今日後院巡查結束！答對 {earned} 題，抓到 {earned} 隻小老鼠，獲得 {earned} 金幣與 {earned} 點最高特質成長。',
          battleTitle: '🐾 [ 領域防衛 ] 擊退入侵貓咪',
          battleSelectionTitle: '🐾 選擇出動的貓咪夥伴',
          battleSelectionDesc: '請從寄宿紀錄中挑選一隻貓咪夥伴來進行領域防衛！<br/><span style="color:var(--warning);">(注意：答錯題目或失敗，皆算消耗今日機會)</span>',
          battleArenaHeading: '🐾 領域防衛開始',
          battleArenaDesc: '雙方進行 3 次敏捷爆發判定，爆發總值越高的一方就能守住領地！',
          battleAction: '開始敏捷判定',
          battleComputing: '敏捷判定中...',
          battleStat: '爆發數值 {roll} ({detail})',
          battleTie: '平手！重新判定！',
          battleWin: '🎉 成功守住領地！',
          battleLose: '🙀 防衛失敗...',
          battleConsume: '🙀 防衛失敗，本日挑戰機會已消耗。',
          battleReward: '🎉 成功守住領地！獲得 {reward}',
          battleRewardAlertTitle: '領域防衛獎勵',
          battleReady: '狀態就緒，點擊開始領域防衛！（每日中午 12:00 重置）',
          battleCooldown: '今日領域防衛次數已用完，將於中午 12:00 重置（尚需 {countdown}）。',
          bossName: '入侵浪貓',
          playerLabel: '我的貓咪',
          bossLabel: '入侵者',
          statusHealthy: '狀態穩定',
          legendaryEmptySpeech: '目前後院很平靜，這週還沒有新的特殊品種救援消息。請繼續照顧你的貓咪夥伴吧！',
          legendarySpeechPrefix: '這週後院傳來了 {names} 的救援消息！如果你願意提供對應特質的照護紀錄 <span class="speech-highlight">協助救援</span>，我就把新夥伴交給你！',
          legendaryRequirement: '[ 救援需求 ] {current} / {need} {attrName}',
          legendaryExchange: '完成救援',
          legendaryInsufficient: '條件不足',
          galleryEmpty: '尚未建立寄宿紀錄'
        },
        attributes: {
          metal: { icon: '🤍', name: '洞察', color: '#d7d7df', char: '觀察力、專注、守時', desc: '像 Chinchilla Persian 一樣敏銳細心，能留意細節、準時完成事情，展現穩定的洞察力。', coat: 'Chinchilla Persian', emoji: '🐈' },
          wood:  { icon: '🐯', name: '活力', color: '#7cc96b', char: '好奇、探索、敏捷', desc: '像 Bengal cat 一樣充滿好奇，願意探索新事物、快速行動，展現蓬勃活力。', coat: 'Bengal cat', emoji: '🐯' },
          water: { icon: '🩶', name: '溫和', color: '#8ab4d6', char: '包容、整潔、照顧他人', desc: '像 Russian Blue 一樣溫柔安定，能照顧環境、關心同伴，讓人感到安心。', coat: 'Russian Blue', emoji: '🐈' },
          fire:  { icon: '🧡', name: '熱情', color: '#ff9e57', char: '勇敢、積極、熱心助人', desc: '像 Orange Tabby 一樣元氣十足，勇於嘗試、主動參與，也願意熱心幫助別人。', coat: 'Orange Tabby', emoji: '🐈' },
          earth: { icon: '🖤', name: '沉穩', color: '#6f6158', char: '耐心、自律、踏實', desc: '像 Garfield 一樣安靜可靠，能耐心完成任務，展現沉著又踏實的力量。', coat: 'Garfield', emoji: '🐈‍⬛' },
          neutral: { icon: '📦', name: '待救援', color: '#9aa0a6', char: '尚未展現鮮明特質', desc: '小貓還在紙箱裡慢慢適應新環境。只要持續累積好表現，就會顯現自己的特色。', coat: '待救援小紙箱', emoji: '📦' }
        },
        debuffs: {
          Poison: { name: '生病', color: 'var(--color-psychic)', desc: '影響心情，導致獲得經驗減少。' },
          Frozen: { name: '驚嚇', color: 'var(--color-ice)', desc: '躲在角落不出來，暫時無法進行階段成長。' },
          Paralyzed: { name: '嗜睡', color: 'var(--color-electric)', desc: '睡翻了，導致金幣轉換效率變差。' },
          Confusion: { name: '暴走', color: 'var(--danger)', desc: '突然進入 zoomies 模式，屬性加分可能亂跳。' }
        },
        builtInShop: {
          antidote: { name: '🌿 特效除蚤藥 / 頂級貓草', desc: '清除所有負面狀態' },
          evo_stone: { name: '🥫 高級主食罐頭', desc: '指定特質直接 +30 成長值' },
          wonder_stone: { name: '🧶 特製貓玩具', desc: '指定特質素材 +1' },
          hidden_egg: { name: '🐾 特殊品種貓救援任務', desc: '完成後可帶回稀有貓咪夥伴' }
        }
      }
    };


    const CAT_VISUALS = {
      box: {
        file: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2Fbox%2Fbox_800x800.webp?alt=media&token=8285e096-bccc-4f2c-b73d-2973912c5710'
      },
      metal: {
        breed: 'Chinchilla Persian',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02'
        }
      },
      wood: {
        breed: 'Bengal cat',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010'
        }
      },
      water: {
        breed: 'Russian Blue',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629'
        }
      },
      fire: {
        breed: 'Orange Tabby',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5'
        }
      },
      earth: {
        breed: 'Garfield',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9'
        }
      }
    };

    function getContentProfile(data = null) {
      const src = data || currentState?.studentData || {};
      const queryProfile = new URLSearchParams(window.location.search).get('profile');
      const inferredCat = (
        src?.content_profile_id === 'cat' ||
        src?.ui_variant === 'muslim_friendly' ||
        src?.profile_flags?.use_cat_theme === true ||
        queryProfile === 'cat'
      );
      const id = String(src?.content_profile_id || (inferredCat ? 'cat' : 'shanhai')).trim() || 'shanhai';
      return CONTENT_PROFILES[id] || CONTENT_PROFILES.shanhai;
    }

    function isCatProfile(data = null) {
      const src = data || currentState?.studentData || {};
      const query = new URLSearchParams(window.location.search);
      const qp = String(query.get('profile') || '').trim().toLowerCase();
      const qg = String(query.get('guide') || '').trim().toLowerCase();
      return (
        qp === 'cat' ||
        qg === 'cat' ||
        src?.content_profile_id === 'cat' ||
        src?.ui_variant === 'muslim_friendly' ||
        src?.profile_flags?.use_cat_theme === true ||
        src?.profile_flags?.hide_fantasy === true ||
        src?.profile_flags?.use_safe_random_label === true ||
        getContentProfile(src).id === 'cat'
      );
    }

    function getCatBossVisualByType(typeKey = 'neutral') {
      const normalized = ELEMENT_KEYS.includes(typeKey) ? typeKey : 'metal';
      const pseudo = {
        content_profile_id: 'cat',
        dragon_stage: 0,
        dragon_path: normalized,
        attributes: ELEMENT_KEYS.reduce((acc, key) => { acc[key] = key === normalized ? 1 : 0; return acc; }, {})
      };
      return getCatVisual(pseudo);
    }

    function getProfileAttributeInfo(attrKey, data = null) {
      const p = getContentProfile(data);
      return (p.attributes && p.attributes[attrKey]) || p.attributes?.neutral || CONSTANTS.ATTRIBUTES[attrKey] || { icon: '❓', name: attrKey, color: 'var(--cyan)', char: '' };
    }

    function getProfileDebuffInfo(statusKey, data = null) {
      const p = getContentProfile(data);
      return (p.debuffs && p.debuffs[statusKey]) || CONSTANTS.DEBUFF_INFO[statusKey] || { name: statusKey, color: 'var(--danger)', desc: '' };
    }

    function getProfileLabels(data = null) {
      return getContentProfile(data).labels || {};
    }

    function getProfileFlags(data = null) {
      const src = data || currentState?.studentData || {};
      return Object.assign({ hide_fantasy: false, use_cat_theme: isCatProfile(src), use_safe_random_label: isCatProfile(src) }, src?.profile_flags || {});
    }

    function getCatVisual(source = {}, sourceItem = null) {
      return getCatVisualCore(source, sourceItem, {
        CAT_VISUALS,
        getDominantElementFromData,
        getProfileAttributeInfo,
        makeBadgeSvg,
      });
    }

    function getProfileVisual(data = {}, sourceItem = null) {
      return getProfileVisualCore(data, sourceItem, {
        isCatProfile,
        getCatVisual,
        getDragonVisual,
      });
    }

    function getRadarLabelsForData(data = null) {
      return getRadarLabelsForDataCore(data, {
        attrOrder: CONSTANTS.ATTR_ORDER,
        getProfileAttributeInfo,
      });
    }

    function buildCollectionDisplayItem(item, ownerData = null) {
      return buildCollectionDisplayItemCore(item, ownerData, {
        getContentProfile,
        getProfileAttributeInfo,
        isCatProfile,
        getProfileDebuffInfo,
        makeBadgeSvg,
        getCatVisual,
      });
    }


    function normalizeQuizGradeToken(raw) {
      return normalizeQuizGradeTokenCore(raw);
    }

    function isQuizEnabled(q = {}) {
      return isQuizEnabledCore(q);
    }

    function quizMatchesStudentGrade(q = {}, userGrade = '', isSupportClass = false) {
      return quizMatchesStudentGradeCore(q, userGrade, isSupportClass, {
        normalizeQuizGradeToken,
      });
    }

    function getStudentGradeInfo(data = {}) {
      return getStudentGradeInfoCore(data);
    }

    function getBattleAudienceOptions() {
      return getBattleAudienceOptionsCore();
    }

    function normalizeBattleTowerDoc(raw = {}) {
      return normalizeBattleTowerDocCore(raw, {
        normalizeBossDiceCount,
      });
    }

    function getBattleBossConfigForAudience(rawDoc = {}, audienceKey = 'default') {
      return getBattleBossConfigForAudienceCore(rawDoc, audienceKey, {
        normalizeBattleTowerDoc,
      });
    }

    function getBattleBossConfigForStudent(studentData = {}, rawDoc = {}) {
      return getBattleBossConfigForStudentCore(studentData, rawDoc, {
        getStudentGradeInfo,
        getBattleBossConfigForAudience,
      });
    }

    function ensureRewardEventState(data = {}) {
      return ensureRewardEventStateCore(data);
    }

    function buildRewardEventId(type, scopeParts = []) {
      return buildRewardEventIdCore(type, scopeParts);
    }

    function applyRewardEventToData(dataObj, type, options = {}) {
      return applyRewardEventToDataCore(dataObj, type, options, {
        ensureRewardEventState,
        buildRewardEventId,
        getDominantElementFromData,
        getProfileAttributeInfo,
        addAttributeXP,
        getProfileLabels,
      });
    }

    function applyProfileStaticTexts(data, isStudentMode = false) {
      const labels = getProfileLabels(data);
      const pfx = isStudentMode ? 'stu' : 'adm';
      const xpEl = DomBridge.get(`${pfx}XpLabel`);
      if (xpEl) xpEl.innerText = labels.xp || '成長能量';
      const collectionEl = DomBridge.get(`${pfx}CollectionTitle`);
      if (collectionEl) collectionEl.innerText = labels.collection || '圖鑑與寄宿紀錄';
      if (isStudentMode) {
        const qBtn = DomBridge.get('stuDailyQuestBtn'); if (qBtn) qBtn.innerText = labels.dailyQuestButton || qBtn.innerText;
        const journey = DomBridge.get('stuJourneyTitle'); if (journey) journey.innerText = labels.journey || journey.innerText;
        const battleTitle = DomBridge.get('stuBattleTitle'); if (battleTitle) battleTitle.innerText = labels.battleTitle || battleTitle.innerText;
        const selTitle = DomBridge.get('battleSelectionTitle'); if (selTitle) selTitle.innerText = labels.battleSelectionTitle || selTitle.innerText;
        const selDesc = DomBridge.get('battleSelectionDesc'); if (selDesc) selDesc.innerHTML = labels.battleSelectionDesc || selDesc.innerHTML;
        const arenaTitle = DomBridge.get('battleArenaHeading'); if (arenaTitle) arenaTitle.innerText = labels.battleArenaHeading || arenaTitle.innerText;
        const arenaDesc = DomBridge.get('battleArenaDesc'); if (arenaDesc) arenaDesc.innerText = labels.battleArenaDesc || arenaDesc.innerText;
        const arenaBtn = DomBridge.get('baActionBtn'); if (arenaBtn) arenaBtn.innerText = labels.battleAction || arenaBtn.innerText;
        const playerLabel = DomBridge.get('baPlayerLabel'); if (playerLabel) playerLabel.innerText = labels.playerLabel || playerLabel.innerText;
        const bossLabel = DomBridge.get('baBossLabel'); if (bossLabel) bossLabel.innerText = labels.bossLabel || bossLabel.innerText;
      }
    }

    function syncProfileForm(data) {
      const src = data || {};
      const flags = getProfileFlags(src);
      const p = getContentProfile(src);
      const {
        profileSelect,
        profileVariantSelect,
        guideModeSelect,
        guideModeLocked,
        flagHideFantasy,
        flagUseCatTheme,
        flagSafeRandom
      } = getContentProfileDom();
      if (profileSelect) profileSelect.value = p.id;
      if (profileVariantSelect) profileVariantSelect.value = src?.ui_variant || (p.id === 'cat' ? 'muslim_friendly' : 'default');
      if (guideModeSelect) guideModeSelect.value = (String(src?.guide_mode || '').trim().toLowerCase() === 'baize' ? 'baize' : (String(src?.guide_mode || '').trim().toLowerCase() === 'cat' ? 'cat' : (p.id === 'cat' ? 'cat' : 'baize')));
      if (guideModeLocked) guideModeLocked.checked = src?.guide_mode_locked !== false;
      if (flagHideFantasy) flagHideFantasy.checked = !!flags.hide_fantasy;
      if (flagUseCatTheme) flagUseCatTheme.checked = !!flags.use_cat_theme;
      if (flagSafeRandom) flagSafeRandom.checked = !!flags.use_safe_random_label;
    }


    function syncMainEntryDomContract(diagKey, stateKey, contract) {
      const snapshot = {
        checkedAt: Date.now(),
        missing: Array.isArray(contract?.missing) ? contract.missing.slice() : [],
        ok: !!contract?.ok
      };
      currentState[stateKey] = snapshot;
      try {
        const base = (globalThis.__BOOT_DIAG && typeof globalThis.__BOOT_DIAG === 'object') ? globalThis.__BOOT_DIAG : {};
        globalThis.__BOOT_DIAG = {
          ...base,
          [diagKey]: {
            ok: snapshot.ok,
            missing: snapshot.missing.slice(),
            checkedAt: snapshot.checkedAt
          }
        };
      } catch (_) {}
      return snapshot;
    }

    function getAccountMgmtDom() {
      const contract = buildElementContract({
        modal: 'accountMgmtModal',
        lookupMsg: 'amLookupMsg',
        reissueMsg: 'amReissueMsg',
        reissueInfo: 'amReissueInfo',
        reissueStartBtn: 'amReissueStartBtn',
        serialLookupInput: 'amSerialLookupInput',
        reissueSerialInput: 'amReissueSerialInput',
        lookupPane: 'amLookupPane',
        reissuePane: 'amReissuePane'
      }, [
        'modal', 'lookupMsg', 'reissueMsg', 'reissueInfo', 'reissueStartBtn',
        'serialLookupInput', 'reissueSerialInput', 'lookupPane', 'reissuePane'
      ]);
      syncMainEntryDomContract('accountMgmtDomContract', 'accountMgmtDomContract', contract);
      return contract.elements;
    }

    function getBaizeDom() {
      const contract = buildElementContract({
        section: 'stuBaizeSection',
        modal: 'baizeModal',
        guideAvatar: 'baizeGuideAvatar',
        guideTitle: 'baizeGuideTitle',
        guideDesc: 'baizeGuideDesc',
        guideOpenBtn: 'baizeGuideOpenBtn',
        modalTitle: 'baizeModalTitle',
        modalDesc: 'baizeModalDesc',
        suggestionText: 'baizeSuggestionText',
        input: 'baizeInput',
        statusText: 'baizeStatusText',
        sendBtn: 'baizeSendBtn',
        modalContent: 'baizeModalContent',
        chatHistory: 'baizeChatHistory'
      }, [
        'section', 'modal', 'guideAvatar', 'guideTitle', 'guideDesc', 'guideOpenBtn',
        'modalTitle', 'modalDesc', 'suggestionText', 'input', 'statusText', 'sendBtn',
        'modalContent', 'chatHistory'
      ]);
      syncMainEntryDomContract('baizeDomContract', 'baizeDomContract', contract);
      return contract.elements;
    }


    function syncAiGuideFeatureUiState() {
      const dom = getBaizeDom();
      const contentDom = getContentProfileDom();
      const status = {
        enabled: AI_GUIDE_RUNTIME.enabled === true,
        hidden: AI_GUIDE_RUNTIME.enabled !== true,
        checkedAt: Date.now(),
        reason: AI_GUIDE_RUNTIME.disabledReason || ''
      };
      if (!status.enabled) {
        const section = dom.section;
        if (section) {
          section.hidden = true;
          section.style.display = 'none';
        }
        const modal = dom.modal;
        if (modal) {
          modal.hidden = true;
          modal.style.display = 'none';
          modal.classList.add('hidden');
        }
        const guideBtn = dom.guideOpenBtn;
        if (guideBtn) {
          guideBtn.disabled = true;
          guideBtn.setAttribute('aria-disabled', 'true');
          guideBtn.title = status.reason;
        }
        const sendBtn = dom.sendBtn;
        if (sendBtn) {
          sendBtn.disabled = true;
          sendBtn.setAttribute('aria-disabled', 'true');
          sendBtn.title = status.reason;
        }
        const input = dom.input;
        if (input) {
          input.value = '';
          input.disabled = true;
          input.setAttribute('aria-disabled', 'true');
          input.placeholder = status.reason || 'AI 導引功能已停用';
        }
        const chatHistory = dom.chatHistory;
        if (chatHistory) {
          chatHistory.innerHTML = '';
        }
        const statusText = dom.statusText;
        if (statusText) {
          statusText.textContent = status.reason || '[ AI 導引功能已停用 ]';
        }
        if (contentDom.guideModeSelect) {
          contentDom.guideModeSelect.disabled = true;
          contentDom.guideModeSelect.setAttribute('aria-disabled', 'true');
        }
        if (contentDom.guideModeLocked) {
          contentDom.guideModeLocked.disabled = true;
          contentDom.guideModeLocked.setAttribute('aria-disabled', 'true');
        }
        const guideInputWrap = contentDom.guideModeSelect?.parentElement || null;
        const guideLockWrap = contentDom.guideModeLocked?.closest?.('div') || null;
        const guideRow = guideInputWrap && guideLockWrap && guideInputWrap.parentElement === guideLockWrap.parentElement
          ? guideInputWrap.parentElement
          : null;
        if (guideRow) {
          guideRow.hidden = true;
          guideRow.style.display = 'none';
        } else {
          if (guideInputWrap) {
            guideInputWrap.hidden = true;
            guideInputWrap.style.display = 'none';
          }
          if (guideLockWrap) {
            guideLockWrap.hidden = true;
            guideLockWrap.style.display = 'none';
          }
        }
        const profileHint = globalThis.document?.getElementById?.('profileConfigHint') || null;
        if (profileHint) {
          profileHint.textContent = '老師可直接切換此學生端看到的世界觀與顯示風格；AI 夥伴功能目前已停用，不再對學生端開放。';
        }
      }
      currentState.aiGuideFeature = status;
      try {
        const base = (globalThis.__BOOT_DIAG && typeof globalThis.__BOOT_DIAG === 'object') ? globalThis.__BOOT_DIAG : {};
        globalThis.__BOOT_DIAG = { ...base, aiGuideFeature: status };
      } catch (_) {}
      return status;
    }

    function getScanModeDom() {
      const contract = buildElementContract({
        title: 'scanModeTitle',
        hint: 'scanHintText',
        cardSeqSearchGroup: 'cardSeqSearchGroup',
        cardSeqInput: 'cardSeqInput',
        usbScannerInput: 'usbScannerInput',
        cardSeqSearchBtn: 'cardSeqSearchBtn'
      }, ['title', 'hint', 'cardSeqSearchGroup', 'cardSeqInput', 'usbScannerInput', 'cardSeqSearchBtn']);
      syncMainEntryDomContract('scanModeDomContract', 'scanModeDomContract', contract);
      return contract.elements;
    }

    function getLegendaryAdminDom() {
      const contract = buildElementContract({
        adminModal: 'legendaryAdminModal',
        addModal: 'legendaryAddModal',
        activeList: 'laActiveList',
        selectId: 'laSelectId',
        pointsInput: 'laPoints',
        reqAttrSelect: 'laReqAttr',
        reqCountInput: 'laReqCount'
      }, ['adminModal', 'addModal', 'activeList', 'selectId', 'pointsInput', 'reqAttrSelect', 'reqCountInput']);
      syncMainEntryDomContract('legendaryAdminDomContract', 'legendaryAdminDomContract', contract);
      return contract.elements;
    }

    function getLegendaryStudentDom() {
      const contract = buildElementContract({
        list: 'stuLegendaryList',
        speechText: 'teacherSpeechText',
        teacherAvatar: 'teacherAvatar'
      }, ['list', 'speechText', 'teacherAvatar']);
      syncMainEntryDomContract('legendaryStudentDomContract', 'legendaryStudentDomContract', contract);
      return contract.elements;
    }

    function getDisplayTeamDom() {
      const contract = buildElementContract({
        modal: 'displayTeamModal',
        grid: 'dtGrid',
        countDisplay: 'dtCountDisplay'
      }, ['modal', 'grid', 'countDisplay']);
      syncMainEntryDomContract('displayTeamDomContract', 'displayTeamDomContract', contract);
      return contract.elements;
    }

    function getBulkProgressDom() {
      const contract = buildElementContract({
        modal: 'bulkProgressModal',
        result: 'bulkProgressResult',
        startSerialInput: 'bulkStartSerial',
        endSerialInput: 'bulkEndSerial',
        gradeSelect: 'bulkGradeSelect',
        rankSelect: 'bulkRankSelect',
        resetCheckbox: 'bulkResetProgress'
      }, ['modal', 'result', 'startSerialInput', 'endSerialInput', 'gradeSelect', 'rankSelect', 'resetCheckbox']);
      syncMainEntryDomContract('bulkProgressDomContract', 'bulkProgressDomContract', contract);
      return contract.elements;
    }

    function getBatchModeDom() {
      const contract = buildElementContract({
        classText: 'batchStuClass',
        nameText: 'batchStuName',
        xpText: 'batchStuXp',
        statusText: 'batchStuStatus',
        phaseTextEl: 'batchPhaseText',
        phaseSubtextEl: 'batchPhaseSubtext',
        readyChip: 'batchStudentReadyChip',
        panel: 'batchMainPanel',
        valueBurst: 'batchValueBurst',
        feedbackArea: 'batchFeedbackArea',
        actionText: 'batchActionText',
        valueText: 'batchValueText',
        resultMeta: 'batchResultMeta',
        resultBadge: 'batchResultBadge',
        comboText: 'batchComboText',
        timerBar: 'batchTimerBar',
        timerSec: 'batchTimerSec',
        scannerInput: 'usbScannerInput'
      }, [
        'classText', 'nameText', 'xpText', 'statusText',
        'phaseTextEl', 'phaseSubtextEl', 'readyChip', 'panel',
        'valueBurst', 'feedbackArea', 'actionText', 'valueText',
        'resultMeta', 'resultBadge', 'comboText', 'timerBar', 'timerSec', 'scannerInput'
      ]);
      syncMainEntryDomContract('batchModeDomContract', 'batchModeDomContract', contract);
      return contract.elements;
    }

    function getAuthLoginDom() {
      const contract = buildElementContract({
        adminEmailInput: 'adminEmail',
        adminPwdInput: 'adminPassword',
        loginBtn: 'loginBtn'
      }, ['adminEmailInput', 'adminPwdInput', 'loginBtn']);
      syncMainEntryDomContract('authLoginDomContract', 'authLoginDomContract', contract);
      return contract.elements;
    }

    function getAuthViewsDom() {
      const contract = buildElementContract({
        loginView: 'loginView',
        dashboardView: 'dashboardView',
        adminView: 'adminView',
        viewerModeBadge: 'viewerModeBadge',
        exitPreviewBtn: 'exitPreviewBtn'
      }, ['loginView', 'dashboardView', 'adminView', 'viewerModeBadge', 'exitPreviewBtn']);
      syncMainEntryDomContract('authViewsDomContract', 'authViewsDomContract', contract);
      return contract.elements;
    }

    function getAdminDiagDom() {
      const contract = buildElementContract({
        buildPrimary: 'adminDiagBuild',
        buildInline: 'adminDiagInlineBuild',
        projectPrimary: 'adminDiagProject',
        projectInline: 'adminDiagInlineProject',
        emailPrimary: 'adminDiagEmail',
        emailInline: 'adminDiagInlineEmail',
        uidPrimary: 'adminDiagUid',
        uidInline: 'adminDiagInlineUid',
        claimPrimary: 'adminDiagClaim',
        claimInline: 'adminDiagInlineClaim',
        allowlistPrimary: 'adminDiagAllowlist',
        allowlistInline: 'adminDiagInlineAllowlist',
        finalPrimary: 'adminDiagFinal',
        finalInline: 'adminDiagInlineFinal',
        errorPrimary: 'adminDiagError',
        errorInline: 'adminDiagInlineError',
        checkedAtPrimary: 'adminDiagCheckedAt',
        checkedAtInline: 'adminDiagInlineCheckedAt',
        summaryPrimary: 'adminDiagSummary',
        summaryInline: 'adminDiagInlineSummary'
      }, [
        'buildPrimary', 'buildInline',
        'projectPrimary', 'projectInline',
        'emailPrimary', 'emailInline',
        'uidPrimary', 'uidInline',
        'claimPrimary', 'claimInline',
        'allowlistPrimary', 'allowlistInline',
        'finalPrimary', 'finalInline',
        'errorPrimary', 'errorInline',
        'checkedAtPrimary', 'checkedAtInline',
        'summaryPrimary', 'summaryInline'
      ]);
      const elements = contract.elements;
      const finalContract = {
        elements: {
          buildEls: [elements.buildPrimary, elements.buildInline],
          projectEls: [elements.projectPrimary, elements.projectInline],
          emailEls: [elements.emailPrimary, elements.emailInline],
          uidEls: [elements.uidPrimary, elements.uidInline],
          claimEls: [elements.claimPrimary, elements.claimInline],
          allowlistEls: [elements.allowlistPrimary, elements.allowlistInline],
          finalEls: [elements.finalPrimary, elements.finalInline],
          errorEls: [elements.errorPrimary, elements.errorInline],
          checkedAtEls: [elements.checkedAtPrimary, elements.checkedAtInline],
          summaryEls: [elements.summaryPrimary, elements.summaryInline]
        },
        missing: contract.missing.slice(),
        ok: contract.ok
      };
      syncMainEntryDomContract('adminDiagDomContract', 'adminDiagDomContract', finalContract);
      return finalContract.elements;
    }

    function getRegistrationDom() {
      const contract = buildElementContract({
        modal: 'regModal',
        uidDisplay: 'regUidDisplay',
        gradeSelect: 'regGrade',
        cardSeqInput: 'regCardSeq',
        randomNameDisplay: 'regRandomNameDisplay',
        submitWriteBtn: 'submitRegAndWriteBtn',
        submitBtn: 'submitRegBtn'
      }, ['modal', 'uidDisplay', 'gradeSelect', 'cardSeqInput', 'randomNameDisplay', 'submitWriteBtn', 'submitBtn']);
      syncMainEntryDomContract('registrationDomContract', 'registrationDomContract', contract);
      return contract.elements;
    }

    function getStudentInfoDom() {
      const contract = buildElementContract({
        statusDescTitle: 'statusDescTitle',
        statusDescText: 'statusDescText',
        attrInfoModal: 'attrInfoModal',
        attrInfoTitle: 'attrInfoTitle',
        attrInfoIcon: 'attrInfoIcon',
        attrInfoChar: 'attrInfoChar',
        attrInfoDesc: 'attrInfoDesc',
        attrInfoList: 'attrInfoList',
        hackerAlertModal: 'hackerAlertModal',
        hackerTargetName: 'haTargetName',
        hackerXpDiff: 'haXpDiff'
      }, [
        'statusDescTitle', 'statusDescText',
        'attrInfoModal', 'attrInfoTitle', 'attrInfoIcon', 'attrInfoChar', 'attrInfoDesc', 'attrInfoList',
        'hackerAlertModal', 'hackerTargetName', 'hackerXpDiff'
      ]);
      const elements = contract.elements;
      elements.attrInfoModalContent = elements.attrInfoModal?.querySelector?.('.modal-content') || null;
      const finalContract = {
        elements,
        missing: elements.attrInfoModalContent ? contract.missing.slice() : contract.missing.concat('attrInfoModalContent'),
        ok: contract.ok && !!elements.attrInfoModalContent
      };
      syncMainEntryDomContract('studentInfoDomContract', 'studentInfoDomContract', finalContract);
      return finalContract.elements;
    }

    function getStudentActionDom() {
      const contract = buildElementContract({
        studentView: 'studentView',
        dailyQuestBtn: 'stuDailyQuestBtn',
        dailyQuestTimer: 'stuDailyQuestTimer',
        actionGrid: 'actionGrid',
        actionGridModeHint: 'actionGridModeHint',
        studentLockOverlay: 'studentLockOverlay',
        studentLockMsg: 'studentLockMsg',
        studentLockPanel: 'studentLockPanel',
        studentLockTitle: 'studentLockTitle'
      }, [
        'studentView', 'dailyQuestBtn', 'dailyQuestTimer', 'actionGrid', 'actionGridModeHint',
        'studentLockOverlay', 'studentLockMsg', 'studentLockPanel', 'studentLockTitle'
      ]);
      syncMainEntryDomContract('studentActionDomContract', 'studentActionDomContract', contract);
      return contract.elements;
    }

    function getStudentDisplayDom(prefix = 'stu') {
      const normalizedPrefix = String(prefix || 'stu');
      const contract = buildElementContract({
        classSeat: `${normalizedPrefix}ClassSeat`,
        name: `${normalizedPrefix}Name`,
        coins: `${normalizedPrefix}Coins`,
        lapBadge: `${normalizedPrefix}LapBadge`,
        xpBar: `${normalizedPrefix}XpBar`,
        xpText: `${normalizedPrefix}XpText`,
        streakRow: `${normalizedPrefix}StreakRow`,
        lifetimeStatsRow: normalizedPrefix === 'stu' ? 'stuLifetimeStatsRow' : null,
        logsList: normalizedPrefix === 'adm' ? 'admLogsList' : null
      }, ['classSeat', 'name', 'coins', 'lapBadge', 'xpBar', 'xpText', 'streakRow']);
      syncMainEntryDomContract(`studentDisplayDomContract:${normalizedPrefix}`, `studentDisplayDomContract:${normalizedPrefix}`, contract);
      return contract.elements;
    }

    function getStudentIdentityDom() {
      const contract = buildElementContract({
        admName: 'admName',
        stuName: 'stuName',
        batchStuName: 'batchStuName',
        admClassSeat: 'admClassSeat',
        stuClassSeat: 'stuClassSeat',
        batchStuClass: 'batchStuClass',
        admCoins: 'admCoins',
        stuCoins: 'stuCoins',
        batchStuXp: 'batchStuXp'
      }, [
        'admName', 'stuName', 'batchStuName',
        'admClassSeat', 'stuClassSeat', 'batchStuClass',
        'admCoins', 'stuCoins', 'batchStuXp'
      ]);
      syncMainEntryDomContract('studentIdentityDomContract', 'studentIdentityDomContract', contract);
      return contract.elements;
    }

    function getStudentViewDom() {
      const contract = buildElementContract({
        studentView: 'studentView',
        adminStudentPanel: 'adminStudentPanel'
      }, ['studentView', 'adminStudentPanel']);
      syncMainEntryDomContract('studentViewDomContract', 'studentViewDomContract', contract);
      return contract.elements;
    }

    function getStudentShopStatusDom() {
      const contract = buildElementContract({
        shopModal: 'shopModal',
        shopCoins: 'shopCoins'
      }, ['shopModal', 'shopCoins']);
      const elements = contract.elements;
      const finalContract = {
        elements: {
          ...elements,
          itemButtons: Array.from(elements.shopModal?.querySelectorAll?.('.shop-item') || [])
        },
        missing: contract.missing.slice(),
        ok: contract.ok
      };
      syncMainEntryDomContract('studentShopStatusDomContract', 'studentShopStatusDomContract', finalContract);
      return finalContract.elements;
    }

    function getRuntimeUiDom() {
      const contract = buildElementContract({
        adminDiagInlineWrap: 'adminDiagInlineWrap',
        loginView: 'loginView',
        battleArenaModal: 'battleArenaModal',
        dashboardView: 'dashboardView',
        adminView: 'adminView',
        batchModeView: 'batchModeView',
        adminEmail: 'adminEmail',
        adminPassword: 'adminPassword',
        scanNfcBtn: 'scanNfcBtn',
        cancelActionBtn: 'cancelActionBtn'
      }, [
        'adminDiagInlineWrap', 'loginView', 'battleArenaModal', 'dashboardView', 'adminView', 'batchModeView',
        'adminEmail', 'adminPassword', 'scanNfcBtn', 'cancelActionBtn'
      ]);
      syncMainEntryDomContract('runtimeUiDomContract', 'runtimeUiDomContract', contract);
      return contract.elements;
    }

    function getTeacherUtilityDom() {
      const contract = buildElementContract({
        confirmActionBtn: 'confirmActionBtn',
        writeNfcLinkBtn: 'writeNfcLinkBtn',
        openShopBtn: 'openShopBtn',
        openCardForgeBtn: 'openCardForgeBtn',
        openDebuffBtn: 'openDebuffBtn'
      }, ['confirmActionBtn', 'writeNfcLinkBtn', 'openShopBtn', 'openCardForgeBtn', 'openDebuffBtn']);
      syncMainEntryDomContract('teacherUtilityDomContract', 'teacherUtilityDomContract', contract);
      return contract.elements;
    }

    function getZoneLinkDom() {
      const contract = buildElementContract({
        supportWriteBtn: 'writeSupportZoneNfcBtn',
        supportUrlDisplay: 'supportZoneUrlDisplay',
        scienceWriteBtn: 'writeScienceZoneNfcBtn',
        scienceUrlDisplay: 'scienceZoneUrlDisplay',
        secretPropTrigger: 'secretPropTrigger'
      }, ['supportWriteBtn', 'supportUrlDisplay', 'scienceWriteBtn', 'scienceUrlDisplay']);
      syncMainEntryDomContract('zoneLinkDomContract', 'zoneLinkDomContract', contract);
      return contract.elements;
    }

    function getBattleSetupDom() {
      const contract = buildElementContract({
        legendarySelect: 'laSelectId',
        legendaryPreviewImg: 'laPreviewImg',
        legendaryPreviewName: 'laPreviewName',
        battleTypeSelect: 'btSetType',
        battleBossSelect: 'btSetBoss',
        battleBossPreviewImg: 'btBossPreviewImg',
        battleBossPreviewName: 'btBossPreviewName'
      }, [
        'legendarySelect', 'legendaryPreviewImg', 'legendaryPreviewName',
        'battleTypeSelect', 'battleBossSelect', 'battleBossPreviewImg', 'battleBossPreviewName'
      ]);
      syncMainEntryDomContract('battleSetupDomContract', 'battleSetupDomContract', contract);
      return contract.elements;
    }


    function getContentProfileDom() {
      const contract = buildElementContract({
        profileSelect: 'profileSelect',
        profileVariantSelect: 'profileVariantSelect',
        guideModeSelect: 'guideModeSelect',
        guideModeLocked: 'guideModeLocked',
        flagHideFantasy: 'flagHideFantasy',
        flagUseCatTheme: 'flagUseCatTheme',
        flagSafeRandom: 'flagSafeRandom'
      }, [
        'profileSelect', 'profileVariantSelect', 'guideModeSelect', 'guideModeLocked',
        'flagHideFantasy', 'flagUseCatTheme', 'flagSafeRandom'
      ]);
      syncMainEntryDomContract('contentProfileDomContract', 'contentProfileDomContract', contract);
      return contract.elements;
    }

    function getQuizManagerDom() {
      const contract = buildElementContract({
        modal: 'quizManagerModal',
        formTitle: 'qmFormTitle',
        editId: 'qmEditId',
        saveBtn: 'qmSaveBtn',
        cancelBtn: 'qmCancelEditBtn',
        grade: 'qmGrade',
        unit: 'qmUnit',
        question: 'qmQuestion',
        imageUrl: 'qmImageUrl',
        imageAsset: 'qmImageAsset',
        imagePreview: 'qmImagePreview',
        imagePreviewHint: 'qmImagePreviewHint',
        opt0: 'qmOpt0',
        opt1: 'qmOpt1',
        opt2: 'qmOpt2',
        opt3: 'qmOpt3',
        bulkImport: 'qmBulkImport',
        selectedCount: 'qmSelectedCount',
        selectAll: 'qmSelectAll',
        filterGrade: 'qmFilterGrade',
        filterUnit: 'qmFilterUnit',
        listContainer: 'quizListContainer',
        totalCount: 'qmTotalCount'
      }, [
        'modal', 'formTitle', 'editId', 'saveBtn', 'cancelBtn', 'grade', 'unit', 'question',
        'opt0', 'opt1', 'opt2', 'opt3', 'bulkImport', 'selectedCount', 'selectAll',
        'filterGrade', 'filterUnit', 'listContainer', 'totalCount'
      ]);
      const elements = contract.elements;
      elements.optionInputs = [elements.opt0, elements.opt1, elements.opt2, elements.opt3];
      elements.correctInputs = Array.from(globalThis.document?.querySelectorAll?.('input[name="qmCorrect"]') || []);
      elements.modalContent = elements.modal?.querySelector?.('.modal-content') || null;
      elements.getCorrectInputByValue = (value) => elements.correctInputs.find((el) => String(el?.value) === String(value)) || null;
      elements.getCheckedCorrectInput = () => elements.correctInputs.find((el) => !!el?.checked) || null;
      const missing = contract.missing.slice();
      if (elements.correctInputs.length < 4) missing.push('correctInputs');
      if (!elements.modalContent) missing.push('modalContent');
      const finalContract = {
        elements,
        missing,
        ok: contract.ok && elements.correctInputs.length >= 4 && !!elements.modalContent
      };
      syncMainEntryDomContract('quizManagerDomContract', 'quizManagerDomContract', finalContract);
      return finalContract.elements;
    }

    function getQuizPlayDom() {
      const contract = buildElementContract({
        modal: 'quizPlayModal',
        title: 'quizPlayTitle',
        playArea: 'quizPlayArea',
        resultArea: 'quizResultArea',
        progress: 'quizProgress',
        questionMedia: 'quizQuestionMedia',
        questionImage: 'quizQuestionImage',
        questionImageHint: 'quizQuestionImageHint',
        questionText: 'quizQuestionText',
        optionsArea: 'quizOptionsArea',
        scoreText: 'quizScoreText',
        resultDesc: 'quizResultDesc',
        rewardArea: 'quizRewardArea',
        rewardAttr: 'quizRewardAttr',
        closeBtn: 'quizCloseBtn'
      }, [
        'modal', 'title', 'playArea', 'resultArea', 'progress', 'questionText',
        'optionsArea', 'scoreText', 'resultDesc', 'rewardArea', 'rewardAttr', 'closeBtn'
      ]);
      const elements = contract.elements;
      elements.modalContent = elements.modal?.querySelector?.('.modal-content') || null;
      const missing = contract.missing.slice();
      if (!elements.modalContent) missing.push('modalContent');
      const finalContract = {
        elements,
        missing,
        ok: contract.ok && !!elements.modalContent
      };
      syncMainEntryDomContract('quizPlayDomContract', 'quizPlayDomContract', finalContract);
      return finalContract.elements;
    }

    function getRankingDom() {
      const contract = buildElementContract({
        modal: 'rankingModal',
        tableBody: 'rankingTableBody'
      }, ['modal', 'tableBody']);
      syncMainEntryDomContract('rankingDomContract', 'rankingDomContract', contract);
      return contract.elements;
    }

    function getShopFlowDom() {
      const contract = buildElementContract({
        shopModal: 'shopModal',
        shopCoins: 'shopCoins',
        attrSelectModal: 'attrSelectModal',
        attrSelectTitle: 'attrSelectTitle',
        confirmAttrSelectBtn: 'confirmAttrSelectBtn',
        attrSelectDropdown: 'attrSelectDropdown'
      }, ['shopModal', 'shopCoins', 'attrSelectModal', 'attrSelectTitle', 'confirmAttrSelectBtn', 'attrSelectDropdown']);
      syncMainEntryDomContract('shopFlowDomContract', 'shopFlowDomContract', contract);
      return contract.elements;
    }

    function getStudentShopShowcaseDom() {
      const contract = buildElementContract({
        section: 'studentShopSection',
        status: 'studentShopStatus',
        track: 'studentShopTrack',
        prevBtn: 'studentShopPrevBtn',
        nextBtn: 'studentShopNextBtn'
      }, ['section', 'status', 'track', 'prevBtn', 'nextBtn']);
      syncMainEntryDomContract('studentShopShowcaseDomContract', 'studentShopShowcaseDomContract', contract);
      return contract.elements;
    }

    function getStudentShopRailStep(track) {
      if (!track) return 220;
      const firstCard = track.querySelector('.student-shop-card');
      const computed = window.getComputedStyle(track);
      const gap = Math.max(0, parseFloat(computed.columnGap || computed.gap || '12') || 12);
      const fallback = Math.max(180, Math.floor((track.clientWidth || 220) * 0.82));
      if (!firstCard) return fallback;
      return Math.max(fallback, Math.ceil(firstCard.getBoundingClientRect().width + gap));
    }

    function updateStudentShopRailButtons() {
      const { track, prevBtn, nextBtn } = getStudentShopShowcaseDom();
      if (!track || !prevBtn || !nextBtn) return;
      const maxScrollLeft = Math.max(0, track.scrollWidth - track.clientWidth);
      const atStart = track.scrollLeft <= 8;
      const atEnd = track.scrollLeft >= (maxScrollLeft - 8);
      prevBtn.disabled = atStart;
      nextBtn.disabled = atEnd;
      prevBtn.style.opacity = atStart ? '0.4' : '1';
      nextBtn.style.opacity = atEnd ? '0.4' : '1';
      prevBtn.style.cursor = atStart ? 'not-allowed' : 'pointer';
      nextBtn.style.cursor = atEnd ? 'not-allowed' : 'pointer';
    }

    function scrollStudentShopRail(direction = 1) {
      const { track } = getStudentShopShowcaseDom();
      if (!track) return;
      track.scrollBy({ left: getStudentShopRailStep(track) * direction, behavior: 'smooth' });
      window.setTimeout(updateStudentShopRailButtons, 260);
    }

    function bindStudentShopRailControls() {
      const { track, prevBtn, nextBtn } = getStudentShopShowcaseDom();
      if (track && !track.dataset.shopRailBound) {
        track.addEventListener('scroll', () => window.requestAnimationFrame(updateStudentShopRailButtons), { passive: true });
        track.dataset.shopRailBound = '1';
      }
      if (prevBtn && !prevBtn.dataset.shopRailBound) {
        prevBtn.addEventListener('click', () => scrollStudentShopRail(-1));
        prevBtn.dataset.shopRailBound = '1';
      }
      if (nextBtn && !nextBtn.dataset.shopRailBound) {
        nextBtn.addEventListener('click', () => scrollStudentShopRail(1));
        nextBtn.dataset.shopRailBound = '1';
      }
      updateStudentShopRailButtons();
    }

    function getSystemUiDom() {
      const contract = buildElementContract({
        toast: 'toast',
        alertTitle: 'sysAlertTitle',
        alertMsg: 'sysAlertMsg',
        confirmTitle: 'sysConfirmTitle',
        confirmMsg: 'sysConfirmMsg',
        confirmBtn: 'sysConfirmBtn',
        cancelBtn: 'sysCancelBtn',
        enlargedImg: 'enlargedImg',
        enlargedTitle: 'enlargedTitle',
        archiveTitle: 'archiveTitle',
        archiveImg: 'archiveImg',
        archiveHoloText: 'archiveHoloText',
        archivePrimaryActionBtn: 'archivePrimaryActionBtn',
        imageModal: 'imageModal',
        sysAlertModal: 'sysAlertModal',
        sysConfirmModal: 'sysConfirmModal',
        adminView: 'adminView'
      }, [
        'toast', 'alertTitle', 'alertMsg', 'confirmTitle', 'confirmMsg', 'confirmBtn', 'cancelBtn',
        'enlargedImg', 'enlargedTitle', 'archiveTitle', 'archiveImg', 'archiveHoloText',
        'archivePrimaryActionBtn', 'imageModal', 'sysAlertModal', 'sysConfirmModal', 'adminView'
      ]);
      syncMainEntryDomContract('systemUiDomContract', 'systemUiDomContract', contract);
      return contract.elements;
    }

    function getShopAdminDom() {
      const contract = buildElementContract({
        itemsContainer: 'shopItemsContainer',
        hiddenEggSelect: 'shopAdminHiddenEgg',
        effectSelect: 'shopAdminEffect',
        hintText: 'shopAdminHint',
        quantityInput: 'shopAdminQty',
        nameInput: 'shopAdminName',
        costInput: 'shopAdminCost',
        descInput: 'shopAdminDesc',
        activeToggle: 'shopAdminActive',
        giftTargetSeqInput: 'shopGiftTargetSeq',
        giftNoteInput: 'shopGiftNote',
        giftAttrSelect: 'shopGiftAttrSelect',
        giftTargetInfo: 'shopGiftTargetInfo',
        catalogPane: 'shopAdminCatalogPane',
        giftPane: 'shopAdminGiftPane',
        catalogTabBtn: 'shopAdminTabBtnCatalog',
        giftTabBtn: 'shopAdminTabBtnGift',
        giftItemSelect: 'shopGiftItemSelect',
        giftCatalogList: 'shopGiftCatalogList',
        adminList: 'shopAdminList',
        adminModal: 'shopAdminModal'
      }, [
        'itemsContainer', 'hiddenEggSelect', 'effectSelect', 'hintText', 'quantityInput', 'nameInput', 'costInput',
        'descInput', 'activeToggle', 'giftTargetSeqInput', 'giftNoteInput', 'giftAttrSelect', 'giftTargetInfo',
        'catalogPane', 'giftPane', 'catalogTabBtn', 'giftTabBtn', 'giftItemSelect', 'giftCatalogList',
        'adminList', 'adminModal'
      ]);
      syncMainEntryDomContract('shopAdminDomContract', 'shopAdminDomContract', contract);
      return contract.elements;
    }

    const TYPE_CHART = {}; // 倍率固定為 1.0（不使用相性表）

    const CONSTANTS = {
      DEBUFF_CD_MS: 7 * 24 * 60 * 60 * 1000, 
      DEBUFF_INFO: {
        Poison: { name: '中毒', color: 'var(--color-psychic)', desc: '龍獸處於中毒狀態。結算時獲得的總經驗值，將依據『中毒層數』大幅減少。' },
        Frozen: { name: '冰凍', color: 'var(--color-ice)', desc: '龍獸處於冰凍狀態。狀態解除前，即使經驗值達到 100 也無法進行進化結算。' },
        Paralyzed: { name: '麻痺', color: 'var(--color-electric)', desc: '龍獸處於麻痺狀態。結算進化金幣時，金幣轉換比例將依據『麻痺層數』大幅降低！' },
        Confusion: { name: '混亂', color: 'var(--danger)', desc: '龍獸處於混亂狀態。操作加分時，獲取的分數將不受控制，完全隨機分配至非目標的其他屬性上。' }
      },
      MEDIA: {
        // Firebase Storage: 建議把圖片放在 monsters/ 資料夾，檔名請與下方對應
        MEDIA_BUCKET: firebaseConfig.storageBucket, // 例：xxx.firebasestorage.app 或 xxx.appspot.com
        MEDIA_FOLDER: "images/monster pictures",
        MEDIA_EXT: "png",
        MEDIA_EXTS: ["png","jpg","jpeg","webp"],
        // 圖檔位置對照表（已依你在 Storage 的路徑建立）
        ASSET_PATHS: {
          "teacher": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fteacher%2Fteacher_800x800.webp?alt=media&token=d8cb0c56-6e21-419d-b6d2-55d7bca96361",
          "Primal Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FPrimal%20Dragon%20Egg_800x800.webp?alt=media&token=f9347d54-7037-4e0c-9aff-b5aee43f1754",
          "Fire Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FFire%20Dragon%20Egg_800x800.webp?alt=media&token=14e55e1d-4414-4309-9e7f-ed32f697c95b",
          "Water Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Dragon%20Egg_800x800.webp?alt=media&token=b9a5753b-c7fc-4baa-9de5-e006a5d43df0",
          "Earth Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FEarth%20Dragon%20Egg_800x800.webp?alt=media&token=88877c80-3f59-49b4-8785-426c6298c8f1",
          "Metal Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FMetal%20Dragon%20Egg_800x800.webp?alt=media&token=4153102f-eaf0-49f7-adca-4a89d081f47f",
          "Wood Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWood%20Dragon%20Egg_800x800.webp?alt=media&token=013fe80e-dbfb-4471-b8f2-6a6f4a0a569d",
          "Chiwen (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Hatchling)_800x800.webp?alt=media&token=fc17ab60-9aec-4a98-bd8e-252697d5bfe9",
          "Chiwen (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Juvenile)_800x800.webp?alt=media&token=f7519672-afec-436e-9f16-fec089b4c403",
          "Chiwen (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Adult)_800x800.webp?alt=media&token=b261f0b2-c797-4b34-8bc9-0b7c1ba76074",
          "Yazi (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Hatchling)_800x800.webp?alt=media&token=5ab5d293-a48e-4ba6-b9c8-a54b85d376f8",
          "Yazi (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Juvenile)_800x800.webp?alt=media&token=09b1dff7-f8c0-4d1b-b73c-4573a8ff5ae2",
          "Yazi (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Adult)_800x800.webp?alt=media&token=99eb7d20-a49d-4b36-a608-0e7d5a4ce0ee",
          "Suanni (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Hatchling)_800x800.webp?alt=media&token=67185a35-793e-42f6-b2ad-e94a8247ef8f",
          "Suanni (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Juvenile)_800x800.webp?alt=media&token=b09b298f-6a40-4c17-8b79-4298501171fb",
          "Suanni (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Adult)_800x800.webp?alt=media&token=29ce43db-a6d2-4cb0-a0f8-fd228f75ac92",
          "Bixi (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Hatchling)_800x800.webp?alt=media&token=15d591b4-4d40-4ebc-a7a1-87401c96deb0",
          "Bixi (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Juvenile)_800x800.webp?alt=media&token=e786db30-fc84-4b38-ae8c-89b736d946c0",
          "Bixi (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Adult)_800x800.webp?alt=media&token=79c204c9-0a2b-449e-a145-f70811ce9c13",
          "Bi'an (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Hatchling)_800x800.webp?alt=media&token=7a85fca9-1263-42f7-ba91-45aa27c42d3a",
          "Bi'an (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Juvenile)_800x800.webp?alt=media&token=43b78ffc-d297-49ba-9449-ddc011a6547e",
          "Bi'an (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Adult)_800x800.webp?alt=media&token=23e152c0-6d42-4d27-89d0-1fff613ee0fc"
        },
        mediaUrl(objectPath) {
          // objectPath 例："images/monster pictures/dragon egg/Primal Dragon Egg.png"
          const bucket = this.MEDIA_BUCKET;
          return `https://firebasestorage.googleapis.com/v0/b/${bucket}/o/${encodeURIComponent(objectPath)}?alt=media`;
        },
        imageUrl(fileBaseName) {
          return this.mediaUrl(`${this.MEDIA_FOLDER}/${fileBaseName}.${this.MEDIA_EXT}`);
        },

        // 龍蛋（總經驗 < 100 時顯示）
        DRAGON_EGGS: {
          primal: { file: "Primal Dragon Egg", caption: "尚未甦醒的龍蛋" },
          fire:   { file: "Fire Dragon Egg",   caption: "蘊藏熾焰氣息的龍蛋" },
          water:  { file: "Water Dragon Egg",  caption: "流轉清泉氣息的龍蛋" },
          earth:  { file: "Earth Dragon Egg",  caption: "蘊藏厚土氣息的龍蛋" },
          metal:  { file: "Metal Dragon Egg",  caption: "散發銳金光澤的龍蛋" },
          wood:   { file: "Wood Dragon Egg",   caption: "蘊藏青木生機的龍蛋" }
        },

        // 破殼後的進化路線（每滿 100 XP 升級一次：破殼期 -> 成長期 -> 成年期）
        DRAGON_PATHS: {
          water: {
            species: "Chiwen",
            stages: [
              { file: "Chiwen (Hatchling)", name: "螭吻(破殼期)" },
              { file: "Chiwen (Juvenile)",  name: "螭吻(成長期)" },
              { file: "Chiwen (Adult)",     name: "螭吻(成年期)" }
            ]
          },
          metal: {
            species: "Yazi",
            stages: [
              { file: "Yazi (Hatchling)", name: "睚眥(破殼期)" },
              { file: "Yazi (Juvenile)",  name: "睚眥(成長期)" },
              { file: "Yazi (Adult)",     name: "睚眥(成年期)" }
            ]
          },
          fire: {
            species: "Suanni",
            stages: [
              { file: "Suanni (Hatchling)", name: "狻猊(破殼期)" },
              { file: "Suanni (Juvenile)",  name: "狻猊(成長期)" },
              { file: "Suanni (Adult)",     name: "狻猊(成年期)" }
            ]
          },
          earth: {
            species: "Bixi",
            stages: [
              { file: "Bixi (Hatchling)", name: "贔屭(破殼期)" },
              { file: "Bixi (Juvenile)",  name: "贔屭(成長期)" },
              { file: "Bixi (Adult)",     name: "贔屭(成年期)" }
            ]
          },
          wood: {
            species: "Bi'an",
            stages: [
              { file: "Bi'an (Hatchling)", name: "狴犴(破殼期)" },
              { file: "Bi'an (Juvenile)",  name: "狴犴(成長期)" },
              { file: "Bi'an (Adult)",     name: "狴犴(成年期)" }
            ]
          }
        },

        // 內建佔位圖（避免顯示舊版龍獸圖源）
        PLACEHOLDER_SVG: "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='256' height='256'><rect width='256' height='256' fill='%23020813'/><circle cx='128' cy='128' r='84' fill='none' stroke='%2300e5ff' stroke-width='6' opacity='0.35'/><path d='M128 56 L188 92 L188 164 L128 200 L68 164 L68 92 Z' fill='none' stroke='%2300e5ff' stroke-width='6' opacity='0.55'/><text x='50%' y='52%' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' opacity='0.75' font-family='Noto Sans TC' font-size='18'>異獸</text></svg>`)
      },
      ATTRIBUTES: {
        metal: { icon: '🛡️', name: '金', color: 'var(--color-metal)', char: '精準守時', desc: '金象徵凝鍊與規範，對應守時、重視步驟，以及俐落完成任務的能力。' },
        wood:  { icon: '🌿', name: '木', color: 'var(--color-wood)',  char: '探究成長', desc: '木象徵生長與延伸，對應觀察、提問、分享發現與持續探索的能力。' },
        water: { icon: '🌊', name: '水', color: 'var(--color-water)', char: '關懷協作', desc: '水象徵流動與滋養，對應整理環境、照顧器材，以及友善合作的能力。' },
        fire:  { icon: '🔥', name: '火', color: 'var(--color-fire)',  char: '熱情精進', desc: '火象徵熱力與光亮，對應主動投入、勇於挑戰，以及展現學習成果的能力。' },
        earth: { icon: '⛰️', name: '土', color: 'var(--color-earth)', char: '沉著自律', desc: '土象徵穩定與承載，對應專注、自律，以及耐心完成任務的能力。' }
      },
      ATTR_ORDER: ['metal','wood','water','fire','earth'],

      // 顯示用：進化型態名稱（用於寄放系統/放大預覽，不影響屬性判定）
      DRAGON_NAMES: {},

      LEGENDARIES: [],
      HIDDEN_EGGS: {
        starlight_kirin: { id: 'starlight_kirin', name: '星輝麒麟蛋', requiredAttr: 'metal', points: 18, icon: '🌠', desc: '養成金系成年龍獸後，轉化為隱藏版異獸「星輝麒麟」，提供 18 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FMetal%20Dragon%20Egg_800x800.webp?alt=media&token=4153102f-eaf0-49f7-adca-4a89d081f47f' },
        verdant_phoenix: { id: 'verdant_phoenix', name: '翠羽鳳凰蛋', requiredAttr: 'wood', points: 16, icon: '🪶', desc: '養成木系成年龍獸後，轉化為隱藏版異獸「翠羽鳳凰」，提供 16 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWood%20Dragon%20Egg_800x800.webp?alt=media&token=013fe80e-dbfb-4471-b8f2-6a6f4a0a569d' },
        abyssal_kun: { id: 'abyssal_kun', name: '滄淵鯤蛋', requiredAttr: 'water', points: 20, icon: '🌊', desc: '養成水系成年龍獸後，轉化為隱藏版異獸「滄淵鯤」，提供 20 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Dragon%20Egg_800x800.webp?alt=media&token=b9a5753b-c7fc-4baa-9de5-e006a5d43df0' },
        ember_qilin: { id: 'ember_qilin', name: '熾焰麒獸蛋', requiredAttr: 'fire', points: 22, icon: '🔥', desc: '養成火系成年龍獸後，轉化為隱藏版異獸「熾焰麒獸」，提供 22 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FFire%20Dragon%20Egg_800x800.webp?alt=media&token=14e55e1d-4414-4309-9e7f-ed32f697c95b' },
        gaia_basilisk: { id: 'gaia_basilisk', name: '蓋亞巨蜥蛋', requiredAttr: 'earth', points: 19, icon: '🪨', desc: '養成土系成年龍獸後，轉化為隱藏版異獸「蓋亞巨蜥」，提供 19 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FEarth%20Dragon%20Egg_800x800.webp?alt=media&token=88877c80-3f59-49b4-8785-426c6298c8f1' },
        azure_kirin: {
          id: 'azure_kirin',
          name: '碧瀾麒麟蛋',
          beastName: '碧瀾麒麟',
          requiredAttr: 'water',
          points: 100,
          icon: '🩵',
          cost: 100,
          desc: '購買後會進入孵化紀錄；沿用原本的經驗累積與進化節奏，最終可轉化為水屬性隱藏異獸「碧瀾麒麟」，提供 100 點隱藏積分。',
          img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Kirin%20egg_800x800.webp?alt=media&token=3e256b90-6870-4e83-9b43-70bab4a0a8f0',
          forms: {
            egg: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Kirin%20egg_800x800.webp?alt=media&token=3e256b90-6870-4e83-9b43-70bab4a0a8f0',
            hatchling: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20Kirin%20egg(Hatchling)_800x800.webp?alt=media&token=77a30a86-622a-4eb7-b72c-51d475571b0b',
            juvenile: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20KirinYazi%20(Juvenile)_800x800.webp?alt=media&token=947ef8e6-8296-4f4d-bf2c-6a5ffc3b06d0',
            adult: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20KirinYazi%20(Adult)_800x800.webp?alt=media&token=8796cbb8-e4c6-47ed-9379-e9a890524d68'
          }
        }
      },
      LAP_TITLES: { 1: "初心者", 2: "館主", 3: "四天王", 4: "地區冠軍" },
      TRAINER_RANKS: [
  "見習守護員",
  "初階守護員",
  "進階守護員",
  "資深守護員",
  "卓越守護員",
  "榮譽守護師",
  "傳奇守護者",
  "殿堂守護者"
],
// 進化結算金幣匯率（100 / rate）
// 依你選擇的策略 2：階級越高優惠越好，且升級後永久保留相同/更佳優惠
TRAINER_RATE_BY_RANK: { 0: 5, 1: 4, 2: 3, 3: 3, 4: 2, 5: 2, 6: 2, 7: 2 },
ACTION_LIST: {
        metal: [{ desc: "準時完成並繳交任務，展現守時與條理", val: 5 }, { desc: "做事俐落、步驟清楚，能有效率完成工作", val: 5 }],
        wood:  [{ desc: "主動參與討論並提出自己的想法，展現探索精神", val: 20 }, { desc: "主動觀察並分享新發現，讓學習持續向外延伸", val: 15 }],
        water: [{ desc: "主動整理器材並確實歸位，照顧共同使用的空間", val: 5 }, { desc: "用心打掃並維護學習環境，讓大家都能安心學習", val: 10 }],
        fire:  [{ desc: "學習表現優良（90–94），展現主動投入的成果", val: 20 }, { desc: "學習表現亮眼（95–99），持續燃起精進的動力", val: 25 }, { desc: "學習表現卓越（100），展現全力以赴的光芒", val: 30 }],
        earth: [{ desc: "長時間專注完成學習任務，展現穩定與耐心", val: 5 }, { desc: "作品完整扎實，足以作為同學參考的優良示範", val: 20 }]
      },

TEAM_ACTION_PANELS: {
  science: {
    id: 'science',
    title: '科展團隊專屬加分面板',
    hint: '依據科展團隊的任務面向，將表現對應到五行能力。每次點選固定 +10 點經驗，方便老師快速記錄研究歷程中的亮點表現。',
    attrFocus: {
      metal: { label: '紀錄扎實', summary: '資料整理清楚、標示完整，讓研究脈絡一目了然。' },
      wood: { label: '創意發想', summary: '提出新方法、新問題或改良點，讓研究持續生長。' },
      water: { label: '口語表達', summary: '能溫和清楚地說明發現，並接住夥伴的想法。' },
      fire: { label: '操作用心', summary: '主動動手、反覆測試，讓作品持續進步。' },
      earth: { label: '作業優良', summary: '準時完成、內容完整，是團隊穩定推進的基石。' }
    },
    actions: {
      metal: [
        { desc: '實驗紀錄完整，時間、步驟與結果都標示清楚', val: 10 },
        { desc: '數據整理整齊，能用表格或圖示讓發現更清楚', val: 10 }
      ],
      wood: [
        { desc: '提出可行的新點子，讓作品更有特色或更完善', val: 10 },
        { desc: '主動延伸問題，替研究找到下一步方向', val: 10 }
      ],
      water: [
        { desc: '能清楚向同學說明操作流程與研究發現', val: 10 },
        { desc: '回答提問有條理，也能補充隊友的說明', val: 10 }
      ],
      fire: [
        { desc: '操作專注用心，願意反覆測試與調整細節', val: 10 },
        { desc: '主動協助器材準備與實作，讓實驗更順利', val: 10 }
      ],
      earth: [
        { desc: '科展作業準時且內容完整，展現可靠態度', val: 10 },
        { desc: '展板或書面成果扎實，可作為團隊示範', val: 10 }
      ]
    }
  },
  support: {
    id: 'support',
    title: '學習扶助專屬加分面板',
    hint: '聚焦學習扶助常見的學習表現，將每一次努力都轉成可見的成長紀錄。每次點選固定 +10 點經驗，方便老師穩定累積學生信心。',
    attrFocus: {
      metal: { label: '作業繳交', summary: '準時完成、條理清楚，幫助自己建立穩定節奏。' },
      wood: { label: '學習成效', summary: '願意挑戰、持續進步，把今天學會的帶到明天。' },
      water: { label: '組間合作', summary: '願意傾聽、互相幫忙，讓學習更有力量。' },
      fire: { label: '學習態度', summary: '主動投入、勇敢嘗試，不怕從錯誤中學習。' },
      earth: { label: '學習秩序', summary: '專心穩定、遵守規範，讓大家都能安心學習。' }
    },
    actions: {
      metal: [
        { desc: '作業準時繳交，內容完整清楚', val: 10 },
        { desc: '訂正確實，能看見自己一步步修正', val: 10 }
      ],
      wood: [
        { desc: '比前一次更進步，能看見自己的成長', val: 10 },
        { desc: '願意挑戰較難題型，持續向前探索', val: 10 }
      ],
      water: [
        { desc: '能和同學互相提醒，一起完成任務', val: 10 },
        { desc: '主動幫助組員理解題目，合作氣氛良好', val: 10 }
      ],
      fire: [
        { desc: '上課主動投入，願意舉手或回答問題', val: 10 },
        { desc: '遇到困難仍願意再試一次，保持學習熱情', val: 10 }
      ],
      earth: [
        { desc: '能安靜專心完成任務，維持良好學習秩序', val: 10 },
        { desc: '遵守約定與上課流程，展現自律與耐心', val: 10 }
      ]
    }
  }
},
      ANONYMOUS_CODES: [
        // 🌌 天文與星象 (Astronomy)
        "宇宙", "星辰", "銀河", "穹蒼", "彗星", "恆星", "星雲", "軌道", "日冕", "曜日",
        "皎月", "朔望", "弦月", "璇璣", "奇點", "穹宇", "寰宇", "虛空", "視界", "緯度",
        "星軌", "光年", "日珥", "繁星", "孤星", "雙星", "星團", "星弧", "極光", "幻日",
        // 🌍 地質與氣象 (Earth & Weather)
        "山嵐", "峽谷", "季風", "冰川", "斷層", "沉積", "潮汐", "霞光", "晨露", "山脈",
        "盆地", "丘陵", "高原", "平原", "荒漠", "綠洲", "苔原", "凍土", "冰山", "融雪",
        // 🌊 海洋與生態 (Marine & Ecology)
        "珊瑚", "礁岩", "深淵", "海溝", "洋流", "劍尾", "藍血", "蛻皮", "潮間", "浮游",
        "橈足", "底棲", "洄游", "成體", "甲殼", "觸角", "複眼", "側眼", "步足", "鰓弧",
        // 🌿 植物與微觀 (Botany & Microscopic)
        "蒼松", "翠竹", "葉脈", "根系", "孢子", "蕨類", "花萼", "樹冠", "苔蘚", "地衣",
        "雙子", "單子", "胚軸", "子葉", "根冠", "根毛", "皮層", "內皮", "中柱", "韌皮",
        // 🧬 演化與科學 (Science & Systems)
        "基因", "突觸", "遺傳", "轉化", "演化", "適應", "篩選", "隔離", "物種", "復育",
        "保育", "多樣", "豐度", "均度", "歧異", "染色", "密碼", "轉錄", "轉譯", "表現",
        // ⚛️ 物理與力學 (Physics & Mechanics)
        "慣性", "動量", "向量", "矩陣", "標量", "質心", "槓桿", "阻力", "滑輪", "軌跡",
        "速度", "加速", "位移", "距離", "質量", "重量", "重力", "引力", "彈力", "浮力",
        // ⚡ 電磁與科技 (Electromagnetism & Tech)
        "磁場", "電極", "晶片", "電荷", "庫侖", "電場", "電位", "電壓", "電流", "電阻",
        "電導", "電容", "電感", "串聯", "並聯", "歐姆", "安培", "伏特", "法拉", "亨利",
        // 🧪 化學與元素 (Chemistry & Elements)
        "離子", "晶格", "催化", "昇華", "凝華", "溶解", "沉澱", "萃取", "蒸餾", "結晶",
        "元素", "週期", "族群", "鹼金", "鹼土", "鹵素", "惰性", "過渡", "稀土", "錒系",
        // 📐 數學與幾何 (Math & Geometry)
        "幾何", "象限", "座標", "維度", "演繹", "歸納", "函數", "極限", "微分", "積分",
        "導數", "偏導", "級數", "數列", "行列", "張量", "純量", "空間", "拓樸", "流形",
        // ⏳ 理性與思維 (Reasoning & Philosophy)
        "剎那", "須臾", "永恆", "瞬息", "規律", "秩序", "均衡", "守恆", "輪迴", "起源",
        "黎明", "創世", "新生", "世紀", "紀元", "世代", "歲月", "光陰", "韶華", "流年"
      ]
    };
    // ===== 初始化：將「成熟期異獸」加入 Boss / 異獸基因庫下拉選單 =====
    (function __initAdultBeastsAsLegendaries() {
      try {
        const list = Array.isArray(CONSTANTS.LEGENDARIES) ? CONSTANTS.LEGENDARIES.slice() : [];
        const paths = (CONSTANTS.MEDIA && CONSTANTS.MEDIA.DRAGON_PATHS) ? CONSTANTS.MEDIA.DRAGON_PATHS : {};
        const assetMap = (CONSTANTS.MEDIA && CONSTANTS.MEDIA.ASSET_PATHS) ? CONSTANTS.MEDIA.ASSET_PATHS : {};
        const seen = new Set(list.map(x => String(x && x.id)));

        for (const [typeKey, p] of Object.entries(paths)) {
          const st = p && p.stages && p.stages[2]; // 成熟期/成年期
          if (!st) continue;

          const species = (p.species || '').trim() || String(st.file || '').trim();
          const id = `${species}_Adult`.replace(/[^\w\-]/g, '_');
          if (seen.has(id)) continue;
          seen.add(id);

          const imgUrl = (typeof assetMap[st.file] === 'string' && /^https?:\/\//i.test(assetMap[st.file]))
            ? assetMap[st.file]
            : CONSTANTS.MEDIA.PLACEHOLDER_SVG;

          list.push({
            id,
            name: st.name || species,
            img: imgUrl,
            typeKey,       // 建議屬性（五行）
            assetKey: st.file
          });
        }

        // 排序：依五行順序
        const order = Array.isArray(CONSTANTS.ATTR_ORDER) ? CONSTANTS.ATTR_ORDER : ['metal','wood','water','fire','earth'];
        list.sort((a, b) => (order.indexOf(a.typeKey) - order.indexOf(b.typeKey)) || String(a.name).localeCompare(String(b.name)));

        CONSTANTS.LEGENDARIES = list;
      } catch (e) {
        console.warn('[init] adult beasts list failed:', e?.message || e);
      }
    })();



    // ===== 五行屬 / 龍蛋成長系統 =====
    const ELEMENT_KEYS = CONSTANTS.ATTR_ORDER || ['metal','wood','water','fire','earth'];

function getStudentTeamPanelKey(data = null) {
  return getStudentTeamPanelKeyFromData(data || currentState?.studentData || {});
}

function getActionPanelConfig(data = null) {
  return getActionPanelConfigForData(data || currentState?.studentData || {}, CONSTANTS.TEAM_ACTION_PANELS || {}, CONSTANTS.ACTION_LIST);
}

const getMaxElementFromAttributes = (attrs = {}, firstGainOrder = null) => getMaxElementFromAttributesCore(attrs, firstGainOrder, ELEMENT_KEYS);
const ensureAttributeFirstGainOrder = (data) => ensureAttributeFirstGainOrderCore(data, ELEMENT_KEYS, inferElementKeyFromText);
const markAttributeGain = (data, attr) => markAttributeGainCore(data, attr, ELEMENT_KEYS, ensureAttributeFirstGainOrder);
const addAttributeXP = (data, attr, amount) => addAttributeXPCore(data, attr, amount, ELEMENT_KEYS, markAttributeGain);
const getDominantElementFromData = (data) => getDominantElementFromDataCore(data, ELEMENT_KEYS, getMaxElementFromAttributes, ensureAttributeFirstGainOrder);
    function getEggVisual(data) {
      return getEggVisualCore(data, {
        constants: CONSTANTS,
        getDominantElementFromData,
      });
    }

    function getDragonVisual(data) {
      return getDragonVisualCore(data, {
        constants: CONSTANTS,
        getDominantElementFromData,
        getEggVisual,
      });
    }

    function normalizeBossDiceCount(value, fallback = 3) {
      return normalizeBossDiceCountCore(value, fallback);
    }
    const isDirectVisualSource = (ref) => isDirectVisualSourceAssetCore(ref);
    const splitBattleVisualRef = (ref, fallbackImg = CONSTANTS.MEDIA.PLACEHOLDER_SVG) => splitBattleVisualRefAssetCore(ref, fallbackImg);

    function getBattleMonStage(mon = {}, ownerData = {}) {
      return getBattleMonStageCore(mon, ownerData);
    }

    function getBattleMonDiceCount(mon = {}, ownerData = {}) {
      return getBattleMonDiceCountCore(mon, ownerData, {
        getBattleMonStage,
      });
    }

    function getBattleStageLabel(stage, ownerData = null) {
      return getBattleStageLabelCore(stage, ownerData, {
        isCatProfile,
      });
    }

    function createBattleDiceFaces(containerId, count = 3) {
      const container = DomBridge.get(containerId);
      if (!container) return;
      const safeCount = Math.max(1, Math.min(12, Number(count) || 3));
      container.innerHTML = Array.from({ length: safeCount }, () => '<div class="dice">?</div>').join('');
    }

    function buildActiveBattleMon(studentData = {}) {
      const vis = getProfileVisual(studentData);
      const stage = Number(studentData?.dragon_stage);
      const stageIdx = Number.isFinite(stage) ? stage : -1;
      const dominant = getDominantElementFromData(studentData) || 'neutral';
      const pathKey = studentData?.dragon_path || dominant || 'neutral';
      const activeHiddenEggId = String(studentData?.active_hidden_egg_id || '').trim();
      const activeHiddenEgg = (studentData?.active_hidden_egg && typeof studentData.active_hidden_egg === 'object') ? studentData.active_hidden_egg : null;
      const activeHiddenMeta = (activeHiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEggId])
        ? CONSTANTS.HIDDEN_EGGS[activeHiddenEggId]
        : (activeHiddenEggId && activeHiddenEgg?.hiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId])
          ? CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId]
          : activeHiddenEgg;
      const visualRef = splitBattleVisualRef(vis?.file, vis?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
      const attrInfo = getProfileAttributeInfo(pathKey, studentData);
      const activeName = (() => {
        if (activeHiddenMeta) {
          if (stageIdx < 0) return `當前型態｜${activeHiddenMeta.name || '特殊異獸蛋'}`;
          return `當前型態｜${vis?.name || activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}`;
        }
        if (isCatProfile(studentData)) {
          return `當前型態｜${vis?.stageName || vis?.name || '夥伴'}`;
        }
        if (stageIdx < 0) {
          const eggName = (Number(studentData?.totalXP) || 0) > 0 ? `${attrInfo.name}龍蛋` : '初始龍蛋';
          return `當前型態｜${eggName}`;
        }
        return `當前型態｜${vis?.name || attrInfo.name || '龍獸'}`;
      })();
      return {
        isActiveCurrent: true,
        hiddenEggId: activeHiddenMeta?.id || activeHiddenMeta?.hiddenEggId || activeHiddenEggId || '',
        name: activeName,
        img_file: visualRef.img_file,
        img: visualRef.img,
        type: activeHiddenMeta ? 'hidden_egg' : (stageIdx < 0 ? 'egg' : 'dragon'),
        typeKey: (activeHiddenMeta?.requiredAttr || pathKey || dominant || 'neutral'),
        element: pathKey || dominant || 'neutral',
        path: pathKey || dominant || 'neutral',
        stage: stageIdx,
        dragon_stage: stageIdx,
        dragon_path: pathKey || dominant || 'neutral',
        stats: { ...(studentData.attributes || {}) }
      };
    }

    function buildBattleTeamForStudent(studentData = {}) {
      const col = Array.isArray(studentData?.collection) ? studentData.collection : [];
      return [
        buildActiveBattleMon(studentData),
        ...col.filter(i => (i.type === 'dragon' || i.type === 'legendary') && i.type !== 'dead_dragon' && !i.isHologram)
      ];
    }
    function __objectPathsForAssetKey(assetKey) {
      return buildAssetObjectPaths(assetKey, {
        assetPaths: (CONSTANTS.MEDIA && CONSTANTS.MEDIA.ASSET_PATHS) ? CONSTANTS.MEDIA.ASSET_PATHS : {},
        mediaExts: (CONSTANTS.MEDIA && CONSTANTS.MEDIA.MEDIA_EXTS) ? CONSTANTS.MEDIA.MEDIA_EXTS : null,
        mediaExt: (CONSTANTS.MEDIA && CONSTANTS.MEDIA.MEDIA_EXT) ? CONSTANTS.MEDIA.MEDIA_EXT : null,
        mediaFolder: (CONSTANTS.MEDIA && CONSTANTS.MEDIA.MEDIA_FOLDER) ? CONSTANTS.MEDIA.MEDIA_FOLDER : ''
      });
    }

    function assetUrlFromFileBaseName(fileBaseName) {
      return getCachedAssetUrlFromFileBaseName(fileBaseName, {
        mediaConfig: CONSTANTS.MEDIA,
        assetUrlCache: __assetUrlCache
      });
    }

    // --- Firebase Storage (downloadURL/token) image resolver --- (downloadURL/token) image resolver ---
    const __assetUrlCache = new Map();
    const __assetUrlCacheLSKey = 'shan_hai_asset_url_cache_v2';
    // Debug helper: 清除圖片 URL 快取（正式環境不直接暴露為全域，由 global bridge 視模式決定是否掛載）
    function __clearAssetUrlCache() {
      try { localStorage.removeItem(__assetUrlCacheLSKey); } catch (e) {}
      try { __assetUrlCache.clear(); } catch (e) {}
      try { location.reload(); } catch (e) {}
    }


    (function __loadAssetCacheFromLS() {
      try {
        const raw = localStorage.getItem(__assetUrlCacheLSKey);
        if (!raw) return;
        const obj = JSON.parse(raw);
        if (!obj || typeof obj !== 'object') return;
        Object.entries(obj).forEach(([k, v]) => {
          if (typeof k === 'string' && typeof v === 'string' && v.startsWith('http')) __assetUrlCache.set(k, v);
        });
      } catch (e) { /* ignore */ }
    })();

    function __persistAssetCacheToLS() {
      try {
        const obj = {};
        // 限制寫入大小：最多 200 筆，避免 localStorage 過大
        let count = 0;
        for (const [k, v] of __assetUrlCache.entries()) {
          obj[k] = v; count += 1;
          if (count >= 200) break;
        }
        localStorage.setItem(__assetUrlCacheLSKey, JSON.stringify(obj));
      } catch (e) { /* ignore */ }
    }

    // --- Firebase Storage Cache-Control helper ---
    // 註：Storage 物件的 Cache-Control 需要寫在「檔案 metadata」中才會真的影響瀏覽器快取。
    // 這裡提供「管理端/測試模式」下的自動補上 cacheControl（不阻塞圖片載入，失敗會忽略）。
    const __cacheControlLSKey = 'shan_hai_asset_cachecontrol_v1';
    const __cacheControlDone = new Set();
    const __DEFAULT_CACHE_CONTROL = 'public,max-age=31536000,immutable';
    const __assetUrlPromiseCache = new Map();
    const __assetHydrationObserverKey = Symbol('assetHydrationObserver');

    (function __loadCacheControlDoneFromLS() {
      try {
        const raw = localStorage.getItem(__cacheControlLSKey);
        if (!raw) return;
        const arr = JSON.parse(raw);
        if (!Array.isArray(arr)) return;
        arr.forEach((p) => { if (typeof p === 'string') __cacheControlDone.add(p); });
      } catch (e) { /* ignore */ }
    })();

    function __persistCacheControlDoneToLS() {
      try {
        const arr = Array.from(__cacheControlDone.values()).slice(0, 200);
        localStorage.setItem(__cacheControlLSKey, JSON.stringify(arr));
      } catch (e) { /* ignore */ }
    }

    function __maybeSetCacheControl(objectPath) {
      try {
        if (!objectPath) return;
        // 只在管理端/測試模式嘗試（避免學生端增加額外寫入）
        if (!(currentState?.viewMode === 'admin' || currentState?.viewMode === 'test')) return;
        if (__cacheControlDone.has(objectPath)) return;

        // fire-and-forget：不阻塞圖片載入
        updateMetadata(storageRef(storage, objectPath), { cacheControl: __DEFAULT_CACHE_CONTROL })
          .then(() => {
            __cacheControlDone.add(objectPath);
            __persistCacheControlDoneToLS();
          })
          .catch(() => { /* ignore (likely permission/rules) */ });
      } catch (e) { /* ignore */ }
    }

        async function resolveAssetUrlFromFileBaseName(fileBaseName) {

      const key = String(fileBaseName || '').trim();
      if (!key) return CONSTANTS.MEDIA.PLACEHOLDER_SVG;

      const paths = __objectPathsForAssetKey(key);
      if (!paths.length) return CONSTANTS.MEDIA.PLACEHOLDER_SVG;

      for (let i = 0; i < paths.length; i++) {
        const objectPath = paths[i];

        // 已是 downloadURL（https://...）：直接使用，不再呼叫 getDownloadURL
        if (typeof objectPath === 'string' && /^https?:\/\//i.test(objectPath)) {
          __assetUrlCache.set(objectPath, objectPath);
          __persistAssetCacheToLS();
          return objectPath;
        }

        // cache hit
        if (__assetUrlCache.has(objectPath)) return __assetUrlCache.get(objectPath);
        if (__assetUrlPromiseCache.has(objectPath)) {
          try {
            return await __assetUrlPromiseCache.get(objectPath);
          } catch (e) { /* try next objectPath */ }
        }

        try {
          const pending = getDownloadURL(storageRef(storage, objectPath));
          __assetUrlPromiseCache.set(objectPath, pending);
          const url = await pending;
          __assetUrlCache.set(objectPath, url);
          __persistAssetCacheToLS();
          __maybeSetCacheControl(objectPath);
          __assetUrlPromiseCache.delete(objectPath);
          return url;
        } catch (e) {
          __assetUrlPromiseCache.delete(objectPath);
          if (i === paths.length - 1) {
            console.warn('[storage] getDownloadURL failed:', { assetKey: key, objectPath }, e?.message || e);
          }
        }
      }

      // fallback：若你把對應路徑設成 public read，也可用直連
      try { return CONSTANTS.MEDIA.mediaUrl(paths[0]); }
      catch { return CONSTANTS.MEDIA.PLACEHOLDER_SVG; }
    }

    function setImgFromFileBaseName(imgEl, fileBaseName, { shadowColor } = {}) {
      if (!imgEl) return;
      imgEl.dataset.asset = fileBaseName || '';
      imgEl.loading = imgEl.loading || 'lazy';
      imgEl.decoding = 'async';
      // 先放 placeholder，避免破圖閃爍
      imgEl.src = imgEl.src || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      if (imgEl.src === location.href) imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      if (shadowColor) imgEl.style.filter = `drop-shadow(0 0 20px ${shadowColor})`;

      // 非同步替換成帶 token 的 URL
      (async () => {
        const base = String(fileBaseName || '');
        if (!base) return;
        const url = await resolveAssetUrlFromFileBaseName(base);
        // 確保沒有被其他更新覆蓋
        if (imgEl.dataset.asset === base) imgEl.src = url;
      })();
    }

    function __getAssetHydrationObserver(root = document, rootMargin = '280px 0px') {
      const holder = (root && root.nodeType === 1) ? root : document.body;
      if (!holder) return null;
      const existing = holder[__assetHydrationObserverKey];
      if (existing) return existing;
      if (typeof IntersectionObserver !== 'function') return null;
      try {
        const observer = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            const img = entry.target;
            observer.unobserve(img);
            if (!img || img.dataset.assetHydrated === '1') return;
            img.dataset.assetHydrated = '1';
            setImgFromFileBaseName(img, img.dataset.asset || '');
          });
        }, { root: null, rootMargin, threshold: 0.01 });
        holder[__assetHydrationObserverKey] = observer;
        return observer;
      } catch (_) {
        return null;
      }
    }

    function hydrateStorageImages(root = document, options = {}) {
      const config = (options && typeof options === 'object') ? options : {};
      const immediate = !!config.immediate;
      const eagerLimit = Number.isFinite(config.eagerLimit) ? Math.max(0, Number(config.eagerLimit)) : 2;
      const rootMargin = String(config.rootMargin || '280px 0px');
      const rootEl = (root && root.nodeType === 1) ? root : document;
      const imgs = [];
      if (rootEl && rootEl.tagName === 'IMG' && rootEl.dataset && rootEl.dataset.asset) imgs.push(rootEl);
      if (rootEl && typeof rootEl.querySelectorAll === 'function') imgs.push(...Array.from(rootEl.querySelectorAll('img[data-asset]')));
      let eagerUsed = 0;
      const observer = immediate ? null : __getAssetHydrationObserver(rootEl, rootMargin);
      imgs.forEach((img) => {
        const base = img?.dataset?.asset;
        if (!base) return;
        img.loading = img.loading || 'lazy';
        img.decoding = 'async';
        if (img.dataset.assetHydrated === '1') return;
        const isPriority = immediate || img.dataset.assetPriority === '1' || eagerUsed < eagerLimit;
        if (isPriority || !observer) {
          img.dataset.assetHydrated = '1';
          eagerUsed += 1;
          setImgFromFileBaseName(img, base);
          return;
        }
        observer.observe(img);
      });
    }

    function prefetchQuizQuestionMedia(questionRecord = null) {
      try {
        const meta = App.resolveQuizImageMeta(questionRecord || {});
        if (meta.imageUrl) {
          const warm = new Image();
          warm.decoding = 'async';
          warm.loading = 'eager';
          warm.src = meta.imageUrl;
          return;
        }
        if (meta.imageAssetKey) {
          const task = () => resolveAssetUrlFromFileBaseName(meta.imageAssetKey).catch(() => null);
          if (typeof requestIdleCallback === 'function') requestIdleCallback(() => { task(); }, { timeout: 800 });
          else setTimeout(task, 0);
        }
      } catch (_) { /* ignore */ }
    }

    
    function __updateLegendarySelectPreview(selectId, imgId, nameId) {
      try {
        const sel = DomBridge.get(selectId);
        const img = DomBridge.get(imgId);
        const name = DomBridge.get(nameId);
        if (!sel || !img || !name) return;

        const val = sel.value;
        const info = (CONSTANTS.LEGENDARIES || []).find(l => String(l.id) === String(val));
        name.innerText = info ? (info.name || val) : '---';
        img.src = info ? (info.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG) : CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      } catch (e) {
        console.warn('[ui] preview update failed:', e?.message || e);
      }
    }

const DomBridge = {
      cache: new Map(),
      get(id) {
        if (!id) return null;
        const cached = this.cache.get(id);
        if (cached && document.body.contains(cached)) return cached;
        const el = document.getElementById(id);
        if (el) this.cache.set(id, el);
        return el;
      },
      getAll(selector, root = document) {
        return Array.from((root || document).querySelectorAll(selector));
      },
      clear(id) {
        if (id) this.cache.delete(id);
        else this.cache.clear();
      }
    };

    const ModuleBridge = {
      modules: new Map(),
      hooks: { beforeInit: [], afterInit: [], afterRoute: [], afterAuth: [] },
      ready: false,
      context: null,
      register(name, moduleDef = {}) {
        const key = String(name || '').trim();
        if (!key) throw new Error('module name is required');
        this.modules.set(key, moduleDef);
        return moduleDef;
      },
      get(name) { return this.modules.get(String(name || '').trim()) || null; },
      has(name) { return this.modules.has(String(name || '').trim()); },
      list() { return Array.from(this.modules.keys()); },
      on(hookName, handler) {
        if (!this.hooks[hookName]) this.hooks[hookName] = [];
        if (typeof handler === 'function') this.hooks[hookName].push(handler);
        return handler;
      },
      async run(hookName, context) {
        const queue = this.hooks[hookName] || [];
        for (const handler of queue) {
          try {
            await handler(context);
          } catch (err) {
            console.warn(`[split-bridge] hook ${hookName} failed:`, err?.message || err);
          }
        }
      },
      markReady(context) {
        this.ready = true;
        this.context = context || this.context;
        try {
          window.dispatchEvent(new CustomEvent(`${APP_CONFIG.eventPrefix}:ready`, {
            detail: {
              version: APP_CONFIG.version,
              modules: this.list()
            }
          }));
        } catch (err) {
          console.warn('[split-bridge] ready event failed:', err?.message || err);
        }
      },
      whenReady(handler) {
        if (typeof handler !== 'function') return;
        if (this.ready && this.context) {
          handler(this.context);
          return;
        }
        const onceHandler = () => {
          window.removeEventListener(`${APP_CONFIG.eventPrefix}:ready`, onceHandler);
          handler(this.context);
        };
        window.addEventListener(`${APP_CONFIG.eventPrefix}:ready`, onceHandler);
      }
    };

initializeState({ buildTag: BUILD_TAG, projectId: firebaseConfig.projectId });

    // ==========================================
    // 【全新升級】：拔除所有原生 alert 與 confirm，自建全域防護模組
    // ==========================================
    const UI = Object.assign(baseUI, {
      show(id) {
        const el = DomBridge.get(id);
        if (el) el.classList.remove('hidden');
      },
      hide(id) {
        const el = DomBridge.get(id);
        if (el) el.classList.add('hidden');
      },
      showModal(id) {
        this.show(id);
      },
      hideModal(id) {
        const el = DomBridge.get(id);
        if (el) el.style.display = '';
        this.hide(id);
      },
      toast(msg) {
        const { toast } = getSystemUiDom();
        if (!toast) return;
        toast.innerText = msg;
        toast.style.opacity = 1;
        setTimeout(() => {
          if (toast) toast.style.opacity = 0;
        }, 3000);
      },
      alert(msg, title = "系統通知") {
        const { alertTitle, alertMsg } = getSystemUiDom();
        if (alertTitle && alertMsg) {
          alertTitle.innerText = title;
          alertMsg.innerText = msg;
          this.showModal('sysAlertModal');
        } else {
          console.error("UI.alert Failed:", msg);
        }
      },
      confirm(msg, title = "請再次確認") {
        return new Promise((resolve) => {
          const { confirmTitle, confirmMsg, confirmBtn, cancelBtn } = getSystemUiDom();
          if (confirmTitle && confirmMsg && confirmBtn && cancelBtn) {
            confirmTitle.innerText = title;
            confirmMsg.innerText = msg;

            const handleConfirm = () => { cleanup(); resolve(true); };
            const handleCancel = () => { cleanup(); resolve(false); };

            const cleanup = () => {
              confirmBtn.removeEventListener('click', handleConfirm);
              cancelBtn.removeEventListener('click', handleCancel);
              this.hideModal('sysConfirmModal');
            };

            confirmBtn.addEventListener('click', handleConfirm);
            cancelBtn.addEventListener('click', handleCancel);

            this.showModal('sysConfirmModal');
          } else {
            resolve(false);
          }
        });
      },
      showImageModal(src, titleText) {
        const { enlargedImg, enlargedTitle } = getSystemUiDom();
        if (!enlargedImg || !enlargedTitle) {
          UI.toast('圖片預覽元件不存在');
          return;
        }
        enlargedImg.src = src;
        enlargedTitle.innerText = titleText;
        this.showModal('imageModal');
      },
      showArchiveModal(index) { return studentApi.showArchiveModal.apply(this, arguments);; },
      showStatusInfo(statusKey) {
        const info = getProfileDebuffInfo(statusKey, currentState.studentData);
        const { statusDescTitle: titleEl, statusDescText: textEl } = getStudentInfoDom();
        if (!titleEl || !textEl) {
          UI.toast('狀態說明面板不存在');
          return;
        }
        titleEl.innerText = `[ 異常狀態：${info.name} ]`;
        titleEl.style.color = info.color;
        textEl.innerHTML = info.desc;
        this.showModal('statusDescModal');
      },
      showAttrInfo(attrKey) {
        const info = getProfileAttributeInfo(attrKey, currentState.studentData);
        const panelConfig = getActionPanelConfig(currentState.studentData);
        const actions = (panelConfig.actions && panelConfig.actions[attrKey]) || CONSTANTS.ACTION_LIST[attrKey] || [];
        const { attrInfoModalContent: modalContent, attrInfoTitle: title, attrInfoIcon: iconEl, attrInfoChar: charEl, attrInfoDesc: descEl, attrInfoList: list } = getStudentInfoDom();
        if (!modalContent || !title || !iconEl || !charEl || !list) {
          UI.toast('屬性說明面板不存在');
          return;
        }
        modalContent.style.borderColor = info.color;
        modalContent.style.boxShadow = `0 0 25px ${info.color}66`;
        const isCat = isCatProfile(currentState.studentData);
        title.innerText = `[ ${info.name}｜${isCat ? '特質說明' : '五行學習指標'} ]`;
        title.style.color = info.color;
        iconEl.innerText = info.icon;
        charEl.innerText = `${isCat ? '代表特質' : '核心能力'}：${info.char || '—'}`;
        if (descEl) descEl.innerText = info.desc || '';
        list.innerHTML = '';
        actions.forEach(act => {
           list.innerHTML += `<li style="border-bottom: 1px dashed rgba(255,255,255,0.1); padding: 6px 0;"><span style="color:#ddd;">${act.desc}</span> <span style="color:${info.color}; font-family:'Orbitron'; float:right; font-weight:bold;">+${act.val}</span></li>`;
        });
        this.showModal('attrInfoModal');
      },
      showHackerAlert(data, diff) {
         const { hackerTargetName: nameEl, hackerXpDiff: diffEl } = getStudentInfoDom();
         if (!nameEl || !diffEl) {
           UI.toast('警示面板不存在');
           return;
         }
         nameEl.innerText = `${data.class_name} | ID:${data.seat_number} | ${data.name}`;
         diffEl.innerText = `+${diff}`;
         this.showModal('hackerAlertModal');
      },
      updateDailyQuestTimer() {
        const { studentView, dailyQuestBtn: btn, dailyQuestTimer: timerText } = getStudentActionDom();
        if (!currentState.studentData || !studentView || studentView.classList.contains('hidden')) return;
        const lastTime = Number(currentState.studentData.last_practice_time) || 0;
        if (!btn || !timerText) return;
        const labels = getProfileLabels(currentState.studentData);
        if (isSameNoonWindow(lastTime)) {
            btn.disabled = true;
            const remain = getNextNoonTimestamp(Date.now()) - Date.now();
            timerText.innerText = fillProfileTemplate(labels.dailyQuestCooldown, { countdown: formatCountdown(remain) });
            timerText.style.color = 'var(--danger)';
        } else {
            btn.disabled = false;
            timerText.innerText = labels.dailyQuestReady || `[ 狀態就緒 ] 每日修練已重置（每日中午 12:00）`;
            timerText.style.color = 'var(--color-grass)';
        }
      },
initActionGrid() {
  const { actionGrid: grid, actionGridModeHint: hintEl } = getStudentActionDom();
  if (!grid) return;
  const panelConfig = getActionPanelConfig(currentState.studentData);
  if (hintEl) {
    hintEl.innerHTML = `<span style="color:var(--legendary-gold); font-weight:bold;">${panelConfig.title}</span><br>${panelConfig.hint}`;
  }
  grid.innerHTML = '';
  for (const attr of CONSTANTS.ATTR_ORDER) {
    const data = (panelConfig.actions && panelConfig.actions[attr]) || CONSTANTS.ACTION_LIST[attr] || [];
    const info = getProfileAttributeInfo(attr, currentState.studentData);
    const focus = panelConfig.attrFocus?.[attr] || null;
    const heading = focus?.label ? `${info.icon} ${focus.label}` : `${info.icon} ${info.char}`;
    let html = `<div class="attr-card attr-${attr}"><h4 style="color:${info.color};">${heading}</h4>`;
    if (focus?.summary) {
      html += `<div style="font-size:0.78em; line-height:1.6; color:var(--text-muted); margin:-2px 0 10px;">${info.name}對應：${focus.summary}</div>`;
    }
    data.forEach(act => {
      const safeDesc = String(act.desc ?? '')
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      html += `<button type="button" class="action-btn" data-attr="${attr}" data-val="${act.val}" data-desc="${safeDesc}" onclick="App.prepareActionFromButton(this); return false;">
                  <span style="font-family:Noto Sans TC, sans-serif;">${act.desc}</span> <span style="font-family:'Orbitron'; color:${info.color}">+${act.val}</span>
               </button>`;
    });
    html += `</div>`;
    grid.innerHTML += html;
  }
},
      updateDragonImage(data, imgElementId) { return studentApi.updateDragonImage.apply(this, arguments);; },
      updateCollectionGallery(data, galleryId) { return studentApi.updateCollectionGallery.apply(this, arguments);; },
      updateStudentAttributes(data, rowId) { return studentApi.updateStudentAttributes.apply(this, arguments);; },
      renderRadarChartRaw(statsObj, canvasId, instanceKey, borderColor, bgColor) { return studentApi.renderRadarChartRaw.apply(this, arguments);; },
      updateStatusContainer(data, containerId) { return studentApi.updateStatusContainer.apply(this, arguments);; },
      updatePanel(data, isStudentMode = false) { return studentApi.updatePanel.apply(this, arguments);; },
    });

    const App = {
      ndef: null,

      createModuleContext(extra = {}) {
        return {
          App: this,
          UI,
          DomBridge,
          ModuleBridge,
          currentState,
          batchState,
          quizSession,
          radarChartInstances,
          CONSTANTS,
          TYPE_INFO,
          CONTENT_PROFILES,
          APP_CONFIG,
          db,
          auth,
          storage,
          ...extra
        };
      },

      registerModule(name, moduleDef = {}) {
        return ModuleBridge.register(name, moduleDef);
      },

      onModuleHook(hookName, handler) {
        return ModuleBridge.on(hookName, handler);
      },

      getRegisteredModules() {
        return ModuleBridge.list();
      },

      // --- Auth helpers (P0: move admin login to Firebase Auth + Rules) ---
      async ensureStudentAuth() { return authApi.ensureStudentAuth.apply(this, arguments);; },
      async isCurrentUserAdmin() { return authApi.isCurrentUserAdmin.apply(this, arguments);; },
      renderAdminDiagnostics() { return authApi.renderAdminDiagnostics.apply(this, arguments);; },
      toggleAdminDiagPanel(forceOpen = null) {
        const { adminDiagInlineWrap: wrap } = getRuntimeUiDom();
        if (!wrap) return;
        const shouldOpen = forceOpen == null ? wrap.classList.contains('hidden') : Boolean(forceOpen);
        wrap.classList.toggle('hidden', !shouldOpen);
        if (shouldOpen) {
          this.renderAdminDiagnostics();
        }
      },

      async refreshAdminDiagnostics() {
        try {
          const ok = await this.isCurrentUserAdmin();
          currentState.isAdmin = ok;
          UI.toast(ok ? '管理員權限檢查：已通過' : '管理員權限檢查：未通過');
        } catch (e) {
          console.error('[auth] refreshAdminDiagnostics failed:', e);
          UI.alert(`重新檢查失敗：${e?.message || e}`, '診斷失敗');
        }
      },

      // --- Token helpers (方案三：base62 + hash + active=false) ---
      // --- Token helpers (方案三：base62 + hash + active=false) ---
      getTokenFromHash(hashStr = window.location.hash) {
        try {
          const h = String(hashStr || '').trim();
          if (!h) return null;
          const hs = h.startsWith('#') ? h.slice(1) : h;
          const qs = hs.startsWith('?') ? hs.slice(1) : hs;
          const sp = new URLSearchParams(qs);
          const t = sp.get('t');
          return t ? String(t).trim() : null;
        } catch (_) { return null; }
      },

      normalizeSerial(raw) {
        const digits = String(raw == null ? '' : raw).replace(/[^0-9]/g, '');
        if (!digits) return null;
        return digits.padStart(3, '0');
      },

      // UID 標準化：移除掃描槍常見的冒號/空白，統一大寫
      normalizeUid(raw) {
        return String(raw == null ? '' : raw).trim().toUpperCase().replace(/:/g, '').replace(/\s+/g, '');
      },

      
      validateEvolutionTree() {
        return evolutionApi?.validateEvolutionTree ? evolutionApi.validateEvolutionTree(...arguments) : [];
      },

      // --- Student access gate (Token required) ---
      lockStudentAccess(message) {
        currentState.currentTokenValidated = false;
        currentState.currentToken = null;
        currentState.currentUid = null;
        currentState.studentData = null;
        currentState.studentLocked = true;

        const { studentLockOverlay: overlay, studentLockMsg: msgEl, studentLockPanel: panelEl, studentLockTitle: titleEl } = getStudentActionDom();
        const msg = message || '請使用已註冊的 NFC 卡片進入學生面板。';
        const isInfo = /驗證中|讀取中|感應中|載入中/.test(msg);
        if (msgEl) msgEl.textContent = msg;
        if (panelEl) {
          panelEl.style.borderColor = isInfo ? 'var(--cyan)' : 'var(--danger)';
          panelEl.style.boxShadow = isInfo ? '0 0 26px rgba(0,229,255,0.22)' : '0 0 26px rgba(255,0,85,0.22)';
        }
        if (titleEl) {
          titleEl.textContent = isInfo ? 'CARD CHECKING' : '請先感應學生卡';
          titleEl.style.color = isInfo ? 'var(--cyan)' : 'var(--danger)';
        }
        if (overlay) overlay.classList.remove('hidden');
        this.resetSessionIdleTimer();
      },

      unlockStudentAccess() {
        currentState.studentLocked = false;
        const { studentLockOverlay: overlay } = getStudentActionDom();
        if (overlay) overlay.classList.add('hidden');
        this.resetSessionIdleTimer();
      },

      buildStudentUrlFromToken(...args) { return studentAccessApi.buildStudentUrlFromToken(...args); },
      generateBase62Token(...args) { return studentAccessApi.generateBase62Token(...args); },
      async resolveSerialFromToken(...args) { return studentAccessApi.resolveSerialFromToken(...args); },
      async getActiveTokenForSerial(...args) { return studentAccessApi.getActiveTokenForSerial(...args); },
      async ensureActiveTokenForSerial(...args) { return studentAccessApi.ensureActiveTokenForSerial(...args); },
      async writeCurrentStudentUrlToCard(...args) { return studentAccessApi.writeCurrentStudentUrlToCard(...args); },

      dedupeLogs(logs = []) {
        return dedupeLogsCore(logs);
      },

      dedupeCollection(items = []) {
        return dedupeCollectionCore(items);
      },

      mergeStudentRecords(primary = {}, secondary = {}, serial = null) {
        const base = this.applyDataMigration(JSON.parse(JSON.stringify(primary || {})));
        const other = this.applyDataMigration(JSON.parse(JSON.stringify(secondary || {})));
        const merged = { ...other, ...base };
        const s = this.normalizeSerial(serial || base.card_seq || base.serial || other.card_seq || other.serial);
        const hasOwn = (obj, key) => !!obj && Object.prototype.hasOwnProperty.call(obj, key);
        const pickScalar = (key, fallback = null) => hasOwn(base, key) ? base[key] : (hasOwn(other, key) ? other[key] : fallback);
        const pickNumeric = (key, fallback = 0) => {
          if (hasOwn(base, key)) return Number(base[key]) || 0;
          if (hasOwn(other, key)) return Number(other[key]) || 0;
          return fallback;
        };
        const pickNumericWithDefault = (key, fallback) => {
          if (hasOwn(base, key)) {
            const n = Number(base[key]);
            return Number.isFinite(n) ? n : fallback;
          }
          if (hasOwn(other, key)) {
            const n = Number(other[key]);
            return Number.isFinite(n) ? n : fallback;
          }
          return fallback;
        };
        const pickNestedNumeric = (containerKey, nestedKey, fallback = 0) => {
          const baseObj = (base && typeof base[containerKey] === 'object') ? base[containerKey] : null;
          const otherObj = (other && typeof other[containerKey] === 'object') ? other[containerKey] : null;
          if (baseObj && Object.prototype.hasOwnProperty.call(baseObj, nestedKey)) return Number(baseObj[nestedKey]) || 0;
          if (otherObj && Object.prototype.hasOwnProperty.call(otherObj, nestedKey)) return Number(otherObj[nestedKey]) || 0;
          return fallback;
        };
        const pickNestedOrder = (nestedKey) => {
          const baseObj = (base && typeof base.attribute_first_gain_order === 'object') ? base.attribute_first_gain_order : null;
          const otherObj = (other && typeof other.attribute_first_gain_order === 'object') ? other.attribute_first_gain_order : null;
          if (baseObj && Object.prototype.hasOwnProperty.call(baseObj, nestedKey)) {
            const n = Number(baseObj[nestedKey]);
            return Number.isFinite(n) && n > 0 ? n : null;
          }
          if (otherObj && Object.prototype.hasOwnProperty.call(otherObj, nestedKey)) {
            const n = Number(otherObj[nestedKey]);
            return Number.isFinite(n) && n > 0 ? n : null;
          }
          return null;
        };
        const mergeUniqueScalars = (baseArr, otherArr) => Array.from(new Set([...(Array.isArray(otherArr) ? otherArr : []), ...(Array.isArray(baseArr) ? baseArr : [])].map(v => String(v || '').trim()).filter(Boolean)));

        merged.uid = pickScalar('uid', null) || null;
        merged.card_seq = s || pickScalar('card_seq', null) || null;
        merged.serial = s || pickScalar('serial', null) || null;
        merged.class_name = String(pickScalar('class_name', '') || '');
        merged.name = String(pickScalar('name', '') || '');
        merged.seat_number = String(pickScalar('seat_number', '匿名') || '匿名');
        merged.boss_win_total = Math.max(Number(base?.boss_win_total) || 0, Number(other?.boss_win_total) || 0);
        merged.daily_correct_total = Math.max(Number(base?.daily_correct_total) || 0, Number(other?.daily_correct_total) || 0);
        merged.totalXP = pickNumeric('totalXP', 0);
        merged.coins = pickNumeric('coins', 0);
        merged.lap = pickNumericWithDefault('lap', 1);
        merged.trainerRankIndex = pickNumeric('trainerRankIndex', 0);
        merged.best_rate = pickNumericWithDefault('best_rate', this.getRateFromRankIndex(merged.trainerRankIndex));
        if (!Number.isFinite(merged.best_rate) || merged.best_rate <= 0) merged.best_rate = this.getRateFromRankIndex(merged.trainerRankIndex);
        merged.last_practice_time = Math.max(Number(base.last_practice_time) || 0, Number(other.last_practice_time) || 0);
        merged.last_battle_time = Math.max(Number(base.last_battle_time) || 0, Number(other.last_battle_time) || 0);
        merged.dragon_stage = pickNumericWithDefault('dragon_stage', -1);
        merged.dragon_path = pickScalar('dragon_path', null) || null;
        merged.display_team = Array.isArray(base.display_team) ? [...base.display_team] : (Array.isArray(other.display_team) ? [...other.display_team] : []);
        const baseProfile = primary && primary.content_profile_id ? primary.content_profile_id : null;
        const otherProfile = secondary && secondary.content_profile_id ? secondary.content_profile_id : null;
        merged.content_profile_id = baseProfile || otherProfile || 'shanhai';
        merged.ui_variant = (primary && primary.ui_variant) || (secondary && secondary.ui_variant) || (merged.content_profile_id === 'cat' ? 'muslim_friendly' : 'default');
        merged.profile_flags = Object.assign({}, secondary?.profile_flags || {}, primary?.profile_flags || {});
        merged.guide_mode = pickScalar('guide_mode', merged.content_profile_id === 'cat' ? 'lingmao' : 'baize') || (merged.content_profile_id === 'cat' ? 'lingmao' : 'baize');
        merged.guide_mode_locked = hasOwn(base, 'guide_mode_locked') ? base.guide_mode_locked !== false : (hasOwn(other, 'guide_mode_locked') ? other.guide_mode_locked !== false : true);
        merged.attributes = {};
        merged.streaks = {};
        merged.attr_event_counts = {};
        merged.attribute_first_gain_order = { metal: null, wood: null, water: null, fire: null, earth: null };
        merged.debuffs = {};
        const rawPrimary = (primary && typeof primary === 'object') ? primary : {};
        const rawSecondary = (secondary && typeof secondary === 'object') ? secondary : {};
        const primaryHasDebuffState = !!(
          (rawPrimary.debuffs && typeof rawPrimary.debuffs === 'object') ||
          Object.prototype.hasOwnProperty.call(rawPrimary, 'status') ||
          Object.prototype.hasOwnProperty.call(rawPrimary, 'debuffs_timestamp')
        );
        const secondaryHasDebuffState = !!(
          (rawSecondary.debuffs && typeof rawSecondary.debuffs === 'object') ||
          Object.prototype.hasOwnProperty.call(rawSecondary, 'status') ||
          Object.prototype.hasOwnProperty.call(rawSecondary, 'debuffs_timestamp')
        );
        ELEMENT_KEYS.forEach(k => {
          merged.attributes[k] = pickNestedNumeric('attributes', k, 0);
          merged.streaks[k] = pickNestedNumeric('streaks', k, 0);
          merged.attr_event_counts[k] = pickNestedNumeric('attr_event_counts', k, 0);
          merged.attribute_first_gain_order[k] = pickNestedOrder(k);
        });
        ['Poison','Frozen','Paralyzed','Confusion'].forEach(k => {
          if (primaryHasDebuffState) {
            merged.debuffs[k] = Number(base.debuffs?.[k]) || 0;
          } else if (secondaryHasDebuffState) {
            merged.debuffs[k] = Number(other.debuffs?.[k]) || 0;
          } else {
            merged.debuffs[k] = 0;
          }
        });
        if (primaryHasDebuffState) {
          merged.debuffs_timestamp = Number(base.debuffs_timestamp) || null;
        } else if (secondaryHasDebuffState) {
          merged.debuffs_timestamp = Number(other.debuffs_timestamp) || null;
        } else {
          merged.debuffs_timestamp = null;
        }
        merged.status = pickScalar('status', 'Healthy') || 'Healthy';
        merged.status_timestamp = pickNumericWithDefault('status_timestamp', null);
        merged.collection = this.dedupeCollection([...(other.collection || []), ...(base.collection || [])]);
        merged.logs = this.dedupeLogs([...(other.logs || []), ...(base.logs || [])]);
        merged.hidden_eggs = this.dedupeCollection([...(other.hidden_eggs || []), ...(base.hidden_eggs || [])]);
        merged.reward_events = this.dedupeLogs([...(other.reward_events || []), ...(base.reward_events || [])]);
        merged.reward_settled_ids = mergeUniqueScalars(base.reward_settled_ids, other.reward_settled_ids);
        merged.active_hidden_egg_id = pickScalar('active_hidden_egg_id', '') || '';
        merged.active_hidden_egg = pickScalar('active_hidden_egg', null) || null;
        merged.free_rename_available = hasOwn(base, 'free_rename_available') ? base.free_rename_available === true : (hasOwn(other, 'free_rename_available') ? other.free_rename_available === true : false);
        if (!merged.active_hidden_egg && merged.active_hidden_egg_id) {
          merged.active_hidden_egg = merged.hidden_eggs.find(item => String(item.hiddenEggId || item.id || '') === String(merged.active_hidden_egg_id))
            || merged.collection.find(item => item && item.type === 'hidden_egg' && String(item.hiddenEggId || item.id || '') === String(merged.active_hidden_egg_id))
            || null;
        }
        ensureAttributeFirstGainOrder(merged);
        return this.applyDataMigration(merged);
      },

      async syncStudentMirrorForSerial(...args) { return studentAccessApi.syncStudentMirrorForSerial(...args); },
      async saveStudentTokenPayload(...args) { return studentAccessApi.saveStudentTokenPayload(...args); },
      async saveFastAdminStudentPayload(...args) { return studentAccessApi.saveFastAdminStudentPayload(...args); },

      getBuiltInShopItems() {
        const profile = getContentProfile(currentState.studentData);
        const alias = profile.builtInShop || {};
        return [
          { id: 'antidote', name: alias.antidote?.name || '💊 萬靈藥', desc: alias.antidote?.desc || '清除所有負面狀態', cost: 10, borderColor: 'var(--color-grass)', effectType: 'antidote', quantity: null, active: true, builtIn: true },
          { id: 'evo_stone', name: alias.evo_stone?.name || '✨ 各系進化石', desc: alias.evo_stone?.desc || '指定屬性直接 +30 XP', cost: 20, borderColor: 'var(--color-fire)', effectType: 'evo_stone', quantity: null, active: true, builtIn: true },
          { id: 'wonder_stone', name: alias.wonder_stone?.name || '🌟 進化奇石', desc: alias.wonder_stone?.desc || '指定屬性素材 +1', cost: 50, borderColor: 'var(--color-fairy)', effectType: 'wonder_stone', quantity: null, active: true, builtIn: true },
          { id: 'azure_kirin_egg', name: '🌊 碧瀾麒麟蛋', desc: '水屬性隱藏異獸蛋；沿用原本經驗累積與進化節奏，最終可轉化為碧瀾麒麟（★100）', cost: 100, borderColor: 'var(--color-water)', effectType: 'hidden_egg', hiddenEggId: 'azure_kirin', quantity: null, active: true, builtIn: true },
          { id: 'marshmallow_physical', name: '🍡 烤棉花糖(實體)', desc: '需在老師面前購買才能獲得（否則不算數）', cost: 50, borderColor: 'var(--color-electric)', effectType: 'physical_reward', quantity: null, active: true, builtIn: true }
        ];
      },

      getShopEffectLabel(effectType) {
        const alias = (getContentProfile(currentState.studentData).builtInShop || {});
        const map = { antidote: alias.antidote?.name || '萬靈藥', evo_stone: alias.evo_stone?.name || '進化石', wonder_stone: alias.wonder_stone?.name || '進化奇石', physical_reward: '實體兌換品', hidden_egg: alias.hidden_egg?.name || '特殊異獸蛋' };
        return map[effectType] || effectType || '自訂商品';
      },

      getShopButtonHtml(item) {
        const cost = Number(item.cost) || 0;
        const qty = (item.quantity === null || item.quantity === undefined || item.quantity === '') ? null : Math.max(0, Number(item.quantity) || 0);
        const soldOut = qty !== null && qty <= 0;
        const inactive = item.active === false;
        const borderColor = (soldOut || inactive) ? '#666' : (item.borderColor || 'var(--color-electric)');
        const extra = item.effectType === 'hidden_egg' && item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId]
          ? `<br/><span style="font-size:0.68em; color:var(--legendary-gold); font-family:Noto Sans TC, sans-serif;">${CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].desc}</span>`
          : '';
        const statusLabel = inactive ? '未上架' : (qty === null ? '不限量' : (soldOut ? '售罄' : `剩餘 ${qty}`));
        const statusColor = inactive ? 'var(--text-muted)' : (soldOut ? '#999' : (item.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--cyan)'));
        return `<button class="btn shop-item" onclick="App.handleShopPurchase('${item.id}', ${cost}, ${item.builtIn ? 'true' : 'false'})" ${soldOut || inactive ? 'disabled' : ''} style="text-align:left; border-color:${borderColor}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.55' : '1'};">
          ${String(item.name || '未命名商品')} (${cost} 🪙)<br/><span style="font-size:0.7em; color:${soldOut || inactive ? '#999' : 'var(--text-muted)'}; font-family:Noto Sans TC, sans-serif;">${String(item.desc || '—')}</span>${extra}
          <div class="tech-font" style="margin-top:6px; font-size:0.72em; color:${statusColor};">${statusLabel}</div>
        </button>`;
      },

      async renderShopItems() { return shopApi.renderShopItems(...arguments); },
      populateHiddenEggSelect() { return shopApi.populateHiddenEggSelect(...arguments); },
      updateShopAdminFormState() { return shopApi.updateShopAdminFormState(...arguments); },
      resetShopAdminForm() { return shopApi.resetShopAdminForm(...arguments); },
      resetShopGiftForm() { return shopApi.resetShopGiftForm(...arguments); },
      setShopAdminTab(tab = 'catalog') { return shopApi.setShopAdminTab(tab); },
      getAdminGiftableShopItems() { return shopApi.getAdminGiftableShopItems(...arguments); },
      async loadShopGiftOptions(preferredId = '') { return shopApi.loadShopGiftOptions(preferredId); },
      pickShopGiftItem(sourceId) { return shopApi.pickShopGiftItem(sourceId); },
      fillShopGiftCurrentStudent() { return shopApi.fillShopGiftCurrentStudent(...arguments); },
      async lookupShopGiftTarget() { return shopApi.lookupShopGiftTarget(...arguments); },
      async getShopGiftItemMeta(sourceId) { return shopApi.getShopGiftItemMeta(sourceId); },
      async applyAdminGiftEffect(data, itemMeta, targetSerial, selectedAttr = 'metal', note = '') { return shopApi.applyAdminGiftEffect(data, itemMeta, targetSerial, selectedAttr, note); },
      async sendShopGift() { return shopApi.sendShopGift(...arguments); },
      async openShopAdmin() { return shopApi.openShopAdmin(...arguments); },
      async loadShopAdminList() { return shopApi.loadShopAdminList(...arguments); },
      async editShopProduct(productId) { return shopApi.editShopProduct(productId); },
      async saveShopProduct() { return shopApi.saveShopProduct(...arguments); },
      async deleteShopProduct(productId) { return shopApi.deleteShopProduct(productId); },

      resetGameplayState(...args) { return batchApi.resetGameplayState(...args); },

      openBulkProgressModal(...args) { return batchApi.openBulkProgressModal(...args); },

      getBulkSerialRange(...args) { return batchApi.getBulkSerialRange(...args); },

      async bulkRepairStudentPages(...args) { return studentAccessApi.bulkRepairStudentPages(...args); },

      async bulkUpdateProgressAndGrade(...args) { return batchApi.bulkUpdateProgressAndGrade(...args); },
      async tryAutoEnterAdmin() { return authApi.tryAutoEnterAdmin.apply(this, arguments);; },
      async logoutAdmin() { return authApi.logoutAdmin.apply(this, arguments);; },
      bindSessionActivityWatchers() { return authApi.bindSessionActivityWatchers.apply(this, arguments);; },
      getSessionIdleMode() { return authApi.getSessionIdleMode.apply(this, arguments);; },
      async handleIdleTimeout(mode) { return authApi.handleIdleTimeout.apply(this, arguments);; },
      resetSessionIdleTimer() { return authApi.resetSessionIdleTimer.apply(this, arguments);; },
      async generateUniqueName(...args) { return studentAccessApi.generateUniqueName(...args); },

      async studentRerollName() {
         let data = currentState.studentData;
         if (!data) return;

         const isFree = (data.free_rename_available === true);
         const cost = isFree ? 0 : 1;

         const currentCoins = Number(data.coins) || 0;
         if (cost > 0 && currentCoins < cost) { 
            UI.alert(`餘額不足！需要 ${cost} 🪙 才能改名喔。`, "操作失敗"); 
            return; 
         }

         const confirmMsg = cost === 0
           ? "首次改名免費！確定要重新抽取代號嗎？\n(舊代號將被釋放回系統)"
           : "確定要消耗 1 🪙 重新抽取代號嗎？\n(舊代號將被釋放回系統)";
         const isConfirmed = await UI.confirm(confirmMsg, "基因重組確認");
         if (!isConfirmed) return;

         this.executeStudentRename();
      },

      async executeStudentRename() {
         let data = JSON.parse(JSON.stringify(currentState.studentData));

         const isFree = (data.free_rename_available === true);
         const cost = isFree ? 0 : 1;
         if (cost > 0 && (Number(data.coins) || 0) < cost) return;

         try {
           UI.toast("⏳ 基因重組中，請稍候...");

           const codes = CONSTANTS.ANONYMOUS_CODES || ["星塵", "光年", "矩陣"];
           const picked = codes[Math.floor(Math.random() * codes.length)];
           const newName = `匿名學員-${picked}_${Math.floor(Math.random()*1000)}`;

           if (cost > 0) data.coins -= cost;
           data.name = newName;
           if (isFree) data.free_rename_available = false;
           data.logs.push({ timestamp: Date.now(), action_type: "system", detail: cost > 0 ? `[商城] 消耗 1 🪙 重新抽取代號：${newName}` : `[商城] 首次改名免費：${newName}` });

           const savedAfterRename = await this.saveToDB(data);
           const latest = this.applyDataMigration(JSON.parse(JSON.stringify(savedAfterRename || data)));
           currentState.studentData = latest;
           if (typeof this.refreshStudentIdentityLabels === 'function') this.refreshStudentIdentityLabels(latest);
           try { UI.updatePanel(latest, currentState.viewMode === 'student'); } catch (_) {}
           UI.toast(`✨ 改名成功！新代號為：${newName}`);
         } catch (error) {
           console.error("改名異常:", error);
           UI.alert("改名失敗，請檢查網路狀態或稍後再試。", "錯誤");
         }
      },

      async rollRegistrationName(...args) { return studentAccessApi.rollRegistrationName(...args); },
      async registerNewStudent(...args) { return studentAccessApi.registerNewStudent(...args); },
      escapeBaizeText(text = '') {
        return String(text || '')
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
      },

      getCatGuideAvatar() {
        return 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FA%20Sagacious%20Cat_800x800.webp?alt=media&token=58e2a846-e249-4741-ac54-b8ad501e6d69&v=20260308';
      },

      getGuideMode(data = null) {
        const src = data || currentState.studentData || {};
        const query = new URLSearchParams(window.location.search);
        const qg = String(query.get('guide') || '').trim().toLowerCase();
        const explicitGuideMode = String(src?.guide_mode || src?.assistant_mode || '').trim().toLowerCase();
        const locked = src?.guide_mode_locked !== false;
        const contentProfileId = String(src?.content_profile_id || '').trim().toLowerCase();
        const uiVariant = String(src?.ui_variant || '').trim().toLowerCase();

        // 最高優先：網址明確指定 guide 角色（僅供測試/覆蓋）
        if (qg === 'cat' || qg === 'sage_cat') return 'cat';
        if (qg === 'baize' || qg === 'shanhai') return 'baize';

        // 真實來源：老師或資料庫明確寫入的 guide_mode
        if (explicitGuideMode === 'cat' || explicitGuideMode === 'sage_cat') return 'cat';
        if (explicitGuideMode === 'baize' || explicitGuideMode === 'shanhai') return 'baize';

        // 若未鎖定，才允許跟內容模式同步推論
        if (!locked) {
          if (contentProfileId === 'cat' || uiVariant === 'muslim_friendly') return 'cat';
          if (contentProfileId === 'shanhai' || uiVariant === 'default') return 'baize';
        }

        // 舊資料回補：優先看明確的內容模式，不再讀多個旗標猜測
        if (contentProfileId === 'cat' || uiVariant === 'muslim_friendly') return 'cat';
        if (contentProfileId === 'shanhai' || uiVariant === 'default') return 'baize';

        // 安全預設：沒有明確設定時，一律走智者貓咪
        return 'cat';
      },


      getBaizeGuideConfig(data = null) {
        if (AI_GUIDE_RUNTIME.enabled !== true) {
          return {
            enabled: false,
            disabled: true,
            reason: AI_GUIDE_RUNTIME.disabledReason,
            key: 'disabled',
            assistantName: 'AI 夥伴',
            statusWaiting: '[ AI 夥伴功能已停用 ]',
            statusReady: '[ AI 夥伴功能已停用 ]',
            statusThinking: '[ AI 夥伴功能已停用 ]',
            statusDone: '[ AI 夥伴功能已停用 ]',
            statusFail: '[ AI 夥伴功能已停用 ]',
            emptyToast: AI_GUIDE_RUNTIME.disabledReason,
            overLimitAlert: AI_GUIDE_RUNTIME.disabledReason,
            unauthenticatedReply: AI_GUIDE_RUNTIME.disabledReason,
            notDeployedReply: AI_GUIDE_RUNTIME.disabledReason,
            genericReply: AI_GUIDE_RUNTIME.disabledReason,
            welcomeText: AI_GUIDE_RUNTIME.disabledReason
          };
        }
        const src = data || currentState.studentData || {};
        const flags = getProfileFlags(src);
        if (flags.hide_ai_guide === true || flags.hide_baize === true) {
          return { enabled: false };
        }
        const guideMode = this.getGuideMode(src);
        if (guideMode === 'cat') {
          return {
            enabled: true,
            key: 'cat',
            persona: 'cat',
            assistantName: '智者貓咪',
            sectionTitle: '🐾 智者貓咪',
            sectionDesc: '若你對照護、自然、科學或任務中的疑問有困惑，可向智者貓咪請教。牠只會一步步引導你思考，不會直接給答案。',
            buttonLabel: '請教智者貓咪',
            modalTitle: '🐾 智者貓咪',
            modalDesc: '智者貓咪會用溫和的方式陪你梳理想法，不直接給標準答案。若遇到重要問題，仍請再向老師確認。',
            suggestionText: '建議提問：例如「小貓為什麼喜歡追光點？」、「我這題卡住了，可以提醒我先想哪一步？」',
            placeholder: '請輸入你想請教智者貓咪的問題…',
            welcomeText: '嗨，年輕的照護員。我是智者貓咪。若你對自然、科學或任務卡關了，可以先告訴我你已經想到哪一步，我陪你慢慢整理。',
            statusWaiting: '[ 等待請教 ]',
            statusReady: '[ 可向智者貓咪請教 ]',
            statusThinking: '[ 智者貓咪正在整理鬍鬚與思路… ]',
            statusDone: '[ 智者貓咪已回應 ]',
            statusFail: '[ 智者貓咪去打盹了 ]',
            emptyToast: '請先輸入想請教智者貓咪的問題',
            overLimitAlert: '問題請控制在 300 字以內，讓智者貓咪更容易聚焦引導你。',
            unauthenticatedReply: '你目前尚未完成學生驗證，請重新感應學生卡後再請教智者貓咪。',
            notDeployedReply: '尚未部署 askBaize 後端函式，請先到 Firebase Functions 完成部署。',
            genericReply: '智者貓咪暫時沒有回應，請稍後再試。',
            avatarSrc: this.getCatGuideAvatar()
          };
        }
        return {
          enabled: true,
          key: 'baize',
          persona: 'baize',
          assistantName: '白澤',
          sectionTitle: '🦄 白澤',
          sectionDesc: '若你對自然、科學或任務中的疑問有困惑，可向白澤請示。白澤只會引導你思考，不會直接給答案。',
          buttonLabel: '請示白澤',
          modalTitle: '🦄 白澤靈諭',
          modalDesc: '白澤會以引導方式協助思考，不直接提供標準答案。若遇到重要問題，仍請再向老師確認。',
          suggestionText: '建議提問：例如「為什麼月亮會有圓缺？」、「我這題卡住了，可以提醒我先想哪一步？」',
          placeholder: '請輸入你想請示白澤的問題…',
          welcomeText: '年輕的守護員，吾乃白澤。若你對自然萬物、科學現象或任務關卡有所疑惑，可先說說你已經想到哪一步，吾再循序引你探究。',
          statusWaiting: '[ 等待請教 ]',
          statusReady: '[ 可向白澤請示 ]',
          statusThinking: '[ 白澤正在推演萬物之理… ]',
          statusDone: '[ 白澤已回應 ]',
          statusFail: '[ 白澤靈力不足 ]',
          emptyToast: '請先輸入想請示白澤的問題',
          overLimitAlert: '問題請控制在 300 字以內，讓白澤更容易聚焦引導你。',
          unauthenticatedReply: '你目前尚未完成學生驗證，請重新感應學生卡後再請示白澤。',
          notDeployedReply: '尚未部署 askBaize 後端函式，請先到 Firebase Functions 完成部署。',
          genericReply: '白澤暫時沒有回應，請稍後再試。',
          avatarSrc: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBaize%2FBaize_800x800.webp?alt=media&token=e2a96804-1c49-4374-a83a-96d34c5b2e92&v=20260308'
        };
      },

      refreshBaizeUi(data = null) {
        const guide = this.getBaizeGuideConfig(data);
        const dom = getBaizeDom();
        const section = dom.section;
        if (!section) return guide;
        if (!guide.enabled) {
          section.style.display = 'none';
          if (!dom.modal?.classList.contains('hidden')) this.closeBaizeModal();
          return guide;
        }
        section.style.display = '';
        const avatar = dom.guideAvatar;
        if (avatar) {
          avatar.style.opacity = '1';
          avatar.onload = () => { avatar.style.opacity = '1'; };
          avatar.src = guide.avatarSrc || '';
          avatar.alt = guide.assistantName || '智慧引導夥伴';
          avatar.onerror = () => {
            avatar.onerror = null;
            avatar.src = guide.key === 'cat'
              ? 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FA%20Sagacious%20Cat_800x800.webp?alt=media&token=58e2a846-e249-4741-ac54-b8ad501e6d69&v=20260308c'
              : 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBaize%2FBaize_800x800.webp?alt=media&token=e2a96804-1c49-4374-a83a-96d34c5b2e92&v=20260308c';
            avatar.style.opacity = '1';
          };
          if (avatar.complete && avatar.naturalWidth > 0) avatar.style.opacity = '1';
        }
        const titleEl = dom.guideTitle;
        if (titleEl) titleEl.textContent = guide.sectionTitle;
        const descEl = dom.guideDesc;
        if (descEl) descEl.textContent = guide.sectionDesc;
        const btn = dom.guideOpenBtn;
        if (btn) btn.textContent = guide.buttonLabel;
        const modalTitle = dom.modalTitle;
        if (modalTitle) modalTitle.textContent = guide.modalTitle;
        const modalDesc = dom.modalDesc;
        if (modalDesc) modalDesc.textContent = guide.modalDesc;
        const suggestion = dom.suggestionText;
        if (suggestion) suggestion.textContent = guide.suggestionText;
        const input = dom.input;
        if (input) input.placeholder = guide.placeholder;
        const status = dom.statusText;
        if (status && !currentState.baizeSending) status.textContent = guide.statusWaiting || '[ 等待請教 ]';
        const sendBtn = dom.sendBtn;
        if (sendBtn) sendBtn.textContent = guide.key === 'cat' ? '送出請教' : '送出請示';
        const modalEl = dom.modalContent;
        if (modalEl) modalEl.setAttribute('data-guide-mode', guide.key || 'cat');
        return guide;
      },

      ensureBaizeHistory() {
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        const guideKey = guide.enabled ? guide.key : 'hidden';
        if (currentState.baizeGuideKey !== guideKey || !Array.isArray(currentState.baizeHistory) || currentState.baizeHistory.length === 0) {
          currentState.baizeHistory = guide.enabled ? [{ role: 'assistant', text: guide.welcomeText }] : [];
          currentState.baizeGuideKey = guideKey;
        }
        return currentState.baizeHistory;
      },

      renderBaizeHistory() {
        const historyEl = getBaizeDom().chatHistory;
        if (!historyEl) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        const history = this.ensureBaizeHistory();
        historyEl.innerHTML = history.map((entry) => {
          const isUser = entry.role === 'user';
          const name = isUser ? '你' : guide.assistantName;
          const bubbleStyle = isUser
            ? 'background:rgba(255,255,255,0.12); color:#fff; border-radius:14px 14px 4px 14px; margin-left:auto; border:1px solid rgba(255,255,255,0.08);'
            : 'background:rgba(0,229,255,0.12); color:#d8fbff; border-radius:14px 14px 14px 4px; margin-right:auto; border:1px solid rgba(0,229,255,0.18);';
          const safeText = this.escapeBaizeText(entry.text).replace(/\n/g, '<br>');
          return `
            <div style="display:flex; ${isUser ? 'justify-content:flex-end;' : 'justify-content:flex-start;'} margin-bottom:10px;">
              <div style="max-width:84%; padding:10px 12px; line-height:1.6; font-size:0.92em; ${bubbleStyle}">
                <div class="tech-font" style="font-size:0.7em; margin-bottom:4px; opacity:0.78;">${name}</div>
                <div>${safeText}</div>
              </div>
            </div>`;
        }).join('');
        historyEl.scrollTop = historyEl.scrollHeight;
      },

      setBaizeStatus(text = null) {
        const el = getBaizeDom().statusText;
        if (!el) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        el.textContent = text || guide.statusWaiting || '[ 等待請教 ]';
      },

      bindBaizeUi() {
        if (currentState.baizeBound) return;
        const dom = getBaizeDom();
        const guide = this.refreshBaizeUi(currentState.studentData);
        this.ensureBaizeHistory();
        this.renderBaizeHistory();
        this.setBaizeStatus();
        if (!guide.enabled) {
          currentState.baizeBound = true;
          return;
        }
        const input = dom.input;
        if (input) {
          input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              this.sendBaizeMessage();
            }
          });
        }
        currentState.baizeBound = true;
      },
      openBaizeModal() {
        const guide = this.refreshBaizeUi(currentState.studentData);
        if (!guide.enabled) {
          UI.toast(AI_GUIDE_RUNTIME.disabledReason || 'AI 夥伴功能已停用');
          return;
        }
        const dom = getBaizeDom();
        if (!dom.modal) { UI.alert('找不到白澤/靈貓面板，請重新整理頁面後再試。', '系統異常'); return; }
        this.ensureBaizeHistory();
        this.renderBaizeHistory();
        this.setBaizeStatus(guide.statusReady);
        UI.showModal('baizeModal');
        if (dom.input) setTimeout(() => dom.input.focus(), 30);
      },

      closeBaizeModal() {
        UI.hideModal('baizeModal');
        this.setBaizeStatus();
      },

      async askBaizeViaServer(message) {
        if (AI_GUIDE_RUNTIME.enabled !== true) {
          return { reply: AI_GUIDE_RUNTIME.disabledReason };
        }
        await this.ensureStudentAuth();
        const callable = httpsCallable(functions, 'askBaize');
        const student = currentState.studentData || {};
        const guide = this.getBaizeGuideConfig(student);
        const guideMode = this.getGuideMode(student);
        const result = await callable({
          message,
          profileMode: guideMode === 'cat' ? 'cat' : 'shanhai',
          aiGuideMode: guideMode === 'cat' ? 'sage_cat' : 'baize',
          meta: {
            cardSeq: student.card_seq || student.serial || null,
            className: student.class_name || null,
            contentProfileId: student.content_profile_id || null,
            guidePersona: guide.persona || 'baize',
            source: 'student_baize'
          }
        });
        return result?.data || {};
      },

      async sendBaizeMessage() {
        if (currentState.baizeSending) return;
        const dom = getBaizeDom();
        const input = dom.input;
        if (!input) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        if (!guide.enabled) {
          UI.toast(AI_GUIDE_RUNTIME.disabledReason || 'AI 夥伴功能已停用');
          return;
        }
        const message = String(input.value || '').trim();
        if (!message) {
          UI.toast(guide.emptyToast || '請先輸入問題');
          return;
        }
        if (message.length > 300) {
          UI.alert(guide.overLimitAlert || '提問請控制在 300 字以內。', '提問過長');
          return;
        }

        currentState.baizeSending = true;
        const sendBtn = dom.sendBtn;
        if (sendBtn) sendBtn.disabled = true;
        this.ensureBaizeHistory().push({ role: 'user', text: message });
        this.renderBaizeHistory();
        input.value = '';
        this.setBaizeStatus(guide.statusThinking);

        try {
          const data = await this.askBaizeViaServer(message);
          const reply = String(data?.reply || '').trim() || '先回頭看看題目裡最明確的線索，試著說出你已經知道的部分，我們再往下一步。';
          this.ensureBaizeHistory().push({ role: 'assistant', text: reply });
          this.renderBaizeHistory();
          this.setBaizeStatus(guide.statusDone);
        } catch (e) {
          console.error('[askBaizeViaServer] failed:', e);
          const code = String(e?.code || e?.message || '');
          let friendly = guide.genericReply || '目前暫時沒有回應，請稍後再試。';
          if (code.includes('unauthenticated')) {
            friendly = guide.unauthenticatedReply || friendly;
          } else if (code.includes('not-found')) {
            friendly = guide.notDeployedReply || friendly;
          } else if (code.includes('internal')) {
            friendly = guide.genericReply || friendly;
          }
          this.ensureBaizeHistory().push({ role: 'assistant', text: friendly });
          this.renderBaizeHistory();
          this.setBaizeStatus(guide.statusFail);
        } finally {
          currentState.baizeSending = false;
          if (sendBtn) sendBtn.disabled = false;
          if (input) setTimeout(() => input.focus(), 30);
        }
      },

      async init() {
        const runInitPhase = async (label, fn) => {
          __setBootStatus(label, '執行中');
          beginPerfSpan('boot', `init:${label}`, { label });
          try {
            const result = await fn();
            endPerfSpan('boot', `init:${label}`, { status: 'ok' });
            return result;
          } catch (e) {
            endPerfSpan('boot', `init:${label}`, { status: 'error', message: e?.message || String(e || '未知錯誤') });
            __showBootFailure(e, label);
            throw e;
          }
        };

        await runInitPhase('beforeInit', async () => {
          await ModuleBridge.run('beforeInit', this.createModuleContext({ phase: 'beforeInit' }));
        });
        await runInitPhase('UI.initActionGrid', async () => {
          UI.initActionGrid();
        });
        await runInitPhase('setupEventListeners', async () => {
          this.setupEventListeners();
        });
        await runInitPhase('bindBaizeUi', async () => {
          syncAiGuideFeatureUiState();
          this.bindBaizeUi();
        });
        await runInitPhase('renderAdminDiagnostics', async () => {
          this.renderAdminDiagnostics();
        });
        await runInitPhase('bindSessionActivityWatchers', async () => {
          this.bindSessionActivityWatchers();
        });

        await runInitPhase('onAuthStateChanged', async () => {
          onAuthStateChanged(auth, async (user) => {
            beginPerfSpan('boot', 'auth-state-callback', { hasUser: Boolean(user) });
            try {
              currentState.authUser = user || null;

              const urlParams = new URLSearchParams(window.location.search);
              const isStudentView = (urlParams.get('view') === 'student');
              if (isStudentView) return;

              if (user) {
                const ok = await this.isCurrentUserAdmin();
                currentState.isAdmin = ok;
                await ModuleBridge.run('afterAuth', this.createModuleContext({ phase: 'afterAuth', user, isAdmin: ok }));
                if (ok) {
                  UI.hide('loginView'); UI.show('dashboardView');
                  this.syncAdminDashboardListenerState();
                  await this.openRequestedAdminPanel();
                } else {
                  this.stopAdminDashboardListener();
                  UI.hide('dashboardView');
                  UI.show('loginView');
                }
                this.resetSessionIdleTimer();
              } else {
                currentState.isAdmin = false;
                currentState.adminDiag = {
                  build: BUILD_TAG,
                  projectId: firebaseConfig.projectId,
                  email: '', uid: '', claimAdmin: '未檢查', allowlist: '未檢查', final: '否',
                  lastError: '', checkedAt: new Date().toLocaleString('zh-TW'), summary: '尚未登入，無法驗證管理員權限'
                };
                this.renderAdminDiagnostics();
                this.stopAdminDashboardListener();
                this.resetSessionIdleTimer();
              }
            } catch (error) {
              console.error('[auth-state] callback failed', error);
              __setBootStatus('auth-state-error', error?.message || '登入狀態處理失敗');
              currentState.isAdmin = false;
              try {
                this.stopAdminDashboardListener();
                UI.hide('dashboardView');
                UI.show('loginView');
                this.renderAdminDiagnostics();
              } catch (_) {}
              endPerfSpan('boot', 'auth-state-callback', { status: 'error', message: error?.message || String(error || '未知錯誤') });
              return;
            }
            endPerfSpan('boot', 'auth-state-callback', {
              status: 'ok',
              isAdmin: Boolean(currentState.isAdmin),
              viewMode: currentState.viewMode || '',
              hasAuthUser: Boolean(currentState.authUser)
            });
          });
        });

        await runInitPhase('checkRoute', async () => {
          await this.checkRoute();
          await ModuleBridge.run('afterRoute', this.createModuleContext({ phase: 'afterRoute', viewMode: currentState.viewMode }));
        });

        setInterval(() => {
          try {
            UI.updateDailyQuestTimer();
          } catch (e) {
            console.warn('[timer] updateDailyQuestTimer failed:', e);
          }
        }, 60000);

        this.syncAdminDashboardListenerState();


        const {
          legendarySelect: laSelect,
          battleTypeSelect: typeSelect,
          battleBossSelect: bossSelect
        } = getBattleSetupDom();
        if (laSelect) {
           laSelect.innerHTML = '';
           (CONSTANTS.LEGENDARIES || []).forEach(leg => {
              laSelect.innerHTML += `<option value="${leg.id}">${leg.name}</option>`;
           });

           laSelect.addEventListener('change', () => __updateLegendarySelectPreview('laSelectId', 'laPreviewImg', 'laPreviewName'));
           __updateLegendarySelectPreview('laSelectId', 'laPreviewImg', 'laPreviewName');
        }

        if(typeSelect) {
           typeSelect.innerHTML = '';
           for(let [key, info] of Object.entries(TYPE_INFO)) typeSelect.innerHTML += `<option value="${key}">${info.name}系</option>`;
        }
        if (bossSelect) {
           bossSelect.innerHTML = '';
           (CONSTANTS.LEGENDARIES || []).forEach(leg => bossSelect.innerHTML += `<option value="${leg.id}">${leg.name}</option>`);

           bossSelect.addEventListener('change', () => __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName'));
           __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName');
        }

        await runInitPhase('afterInit', async () => {
          await ModuleBridge.run('afterInit', this.createModuleContext({ phase: 'afterInit' }));
        });
        ModuleBridge.markReady(this.createModuleContext({ phase: 'ready' }));
        __bootState.ready = true;
        markPerfPoint('boot', 'app-ready', { viewMode: currentState.viewMode || '', isAdmin: Boolean(currentState.isAdmin) });
        endPerfSpan('boot', 'app-bootstrap', { status: 'ready', viewMode: currentState.viewMode || '', isAdmin: Boolean(currentState.isAdmin) });
        __setBootStatus('ready', '初始化完成');
        __syncBootDiagnostics({ mainEntryReadyAt: Date.now() });
      },

      handleAdminDashboardSnapshot(snapshot) {
        snapshot.docChanges().forEach((change) => {
          const docId = change.doc.id;
          const newData = change.doc.data();
          if (change.type === "modified") {
            const oldData = currentState.previousStudentsData[docId];
            if (oldData && !change.doc.metadata.hasPendingWrites) {
              const xpDiff = (Number(newData.totalXP) || 0) - (Number(oldData.totalXP) || 0);
              const { dashboardView: dashboardViewEl, adminView: adminViewEl } = getRuntimeUiDom();
              const isLoggedInAdmin = (!!dashboardViewEl && !dashboardViewEl.classList.contains('hidden')) || (!!adminViewEl && !adminViewEl.classList.contains('hidden'));
              const lastLog = (newData.logs && newData.logs.length > 0) ? newData.logs[newData.logs.length - 1] : null;
              const isLegitTeacherAction = lastLog &&
                                           ['batch_action', 'add_xp', 'prop_action', 'shop'].includes(lastLog.action_type) &&
                                           (Date.now() - lastLog.timestamp < 30000);
              if (xpDiff > 2 && isLoggedInAdmin && !isLegitTeacherAction) {
                  UI.showHackerAlert(newData, xpDiff);
              }
            }
          }
          currentState.previousStudentsData[docId] = newData;
        });
      },

      stopAdminDashboardListener() {
        try {
          if (typeof currentState.adminDashboardListenerUnsubscribe === 'function') {
            currentState.adminDashboardListenerUnsubscribe();
          }
        } catch (e) {
          console.warn('[admin-listener] stop failed:', e);
        } finally {
          currentState.adminDashboardListenerUnsubscribe = null;
          currentState.adminDashboardListenerStartedAt = 0;
        }
      },

      startAdminDashboardListener() {
        if (isEmergencyFlagEnabled('disableAdminDashboardListener')) {
          guardLog('admin-dashboard-listener', 'blocked by emergency flag');
          this.stopAdminDashboardListener();
          return;
        }
        if (!currentState.isAdmin) return;
        if (typeof currentState.adminDashboardListenerUnsubscribe === 'function') return;
        try {
          currentState.adminDashboardListenerLastError = '';
          currentState.adminDashboardListenerStartedAt = Date.now();
          currentState.adminDashboardListenerUnsubscribe = onSnapshot(
            collection(db, COLLECTION_NAME),
            { includeMetadataChanges: true },
            (snapshot) => {
              try {
                this.handleAdminDashboardSnapshot(snapshot);
              } catch (listenerErr) {
                console.warn('[admin-listener] snapshot handling failed:', listenerErr);
              }
            },
            (err) => {
              currentState.adminDashboardListenerLastError = err?.message || String(err || '');
              console.warn('[admin-listener] realtime listener error:', err);
              const msg = String(err?.message || err || '').toLowerCase();
              const code = String(err?.code || '').toLowerCase();
              const isOfflineLike = code === 'unavailable' || msg.includes('client is offline') || msg.includes('transport errored') || msg.includes('could not reach cloud firestore backend');
              if (isOfflineLike) {
                try { UI.toast('網路不穩，即時儀表板資料可能延遲。'); } catch (_) {}
              }
            }
          );
        } catch (e) {
          currentState.adminDashboardListenerLastError = e?.message || String(e || '');
          console.warn('Firebase onSnapshot 初始化遇到問題', e);
        }
      },

      syncAdminDashboardListenerState() {
        if (isEmergencyFlagEnabled('disableAdminDashboardListener')) {
          guardLog('admin-dashboard-listener', 'sync forced stop by emergency flag');
          this.stopAdminDashboardListener();
          return;
        }
        const { dashboardView: dashboardViewEl } = getRuntimeUiDom();
        const dashboardVisible = !!dashboardViewEl && !dashboardViewEl.classList.contains('hidden');
        const shouldListen = Boolean(currentState.isAdmin && currentState.viewMode === 'admin' && dashboardVisible);
        if (shouldListen) this.startAdminDashboardListener();
        else this.stopAdminDashboardListener();
      },

      async checkRoute() {
        const urlParams = new URLSearchParams(window.location.search);
        const tokenParam = this.getTokenFromHash();
        const isStudentView = (urlParams.get('view') === 'student');

        if (isStudentView) {
          UI.hide('loginView'); UI.hide('dashboardView'); UI.hide('adminView'); UI.show('studentView');
          currentState.viewMode = 'student';
          this.stopAdminDashboardListener();
          UI.hide('viewerModeBadge'); UI.hide('exitPreviewBtn');

          // Default: locked until a valid active token resolves to a serial.
          this.lockStudentAccess('請使用已註冊的 NFC 卡片進入學生面板。');

          try {
            await this.ensureStudentAuth();
          } catch (e) {
            console.error(e);
            UI.alert(
              `學生模式需要啟用 Firebase Authentication 的『匿名登入 (Anonymous)』，否則將無法寫入加分/對戰/兌換等資料。

請到 Firebase Console → Authentication → Sign-in method 開啟 Anonymous。`,
              "需要啟用匿名登入"
            );
          }

          // 方案三：學生端必須有 token（Hash #t=...），不再接受 serial/uid 直接進入。
          if (!tokenParam) {
            this.lockStudentAccess('此連結缺少有效的卡片驗證（Token）。\n\n請重新感應已註冊的 NFC 卡片，或請老師協助（卡片補發 / 卡序查詢）。');
            return;
          }

          // 方案 A：學生端不直接讀取 tag_tokens（避免 Rules 開放敏感對照表）
          // 直接以 token 作為 student_pages/{token} 的文件 ID；是否有效由 Firestore Rules 透過 tag_tokens.active 判斷
          currentState.currentToken = tokenParam;
          currentState.currentTokenValidated = true;

          // 保持鎖定狀態，直到 student_pages 成功讀到資料才解鎖
          this.lockStudentAccess('卡片驗證中...');

          this.loadStudentData(tokenParam, 'student');
        } else {
          currentState.viewMode = 'admin';
          this.syncAdminDashboardListenerState();
          UI.show('loginView');
          const { adminEmail: emailEl, adminPassword: pwdEl } = getRuntimeUiDom();
          if (emailEl) emailEl.focus();
          else if (pwdEl) pwdEl.focus();

          // Auto-enter if session exists and is authorized admin
          // (onAuthStateChanged may fire after checkRoute; both paths are safe)
          if (auth.currentUser) this.tryAutoEnterAdmin();
          this.resetSessionIdleTimer();
        }
      },

      setupEventListeners() {
        // @phase9-split:auth-bind
        this.bindAuthControls();

        const { usbScannerInput: usbInput, cardSeqInput: scanCardSeqInput, cardSeqSearchBtn: csBtn } = getScanModeDom();
        if (usbInput) usbInput.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
            const uid = usbInput.value.trim().toUpperCase();
            usbInput.value = '';
            if(uid) this.handleCardScan(uid);
            setTimeout(() => {
              try { usbInput.focus(); } catch (_) {}
            }, 100);
          }
        });

        document.addEventListener('click', (e) => {
          const { loginView: loginViewEl, battleArenaModal: battleArenaEl, adminView: adminViewEl, batchModeView: batchModeViewEl } = getRuntimeUiDom();
          const loginHidden = !!loginViewEl?.classList?.contains('hidden');
          const battleHidden = !!battleArenaEl?.classList?.contains('hidden');
          const adminVisible = adminViewEl ? !adminViewEl.classList.contains('hidden') : false;
          const batchVisible = batchModeViewEl ? !batchModeViewEl.classList.contains('hidden') : false;
          if (loginHidden && battleHidden) {
             if(e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'SELECT') {
                 if ((adminVisible || batchVisible) && usbInput) {
                     try { usbInput.focus(); } catch (_) {}
                 }
             }
          }
        });

        const { scanNfcBtn, cancelActionBtn } = getRuntimeUiDom();
        if (scanNfcBtn) scanNfcBtn.addEventListener('click', () => {
          if (!hasWebNfcSupport()) { UI.alert("裝置不支援 Web NFC。", "硬體錯誤"); return; }
          this.startWebNfc(true);
        });

        if (csBtn) csBtn.addEventListener('click', () => this.lookupByCardSeq());
        const csInput = scanCardSeqInput;
        if (csInput) csInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') this.lookupByCardSeq(); });

        const registrationDom = getRegistrationDom();
        const submitRegBtn = registrationDom.submitBtn;
        if (submitRegBtn) submitRegBtn.addEventListener('click', () => this.registerNewStudent(false));
        const submitRegAndWriteBtn = registrationDom.submitWriteBtn;
        if (submitRegAndWriteBtn) submitRegAndWriteBtn.addEventListener('click', () => this.registerNewStudent(true));
        
        if (cancelActionBtn && !cancelActionBtn.dataset.boundCancelAction) {
          cancelActionBtn.dataset.boundCancelAction = '1';
          cancelActionBtn.addEventListener('click', () => { UI.hideModal('previewPanel'); currentState.pendingAction = null; });
        }
        const { confirmActionBtn, writeNfcLinkBtn, openShopBtn, openCardForgeBtn, openDebuffBtn } = getTeacherUtilityDom();
        if (confirmActionBtn && !confirmActionBtn.dataset.boundConfirmAction) {
          confirmActionBtn.dataset.boundConfirmAction = '1';
          confirmActionBtn.addEventListener('click', async () => { await this.commitAction(); });
        }
        
        if (writeNfcLinkBtn && !writeNfcLinkBtn.dataset.boundWriteNfcLink) {
          writeNfcLinkBtn.dataset.boundWriteNfcLink = '1';
          writeNfcLinkBtn.addEventListener('click', async () => {
          if (!hasWebNfcSupport()) { UI.alert("裝置不支援 Web NFC。", "硬體錯誤"); return; }
          if (!window.isSecureContext) { UI.alert("Web NFC 需要在 HTTPS 安全環境下使用。", "硬體錯誤"); return; }
          if (!currentState.currentUid) { UI.toast("❌ 無法取得當前卡序！"); return; }
          const { adminView: adminViewEl, batchModeView: batchModeViewEl } = getRuntimeUiDom();
          const shouldRestart = (!!adminViewEl && !adminViewEl.classList.contains('hidden')) || (!!batchModeViewEl && !batchModeViewEl.classList.contains('hidden'));
          try {
            await this.writeCurrentStudentUrlToCard({ shouldRestartScan: false });
            UI.toast("✅ 專屬面板網址已成功寫入 NFC 卡片！");
          } catch (error) {
            console.error(error);
            UI.alert(`寫入失敗: ${(error && error.message) ? error.message : error}`, "寫入異常");
          } finally {
            if (shouldRestart) {
              try { await this.startWebNfc(false); } catch (_) {}
            }
          }
          });
        }

        const {
          supportWriteBtn,
          supportUrlDisplay,
          scienceWriteBtn,
          scienceUrlDisplay,
          secretPropTrigger: secretPropTriggerEl
        } = getZoneLinkDom();
        if (supportWriteBtn && !supportWriteBtn.dataset.boundSupportZoneWrite) {
          supportWriteBtn.dataset.boundSupportZoneWrite = '1';
          supportWriteBtn.addEventListener('click', async () => {
            await this.writeSupportZoneLinkToNfc();
          });
        }

        if (supportUrlDisplay) supportUrlDisplay.value = this.buildSupportZoneUrl();

        if (scienceWriteBtn && !scienceWriteBtn.dataset.boundScienceZoneWrite) {
          scienceWriteBtn.dataset.boundScienceZoneWrite = '1';
          scienceWriteBtn.addEventListener('click', async () => {
            await this.writeScienceZoneLinkToNfc();
          });
        }

        if (scienceUrlDisplay) scienceUrlDisplay.value = this.buildScienceZoneUrl();

        if (secretPropTriggerEl) {
          let secretClickCount = 0;
          let secretClickTimer = null;
          secretPropTriggerEl.addEventListener('click', () => {
            if(currentState.viewMode !== 'student') return;
            secretClickCount++;
            clearTimeout(secretClickTimer);
            if (secretClickCount >= 3) {
              secretClickCount = 0;
              App.startStudentPropScan();
            } else {
              secretClickTimer = setTimeout(() => { secretClickCount = 0; }, 1000);
            }
          });
        }

        if (openShopBtn && !openShopBtn.dataset.boundOpenShop) {
           openShopBtn.dataset.boundOpenShop = '1';
           openShopBtn.addEventListener('click', () => {
             this.openShop();
           });
        }

        if (openCardForgeBtn) {
           openCardForgeBtn.setAttribute('type', 'button');
           if (!openCardForgeBtn.dataset.boundCardForgeOpen) {
             openCardForgeBtn.dataset.boundCardForgeOpen = '1';
             openCardForgeBtn.addEventListener('click', (evt) => {
               try {
                 if (this.forceOpenCardForge) {
                   this.forceOpenCardForge(evt);
                   return;
                 }
                 if (this.openCardForge) {
                   this.openCardForge(evt);
                 }
               } catch (e) {
                 console.error('[card forge] button click failed:', e);
                 try { UI.alert(`加分框開啟失敗：${e?.message || e}`, '系統通知'); } catch (_) {}
               }
             });
           }
        }
        if (openDebuffBtn && !openDebuffBtn.dataset.boundOpenDebuff) {
           openDebuffBtn.dataset.boundOpenDebuff = '1';
           openDebuffBtn.addEventListener('click', () => {
              UI.showModal('debuffModal');
           });
        }
        this.populateHiddenEggSelect();
},
      stopWebNfc() {
        try {
          if (this.nfcAbortController) {
            this.nfcAbortController.abort();
            this.nfcAbortController = null;
          }
        } catch (e) {}
      },

      getRequestedAdminPanel() {
        const urlParams = new URLSearchParams(window.location.search);
        const panel = String(urlParams.get('panel') || '').trim();
        return panel || null;
      },

      buildSupportZoneUrl() {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('panel', 'support-zone');
        return url.toString();
      },

      buildScienceZoneUrl() {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('panel', 'science-zone');
        return url.toString();
      },

      async openRequestedAdminPanel() {
        const panel = this.getRequestedAdminPanel();
        if (!panel || !currentState.isAdmin || currentState.pendingAdminPanelOpened) return;
        currentState.pendingAdminPanelOpened = true;
        this.syncAdminDashboardListenerState();
        if (panel === 'support-zone') {
          await this.openSupportZone();
          return;
        }
        if (panel === 'science-zone') {
          await this.openScienceZone();
        }
      },

      async startWebNfc(showToast = true) {
        if (!hasWebNfcSupport()) {
          if (showToast) UI.alert("裝置不支援 Web NFC。", "硬體錯誤");
          return false;
        }
        if (!window.isSecureContext) {
          if (showToast) UI.alert("Web NFC 需要在 HTTPS 安全環境下使用。", "硬體錯誤");
          return false;
        }
        try {
          if (!this.ndef) {
            this.ndef = createNdefReaderOrThrow();
            this.ndef.addEventListener("reading", (event) => {
              const serialNumber = event.serialNumber;
              currentState.lastNfcSerialNumber = serialNumber ? String(serialNumber).replace(/:/g, '').toUpperCase() : null;

              // 優先：從 NDEF URL record 解析 serial（新制）或 uid（舊制）
              let key = null;
              try {
                const recs = event.message && event.message.records ? event.message.records : [];
                for (const rec of recs) {
                  if (!rec) continue;
                  if (rec.recordType !== "url" && rec.recordType !== "text") continue;

                  let urlStr = null;
                  if (typeof rec.data === "string") urlStr = rec.data;
                  else if (rec.data) {
                    try { urlStr = new TextDecoder().decode(rec.data); } catch (_) {}
                  }
                  if (!urlStr) continue;

                  const u = new URL(urlStr, window.location.href);
                  const serial = u.searchParams.get("serial");
                  const uid = u.searchParams.get("uid");
                  let token = null;
                  try {
                    const hs = (u.hash || '').startsWith('#') ? (u.hash || '').slice(1) : (u.hash || '');
                    const qs = hs.startsWith('?') ? hs.slice(1) : hs;
                    const hp = new URLSearchParams(qs);
                    token = hp.get('t');
                  } catch (_) {}
                  if (token) { key = 'T:' + token; break; }
                  if (serial) { key = serial; break; }
                  if (uid) { key = uid; break; }
                }
              } catch (_) {}

              // 若 URL record 沒帶 serial/uid，才退回使用 serialNumber（卡片 UID）
              if (!key && serialNumber) {
                key = serialNumber.replace(/:/g, "");
              }

              if (key) this.handleCardScan(String(key));
            });
            this.ndef.addEventListener("readingerror", () => {
              UI.toast("❌ NFC 讀取失敗，請重試貼卡。");
            });
          }

          // 重新啟動掃描：避免重複 scan() 造成 InvalidStateError
          this.stopWebNfc();
          this.nfcAbortController = new AbortController();
          await this.ndef.scan({ signal: this.nfcAbortController.signal });

          if (showToast) UI.toast("📡 NFC 感應已就緒...");
          return true;
        } catch (error) {
          console.error(error);
          const msg = (error && error.message) ? error.message : String(error);
          if (showToast) UI.alert(`NFC 啟動失敗: ${msg}`, "硬體錯誤");
          return false;
        }
      },


      enterScanMode(intention) {
        currentState.scanIntention = intention;
        UI.hide('dashboardView'); UI.show('adminView'); UI.hide('adminStudentPanel');
        this.syncAdminDashboardListenerState();
        const dom = getScanModeDom();
        const titleEl = dom.title;
        const hintEl = dom.hint;
        if (titleEl && hintEl) {
          if (intention === 'register') {
            titleEl.innerText = "AWAITING NEW NTAG..."; titleEl.style.color = "var(--color-water)"; hintEl.innerText = "(請感應未註冊卡片以綁定)";
          } else {
            titleEl.innerText = "等待卡片感應中..."; titleEl.style.color = "var(--cyan)"; hintEl.innerText = "掃描槍 / 手動輸入已就緒";
          }
        }
        if (intention === 'register') { UI.hide('cardSeqSearchGroup'); } else { UI.show('cardSeqSearchGroup'); }
        const cs = dom.cardSeqInput; if (cs) cs.value = '';
        const usbScannerInput = dom.usbScannerInput;
        if (usbScannerInput) {
          try { usbScannerInput.focus(); } catch (_) {}
        }
        this.startWebNfc(false);
      },


      primeAdminStudentPanel(serial, rawData, source = 'admin-prime') {
        const serialDigits = String(serial || '').replace(/[^0-9]/g, '');
        const normalizedSerial = serialDigits ? serialDigits.padStart(3, '0') : '';
        let normalizedData = rawData ? JSON.parse(JSON.stringify(rawData)) : null;
        try {
          if (normalizedData && typeof this.ensureTeacherTargetData === 'function') {
            normalizedData = this.ensureTeacherTargetData(normalizedData) || normalizedData;
          }
        } catch (_) {}
        currentState.scanIntention = 'read';
        if (normalizedSerial) currentState.currentUid = normalizedSerial;
        if (normalizedData) currentState.studentData = normalizedData;
        try { if (typeof this.stopWebNfc === 'function') this.stopWebNfc(); } catch (_) {}
        try { UI.hide('dashboardView'); UI.show('adminView'); UI.show('adminStudentPanel'); UI.hideModal('previewPanel'); } catch (_) {}
        try { if (typeof this.syncAdminDashboardListenerState === 'function') this.syncAdminDashboardListenerState(); } catch (_) {}
        if (normalizedData) {
          try { if (typeof this.refreshStudentIdentityLabels === 'function') this.refreshStudentIdentityLabels(normalizedData); } catch (_) {}
          try { UI.updatePanel(normalizedData, false); } catch (_) {}
          try { if (typeof UI.initActionGrid === 'function') UI.initActionGrid(); } catch (_) {}
          try {
            if (typeof this.syncTeacherTargetContext === 'function') {
              this.syncTeacherTargetContext(normalizedData, {
                source,
                action: 'admin-prime-view',
                serial: normalizedSerial || normalizedData.card_seq || normalizedData.serial || null,
                hydrated: true,
                hasStudentData: true,
                clearError: true
              });
            }
          } catch (_) {}
        }
        return normalizedData;
      },

      async lookupByCardSeq() {
        const inputEl = getScanModeDom().cardSeqInput;
        const raw = (inputEl && inputEl.value ? String(inputEl.value) : '').trim();
        if (!raw) { UI.toast('請輸入卡序'); return; }

        const seqDigits = (raw || '').replace(/[^0-9]/g, '');
        if (!seqDigits) { UI.toast('卡序格式錯誤'); return; }
        const seqStr = seqDigits.padStart(3, '0');
        if (currentState.teacherActionSubmitting) {
          UI.toast('上一筆老師端保存尚在進行中，請稍候再切換學生。');
          return;
        }

        UI.toast('查詢中...');
        try {
          let immediateData = null;
          if (typeof this.lookupTeacherTargetBySerial === 'function') {
            immediateData = await this.lookupTeacherTargetBySerial(seqStr, {
              source: 'lookupByCardSeq',
              action: 'lookup-by-card-seq',
              deferSelection: true,
              showAdminPanel: false,
              updatePanel: false,
              refreshIdentity: false,
              initActionGrid: false
            });
          }
          if (!immediateData) return;
          const primedData = typeof this.primeAdminStudentPanel === 'function'
            ? (this.primeAdminStudentPanel(seqStr, immediateData, 'lookupByCardSeq') || immediateData)
            : immediateData;
          this.loadStudentData(seqStr, 'admin', {
            preloadedData: primedData,
            primeView: false,
            serial: seqStr,
            source: 'lookupByCardSeq'
          });
          try {
            this.scheduleBackgroundTask('student-mirror:autoheal:lookupByCardSeq', () => this.syncStudentMirrorForSerial(seqStr, immediateData));
          } catch (_) {}
          UI.toast(`✅ 已定位卡序 #${seqStr}`);
        } catch (e) {
          console.error(e);
          if (typeof this.syncTeacherTargetContext === 'function') {
            try { this.syncTeacherTargetContext(currentState.studentData, { source: 'lookupByCardSeq', action: 'lookup-error', serial: seqStr, hydrated: Boolean(currentState.studentData), hasStudentData: Boolean(currentState.studentData), lookup: true, error: e?.message || e }); } catch (_) {}
          }
          UI.alert('查詢時發生錯誤，請檢查網路狀態或稍後再試。', '錯誤');
        }
      },



      async simulateScan() {
        UI.alert('測試模式入口已移除；請改用實際卡片、NFC 或卡序查詢進行操作。', '測試模式已停用');
      },



      

      // --- Preview helpers (測試模式預覽用) ---
      buildPreviewStudentData(cardSeqStr) {
        const serial = this.normalizeSerial(cardSeqStr) || String(cardSeqStr || '1000');
        const now = Date.now();
        return {
          uid: `PREVIEW_${serial}`,
          card_seq: serial,
          class_name: '五年級',
          seat_number: '01',
          name: '預覽訓練家',
          totalXP: 85,
          coins: 320,
          free_rename_available: true,
          lap: 1,
          trainerRankIndex: 0,
          best_rate: 5,
          last_practice_time: now - 2 * 60 * 60 * 1000,
          display_team: [],
          status: 'Healthy',
          status_timestamp: null,
          debuffs: { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 },
          debuffs_timestamp: null,
          attributes: { metal: 18, wood: 32, water: 24, fire: 40, earth: 12 },
          streaks: { metal: 1, wood: 2, water: 1, fire: 3, earth: 0 },
          attr_event_counts: { metal: 3, wood: 5, water: 4, fire: 7, earth: 2 },
          dragon_stage: 1,           // 1=成長期（便於看見較完整 UI）
          dragon_path: 'fire',
          collection: [],
          logs: [
            { timestamp: now - 24 * 60 * 60 * 1000, action_type: 'registration', points_added: 0, detail: '預覽帳號建立' },
            { timestamp: now - 3 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 20, detail: '練習加分 (火)' },
            { timestamp: now - 2 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 15, detail: '練習加分 (木)' },
            { timestamp: now - 1 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 25, detail: '練習加分 (水)' }
          ],
          boss_win_total: 4,
          daily_correct_total: 28,
          content_profile_id: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'cat' : 'shanhai',
          ui_variant: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'muslim_friendly' : 'default',
          guide_mode: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'cat' : 'baize',
          guide_mode_locked: true,
          profile_flags: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? { hide_fantasy: true, use_cat_theme: true, use_safe_random_label: true } : { hide_fantasy: false, use_cat_theme: false, use_safe_random_label: false }
        };
      },

      async seedPreviewStudent(...args) { return studentAccessApi.seedPreviewStudent(...args); },


// --- Account Management (卡序查詢 / 卡片補發) --- (卡序查詢 / 卡片補發) ---
      openAccountMgmt() {
        if (!currentState.isAdmin) { UI.alert('需要老師帳號登入後才能使用。', '權限不足'); return; }
        const dom = getAccountMgmtDom();
        if (!dom.modal) { UI.alert('找不到帳號管理面板，請重新整理頁面後再試。', '系統異常'); return; }
        this.setAccountMgmtTab('lookup');
        currentState.reissueDraft = null;
        if (dom.lookupMsg) dom.lookupMsg.textContent = '';
        if (dom.reissueMsg) dom.reissueMsg.textContent = '';
        if (dom.reissueInfo) dom.reissueInfo.innerHTML = '<span style="color:var(--text-muted);">請先輸入卡序並載入學生資料。</span>';
        if (dom.reissueStartBtn) { dom.reissueStartBtn.disabled = true; dom.reissueStartBtn.style.opacity = 0.6; }
        UI.showModal('accountMgmtModal');
        if (dom.serialLookupInput) { dom.serialLookupInput.value = ''; setTimeout(() => dom.serialLookupInput.focus(), 50); }
      },

      setAccountMgmtTab(tab) {
        const { lookupPane: lookup, reissuePane: reissue } = getAccountMgmtDom();
        if (!lookup || !reissue) return;
        if (tab === 'reissue') { lookup.classList.add('hidden'); reissue.classList.remove('hidden'); }
        else { reissue.classList.add('hidden'); lookup.classList.remove('hidden'); }
      },

      // student-mirror:autoheal:amLookupSerial delegated in studentAccessApi
      async amLookupSerial(...args) { return studentAccessApi.amLookupSerial(...args); },
      async amLoadReissue(...args) { return studentAccessApi.amLoadReissue(...args); },
      async amStartReissue(...args) { return studentAccessApi.amStartReissue(...args); },
      async executeReissue(...args) { return studentAccessApi.executeReissue(...args); },
      getProfilePayloadFromForm() { return contentProfileApi.getProfilePayloadFromForm.apply(contentProfileApi, arguments); },

      async applyCurrentStudentProfile() { return contentProfileApi.applyCurrentStudentProfile.apply(contentProfileApi, arguments); },

      quickApplyCatProfile() { return contentProfileApi.quickApplyCatProfile.apply(contentProfileApi, arguments); },

      quickApplyShanhaiProfile() { return contentProfileApi.quickApplyShanhaiProfile.apply(contentProfileApi, arguments); },

      backToDashboard() {
        if(currentState.unsubscribe) { currentState.unsubscribe(); currentState.unsubscribe = null; }
        UI.hide('adminView'); UI.hide('viewerModeBadge'); UI.hide('exitPreviewBtn'); UI.show('dashboardView');
        this.syncAdminDashboardListenerState();
      },

      // --- 訓練家階級（取代原本 LAP 顯示/優惠）---
// 規則：
// - 計算進化型態時：包含全息投影(isHologram)；排除 dead_dragon
// - 異獸以 type==='legendary' 計算
computeTrainerProgress(data) {
  return evolutionApi?.computeTrainerProgress ? evolutionApi.computeTrainerProgress(...arguments) : { dragonMilestones: 0, uniquePaths: 0, legendaryCount: 0, rankIndex: 0, rankName: '新手學徒' };
},

getRateFromRankIndex(rankIndex) {
  return evolutionApi?.getRateFromRankIndex ? evolutionApi.getRateFromRankIndex(...arguments) : 5;
},

getRateFromLap(lap) {
  return evolutionApi?.getRateFromLap ? evolutionApi.getRateFromLap(...arguments) : 5;
},

applyDataMigration(data) {
        if (!data.debuffs) {
          data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
          if (data.status && data.status !== 'Healthy' && data.debuffs[data.status] !== undefined) data.debuffs[data.status] = 1;
          data.status = 'Healthy'; 
        }
        
        if (!data.attributes || data.attributes.electric !== undefined) data.attributes = { metal: Number(data.attributes?.metal)||0, wood: Number(data.attributes?.wood)||0, water: Number(data.attributes?.water)||0, fire: Number(data.attributes?.fire)||0, earth: Number(data.attributes?.earth)||0 };
        if (!data.streaks || data.streaks.electric !== undefined) data.streaks = { metal: Number(data.streaks?.metal)||0, wood: Number(data.streaks?.wood)||0, water: Number(data.streaks?.water)||0, fire: Number(data.streaks?.fire)||0, earth: Number(data.streaks?.earth)||0 };
        data.content_profile_id = data.content_profile_id || 'shanhai';
        data.ui_variant = data.ui_variant || (data.content_profile_id === 'cat' ? 'muslim_friendly' : 'default');
        data.profile_flags = Object.assign({ hide_fantasy: data.content_profile_id === 'cat', use_cat_theme: data.content_profile_id === 'cat', use_safe_random_label: data.content_profile_id === 'cat' }, data.profile_flags || {});
        if (!data.guide_mode) {
          if (data.content_profile_id === 'cat' || data.ui_variant === 'muslim_friendly') data.guide_mode = 'cat';
          else if (data.content_profile_id === 'shanhai' || data.ui_variant === 'default') data.guide_mode = 'baize';
          else data.guide_mode = 'cat';
        }
        if (typeof data.guide_mode_locked !== 'boolean') data.guide_mode_locked = true;
        // 累積「各屬性加分事件次數」：用於學生面板「龍蛋的成長旅程」（不掉階、從創立起累積）
        if (!data.attr_event_counts) {
          data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
          // best-effort：若舊資料尚未有此欄位，嘗試從既有 logs 回推（若 logs 曾被截斷，則以可取得的部分為準）
          try {
            if (Array.isArray(data.logs)) {
              const xpTypes = new Set(['add_xp','batch_action','prop_action','quest']);
              const nameToKey = (rawName) => {
                const n = String(rawName || '')
                  .replace(/[\s\[\]【】()（）]/g, '')
                  .replace(/[⚙️🌳💧🔥🪨]/g, '');
                if (!n) return null;
                if (n.includes('金') || n.includes('鋼')) return 'metal';
                if (n.includes('木') || n.includes('草') || n.includes('葉')) return 'wood';
                if (n.includes('水')) return 'water';
                if (n.includes('火')) return 'fire';
                if (n.includes('土') || n.includes('地')) return 'earth';
                return null;
              };
              data.logs.forEach((log) => {
                if (!log || !xpTypes.has(log.action_type)) return;
                const d = String(log.detail || '');
                const m = d.match(/\(([^)]+)\)\s*$/); // 例：(火) / (太陽)
                if (!m) return;
                const k = nameToKey(m[1]);
                if (k && data.attr_event_counts[k] != null) data.attr_event_counts[k] += 1;
              });
            }
          } catch (e) {}
        } else {
          // 補齊缺漏 key
          const base = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
          data.attr_event_counts = Object.assign(base, data.attr_event_counts);
        }

        ensureAttributeFirstGainOrder(data);
        
        data.coins = Number(data.coins) || 0;
        data.totalXP = Number(data.totalXP) || 0;
        data.boss_win_total = Math.max(0, Math.floor(Number(data.boss_win_total) || 0));
        data.daily_correct_total = Math.max(0, Math.floor(Number(data.daily_correct_total) || 0));
        data.lap = Number(data.lap) || 1;

        // 訓練家階級（不掉階）：若資料缺漏則補上，並以已達成的最高階級為準
data.trainerRankIndex = Number(data.trainerRankIndex);
if (!Number.isFinite(data.trainerRankIndex)) data.trainerRankIndex = 0;
data.best_rate = Number(data.best_rate);
if (!Number.isFinite(data.best_rate)) data.best_rate = 99; // 先給大值，後續再取 min()
if (data.collection && data.collection.length > 0) {
          data.collection = data.collection.map(item => {
            // 舊版資料：曾以字串存入封存項目（避免再顯示舊版圖源/名稱）
            if (typeof item === 'string') {
              return { type: 'legacy', legacy: item, timestamp: Date.now() };
            }
            return item;
          });
        }
        if (data.last_practice_time === undefined) data.last_practice_time = 0;
        if (data.display_team === undefined) data.display_team = [];
        if (!data.logs) data.logs = [];
        if (!Array.isArray(data.reward_events)) data.reward_events = [];
        if (!Array.isArray(data.reward_settled_ids)) data.reward_settled_ids = [];
        if (!Array.isArray(data.hidden_eggs)) data.hidden_eggs = [];
        data.active_hidden_egg_id = data.active_hidden_egg_id || '';
        if (!data.active_hidden_egg && data.active_hidden_egg_id) {
          const activeFromHidden = data.hidden_eggs.find(item => String(item.hiddenEggId || item.id || '') === String(data.active_hidden_egg_id));
          const activeFromCollection = Array.isArray(data.collection) ? data.collection.find(item => item && item.type === 'hidden_egg' && String(item.hiddenEggId || item.id || '') === String(data.active_hidden_egg_id)) : null;
          data.active_hidden_egg = activeFromHidden || activeFromCollection || null;
        }
// 依目前收藏計算階級；並保留「舊 lap」的最佳優惠，避免既有學生優惠被意外削弱
const prog = this.computeTrainerProgress(data);
data.trainerRankIndex = Math.max(data.trainerRankIndex, prog.rankIndex);
const rateFromRank = this.getRateFromRankIndex(data.trainerRankIndex);
const rateFromLap = this.getRateFromLap(data.lap);
data.best_rate = Math.min(data.best_rate, rateFromRank, rateFromLap);
if (!Number.isFinite(data.best_rate) || data.best_rate === 99) data.best_rate = rateFromRank;
        return data;
      },

      async handleCardScan(uid) {
        if (Date.now() - batchState.lastScanTime < 800) return;
        batchState.lastScanTime = Date.now();

        const rawKey = studentAccessApi.normalizeScanKey(uid);
        if (!rawKey) return;
        UI.toast(`UID DETECTED: ${rawKey}`);

        const resolveSerialFromKey = async (key, options = {}) => (
          studentAccessApi.resolveSerialFromScanKey(key, {
            requireActive: true,
            allowAdminUidFallback: true,
            setCurrentToken: true,
            notifyUidFallback: true,
            ...(options || {})
          })
        );

        if (currentState.scanIntention === 'student_prop') {
          await teacherActionsApi.handleStudentPropScan.call(this, rawKey);
          return;
        }

        if (currentState.scanIntention === 'forge') {
          await teacherActionsApi.handleForgeScan.call(this, rawKey);
          return;
        }

        if (currentState.scanIntention === 'support-batch') {
          const serial = await resolveSerialFromKey(rawKey);
          if (serial) {
            await this.handleSupportBatchScan(serial);
            return;
          }
          UI.toast("❌ 無法辨識此學習扶助卡片");
          return;
        }

        if (currentState.scanIntention === 'science-batch') {
          const serial = await resolveSerialFromKey(rawKey);
          if (serial) {
            await this.handleScienceBatchScan(serial);
            return;
          }
          UI.toast("❌ 無法辨識此科展團隊卡片");
          return;
        }

        if (currentState.scanIntention === 'batch') {
          this.startBatchTimer();
          const actionData = await studentAccessApi.getActionCardPayload(rawKey);
          if (actionData) {
            if (!batchState.activeStudentUid) { UI.toast("⚠️ 請先感應學生卡！"); return; }
            await this.executeBatchAction(actionData);
            return;
          }

          const resolved = await studentAccessApi.resolveStudentRecordFromScanKey(rawKey, {
            requireActive: true,
            allowAdminUidFallback: true,
            setCurrentToken: true,
            notifyUidFallback: true
          });
          if (resolved.serial && resolved.data) {
            await this.setBatchStudent(resolved.serial, resolved.data);
            return;
          }

          UI.toast("❌ 未知的卡片！");
          return;
        }

        if (currentState.scanIntention === 'register') {
          const registrationScan = await studentAccessApi.inspectRegistrationScanKey(rawKey);

          if (registrationScan.status === 'token-bound') {
            UI.alert(`此卡已綁定卡序 #${registrationScan.serial}（Token 模式）`, '註冊衝突');
            return;
          }

          if (registrationScan.status === 'token-invalid') {
            UI.alert('偵測到已寫入網址的卡片（可能為舊卡/停用卡），請改用空白新卡。', '註冊衝突');
            return;
          }

          if (registrationScan.status === 'serial-exists') {
            UI.alert(`此卡序 #${registrationScan.serial} 已綁定給：${registrationScan.data?.name || ''}`, "註冊衝突");
            return;
          }

          if (registrationScan.status === 'serial-missing') {
            UI.alert(`偵測到卡序 #${registrationScan.serial}，但資料庫尚未建檔。
請改用空白卡片(UID)進行註冊。`, "註冊異常");
            return;
          }

          if (registrationScan.status === 'uid-bound') {
            UI.alert(`此卡片已綁定卡序 #${registrationScan.serial}`, "註冊衝突");
            return;
          }

          if (registrationScan.status !== 'blank-uid') {
            UI.toast("❌ 無法辨識此卡片");
            return;
          }

          currentState.currentCardUid = registrationScan.uid;
          const registrationDom = getRegistrationDom();
          const regUidDisplay = registrationDom.uidDisplay;
          if (regUidDisplay) regUidDisplay.innerText = registrationScan.uid;
          UI.showModal('regModal');
          const cs = registrationDom.cardSeqInput;
          if (cs) { cs.value = ''; cs.focus(); }
          return;
        }

        if (currentState.scanIntention === 'reissue') {
          const st = currentState.reissueState;
          if (!st || !st.serial) { UI.alert('補發狀態遺失，請回到帳號管理重新操作。', '系統異常'); return; }

          const newUid = currentState.lastNfcSerialNumber || null;
          if (st.oldUid && newUid && String(st.oldUid).toUpperCase() === String(newUid).toUpperCase()) {
            UI.alert('偵測到同一張舊卡，請改用「新卡」進行補發。', '補發失敗');
            return;
          }

          await this.executeReissue(st.serial, st.oldToken || null, st.oldUid || null, newUid);
          return;
        }

        const resolved = await studentAccessApi.resolveStudentRecordFromScanKey(rawKey, {
          requireActive: true,
          allowAdminUidFallback: true,
          setCurrentToken: true,
          notifyUidFallback: true
        });
        if (!resolved.serial || !resolved.data) {
          UI.alert('資料庫中查無此卡片紀錄，或此卡已被停用（補發後舊卡失效）。', '查無檔案');
          return;
        }

        const primedData = typeof this.primeAdminStudentPanel === 'function'
          ? (this.primeAdminStudentPanel(resolved.serial, resolved.data, 'handleCardScan:default-read') || resolved.data)
          : resolved.data;
        this.loadStudentData(resolved.serial, 'admin', {
          preloadedData: primedData,
          primeView: false,
          serial: resolved.serial,
          source: 'handleCardScan:default-read'
        });
        try {
          this.scheduleBackgroundTask('student-mirror:autoheal:nfc-read', () => this.syncStudentMirrorForSerial(resolved.serial, resolved.data));
        } catch (_) {}
      },
      setCardForgeMode(mode) { return teacherActionsApi.setCardForgeMode.apply(this, arguments); },

      initCardForgePresets() { return teacherActionsApi.initCardForgePresets.apply(this, arguments); },

      applyForgeXpPreset() { return teacherActionsApi.applyForgeXpPreset.apply(this, arguments); },

      ensureTeacherTargetData(data) { return teacherActionsApi.ensureTeacherTargetData.apply(this, arguments); },
      getTeacherTargetContext() { return teacherActionsApi.getTeacherTargetContext.apply(this, arguments); },
      lookupTeacherTargetBySerial(rawSerial, options) { return teacherActionsApi.lookupTeacherTargetBySerial.apply(this, arguments); },
      syncTeacherTargetContext(data, options) { return teacherActionsApi.syncTeacherTargetContext.apply(this, arguments); },
      clearTeacherTargetContext(reason) { return teacherActionsApi.clearTeacherTargetContext.apply(this, arguments); },
      diagnoseTeacherTarget(options) { return teacherActionsApi.diagnoseTeacherTarget.apply(this, arguments); },

      openCardForge() { return teacherActionsApi.openCardForge.apply(this, arguments); },
      startCardForge() { return teacherActionsApi.startCardForge.apply(this, arguments); },
      cancelCardForge() { return teacherActionsApi.cancelCardForge.apply(this, arguments); },
      enterBatchMode() { return batchApi.enterBatchMode.apply(this, arguments); },
      exitBatchMode() { return batchApi.exitBatchMode.apply(this, arguments); },
      setBatchStudent() { return batchApi.setBatchStudent.apply(this, arguments); },
      startBatchTimer() { return batchApi.startBatchTimer.apply(this, arguments); },
      endBatchSession() { return batchApi.endBatchSession.apply(this, arguments); },
      resetBatchState() { return batchApi.resetBatchState.apply(this, arguments); },
      persistBatchStudentData() { return batchApi.persistBatchStudentData.apply(this, arguments); },
      executeBatchAction() { return batchApi.executeBatchAction.apply(this, arguments); },

      startStudentPropScan() { return teacherActionsApi.startStudentPropScan.apply(this, arguments); },
      executeStudentPropAction() { return teacherActionsApi.executeStudentPropAction.apply(this, arguments); },
      loadStudentData(uid, mode) { return studentApi.loadStudentData.apply(this, arguments);; },
      checkDebuffRecovery(data) { return studentApi.checkDebuffRecovery.apply(this, arguments);; },
      refreshStudentRewardPanel(dataObj = null, forceStudentPanel = false) { return studentApi.refreshStudentRewardPanel.apply(this, arguments);; },
      updatePanel(dataObj = null, forceStudentPanel = false) { return UI.updatePanel(dataObj, forceStudentPanel); },
      getDailyResetAnchor(data = {}, nowTs = Date.now()) { return getDailyResetAnchor(data, nowTs); },
      isCatProfile(data = null) { return isCatProfile(data); },
      addAttributeXP(data, attr, amount) { return addAttributeXP(data, attr, amount); },
      async ensureStudentDataReady(options = {}) { return studentAccessApi.ensureStudentDataReady(options); },

      normalizeQuizPoolAudienceKey() { return quizApi.normalizeQuizPoolAudienceKey(...arguments); },
      getQuizPoolAudienceKeyForStudent() { return quizApi.getQuizPoolAudienceKeyForStudent(...arguments); },
      parseQuizAnswerIndex() { return quizApi.parseQuizAnswerIndex(...arguments); },
      buildQuizPoolQuestionSummary() { return quizApi.buildQuizPoolQuestionSummary(...arguments); },
      isPlayableQuizPoolQuestion() { return quizApi.isPlayableQuizPoolQuestion(...arguments); },
      normalizeQuizPoolSummaryRecord() { return quizApi.normalizeQuizPoolSummaryRecord(...arguments); },
      getQuizPoolAudienceKeysForQuestion() { return quizApi.getQuizPoolAudienceKeysForQuestion(...arguments); },
      buildQuizPoolAudiencePayloads() { return quizApi.buildQuizPoolAudiencePayloads(...arguments); },
      async loadQuizPoolAudienceDoc() { return quizApi.loadQuizPoolAudienceDoc(...arguments); },
      pickQuizPoolCandidateIds() { return quizApi.pickQuizPoolCandidateIds(...arguments); },
      sampleQuizPoolQuestions() { return quizApi.sampleQuizPoolQuestions(...arguments); },
      async loadQuizQuestionsByIds() { return quizApi.loadQuizQuestionsByIds(...arguments); },
      async backfillQuizPoolSummaryEntries() { return quizApi.backfillQuizPoolSummaryEntries(...arguments); },
      syncQuizPoolSummaryFromQuizBank() { return quizApi.syncQuizPoolSummaryFromQuizBank(...arguments); },
      scheduleQuizPoolSummaryRefresh() { return quizApi.scheduleQuizPoolSummaryRefresh(...arguments); },
      async warmStudentQuizPool() { return quizApi.warmStudentQuizPool(...arguments); },
      async loadBattleTowerConfigDoc() { return quizApi.loadBattleTowerConfigDoc(...arguments); },
      async listBattleGatekeeperQuestions() { return quizApi.listBattleGatekeeperQuestions(...arguments); },
      async pickBattleGatekeeperQuestion() { return quizApi.pickBattleGatekeeperQuestion(...arguments); },
      async loadBattleGatekeeperQuestion() { return quizApi.loadBattleGatekeeperQuestion(...arguments); },
      async saveBattleTowerAudienceConfig() { return quizApi.saveBattleTowerAudienceConfig(...arguments); },
      async clearBattleTowerAudienceConfig() { return quizApi.clearBattleTowerAudienceConfig(...arguments); },
      resolveVisualMeta(raw = {}, options = {}) {
        const source = raw && typeof raw === 'object' ? raw : {};
        const directCandidates = [
          source.previewImageUrl,
          source.thumbnailUrl,
          source.thumbUrl,
          source.imageUrl,
          source.image_url,
          source.image,
          source.img,
          source.cover,
          source.photo,
          source.artUrl
        ];
        const assetCandidates = [
          source.previewImageAssetKey,
          source.thumbnailAssetKey,
          source.thumbAssetKey,
          source.imageAssetKey,
          source.image_asset_key,
          source.imageAsset,
          source.assetKey,
          source.img_file,
          source.imageFile,
          source.coverAssetKey,
          source.photoAssetKey
        ];
        let imageUrl = '';
        for (const candidate of directCandidates) {
          const value = String(candidate || '').trim();
          if (!value) continue;
          if (isDirectVisualSource(value) || /^blob:/i.test(value)) {
            imageUrl = value;
            break;
          }
        }
        let imageAssetKey = '';
        for (const candidate of assetCandidates) {
          const value = String(candidate || '').trim();
          if (!value) continue;
          imageAssetKey = value;
          break;
        }
        if (!imageUrl && !imageAssetKey) {
          const fallback = String(source.img || source.image || '').trim();
          if (fallback) {
            if (isDirectVisualSource(fallback) || /^blob:/i.test(fallback)) imageUrl = fallback;
            else imageAssetKey = fallback;
          }
        }
        const imageAlt = String(options.alt || source.imageAlt || source.image_alt || source.alt || source.name || '').trim();
        return { imageUrl, imageAssetKey, imageAlt };
      },
      getRankingDisplayItems(...args) {
        return rankingApi?.getRankingDisplayItems ? rankingApi.getRankingDisplayItems(...args) : [];
      },
      getRankingLegendaryPoints(...args) {
        return rankingApi?.getRankingLegendaryPoints ? rankingApi.getRankingLegendaryPoints(...args) : 0;
      },
      buildLeaderboardSummaryData(...args) {
        return rankingApi?.buildLeaderboardSummaryData ? rankingApi.buildLeaderboardSummaryData(...args) : null;
      },
      normalizeLeaderboardSummaryRecord(...args) {
        return rankingApi?.normalizeLeaderboardSummaryRecord ? rankingApi.normalizeLeaderboardSummaryRecord(...args) : null;
      },
      async loadLeaderboardSummary(...args) {
        return rankingApi?.loadLeaderboardSummary ? await rankingApi.loadLeaderboardSummary(...args) : [];
      },
      syncLeaderboardSummaryForSerial(...args) {
        return rankingApi?.syncLeaderboardSummaryForSerial ? rankingApi.syncLeaderboardSummaryForSerial(...args) : Promise.resolve(null);
      },
      backfillLeaderboardSummaryEntries(...args) {
        return rankingApi?.backfillLeaderboardSummaryEntries ? rankingApi.backfillLeaderboardSummaryEntries(...args) : Promise.resolve(0);
      },
      rankStudentsForBoard(...args) {
        return rankingApi?.rankStudentsForBoard ? rankingApi.rankStudentsForBoard(...args) : [];
      },
      renderRankingRows(...args) {
        if (rankingApi?.renderRankingRows) return rankingApi.renderRankingRows(...args);
      },
      async warmRankingCache(...args) {
        return rankingApi?.warmRankingCache ? await rankingApi.warmRankingCache(...args) : [];
      },
      deferStudentViewWarm(options = {}) {
        if (currentState.viewMode !== 'student' || !currentState.studentData) return Promise.resolve([]);
        const now = Date.now();
        if (currentState.studentViewWarmPromise && (now - (currentState.studentViewWarmStartedAt || 0)) < 12000) return currentState.studentViewWarmPromise;

        const source = options.source || 'student';
        const delayMs = Math.max(400, Number(options.delayMs) || 1400);
        const includeShop = options.includeShop !== false;
        const includeRanking = !!options.includeRanking;
        const includeQuiz = !!options.includeQuiz;

        currentState.studentViewWarmStartedAt = now;
        beginPerfSpan('student', 'defer-student-view-warm', { source, includeShop, includeRanking, includeQuiz, delayMs });
        currentState.studentViewWarmPromise = new Promise((resolve) => {
          const runner = () => {
            const jobs = [];
            if (includeShop) jobs.push(this.warmStudentShopCatalog({ source: `${source}:shop-idle`, maxAgeMs: 180000 }));
            if (includeRanking) jobs.push(this.warmRankingCache({ source: `${source}:ranking-idle`, maxAgeMs: 180000 }));
            if (includeQuiz) jobs.push(this.warmStudentQuizPool({ source: `${source}:quiz-idle`, maxAgeMs: 180000 }));
            if (!jobs.length) {
              currentState.studentViewWarmPromise = null;
              endPerfSpan('student', 'defer-student-view-warm', { status: 'empty' });
              resolve([]);
              return;
            }
            Promise.allSettled(jobs).then((results) => {
              endPerfSpan('student', 'defer-student-view-warm', { status: 'ok', resultCount: results.length });
              resolve(results);
            }).finally(() => {
              currentState.studentViewWarmPromise = null;
            });
          };

          if (typeof window.requestIdleCallback === 'function') {
            window.requestIdleCallback(runner, { timeout: Math.max(1800, delayMs + 600) });
          } else {
            window.setTimeout(runner, delayMs);
          }
        });
        return currentState.studentViewWarmPromise;
      },
      warmStudentViewData(options = {}) {
        return this.deferStudentViewWarm(options);
      },
      normalizeStudentShopMode(...args) {
        return shopApi?.normalizeStudentShopMode ? shopApi.normalizeStudentShopMode(...args) : 'preview';
      },
      getStudentShopMode(...args) {
        return shopApi?.getStudentShopMode ? shopApi.getStudentShopMode(...args) : 'preview';
      },
      resolveStudentShopCardFooter(...args) {
        return shopApi?.resolveStudentShopCardFooter ? shopApi.resolveStudentShopCardFooter(...args) : { statusText: '展示模式', helperText: '目前僅供展示，尚未開放學生端直接兌換。', pillTone: 'rgba(255,255,255,0.68)', actionState: 'preview' };
      },
      buildStudentShopSummaryData(...args) {
        return shopApi?.buildStudentShopSummaryData ? shopApi.buildStudentShopSummaryData(...args) : null;
      },
      normalizeStudentShopItem(...args) {
        return shopApi?.normalizeStudentShopItem ? shopApi.normalizeStudentShopItem(...args) : null;
      },
      async loadStudentShopCatalogSummary(...args) {
        return shopApi?.loadStudentShopCatalogSummary ? await shopApi.loadStudentShopCatalogSummary(...args) : [];
      },
      syncStudentShopCatalogSummaryForId(...args) {
        return shopApi?.syncStudentShopCatalogSummaryForId ? shopApi.syncStudentShopCatalogSummaryForId(...args) : Promise.resolve(null);
      },
      removeStudentShopCatalogSummaryForId(...args) {
        return shopApi?.removeStudentShopCatalogSummaryForId ? shopApi.removeStudentShopCatalogSummaryForId(...args) : Promise.resolve(false);
      },
      backfillStudentShopCatalogSummaryEntries(...args) {
        return shopApi?.backfillStudentShopCatalogSummaryEntries ? shopApi.backfillStudentShopCatalogSummaryEntries(...args) : Promise.resolve(0);
      },
      renderStudentShopShowcaseCards(...args) {
        return shopApi?.renderStudentShopShowcaseCards ? shopApi.renderStudentShopShowcaseCards(...args) : '';
      },
      async warmStudentShopCatalog(...args) {
        return shopApi?.warmStudentShopCatalog ? await shopApi.warmStudentShopCatalog(...args) : [];
      },
      async renderStudentShopShowcase(...args) {
        return shopApi?.renderStudentShopShowcase ? await shopApi.renderStudentShopShowcase(...args) : [];
      },
      async showRanking(...args) {
        if (rankingApi?.showRanking) return await rankingApi.showRanking(...args);
      },

      prepareAction(attr, baseVal, desc) { return teacherActionsApi.prepareAction.apply(this, arguments); },
      prepareActionFromButton(buttonEl) { return teacherActionsApi.prepareActionFromButton.apply(this, arguments); },

      async commitAction() { return teacherActionsApi.commitAction.apply(this, arguments); },
      processEvolution(data) {
        return evolutionApi?.processEvolution ? evolutionApi.processEvolution(...arguments) : data;
      },

      // --- 商城（兌換）---
      async openShop() { return shopApi.openShop(...arguments); },
      async applyShopEffect() { return shopApi.applyShopEffect(...arguments); },
      async handleShopPurchase() { return shopApi.handleShopPurchase(...arguments); },

      async redeemCollectionVoucher(index) { return teacherActionsApi.redeemCollectionVoucher.apply(this, arguments); },
      checkDeathTrigger(data, triggerStatusKey) { return teacherActionsApi.checkDeathTrigger.apply(this, arguments); },

      async forceDebuff(statusName) { return teacherActionsApi.forceDebuff.apply(this, arguments); },

      resolveQuizImageMeta(raw = {}) {
        const source = raw && typeof raw === 'object' ? raw : {};
        const directCandidate = String(
          source.imageUrl
          || source.image_url
          || source.questionImage
          || source.question_image
          || source.image
          || source.img
          || ''
        ).trim();
        const assetCandidate = String(
          source.imageAssetKey
          || source.image_asset_key
          || source.imageAsset
          || source.assetKey
          || source.img_file
          || source.imageFile
          || ''
        ).trim();
        let imageUrl = '';
        let imageAssetKey = assetCandidate;
        if (directCandidate) {
          if (isDirectVisualSource(directCandidate) || /^blob:/i.test(directCandidate)) imageUrl = directCandidate;
          else if (!imageAssetKey) imageAssetKey = directCandidate;
        }
        const imageAlt = String(source.imageAlt || source.image_alt || source.alt || source.question || '題目附圖').trim() || '題目附圖';
        return { imageUrl, imageAssetKey, imageAlt };
      },

      updateQuizImagePreview(meta = {}, options = {}) {
        const { imagePreview, imagePreviewHint } = getQuizManagerDom();
        if (!imagePreview || !imagePreviewHint) return;
        const imageUrl = String(meta.imageUrl || '').trim();
        const imageAssetKey = String(meta.imageAssetKey || '').trim();
        const imageAlt = String(meta.imageAlt || '題圖預覽').trim() || '題圖預覽';
        const placeholder = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        imagePreview.alt = imageAlt;
        imagePreview.dataset.assetHydrated = '0';
        imagePreview.removeAttribute('data-asset');
        imagePreview.onclick = null;
        if (imageUrl) {
          imagePreview.src = imageUrl;
          imagePreviewHint.innerText = '目前使用直接題圖網址，學生作答時會優先顯示這張圖片。';
        } else if (imageAssetKey) {
          imagePreview.src = placeholder;
          imagePreview.setAttribute('data-asset', imageAssetKey);
          imagePreviewHint.innerText = `目前使用 Storage 題圖：${imageAssetKey}`;
          try { hydrateStorageImages(imagePreview.parentElement || imagePreview); } catch (_) {}
        } else {
          imagePreview.src = placeholder;
          imagePreviewHint.innerText = options.emptyHint || '未設定題圖時，作答畫面只顯示文字題目。';
        }
        imagePreview.onclick = () => {
          if (imagePreview.src && imagePreview.src !== placeholder) UI.showImageModal(imagePreview.src, imageAlt);
        };
      },

      previewQuizImageFromForm() {
        const { imageUrl, imageAsset, question } = getQuizManagerDom();
        const meta = this.resolveQuizImageMeta({
          imageUrl: imageUrl?.value || '',
          imageAssetKey: imageAsset?.value || '',
          question: question?.value || '題目附圖'
        });
        this.updateQuizImagePreview(meta);
      },

      renderQuizQuestionMedia(questionRecord = null) {
        const { questionMedia, questionImage, questionImageHint } = getQuizPlayDom();
        if (!questionMedia || !questionImage) return;
        const meta = this.resolveQuizImageMeta(questionRecord || {});
        const placeholder = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        questionImage.dataset.assetHydrated = '0';
        questionImage.dataset.assetPriority = '1';
        questionImage.removeAttribute('data-asset');
        questionImage.onclick = null;
        questionImage.loading = 'eager';
        questionImage.decoding = 'async';
        try { questionImage.fetchPriority = 'high'; } catch (_) {}
        questionImage.alt = String(meta.imageAlt || questionRecord?.question || '題目附圖').trim() || '題目附圖';
        if (meta.imageUrl) {
          questionImage.src = meta.imageUrl;
          questionMedia.classList.remove('hidden');
          if (questionImageHint) questionImageHint.innerText = '點擊可放大題圖';
        } else if (meta.imageAssetKey) {
          questionImage.src = placeholder;
          questionImage.setAttribute('data-asset', meta.imageAssetKey);
          questionMedia.classList.remove('hidden');
          if (questionImageHint) questionImageHint.innerText = '題圖載入中，點擊可放大';
          try { hydrateStorageImages(questionMedia, { immediate: true, eagerLimit: 1, rootMargin: '480px 0px' }); } catch (_) {}
        } else {
          questionImage.removeAttribute('src');
          questionMedia.classList.add('hidden');
          if (questionImageHint) questionImageHint.innerText = '點擊可放大題圖';
          return;
        }
        questionImage.onclick = () => {
          if (questionImage.src && questionImage.src !== placeholder) UI.showImageModal(questionImage.src, questionImage.alt || '題目附圖');
        };
      },

      resetQuizForm() {
        const {
          formTitle,
          editId,
          saveBtn,
          cancelBtn,
          grade,
          unit,
          question,
          imageUrl,
          imageAsset,
          optionInputs,
          getCorrectInputByValue
        } = getQuizManagerDom();
        if (formTitle) formTitle.innerText = '[ 新增題目 ]';
        if (editId) editId.value = '';
        if (saveBtn) {
          saveBtn.innerText = '儲存題目';
          saveBtn.setAttribute('onclick', 'App.saveNewQuiz()');
        }
        if (cancelBtn) cancelBtn.classList.add('hidden');
        if (grade) grade.value = '5上';
        if (unit) unit.value = '';
        if (question) question.value = '';
        if (imageUrl) imageUrl.value = '';
        if (imageAsset) imageAsset.value = '';
        (optionInputs || []).forEach(el => { if (el) el.value = ''; });
        this.updateQuizImagePreview({}, { emptyHint: '未設定題圖時，作答畫面只顯示文字題目。' });
        const firstRadio = getCorrectInputByValue?.('0');
        if (firstRadio) firstRadio.checked = true;
      },

      fillQuizForm(quizId, quizData = {}) {
        const {
          formTitle,
          editId,
          saveBtn,
          cancelBtn,
          grade,
          unit,
          question,
          imageUrl,
          imageAsset,
          optionInputs,
          correctInputs,
          getCorrectInputByValue,
          modalContent
        } = getQuizManagerDom();
        if (formTitle) formTitle.innerText = '[ 修改題目 EDIT ENTRY ]';
        if (editId) editId.value = quizId || '';
        if (saveBtn) {
          saveBtn.innerText = 'UPDATE ENTRY (儲存修改)';
          saveBtn.setAttribute('onclick', 'App.saveEditedQuiz()');
        }
        if (cancelBtn) cancelBtn.classList.remove('hidden');
        if (grade) grade.value = quizData.grade || '5上';
        if (unit) unit.value = quizData.unit || '';
        if (question) question.value = quizData.question || '';
        const imageMeta = this.resolveQuizImageMeta(quizData || {});
        if (imageUrl) imageUrl.value = imageMeta.imageUrl || '';
        if (imageAsset) imageAsset.value = imageMeta.imageAssetKey || '';
        this.updateQuizImagePreview({ ...imageMeta, imageAlt: quizData.question || '題目附圖' });
        const options = Array.isArray(quizData.options) ? quizData.options : [];
        for (let i = 0; i < 4; i++) {
          const opt = options[i] || {};
          const input = optionInputs?.[i];
          if (input) input.value = opt.text || '';
          const radio = getCorrectInputByValue?.(String(i));
          if (radio) radio.checked = !!opt.isCorrect;
        }
        if (!(correctInputs || []).some(r => r.checked)) {
          const firstRadio = getCorrectInputByValue?.('0');
          if (firstRadio) firstRadio.checked = true;
        }
        if (modalContent) modalContent.scrollTo({ top: 0, behavior: 'smooth' });
      },

      async openEditQuiz() { return quizApi.openEditQuiz(...arguments); },

      cancelQuizEdit() {
        this.resetQuizForm();
      },

      readQuizFormData() {
        const { grade, unit, question, imageUrl, imageAsset, optionInputs, getCheckedCorrectInput } = getQuizManagerDom();
        const qGrade = grade?.value || '5上';
        const qUnit = unit?.value.trim() || '未分類';
        const qText = question?.value.trim() || '';
        const opts = (optionInputs || []).map((input) => (input?.value || '').trim());
        const checked = getCheckedCorrectInput?.();
        const correctVal = checked ? String(checked.value) : '0';
        if (!qText || opts.some(v => !v)) {
          UI.toast('請填寫完整題目！');
          return null;
        }
        const imageMeta = this.resolveQuizImageMeta({ imageUrl: imageUrl?.value || '', imageAssetKey: imageAsset?.value || '', question: qText });
        return {
          grade: qGrade,
          unit: qUnit,
          question: qText,
          imageUrl: imageMeta.imageUrl,
          image: imageMeta.imageUrl,
          imageAssetKey: imageMeta.imageAssetKey,
          imageAlt: imageMeta.imageAlt,
          options: opts.map((text, idx) => ({ text, isCorrect: correctVal === String(idx) })),
        };
      },

      async importQuizBulk() { return quizApi.importQuizBulk(...arguments); },

      async exportQuizBank() { return quizApi.exportQuizBank(...arguments); },

      updateQuizSelectionSummary(visibleIds = null) {
        const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
        const { selectedCount: counter, selectAll: allCheckbox } = getQuizManagerDom();
        if (counter) counter.innerText = `已勾選 ${selectedIds.length} 題`;

        if (allCheckbox) {
          const visible = Array.isArray(visibleIds) ? visibleIds : [];
          const selectedVisible = visible.filter(id => selectedIds.includes(id)).length;
          allCheckbox.checked = visible.length > 0 && selectedVisible === visible.length;
          allCheckbox.indeterminate = selectedVisible > 0 && selectedVisible < visible.length;
        }
      },

      updateQuizFilterState() {
        const quizzes = Array.isArray(currentState.quizBankCache) ? currentState.quizBankCache : [];
        const { filterGrade: gradeSelect, filterUnit: unitSelect } = getQuizManagerDom();
        if (!gradeSelect || !unitSelect) return;

        const gradeOrder = ['1上','1下','2上','2下','3上','3下','4上','4下','5上','5下','6上','6下','學習扶助班'];
        const gradeRank = (g) => {
          const idx = gradeOrder.indexOf(String(g || ''));
          return idx >= 0 ? idx : 999;
        };

        const gradeValue = gradeSelect.value;
        const grades = Array.from(new Set(quizzes.map(q => String(q.grade || '').trim()).filter(Boolean)))
          .sort((a, b) => gradeRank(a) - gradeRank(b) || String(a).localeCompare(String(b), 'zh-Hant'));

        gradeSelect.innerHTML = '<option value="">全部年級</option>' + grades.map(g => `<option value="${g}">${g}</option>`).join('');
        gradeSelect.value = grades.includes(gradeValue) ? gradeValue : '';

        const filteredForUnit = quizzes.filter(q => !gradeSelect.value || String(q.grade || '').trim() === gradeSelect.value);
        const unitValue = unitSelect.value;
        const units = Array.from(new Set(filteredForUnit.map(q => String(q.unit || '未分類').trim() || '未分類')))
          .sort((a, b) => String(a).localeCompare(String(b), 'zh-Hant'));
        unitSelect.innerHTML = '<option value="">全部單元</option>' + units.map(u => `<option value="${u}">${u}</option>`).join('');
        unitSelect.value = units.includes(unitValue) ? unitValue : '';
      },

      getFilteredQuizzes() {
        const quizzes = Array.isArray(currentState.quizBankCache) ? currentState.quizBankCache : [];
        const { filterGrade, filterUnit } = getQuizManagerDom();
        const gradeValue = filterGrade?.value || '';
        const unitValue = filterUnit?.value || '';
        return quizzes.filter(q => {
          const gradeOk = !gradeValue || String(q.grade || '').trim() === gradeValue;
          const unitOk = !unitValue || String(q.unit || '未分類').trim() === unitValue;
          return gradeOk && unitOk;
        });
      },

      toggleQuizSelection(id, checked) {
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        if (checked) selected.add(id);
        else selected.delete(id);
        currentState.quizSelectedIds = Array.from(selected);
        const visibleIds = this.getFilteredQuizzes().map(q => q.id);
        this.updateQuizSelectionSummary(visibleIds);
      },

      toggleAllQuizSelections(checked) {
        const visibleIds = this.getFilteredQuizzes().map(q => q.id);
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        visibleIds.forEach(id => {
          if (checked) selected.add(id);
          else selected.delete(id);
        });
        currentState.quizSelectedIds = Array.from(selected);
        this.renderQuizBankList();
      },

      renderQuizBankList() {
        const { listContainer: container } = getQuizManagerDom();
        if (!container) return;

        const filtered = this.getFilteredQuizzes();
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        const visibleIds = filtered.map(q => q.id);
        const gradeOrder = ['1上','1下','2上','2下','3上','3下','4上','4下','5上','5下','6上','6下','學習扶助班'];
        const gradeRank = (g) => {
          const idx = gradeOrder.indexOf(String(g || ''));
          return idx >= 0 ? idx : 999;
        };

        if (!filtered.length) {
          container.innerHTML = '<div style="text-align:center; color:#555; padding:18px; border:1px dashed #355; border-radius:8px;">目前篩選條件下沒有題目。</div>';
          this.updateQuizSelectionSummary([]);
          return;
        }

        const grouped = {};
        filtered.forEach(q => {
          const grade = String(q.grade || '未分類').trim() || '未分類';
          const unit = String(q.unit || '未分類').trim() || '未分類';
          if (!grouped[grade]) grouped[grade] = {};
          if (!grouped[grade][unit]) grouped[grade][unit] = [];
          grouped[grade][unit].push(q);
        });

        const gradeKeys = Object.keys(grouped).sort((a, b) => gradeRank(a) - gradeRank(b) || String(a).localeCompare(String(b), 'zh-Hant'));
        container.innerHTML = gradeKeys.map(grade => {
          const units = Object.keys(grouped[grade]).sort((a, b) => String(a).localeCompare(String(b), 'zh-Hant'));
          const unitHtml = units.map(unit => {
            const cards = grouped[grade][unit].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0)).map(q => {
              const optionsHtml = Array.isArray(q.options) ? q.options.map((opt, i) => {
                const color = opt.isCorrect ? 'var(--color-grass)' : '#555';
                return `<span style="color:${color}; margin-right:10px; font-size:0.85em; display:inline-block; margin-bottom:4px;">${i + 1}. ${opt.text}</span>`;
              }).join('') : '';
              const activeColor = q.isActive ? 'var(--color-grass)' : '#555';
              const activeText = q.isActive ? '✅ 已派發' : '❌ 未開放';
              const imageMeta = this.resolveQuizImageMeta(q || {});
              const imagePreviewHtml = imageMeta.imageUrl
                ? `<img src="${imageMeta.imageUrl.replace(/"/g,'&quot;')}" alt="題圖" style="width:88px; height:60px; object-fit:cover; border-radius:8px; border:1px solid rgba(255,255,255,0.12); background:rgba(0,0,0,0.45);">`
                : (imageMeta.imageAssetKey
                  ? `<img src="${CONSTANTS.MEDIA.PLACEHOLDER_SVG}" data-asset="${imageMeta.imageAssetKey.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;')}" alt="題圖" style="width:88px; height:60px; object-fit:cover; border-radius:8px; border:1px solid rgba(255,255,255,0.12); background:rgba(0,0,0,0.45);">`
                  : `<div style="width:88px; height:60px; display:flex; align-items:center; justify-content:center; border-radius:8px; border:1px dashed rgba(255,255,255,0.12); background:rgba(0,0,0,0.22); color:#667; font-size:0.72em;">無題圖</div>`);
              return `<div style="background:rgba(0,0,0,0.35); border:1px solid #333; border-radius:6px; padding:10px;">
                <div style="display:flex; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:8px; align-items:flex-start;">
                  <label style="display:flex; align-items:flex-start; gap:10px; flex:1; min-width:180px; color:#fff;">
                    <input type="checkbox" style="width:auto; margin-top:3px;" ${selected.has(q.id) ? 'checked' : ''} onchange="App.toggleQuizSelection('${q.id}', this.checked)" />
                    <div style="display:flex; gap:10px; align-items:flex-start; flex:1; min-width:0;">
                      ${imagePreviewHtml}
                      <span style="line-height:1.65; flex:1; min-width:0;">${q.question}</span>
                    </div>
                  </label>
                  <button onclick="App.toggleQuizActive('${q.id}', ${q.isActive || false})" style="background:transparent; border:1px dashed ${activeColor}; color:${activeColor}; padding:2px 8px; border-radius:4px; cursor:pointer;">${activeText}</button>
                </div>
                <div style="margin-bottom:10px;">${optionsHtml}</div>
                <div style="text-align:right; display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap;">
                  <button onclick="App.openEditQuiz('${q.id}')" style="background:none; border:1px solid var(--cyan); border-radius:4px; padding:2px 8px; color:var(--cyan); cursor:pointer;">修改</button>
                  <button onclick="App.deleteQuiz('${q.id}')" style="background:none; border:1px solid var(--danger); border-radius:4px; padding:2px 8px; color:var(--danger); cursor:pointer;">刪除</button>
                </div>
              </div>`;
            }).join('');
            return `<div style="background:rgba(0,0,0,0.25); border:1px solid #233; border-radius:8px; padding:12px;">
              <div class="tech-font" style="color:var(--cyan); margin-bottom:10px;">${unit} <span style="color:var(--text-muted); font-size:0.85em;">(${grouped[grade][unit].length} 題)</span></div>
              <div style="display:flex; flex-direction:column; gap:10px;">${cards}</div>
            </div>`;
          }).join('');
          return `<div style="border:1px solid #355; border-radius:10px; padding:12px; background:rgba(0,20,30,0.25);">
            <div class="tech-font" style="color:var(--legendary-gold); margin-bottom:12px; font-size:1.05em;">${grade}</div>
            <div style="display:flex; flex-direction:column; gap:12px;">${unitHtml}</div>
          </div>`;
        }).join('');
        try { hydrateStorageImages(container); } catch (_) {}

        this.updateQuizSelectionSummary(visibleIds);
      },

      async batchSetQuizActive() { return quizApi.batchSetQuizActive(...arguments); },

      async batchDeleteSelectedQuizzes() { return quizApi.batchDeleteSelectedQuizzes(...arguments); },

      async loadQuizBank() { return quizApi.loadQuizBank(...arguments); },

      async saveNewQuiz() { return quizApi.saveNewQuiz(...arguments); },

      async saveEditedQuiz() { return quizApi.saveEditedQuiz(...arguments); },

      async deleteQuiz() { return quizApi.deleteQuiz(...arguments); },
      
      async toggleQuizActive() { return quizApi.toggleQuizActive(...arguments); },

      isPlayableQuizQuestionRecord(questionRecord = {}) {
        if (!questionRecord || typeof questionRecord !== 'object') return false;
        const questionText = String(questionRecord.question || questionRecord.questionText || questionRecord.q || questionRecord.title || questionRecord.prompt || questionRecord.stem || questionRecord.text || '').trim();
        const options = Array.isArray(questionRecord.options)
          ? questionRecord.options.map((opt) => (typeof opt === 'string' ? { text: opt.trim(), isCorrect: false } : { text: String(opt?.text ?? opt?.label ?? opt?.content ?? '').trim(), isCorrect: !!opt?.isCorrect }))
              .filter((opt) => !!opt.text)
          : [];
        const hasCorrect = options.some((opt) => !!opt.isCorrect);
        return !!questionText && options.length >= 2 && hasCorrect;
      },

      buildDailyQuestQuestionSet(quizPool = [], { userGrade = '', isSupportClass = false } = {}) {
        const exactMatches = [];
        const fallbackMatches = [];
        let invalidCount = 0;
        const activePool = Array.isArray(quizPool) ? quizPool : [];
        activePool.forEach((questionRecord) => {
          if (!this.isPlayableQuizQuestionRecord(questionRecord)) {
            invalidCount++;
            return;
          }
          if (quizMatchesStudentGrade(questionRecord, userGrade, isSupportClass)) {
            exactMatches.push(questionRecord);
            return;
          }
          const rawGrade = String(questionRecord.grade || questionRecord.class_name || questionRecord.gradeName || '').trim();
          if (!/學習扶助/.test(rawGrade)) fallbackMatches.push(questionRecord);
        });
        const questions = exactMatches.length ? exactMatches : fallbackMatches;
        const reason = exactMatches.length ? 'exact' : (fallbackMatches.length ? 'fallback_active' : 'empty');
        return { questions, reason, exactCount: exactMatches.length, fallbackCount: fallbackMatches.length, invalidCount };
      },

      clearQuizAdvanceTimer() {
        return clearQuizAdvanceTimerCore();
      },

      resetQuizSession(overrides = {}) {
        return resetQuizSessionCore(overrides);
      },

      beginQuizSession(mode = 'quiz', overrides = {}) {
        return beginQuizSessionCore(mode, overrides);
      },

      scheduleQuizAdvance(callback, delay = 900, expectedToken = quizSession.sessionToken) {
        return scheduleQuizAdvanceCore(callback, delay, expectedToken);
      },

      abortQuizSession(reason = 'manual_close', overrides = {}) {
        return abortQuizSessionCore(reason, overrides);
      },

      handleQuizCloseButton() {
        this.abortQuizSession('manual_close');
        UI.hideModal('quizPlayModal');
        try { if (typeof UI.updateDailyQuestTimer === 'function') UI.updateDailyQuestTimer(); } catch (_) {}
      },


      async startDailyQuest() {
        if (currentState.dailyQuestStarting) {
          UI.toast('題庫載入中，請勿重複點擊');
          return;
        }

        const { dailyQuestBtn: btn, dailyQuestTimer: timerText } = getStudentActionDom();
        let studentData = currentState.studentData;
        if (!studentData) {
          try {
            studentData = await this.ensureStudentDataReady({ source: 'startDailyQuest', timeoutMs: 7000 });
          } catch (err) {
            UI.alert('學生資料仍在同步中，請稍候 2～3 秒後再試。', '尚未載入學生資料');
            return;
          }
        }
        const remainingRewardCount = getTodayDailyRemaining(studentData);
        if (remainingRewardCount <= 0) {
          UI.alert('今日歷練獎勵已滿 10 題，繼續作答也不會再增加金幣與經驗。請等待中午 12:00 重置，避免重複刷題浪費時間。', '今日歷練已達上限');
          UI.updateDailyQuestTimer();
          return;
        }

        const dailyContext = this.getDailyQuestLaunchContext(studentData || {});
        if (!dailyContext.isSupportClass && !dailyContext.userGrade) {
          UI.alert('目前學生資料中的班級名稱缺少年級資訊，系統無法判斷要抽哪一組題目。\n\n請先補上正確班級，再重新開始每日歷練。', '缺少年級資訊');
          UI.updateDailyQuestTimer();
          return;
        }

        const quizDom = getQuizPlayDom();
        if (!quizDom?.modal || !quizDom?.modalContent || !quizDom?.questionText || !quizDom?.optionsArea || !quizDom?.playArea || !quizDom?.resultArea) {
          UI.alert('每日歷練作答面板尚未正確載入，請重新整理頁面後再試。', '作答面板缺失');
          return;
        }

        currentState.dailyQuestStarting = true;
        if (btn) btn.disabled = true;
        if (timerText) {
          timerText.innerText = '[ 題庫載入中... ] 正在鎖定今日歷練';
          timerText.style.color = 'var(--warning)';
        }

        try {
          const desiredCount = Math.max(12, Math.min(24, remainingRewardCount + 8));
          const audienceCacheMap = currentState.studentQuizPoolCacheByAudience || {};
          const quizPoolPromise = this.warmStudentQuizPool({ source: 'startDailyQuest', maxAgeMs: 180000, audienceKey: dailyContext.audienceKey, desiredCount });
          const quizTimeoutToken = Symbol('quiz-timeout');
          let activeQuizPool = await Promise.race([
            quizPoolPromise,
            new Promise((resolve) => window.setTimeout(() => resolve(quizTimeoutToken), 6500))
          ]);
          if (activeQuizPool === quizTimeoutToken) {
            const audienceCache = audienceCacheMap[dailyContext.audienceKey];
            activeQuizPool = Array.isArray(audienceCache) && audienceCache.length
              ? audienceCache
              : (Array.isArray(currentState.studentQuizPoolCache) && currentState.studentQuizPoolCache.length ? currentState.studentQuizPoolCache : null);
          }
          if (!Array.isArray(activeQuizPool) || !activeQuizPool.length) {
            try {
              activeQuizPool = await quizPoolPromise;
            } catch (quizErr) {
              console.error(quizErr);
              activeQuizPool = [];
            }
          }

          const questionSet = this.buildDailyQuestQuestionSet(activeQuizPool, {
            userGrade: dailyContext.userGrade,
            isSupportClass: dailyContext.isSupportClass
          });
          let allQ = Array.isArray(questionSet.questions) ? questionSet.questions.slice() : [];
          if (questionSet.reason === 'fallback_active' && allQ.length > 0) {
            console.warn('[daily quest] no exact grade match, fallback to active quiz bank', {
              audienceKey: dailyContext.audienceKey,
              className: dailyContext.className,
              exactCount: questionSet.exactCount,
              fallbackCount: questionSet.fallbackCount,
              invalidCount: questionSet.invalidCount
            });
          }
          if (questionSet.invalidCount > 0) {
            console.warn('[daily quest] filtered invalid questions before launch:', questionSet.invalidCount);
          }
          if (allQ.length < 1) {
            const shortageReason = questionSet.invalidCount > 0
              ? '目前符合條件的題目不足，或部分題目缺少完整選項/正解設定。'
              : '目前沒有符合年級且已啟用的題目。';
            UI.alert(`無法載入題庫：${shortageReason}`, '題庫不足');
            UI.updateDailyQuestTimer();
            return;
          }

          for (let i = allQ.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [allQ[i], allQ[j]] = [allQ[j], allQ[i]];
          }

          const launchQuestions = allQ.slice(0, Math.max(1, Math.min(10, remainingRewardCount))).filter((q) => this.isPlayableQuizQuestionRecord(q));
          if (!launchQuestions.length) {
            UI.alert('目前題庫中可用題目不足，或題目缺少完整選項/正解設定，無法開始每日歷練。', '無法開始挑戰');
            UI.updateDailyQuestTimer();
            return;
          }

          // 初始化 session：每日可重複進入，但每日最多獲獎 10 題；本次僅出剩餘可獲獎題數
          this.abortQuizSession('restart_daily');
          const dailySessionToken = beginDailyQuizSessionCore({
            questions: launchQuestions,
            studentData: studentData || currentState.studentData || {},
            remainingRewardCount,
            mode: 'daily'
          });

          // 立刻鎖定 24h 冷卻（避免中途關閉/刷新可重刷）
          quizSession.dailyData.last_practice_time = Date.now();
          quizSession.dailyData.logs = Array.isArray(quizSession.dailyData.logs) ? quizSession.dailyData.logs : [];
          const dailyLabels = getProfileLabels(quizSession.dailyData);
          const dailyLogPrefix = dailyLabels.dailyQuestLogPrefix || (isCatProfile(quizSession.dailyData) ? '後院巡查' : '每日歷練');
          quizSession.dailyData.logs.push({ timestamp: Date.now(), action_type: "quest", detail: `[${dailyLogPrefix}] 開始今日挑戰（本次可獲獎 ${quizSession.questions.length} 題，今日剩餘 ${remainingRewardCount} 題）` });

          const startedData = await this.saveToDB(quizSession.dailyData);
          quizSession.dailyData = this.refreshStudentRewardPanel(startedData || currentState.studentData || quizSession.dailyData, true);
          currentState.studentData = quizSession.dailyData;
          UI.updateDailyQuestTimer();

          const { title: quizPlayTitleEl, modalContent: quizPlayContentEl } = getQuizPlayDom();
          if (quizPlayTitleEl) {
            quizPlayTitleEl.innerText = isCatProfile(quizSession.dailyData) ? '### 後院巡查' : '### 每日歷練';
            quizPlayTitleEl.style.color = "var(--color-grass)";
          }
          if (quizPlayContentEl) quizPlayContentEl.style.borderColor = "var(--color-grass)";
          UI.hide('quizResultArea');
          UI.show('quizPlayArea');
          UI.showModal('quizPlayModal');
          this.renderQuizQuestion();
        } catch(e) {
          console.error(e);
          this.abortQuizSession('daily_start_failed');
          UI.toast('無法載入題庫');
          UI.updateDailyQuestTimer();
        } finally {
          currentState.dailyQuestStarting = false;
          try { if (typeof UI.updateDailyQuestTimer === 'function') UI.updateDailyQuestTimer(); } catch (_) {}
        }
      },

      renderQuizQuestion() {
        if (quizSession.aborted) return;
        quizSession.answerPending = false;

        let q = quizSession.questions[quizSession.currentIndex];
        if (!this.isPlayableQuizQuestionRecord(q)) {
          const nextPlayableIndex = Array.isArray(quizSession.questions)
            ? quizSession.questions.findIndex((candidate, idx) => idx >= quizSession.currentIndex && this.isPlayableQuizQuestionRecord(candidate))
            : -1;
          if (nextPlayableIndex >= 0) {
            if (nextPlayableIndex !== quizSession.currentIndex) {
              console.warn('[renderQuizQuestion] skipped invalid question record', {
                previousIndex: quizSession.currentIndex,
                nextPlayableIndex
              });
            }
            quizSession.currentIndex = nextPlayableIndex;
            q = quizSession.questions[quizSession.currentIndex];
          }
        }
        const { progress: progressEl, questionText: questionEl, optionsArea: optsArea } = getQuizPlayDom();
        if (!q || !questionEl || !optsArea) {
          console.warn('[renderQuizQuestion] missing question or quiz DOM', {
            hasQuestion: !!q,
            hasQuestionEl: !!questionEl,
            hasOptionsEl: !!optsArea
          });
          this.abortQuizSession('render_missing_dom_or_question');
          UI.alert('題目資料或作答面板不存在，請重新開始挑戰。', '無法載入題目');
          UI.hideModal('quizPlayModal');
          return;
        }
        if (progressEl) {
          if (quizSession.mode === 'battle') {
              progressEl.innerText = `只要答錯就會失去今日挑戰機會！請仔細作答。`;
          } else {
              const dailyRemain = Number(quizSession.dailyRemainingAtStart ?? quizSession.questions.length) - Number(quizSession.currentIndex);
              progressEl.innerText = `第 ${quizSession.currentIndex + 1} 題 / 共 ${quizSession.questions.length} 題｜今日剩餘可獲獎 ${Math.max(0, dailyRemain)} 題`; 
          }
        }
        this.renderQuizQuestionMedia(q);
        try { prefetchQuizQuestionMedia(quizSession.questions[quizSession.currentIndex + 1] || null); } catch (_) {}
        questionEl.innerText = q.question || '（題目遺失）';
        optsArea.innerHTML = '';
        let renderedOptionCount = 0;
        if (Array.isArray(q.options)) {
            q.options.forEach((opt, idx) => {
                const optionText = String(opt?.text || '').trim();
                if (!optionText) return;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.style.textAlign = 'left';
                btn.style.color = '#fff';
                if (quizSession.mode === 'battle') {
                    btn.className = 'btn';
                    btn.style.borderColor = '#555';
                    btn.textContent = optionText;
                    btn.addEventListener('click', () => App.handleBattleQuizAnswer(!!opt.isCorrect));
                } else {
                    btn.className = 'btn quiz-opt-btn';
                    btn.style.fontFamily = 'Noto Sans TC, sans-serif';
                    btn.style.borderColor = 'var(--text-muted)';
                    btn.style.fontSize = '1em';
                    btn.textContent = `${String.fromCharCode(65 + idx)}. ${optionText}`;
                    btn.addEventListener('click', () => App.selectQuizOption(idx, !!opt.isCorrect));
                }
                optsArea.appendChild(btn);
                renderedOptionCount += 1;
            });
        }
        if (!renderedOptionCount) {
          this.abortQuizSession('render_empty_options');
          UI.alert('目前這題沒有可作答選項，請通知老師檢查題庫。', '題目格式異常');
          UI.hideModal('quizPlayModal');
        }
      },

      async selectQuizOption(selectedIndex, isCorrect) {
        if (quizSession.aborted) return;
        if (quizSession.answerPending) return;
        const expectedToken = quizSession.sessionToken;
        const questionIndex = Number(quizSession.currentIndex) || 0;
        quizSession.answerPending = true;
        quizSession.lastAnsweredIndex = questionIndex;
        const { optionsArea } = getQuizPlayDom();
        const btns = Array.from(optionsArea?.querySelectorAll?.('.quiz-opt-btn') || []);
        btns.forEach(b => { b.disabled = true; });
        const selectedBtn = btns[selectedIndex];
        if (!selectedBtn) {
          quizSession.answerPending = false;
          UI.alert('找不到對應的作答按鈕，請重新開始本次題目。', '作答失敗');
          return;
        }

        if (isCorrect) {
          selectedBtn.style.background = 'rgba(0,255,153,0.3)';
          selectedBtn.style.borderColor = 'var(--color-grass)';
          quizSession.score++;

          // 每答對一題：改由 Cloud Function settleStudentReward 統一驗證、結算與入帳
          if (quizSession.mode === 'daily') {
            try {
              const baselineData = quizSession.dailyData
                ? JSON.parse(JSON.stringify(quizSession.dailyData))
                : JSON.parse(JSON.stringify(currentState.studentData || {}));
              const q = quizSession.questions[quizSession.currentIndex] || {};
              const serial = this.normalizeSerial(baselineData.card_seq || baselineData.serial || currentState.currentUid || '000') || '000';
              const eventId = buildRewardEventId('daily_correct', [serial, q.id || q.question || quizSession.currentIndex]);
              const settle = await this.settleRewardViaServer('daily_correct', {
                eventId,
                source: 'daily_quiz',
                questionId: q.id || null,
                question: String(q.question || '').slice(0, 80),
                index: quizSession.currentIndex,
                serial
              });

              if (settle?.ok && settle?.student) {
                const latestData = this.refreshStudentRewardPanel(settle.student, true);
                quizSession.dailyData = latestData;
                currentState.studentData = latestData;
                const { resultDesc: descEl } = getQuizPlayDom();

                if (settle.applied) {
                  const rewardCoins = Number(settle?.reward?.coins) || 0;
                  const rewardXp = Number(settle?.reward?.xp) || 0;
                  quizSession.dailyCoinsEarned = (Number(quizSession.dailyCoinsEarned) || 0) + rewardCoins;
                  quizSession.dailyXpEarned = (Number(quizSession.dailyXpEarned) || 0) + rewardXp;
                  if (descEl) descEl.innerHTML = `<span style="color:var(--color-grass)">本題獎勵已成功存入。</span>`;
                } else {
                  if (descEl) {
                    descEl.innerHTML = `<span style="color:var(--warning)">${settle.message || '本題已判定正確，但本次不再增加獎勵。'}</span>`;
                  }
                }
              } else {
                throw new Error(settle?.message || '後端沒有回傳學生資料');
              }
            } catch (e) {
              console.warn('[daily quest] server settlement failed:', e?.message || e);
              const { resultDesc: descEl } = getQuizPlayDom();
              if (descEl) {
                descEl.innerHTML = `<span style="color:var(--danger)">本題作答已判定正確，但後端結算失敗，請勿重複刷題。</span>`;
              }
              UI.alert('獎勵未存入', `本題已判定正確，但後端 settleStudentReward 沒有成功完成結算，所以重新整理後不會保留。

請確認：
1) 前端已部署本版
2) Cloud Function 已部署為 asia-east1 / settleStudentReward
3) 再通知老師協助處理。`);
            }
          }

        } else {
          selectedBtn.style.background = 'rgba(255,0,85,0.3)';
          selectedBtn.style.borderColor = 'var(--danger)';
          const q = quizSession.questions[quizSession.currentIndex];
          let correctIdx = q.options ? q.options.findIndex(o => o.isCorrect) : -1;
          if (correctIdx !== -1) {
            btns[correctIdx].style.borderColor = 'var(--color-grass)';
            btns[correctIdx].style.color = 'var(--color-grass)';
          }
        }

        this.scheduleQuizAdvance(() => {
          if (quizSession.aborted) return;
          if (expectedToken && quizSession.sessionToken !== expectedToken) return;
          if (Number(quizSession.currentIndex) !== questionIndex) {
            quizSession.answerPending = false;
            return;
          }
          quizSession.answerPending = false;
          quizSession.currentIndex = questionIndex + 1;
          if (quizSession.currentIndex < quizSession.questions.length) this.renderQuizQuestion();
          else this.showQuizResult();
        }, 1000, expectedToken);
      },


      async settleRewardViaServer(type, meta = {}) {
        try {
          await this.ensureStudentAuth();
          const token = String(currentState.currentToken || '').trim();
          if (!token) throw new Error('缺少有效學生 token');
          const call = httpsCallable(functions, 'settleStudentReward');
          const response = await call({
            token,
            type: String(type || '').trim(),
            meta: { ...meta, clientBuild: BUILD_TAG }
          });
          const payload = response?.data || {};
          if (payload?.student) {
            const normalized = this.applyDataMigration(JSON.parse(JSON.stringify(payload.student)));
            currentState.studentData = normalized;
            if (quizSession && quizSession.mode === 'daily') quizSession.dailyData = normalized;
          }
          return payload;
        } catch (e) {
          console.error('[settleRewardViaServer] failed:', e);
          throw e;
        }
      },

      buildBattleRewardEventId(studentData = {}, bossKey = 'boss', monKey = 0) {
        const serial = this.normalizeSerial(studentData?.card_seq || studentData?.serial || currentState.currentUid || '000') || '000';
        const anchor = getBattleResetAnchor(studentData || {}, Date.now());
        return buildRewardEventId('boss_win', [serial, bossKey, monKey, anchor]);
      },

      getBattleRewardDisplay(studentData = {}, settle = null) {
        const data = this.applyDataMigration(JSON.parse(JSON.stringify(studentData || {})));
        const labels = getProfileLabels(data);
        const xpUnit = labels.xp || (isCatProfile(data) ? '成長能量' : '進化能量');
        const attrKey = settle?.reward?.attrKey || getDominantElementFromData(data);
        const attrName = settle?.reward?.attrName || (getProfileAttributeInfo(attrKey, data)?.name || attrKey);
        const coins = Number(settle?.reward?.coins);
        const xp = Number(settle?.reward?.xp);
        return {
          xpUnit,
          attrName,
          coins: Number.isFinite(coins) && coins > 0 ? coins : 5,
          xp: Number.isFinite(xp) && xp > 0 ? xp : 5
        };
      },

      async resolveBattleRecordBase(serial, fallbackData = null) {
        const normalizedSerial = this.normalizeSerial(serial || fallbackData?.card_seq || fallbackData?.serial || currentState.currentUid || '');
        if (normalizedSerial) {
          try {
            const synced = await this.syncStudentMirrorForSerial(normalizedSerial);
            if (synced) return this.applyDataMigration(JSON.parse(JSON.stringify(synced)));
          } catch (syncErr) {
            console.warn('[battle] resolve latest record base failed:', syncErr?.message || syncErr);
          }
        }
        return this.applyDataMigration(JSON.parse(JSON.stringify(fallbackData || currentState.studentData || {})));
      },

      buildBattleOutcomeRecord(dataObj = {}, options = {}) {
        const data = this.applyDataMigration(JSON.parse(JSON.stringify(dataObj || {})));
        const now = Number(options.timestamp) || Date.now();
        const isWin = options.isWin === true;
        const settle = options.settle || null;
        const saveStatus = String(options.saveStatus || '').trim() || 'unknown';
        const eventId = String(options.eventId || '').trim();
        const bossKey = String(options.bossKey || currentState.currentBattleBoss?.id || currentState.currentBattleBoss?.legendaryId || currentState.currentBattleBoss?.name || 'boss').trim();
        const monKey = options.monKey == null ? currentState.selectedBattleMonIndex : options.monKey;
        const display = this.getBattleRewardDisplay(data, settle);
        const labels = getProfileLabels(data);
        data.last_battle_time = now;
        data.today_battle_used = true;
        data.today_battle_date = now;
        data.logs = Array.isArray(data.logs) ? data.logs : [];

        let detail = '';
        let summary = '';
        let result = isWin ? 'win' : 'lose';

        if (isWin) {
          if (settle?.ok && settle?.applied) {
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功結算 +${display.coins}🪙 +${display.xp} 點${display.attrName}${display.xpUnit}`;
            summary = `BOSS 討伐成功，已存入 ${display.coins} 金幣與 ${display.xp} 點${display.attrName}${display.xpUnit}`;
            result = 'win_settled';
          } else if (settle?.ok) {
            const msg = String(settle?.message || '本次沒有新增獎勵。').trim();
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功但未新增獎勵：${msg}`;
            summary = `BOSS 討伐成功，但本次沒有新增獎勵。${msg}`;
            result = 'win_no_reward';
          } else {
            const msg = String(settle?.message || options.errorMessage || '獎勵結算失敗，請稍後重整確認是否已入帳。').trim();
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功但結算失敗：${msg}`;
            summary = `BOSS 討伐成功，但獎勵結算失敗。${msg}`;
            result = 'win_settle_failed';
          }
        } else {
          detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 失敗`;
          summary = labels.battleConsume || '討伐失敗，本日挑戰機會已消耗。';
          result = 'lose';
        }

        data.battle_result = result;
        data.battle_summary = summary;
        if (isWin) {
          data.boss_win_total = Math.max(0, Math.floor(Number(data.boss_win_total) || 0)) + 1;
        }
        data.logs.push({
          timestamp: now,
          action_type: 'battle',
          detail,
          battle_result: result,
          battle_save_status: saveStatus,
          reward_event_id: eventId || null,
          boss_id: bossKey || null,
          battle_mon_index: monKey
        });
        return this.processEvolution(data);
      },

      async showQuizResult() {
        if (quizSession.aborted) return;
        if (quizSession.resultShown === true) return;
        quizSession.resultShown = true;
        quizSession.answerPending = false;
        this.clearQuizAdvanceTimer();
        UI.hide('quizPlayArea');
        UI.show('quizResultArea');

        const maxQ = quizSession.questions.length;
        const {
          scoreText: scoreTextEl,
          resultDesc: resultDescEl,
          rewardArea,
          rewardAttr: rewardSelectEl
        } = getQuizPlayDom();
        if (!scoreTextEl || !resultDescEl) {
          this.abortQuizSession('result_missing_dom');
          UI.alert('找不到修練結算面板，請重新整理頁面後再試。', '系統異常');
          return;
        }
        scoreTextEl.innerText = `${quizSession.score} / ${maxQ}`;

        if (quizSession.mode === 'daily') {
          const earned = Number(quizSession.score) || 0;
          const labels = getProfileLabels(currentState.studentData);
          const xpUnit = labels.xp || (isCatProfile(currentState.studentData) ? '成長能量' : '進化能量');
          const totalCoins = Number(currentState.studentData?.coins) || 0;
          const totalXp = Number(currentState.studentData?.totalXP) || 0;
          const remainingAfter = getTodayDailyRemaining(currentState.studentData);
          resultDescEl.innerText =
            fillProfileTemplate(labels.dailyQuestSummary, { earned }) + `
（每日最多 10 題；目前尚可獲得 ${remainingAfter} 題獎勵，歸零後請等待中午 12:00 重置）`;
          scoreTextEl.style.color = earned > 0 ? 'var(--color-grass)' : 'var(--danger)';
          if (rewardArea) {
            rewardArea.innerHTML = `本次獲得：<b>${Number(quizSession.dailyCoinsEarned) || 0}</b> 金幣、<b>${Number(quizSession.dailyXpEarned) || 0}</b> 點${xpUnit}<br>目前持有：<b>${totalCoins}</b> 金幣　｜　目前${xpUnit}：<b>${totalXp}</b>`;
          }
          UI.show('quizRewardArea');
          UI.show('quizCloseBtn');
          UI.updateDailyQuestTimer();
          await this.commitDailyCorrectTotalForSession(Number(quizSession.score) || 0);
          return;
        }

        // 兼容：若未來有其他模式沿用此流程
        if (quizSession.score === maxQ && maxQ > 0) {
          resultDescEl.innerText = "滿分通關！獲得 2 點經驗能量。";
          scoreTextEl.style.color = 'var(--cyan)';
          if (rewardSelectEl) {
            rewardSelectEl.innerHTML = '';
            for (const [key, info] of Object.entries(CONSTANTS.ATTRIBUTES)) rewardSelectEl.innerHTML += `<option value="${key}">${info.icon} ${info.name} 屬性</option>`;
          }
          UI.show('quizRewardArea');
          UI.hide('quizCloseBtn');
        } else {
          resultDescEl.innerText = "修練結束！必須「全數答對」才能獲獎。";
          scoreTextEl.style.color = 'var(--danger)';
          UI.hide('quizRewardArea');
          UI.show('quizCloseBtn');
          this.updatePracticeCooldown();
        }
      },

      async commitDailyCorrectTotalForSession(correctCount = 0) {
        if (quizSession.mode !== 'daily') return currentState.studentData || null;
        const delta = Math.max(0, Math.floor(Number(correctCount) || 0));
        if (delta < 1) return currentState.studentData || null;
        if (quizSession.dailyLifetimeMetricsCommitted === true) return currentState.studentData || null;
        quizSession.dailyLifetimeMetricsCommitted = true;
        try {
          const latest = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || quizSession.dailyData || {})));
          latest.daily_correct_total = Math.max(0, Math.floor(Number(latest.daily_correct_total) || 0)) + delta;
          const saved = await this.saveToDB(latest);
          const refreshed = this.refreshStudentRewardPanel(saved || latest, true);
          quizSession.dailyData = JSON.parse(JSON.stringify(refreshed || latest));
          return refreshed || latest;
        } catch (e) {
          console.warn('[daily quest] commitDailyCorrectTotalForSession failed:', e?.message || e);
          quizSession.dailyLifetimeMetricsCommitted = false;
          return currentState.studentData || null;
        }
      },

      async claimQuizReward() {

        const { rewardAttr: rewardAttrEl } = getQuizPlayDom();
        if (!rewardAttrEl) {
          UI.alert('找不到修練獎勵欄位，請重新開始本次修練。', '系統異常');
          return;
        }
        const attr = rewardAttrEl.value;
        let data = JSON.parse(JSON.stringify(currentState.studentData || {}));
        data.totalXP = Number(data.totalXP) || 0;
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        data.totalXP += 2; addAttributeXP(data, attr, 2); data.last_practice_time = Date.now();
        const attrName = CONSTANTS.ATTRIBUTES?.[attr]?.name || attr || '未知屬性';
        data.logs.push({ timestamp: Date.now(), action_type: "quest", points_added: 2, detail: `[修練] 滿分獲得 2XP (${attrName})` });
        
        if (!data.attr_event_counts) data.attr_event_counts = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
        if (attr && data.attr_event_counts[attr] != null) data.attr_event_counts[attr] = (Number(data.attr_event_counts[attr]) || 0) + 1;
data = this.processEvolution(data); await this.saveToDB(data); UI.hideModal('quizPlayModal'); UI.toast('🔋 能量注入！'); UI.updateDailyQuestTimer();
      },
      
      async updatePracticeCooldown() {
        let data = JSON.parse(JSON.stringify(currentState.studentData || {}));
        data.last_practice_time = Date.now();
        const savedData = await this.saveToDB(data);
        this.refreshStudentRewardPanel(savedData || currentState.studentData || data, true);
        UI.updateDailyQuestTimer();
      },
      
      buildStudentWritablePayload(...args) { return studentAccessApi.buildStudentWritablePayload(...args); },

      _saveQueues: new Map(),
      async enqueueSerialSave(serial, work) {
        const key = this.normalizeSerial(serial) || String(serial || '');
        const prev = this._saveQueues.get(key) || Promise.resolve();
        const next = prev.catch(() => {}).then(() => work());
        this._saveQueues.set(key, next);
        try {
          return await next;
        } finally {
          if (this._saveQueues.get(key) === next) this._saveQueues.delete(key);
        }
      },


      scheduleBackgroundTask(label, work, { logger = console } = {}) {
        const runner = typeof work === 'function' ? work : null;
        if (!runner) return Promise.resolve(null);
        return Promise.resolve()
          .then(() => runner())
          .catch((err) => {
            try { logger.warn(`[background-task] ${label} failed:`, err?.message || err); } catch (_) {}
            return null;
          });
      },

      isFastAdminSaveMode(...args) { return studentAccessApi.isFastAdminSaveMode(...args); },
      async saveToDB(...args) { return studentAccessApi.saveToDB(...args); },



async loadLegendaryAdmin() { return legendaryApi.loadLegendaryAdmin.apply(this, arguments); },

      async publishLegendary() { return legendaryApi.publishLegendary.apply(this, arguments); },

      async deleteLegendary(docId) { return legendaryApi.deleteLegendary.apply(this, arguments); },

      async loadActiveLegendariesForStudent() { return legendaryApi.loadActiveLegendariesForStudent.apply(this, arguments); },

      async exchangeLegendary(docId, reqAttrFromUI, reqCountFromUI) { return legendaryApi.exchangeLegendary.apply(this, arguments); },

      startBattleChallenge() { return battleApi.startBattleChallenge.apply(this, arguments); },
      attackBoss() { return battleApi.startBattleChallenge.apply(this, arguments); },
      selectBattleMon(idx) { return battleApi.selectBattleMon.apply(this, arguments); },
      async confirmBattleSelection() { return battleApi.confirmBattleSelection.apply(this, arguments); },
      async handleBattleQuizAnswer(isCorrect) { return battleApi.handleBattleQuizAnswer.apply(this, arguments); },
      prepareBattleArena() { return battleApi.prepareBattleArena.apply(this, arguments); },
      rollDice() { return battleApi.rollDice.apply(this, arguments); },
      showBattleSettlement() { return battleApi.showBattleSettlement.apply(this, arguments); },
      backToBattleResult() { return battleApi.backToBattleResult.apply(this, arguments); },
      closeBattleArenaAndRefresh() { return battleApi.closeBattleArenaAndRefresh.apply(this, arguments); },
      async endBattle(isWin) { return battleApi.endBattle.apply(this, arguments); },
      async checkBattleTowerStatus(studentData) { return battleApi.checkBattleTowerStatus.apply(this, arguments); },
      async updateBattleTowerStatus(studentData) { return battleApi.updateBattleTowerStatus.apply(this, arguments); },
      async resetDailyAndBattleChallenges() { return battleApi.resetDailyAndBattleChallenges.apply(this, arguments); },
      async populateBattleQuizOptions(audienceKey = 'default') { return battleApi.populateBattleQuizOptions.apply(this, arguments); },
      updateBattleTowerAdminAudienceView(rawDoc = {}) { return battleApi.updateBattleTowerAdminAudienceView.apply(this, arguments); },
      async openBattleTowerSetup() { return battleApi.openBattleTowerSetup.apply(this, arguments); },
      async publishBattleBoss() { return battleApi.publishBattleBoss.apply(this, arguments); },
      async clearBattleBoss() { return battleApi.clearBattleBoss.apply(this, arguments); },
      openDisplayTeamEditor() { return studentApi.openDisplayTeamEditor.apply(this, arguments); },
      toggleDisplayTeamItem() { return studentApi.toggleDisplayTeamItem.apply(this, arguments); },
      async saveDisplayTeam() { return studentApi.saveDisplayTeam.apply(this, arguments); }
    };

    // UI 由 Phase 14 façade 於模組掛載完成後統一對外暴露。
    const forceOpenCardForge = createForceOpenCardForgeBridge({
      currentState,
      UI,
      getApp: () => App
    });


    // @phase15.5.111-split:mount-evolution
    evolutionApi = createEvolutionModule({
      CONSTANTS,
      ELEMENT_KEYS,
      getDominantElementFromData: (...args) => App.getDominantElementFromData(...args),
      getDragonVisual: (...args) => getDragonVisual(...args)
    });

    // @phase10-split:mount-teacher-actions
    teacherActionsApi = createTeacherActionsModule({
      CONSTANTS, ELEMENT_KEYS, auth, db, doc, getDoc, buildRewardEventId, applyRewardEventToData, getProfileLabels, addAttributeXP,
      saveToDB: delegatedSaveToDB,
      processEvolution: (...args) => App.processEvolution(...args),
      isCurrentUserAdmin: (...args) => App.isCurrentUserAdmin(...args),
      normalizeSerial: (...args) => App.normalizeSerial(...args),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      refreshStudentIdentityLabels: (...args) => App.refreshStudentIdentityLabels(...args),
      refreshStudentRewardPanel: (...args) => App.refreshStudentRewardPanel(...args),
      startWebNfc: (...args) => App.startWebNfc(...args),
      backToDashboard: (...args) => App.backToDashboard(...args),
      validateEvolutionTree: (...args) => App.validateEvolutionTree(...args),
      getActionCardPayload: (...args) => studentAccessApi?.getActionCardPayload(...args),
      bindPendingForgeActionCard: (...args) => studentAccessApi?.bindPendingForgeActionCard(...args),
      resolveStudentRecordFromScanKey: (...args) => studentAccessApi?.resolveStudentRecordFromScanKey(...args)
    });

    // @phase11-split:mount-batch
    batchApi = createBatchModule({
      db, getDocs, collection, COLLECTION_NAME, CONSTANTS, addAttributeXP, getProfileLabels,
      currentState, batchState, UI,
      startWebNfc: (...args) => App.startWebNfc(...args),
      saveToDB: delegatedSaveToDB,
      syncStudentMirrorForSerial: (...args) => App.syncStudentMirrorForSerial(...args),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      getActiveTokenForSerial: (...args) => App.getActiveTokenForSerial(...args),
      checkDeathTrigger: (...args) => App.checkDeathTrigger(...args),
      processEvolution: (...args) => App.processEvolution(...args),
      normalizeSerial: (...args) => App.normalizeSerial(...args),
      getRateFromRankIndex: (...args) => App.getRateFromRankIndex(...args),
      getBulkProgressDom: (...args) => getBulkProgressDom(...args),
      getBatchModeDom: (...args) => getBatchModeDom(...args)
    });

    // @phase12-split:mount-battle
    battleApi = createBattleModule({
      db, doc, getDoc, getDocs, collection, writeBatch, setDoc, deleteDoc,
      CONSTANTS, TYPE_INFO, COLLECTION_NAME, STUDENT_PAGE_COLLECTION,
      hasBattleAttemptRemaining, buildBattleTeamForStudent, getDragonVisual, splitBattleVisualRef,
      buildCollectionDisplayItem, getProfileAttributeInfo, getBattleMonDiceCount, getBattleStageLabel,
      getBattleMonStage, isDirectVisualSource, hydrateStorageImages, getStudentGradeInfo,
      isQuizEnabled, quizMatchesStudentGrade, isCatProfile, getProfileLabels, normalizeBossDiceCount,
      createBattleDiceFaces, applyProfileStaticTexts, fillProfileTemplate, getBattleResetAnchor, getDailyResetAnchor,
      formatCountdown, getNextNoonTimestamp, getBattleBossConfigForStudent, getBattleAudienceOptions,
      getBattleBossConfigForAudience, normalizeBattleTowerDoc, getCatBossVisualByType, __updateLegendarySelectPreview,
      normalizeSerial: (...args) => App.normalizeSerial(...args),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      saveToDB: delegatedSaveToDB,
      settleRewardViaServer: (...args) => App.settleRewardViaServer(...args),
      buildBattleRewardEventId: (...args) => App.buildBattleRewardEventId(...args),
      resolveBattleRecordBase: (...args) => App.resolveBattleRecordBase(...args),
      buildBattleOutcomeRecord: (...args) => App.buildBattleOutcomeRecord(...args),
      getBattleRewardDisplay: (...args) => App.getBattleRewardDisplay(...args),
      refreshStudentRewardPanel: (...args) => App.refreshStudentRewardPanel(...args),
      isCurrentUserAdmin: (...args) => App.isCurrentUserAdmin(...args),
      ensureStudentDataReady: (...args) => App.ensureStudentDataReady(...args),
      warmStudentQuizPool: (...args) => App.warmStudentQuizPool(...args),
      loadBattleTowerConfigDoc: (...args) => App.loadBattleTowerConfigDoc(...args),
      listBattleGatekeeperQuestions: (...args) => App.listBattleGatekeeperQuestions(...args),
      pickBattleGatekeeperQuestion: (...args) => App.pickBattleGatekeeperQuestion(...args),
      loadBattleGatekeeperQuestion: (...args) => App.loadBattleGatekeeperQuestion(...args),
      saveBattleTowerAudienceConfig: (...args) => App.saveBattleTowerAudienceConfig(...args),
      clearBattleTowerAudienceConfig: (...args) => App.clearBattleTowerAudienceConfig(...args),
      renderQuizQuestion: (...args) => App.renderQuizQuestion(...args),
      beginQuizSession: (...args) => App.beginQuizSession(...args)
    });


    // @phase13-split:mount-shop-quiz-ranking-content-zones
    shopApi = createShopModule({
      SHOP_COLLECTION, SHOP_PUBLIC_COLLECTION, COLLECTION_NAME, CONSTANTS, getContentProfile,
      normalizeSerial: (...args) => App.normalizeSerial(...args),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      resolveVisualMeta: (...args) => App.resolveVisualMeta(...args),
      saveToDB: delegatedSaveToDB,
      processEvolution: (...args) => App.processEvolution(...args),
      isCatProfile, addAttributeXP,
      hydrateStorageImages,
      getStudentShopShowcaseDom,
      bindStudentShopRailControls,
      updateStudentShopRailButtons,
      teacherActionsApi,
      getDominantElementFromData: (...args) => App.getDominantElementFromData(...args)
    });
    quizApi = createQuizModule({
      isQuizEnabled, quizMatchesStudentGrade, getProfileLabels, isCatProfile, buildRewardEventId, formatLocalDateKey,
      getQuizManagerDom: (...args) => getQuizManagerDom(...args),
      resolveQuizImageMeta: (...args) => App.resolveQuizImageMeta(...args),
      updateQuizImagePreview: (...args) => App.updateQuizImagePreview(...args),
      downloadCsvFile, downloadTextFile,
      scheduleQuizPoolSummaryRefresh: (...args) => App.scheduleQuizPoolSummaryRefresh(...args),
      scheduleBackgroundTask: (...args) => App.scheduleBackgroundTask(...args),
      getStudentGradeInfo,
      QUIZ_POOL_COLLECTION
    });
    const legacyUpdateQuizFilterState = typeof App.updateQuizFilterState === 'function' ? App.updateQuizFilterState.bind(App) : null;
    const legacyGetFilteredQuizzes = typeof App.getFilteredQuizzes === 'function' ? App.getFilteredQuizzes.bind(App) : null;
    const legacyToggleAllQuizSelections = typeof App.toggleAllQuizSelections === 'function' ? App.toggleAllQuizSelections.bind(App) : null;
    const legacyRenderQuizBankList = typeof App.renderQuizBankList === 'function' ? App.renderQuizBankList.bind(App) : null;
    quizApi.updateQuizFilterStateLegacy = (...args) => legacyUpdateQuizFilterState ? legacyUpdateQuizFilterState(...args) : void 0;
    quizApi.getFilteredQuizzesLegacy = (...args) => legacyGetFilteredQuizzes ? legacyGetFilteredQuizzes(...args) : [];
    quizApi.toggleAllQuizSelectionsLegacy = (...args) => legacyToggleAllQuizSelections ? legacyToggleAllQuizSelections(...args) : void 0;
    quizApi.renderQuizBankListLegacy = (...args) => legacyRenderQuizBankList ? legacyRenderQuizBankList(...args) : void 0;
    rankingApi = createRankingModule({ COLLECTION_NAME, LEADERBOARD_COLLECTION, CONSTANTS, hydrateStorageImages, applyDataMigration: (...args) => App.applyDataMigration(...args), computeTrainerProgress: (...args) => App.computeTrainerProgress(...args), normalizeSerial: (...args) => App.normalizeSerial(...args), resolveVisualMeta: (...args) => App.resolveVisualMeta(...args), getRankingDom });
    legendaryApi = createLegendaryModule({
      COLLECTION_NAME, STUDENT_PAGE_COLLECTION, CONSTANTS, getLegendaryAdminDom, getLegendaryStudentDom,
      getProfileLabels, getProfileAttributeInfo, isCatProfile, fillProfileTemplate,
      setTeacherAvatar: (el) => setImgFromFileBaseName(el, 'teacher', { shadowColor: 'rgba(255,183,0,0.55)' }),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      saveToDB: delegatedSaveToDB
    });
    contentProfileApi = createContentProfileModule({ COLLECTION_NAME, STUDENT_PAGE_COLLECTION, CONSTANTS, normalizeSerial: (...args) => App.normalizeSerial(...args), getActiveTokenForSerial: (...args) => App.getActiveTokenForSerial(...args), applyDataMigration: (...args) => App.applyDataMigration(...args), saveToDB: delegatedSaveToDB, refreshStudentRewardPanel: (...args) => App.refreshStudentRewardPanel(...args) });
    zonesApi = createZonesModule({
      COLLECTION_NAME, SUPPORT_ZONE_COLLECTION, SCIENCE_ZONE_COLLECTION, CONSTANTS, ELEMENT_KEYS, addAttributeXP,
      formatLocalDateKey, formatLocalDateTime, downloadCsvFile,
      getRequestedAdminPanel: (...args) => App.getRequestedAdminPanel(...args),
      startWebNfc: (...args) => App.startWebNfc(...args),
      stopWebNfc: (...args) => App.stopWebNfc(...args),
      applyDataMigration: (...args) => App.applyDataMigration(...args),
      processEvolution: (...args) => App.processEvolution(...args),
      saveToDB: delegatedSaveToDB
    });

    studentAccessApi = createStudentAccessModule({
      db, auth, collection, doc, getDoc, getDocs, setDoc, writeBatch, query, where, limit,
      UI, currentState, CONSTANTS, COLLECTION_NAME, TOKEN_COLLECTION, STUDENT_PAGE_COLLECTION,
      getAccountMgmtDom: (...args) => getAccountMgmtDom(...args),
      getRegistrationDom: (...args) => getRegistrationDom(...args),
      getBulkProgressDom: (...args) => getBulkProgressDom(...args),
      getBulkSerialRange: (...args) => App.getBulkSerialRange(...args),
      hasWebNfcSupport, createNdefReaderOrThrow, App
    });

    // @phase9-split:mount-auth-student
    authApi = createAuthModule({
      auth, db, doc, getDoc, signInWithEmailAndPassword, signInAnonymously, signOut,
      UI, currentState, BUILD_TAG, firebaseConfig, __setBootStatus, __bindLoginFallback,
      openRequestedAdminPanel: (...args) => App.openRequestedAdminPanel(...args),
      lockStudentAccess: (...args) => App.lockStudentAccess(...args),
      getAuthLoginDom: (...args) => getAuthLoginDom(...args),
      getAuthViewsDom: (...args) => getAuthViewsDom(...args),
      getAdminDiagDom: (...args) => getAdminDiagDom(...args),
      documentRef: globalThis.document || null,
      storage: globalThis.localStorage || null
    });
    const ChartLib = window.Chart || globalThis.Chart || null;
    studentApi = createStudentModule({
      db, doc, getDoc, onSnapshot, UI, currentState, radarChartInstances, CONSTANTS,
      COLLECTION_NAME, STUDENT_PAGE_COLLECTION, Chart: ChartLib, App,
      getProfileLabels, getProfileDebuffInfo, getProfileAttributeInfo, getProfileVisual,
      isCatProfile, colorToRgba, setImgFromFileBaseName, buildCollectionDisplayItem,
      hydrateStorageImages, getRadarLabelsForData, applyProfileStaticTexts, syncProfileForm,
      getDisplayTeamDom,
      getStudentDisplayDom: (...args) => getStudentDisplayDom(...args),
      getStudentIdentityDom: (...args) => getStudentIdentityDom(...args),
      getStudentViewDom: (...args) => getStudentViewDom(...args),
      getStudentShopStatusDom: (...args) => getStudentShopStatusDom(...args),
      documentRef: globalThis.document || null
    });


// @phase14-split:mount-app-facade
const facadeMountReport = mountAppFacade({
  App,
  UI,
  apis: {
    authApi,
    studentApi,
    teacherActionsApi,
    batchApi,
    battleApi,
    shopApi,
    quizApi,
    rankingApi,
    contentProfileApi,
    zonesApi
  },
  debugFlags: DEBUG_FLAGS
});

App.forceOpenCardForge = function forceOpenCardForgeFacade(...args) {
  return forceOpenCardForge(...args);
};

function delegatedSaveToDB(...args) { return App.saveToDB(...args); }

const __PHASE1_READY_GUARD_METHODS = Object.freeze([
  ['enterBatchMode', '批量模式'],
  ['enterScanMode', '感應掃描'],
  ['openAccountMgmt', '帳號管理'],
  ['amLookupSerial', '卡序查詢'],
  ['amLoadReissue', '卡片補發'],
  ['amStartReissue', '卡片補發'],
  ['loadQuizBank', '題庫管理'],
  ['openSupportZone', '文昌專區'],
  ['openScienceZone', '靈樞專區'],
  ['openShopAdmin', '商城管理'],
  ['loadLegendaryAdmin', '傳說異獸管理'],
  ['openBattleTowerSetup', 'BOSS 管理'],
  ['openCardForge', '鑄造道具卡'],
  ['startCardForge', '鑄造道具卡'],
  ['prepareAction', '老師加分'],
  ['prepareActionFromButton', '老師加分'],
  ['commitAction', '老師加分'],
  ['forceDebuff', '狀態調整'],
  ['startWebNfc', 'NFC 掃描']
]);

const __applyPhase1ReadyGuards = () => {
  const report = { guarded: [], missing: [] };

  App.isSystemReady = function isSystemReady() {
    return Boolean(__bootState?.ready);
  };
  App.getSystemReadyState = function getSystemReadyState() {
    return Object.freeze({
      stage: __bootState?.stage || 'unknown',
      detail: __bootState?.detail || '',
      ready: Boolean(__bootState?.ready),
      error: __bootState?.error || ''
    });
  };
  App.ensureSystemReady = function ensureSystemReady(featureLabel = '此功能', options = {}) {
    return __ensureFeatureReady(featureLabel, options);
  };

  for (const [methodName, featureLabel] of __PHASE1_READY_GUARD_METHODS) {
    if (__wrapAppMethodWithReadyGuard(methodName, featureLabel)) report.guarded.push(methodName);
    else report.missing.push(methodName);
  }

  try {
    Object.defineProperty(App, '__phase1ReadyGuardReport', {
      value: Object.freeze({ guarded: Object.freeze(report.guarded.slice()), missing: Object.freeze(report.missing.slice()) }),
      configurable: true,
      enumerable: false,
      writable: false
    });
  } catch (_) {}

  try {
    const diagBase = (window.__BOOT_DIAG && typeof window.__BOOT_DIAG === 'object') ? window.__BOOT_DIAG : {};
    window.__BOOT_DIAG = {
      ...diagBase,
      phase1ReadyGuardReport: { guarded: report.guarded.slice(), missing: report.missing.slice() }
    };
  } catch (_) {}
};

__applyPhase1ReadyGuards();

exposeGlobalFacade({ App, UI });
const globalSurfaceInventory = buildGlobalSurfaceInventory({ App, UI });
attachSurfaceMetadata({ App, UI, inventory: globalSurfaceInventory });
logSurfaceWarnings(globalSurfaceInventory, { debugFlags: DEBUG_FLAGS });
try {
  const diagBase = (window.__BOOT_DIAG && typeof window.__BOOT_DIAG === 'object') ? window.__BOOT_DIAG : {};
  window.__BOOT_DIAG = {
    ...diagBase,
    facadeSurfaceSummary: {
      appMissingRequired: globalSurfaceInventory?.app?.required?.missing?.slice?.() || [],
      appMissingTransitional: globalSurfaceInventory?.app?.transitional?.missing?.slice?.() || [],
      uiMissingRequired: globalSurfaceInventory?.ui?.required?.missing?.slice?.() || [],
      htmlAppMissingDirect: globalSurfaceInventory?.html?.appDirect?.missing?.slice?.() || [],
      htmlUiMissingDirect: globalSurfaceInventory?.html?.uiDirect?.missing?.slice?.() || [],
      htmlAppOutsidePolicy: globalSurfaceInventory?.html?.policyCoverage?.appOutsidePolicy?.slice?.() || [],
      htmlUiOutsidePolicy: globalSurfaceInventory?.html?.policyCoverage?.uiOutsidePolicy?.slice?.() || []
    }
  };
} catch (_) {}
try {
  document.documentElement.dataset.surfaceOk = (
    !(globalSurfaceInventory?.app?.required?.missing?.length) &&
    !(globalSurfaceInventory?.ui?.required?.missing?.length) &&
    !(globalSurfaceInventory?.html?.appDirect?.missing?.length) &&
    !(globalSurfaceInventory?.html?.uiDirect?.missing?.length) &&
    !(globalSurfaceInventory?.html?.policyCoverage?.appOutsidePolicy?.length) &&
    !(globalSurfaceInventory?.html?.policyCoverage?.uiOutsidePolicy?.length)
  ) ? '1' : '0';
} catch (_) {}
const systemNamespace = buildSystemNamespace({
  APP_CONFIG,
  BUILD_TAG,
  facadeMountReport,
  globalSurfaceInventory,
  clearAssetUrlCache: __clearAssetUrlCache
});

const globalBridgeReport = exposeLegacyGlobals({
  App,
  UI,
  DEBUG_FLAGS,
  RUNTIME_ENV,
  clearAssetUrlCache: __clearAssetUrlCache,
  forceOpenCardForge,
  systemNamespace
});

    const __bootState = {
      stage: 'script-loaded',
      detail: '模組腳本已載入，等待初始化',
      error: '',
      ready: false,
      fallbackLoginBound: false
    };

    function __syncBootDiagnostics(extra = null) {
      try {
        const diagBase = (window.__BOOT_DIAG && typeof window.__BOOT_DIAG === 'object') ? window.__BOOT_DIAG : {};
        const nextDiag = {
          ...diagBase,
          mainEntryStage: __bootState.stage,
          mainEntryDetail: __bootState.detail,
          mainEntryReady: Boolean(__bootState.ready),
          mainEntryError: __bootState.error || ''
        };
        if (extra && typeof extra === 'object') Object.assign(nextDiag, extra);
        window.__BOOT_DIAG = nextDiag;
      } catch (_) {}
      try {
        document.documentElement.dataset.appReady = __bootState.ready ? '1' : '0';
        document.documentElement.dataset.appStage = String(__bootState.stage || 'unknown');
      } catch (_) {}
    }

    function __notifyFeaturePending(featureLabel = '此功能', options = {}) {
      const detail = __bootState.error
        ? `系統初始化尚未完成（${__bootState.stage}），目前有錯誤：${__bootState.error}`
        : `系統仍在初始化中（${__bootState.stage}），請稍候再試。`;
      const title = options.title || '系統尚未就緒';
      const message = options.message || `${featureLabel} 暫時無法使用。\n\n${detail}`;
      try {
        if (options.alert) UI.alert(message, title);
        else UI.toast(`⏳ ${featureLabel}：系統仍在初始化中`);
      } catch (_) {}
      __setBootStatus('waiting-ready', `${featureLabel}：等待初始化完成`);
      return false;
    }

    function __ensureFeatureReady(featureLabel = '此功能', options = {}) {
      if (__bootState.ready) return true;
      return __notifyFeaturePending(featureLabel, options);
    }

    function __wrapAppMethodWithReadyGuard(methodName, featureLabel, options = {}) {
      const original = App?.[methodName];
      if (typeof original !== 'function') return false;
      if (original.__readyGuardWrapped) return true;
      const wrapped = function phase1ReadyGuardedMethod(...args) {
        if (!__ensureFeatureReady(featureLabel, options)) return false;
        return original.apply(this, args);
      };
      Object.defineProperty(wrapped, '__readyGuardWrapped', { value: true, configurable: false, enumerable: false, writable: false });
      Object.defineProperty(wrapped, '__readyGuardOriginal', { value: original, configurable: false, enumerable: false, writable: false });
      App[methodName] = wrapped;
      return true;
    }

    __syncBootDiagnostics();

    // @debug-removable:boot-panel
    const __renderBootStatus = () => {
      __syncBootDiagnostics();
      const panel = DomBridge.get('bootStatusPanel');
      if (!panel) return;
      if (!DEBUG_FLAGS.showBootPanel) {
        panel.style.display = 'none';
        return;
      }
      panel.style.display = '';
      const lines = [];
      lines.push(`啟動階段：${__bootState.stage}`);
      if (__bootState.detail) lines.push(`狀態：${__bootState.detail}`);
      if (__bootState.error) lines.push(`錯誤：${__bootState.error}`);
      if (DEBUG_FLAGS.enableVerboseBootStatus && !__bootState.ready && window.location.protocol === 'file:') {
        lines.push('提醒：若使用分檔/模組版，請改用本機伺服器開啟，不要直接雙擊 HTML。');
      }
      panel.textContent = lines.join('\n');
      panel.style.borderColor = __bootState.error ? 'rgba(255,107,107,0.45)' : 'rgba(0,229,255,0.18)';
      panel.style.color = __bootState.error ? '#ffd6d6' : 'var(--text-muted)';
      panel.style.background = __bootState.error ? 'rgba(66,12,12,0.72)' : 'rgba(7,20,33,0.72)';
    };

    function __setBootStatus(stage, detail = '') {
      __bootState.stage = stage || __bootState.stage;
      if (typeof detail === 'string') __bootState.detail = detail;
      __renderBootStatus();
    }

    function __showBootFailure(error, stage = '') {
      const message = (error && (error.stack || error.message)) ? (error.stack || error.message) : String(error || '未知錯誤');
      __bootState.error = message;
      __setBootStatus(stage || 'failed', '初始化未完成');
      console.error('[boot]', stage || 'failed', error);
      __syncBootDiagnostics({ mainEntryFailureStage: stage || 'failed' });
    }

    // @debug-removable:fallback-login
    function __bindLoginFallback(appRef) {
      if (!DEBUG_FLAGS.enableFallbackLogin) return false;
      if (__bootState.fallbackLoginBound) return true;
      const btn = DomBridge.get('loginBtn');
      const emailInput = DomBridge.get('adminEmail');
      const pwdInput = DomBridge.get('adminPassword');
      if (!btn || !emailInput || !pwdInput) {
        __setBootStatus('login-controls-missing', '找不到登入欄位，請檢查 loginView DOM');
        return false;
      }

      const enterHandler = (e) => {
        if (e.key === 'Enter') btn.click();
      };
      emailInput.addEventListener('keypress', enterHandler);
      pwdInput.addEventListener('keypress', enterHandler);

      btn.addEventListener('click', async (e) => {
        if (__bootState.ready || btn.dataset.loginBound === 'app') return;
        e.preventDefault();
        const email = String(emailInput.value || '').trim();
        const pwd = String(pwdInput.value || '');
        if (!email || !pwd) {
          UI.alert('系統尚未完成初始化，且目前尚未輸入管理者 Email / 密碼。', '尚未就緒');
          __setBootStatus('fallback-login-blocked', '等待初始化完成，或先檢查上方錯誤訊息');
          return;
        }
        const originalText = btn.innerText;
        btn.disabled = true;
        btn.innerText = 'BOOT RECOVERY...';
        try {
          __setBootStatus('fallback-login', '主程式初始化未完成，改用保底登入流程');
          await signInWithEmailAndPassword(auth, email, pwd);
          try { localStorage.setItem('adminEmail', email); } catch (_) {}
          if (auth.currentUser) {
            try { await auth.currentUser.getIdToken(true); } catch (_) {}
          }
          const ok = appRef && appRef.isCurrentUserAdmin ? await appRef.isCurrentUserAdmin() : false;
          currentState.isAdmin = ok;
          if (!ok) {
            const uid = auth.currentUser?.uid || '(unknown uid)';
            await signOut(auth);
            UI.alert(`此帳號已成功登入，但目前仍未通過管理者驗證。

目前登入 UID：${uid}

請檢查 custom claim 或 /admins/${uid} 是否存在。`, '權限不足');
            __setBootStatus('fallback-login-denied', '帳號已登入，但尚未具備管理權限');
            return;
          }
          UI.hide('loginView');
          UI.show('dashboardView');
          UI.toast('ACCESS GRANTED (RECOVERY MODE)');
          if (appRef && appRef.openRequestedAdminPanel) await appRef.openRequestedAdminPanel();
          if (appRef && appRef.resetSessionIdleTimer) appRef.resetSessionIdleTimer();
          pwdInput.value = '';
          __setBootStatus('fallback-login-success', '已透過保底登入流程進入老師端');
        } catch (err) {
          __showBootFailure(err, 'fallback-login');
          UI.alert(`登入失敗。

目前系統尚未完全初始化，請先查看登入按鈕下方的啟動訊息。`, '登入失敗');
        } finally {
          btn.disabled = false;
          btn.innerText = originalText;
        }
      });

      __bootState.fallbackLoginBound = true;
      __setBootStatus('fallback-login-bound', '已建立登入保底機制');
      return true;
    }

    // @debug-removable:boot-error-capture
    if (DEBUG_FLAGS.captureGlobalBootErrors) {
      window.addEventListener('error', (event) => {
        if (__bootState.ready) return;
        __showBootFailure(event?.error || event?.message || '未知錯誤', `window.error:${event?.filename || 'inline'}`);
      });
      window.addEventListener('unhandledrejection', (event) => {
        if (__bootState.ready) return;
        __showBootFailure(event?.reason || 'Promise rejection', 'unhandledrejection');
      });
    }

    let __shanHaiBootstrapped = false;
    const __bootstrapShanHaiApp = async () => {
      if (__shanHaiBootstrapped) return;
      __shanHaiBootstrapped = true;
      __setBootStatus('bootstrap-start', '準備啟動系統');
      if (DEBUG_FLAGS.enableFallbackLogin) __bindLoginFallback(App);
      if (DEBUG_FLAGS.enableVerboseBootStatus && window.location.protocol === 'file:') {
        __setBootStatus('bootstrap-start', '目前以 file:// 開啟；若是分檔版請改用本機伺服器');
      }
      try {
        await App.init();
      } catch (e) {
        __showBootFailure(e, __bootState.stage || 'bootstrap');
        try {
          UI.alert(`初始化失敗: ${(e && e.message) ? e.message : e}

請先查看登入按鈕下方的啟動訊息，以確認卡在哪個階段。`, '系統通知');
        } catch (_) {}
      }
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', __bootstrapShanHaiApp, { once: true });
    } else {
      __bootstrapShanHaiApp();
    }
    window.addEventListener('load', __bootstrapShanHaiApp, { once: true });
// ENTRY_TAIL_SENTINEL: phase15phase129finalreleasegovernancereaudit-tail
