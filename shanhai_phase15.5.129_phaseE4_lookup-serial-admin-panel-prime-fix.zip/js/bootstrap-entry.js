const BOOT_ID = 'phase15phase129finalreleasegovernancereaudit';
const statusId = 'bootStatusPanel';
const TARGET_ENTRY = './main.entry.js';
const DEV_HOST_RE = /^(localhost|127(?:\.\d+){0,2}\.\d+|0\.0\.0\.0)$/i;
const REQUIRED_MARKERS = [
  "const BUILD_TAG = 'v15.5.129-final-release-governance-reaudit-20260316';",
  'exposeGlobalFacade({ App, UI });',
  "window.addEventListener('load', __bootstrapShanHaiApp, { once: true });",
  '// ENTRY_TAIL_SENTINEL: phase15phase129finalreleasegovernancereaudit-tail'
];

function installCompatStubs() {
  const App = (window.App = window.App || {});
  const UI = (window.UI = window.UI || {});

  if (typeof App.bindAuthControls !== 'function') App.bindAuthControls = () => false;
  if (typeof App.prepareActionFromButton !== 'function') App.prepareActionFromButton = () => false;
  if (typeof UI.alert !== 'function') {
    UI.alert = (message, title = '系統通知') => {
      try {
        window.alert(`${title}\n\n${message}`);
      } catch (_) {}
    };
  }
}

function setBootMessage(message, detail = '') {
  const panel = document.getElementById(statusId);
  if (!panel) return;
  panel.style.display = 'block';
  const safeDetail = detail ? `\n${detail}` : '';
  panel.textContent = `[boot] ${message}${safeDetail}`;
}

function setLoginAvailability(isReady, reason = '') {
  const loginBtn = document.getElementById('loginBtn');
  if (!loginBtn) return;
  loginBtn.disabled = !isReady;
  loginBtn.title = isReady ? '' : (reason || '主程式尚未完成載入');
}

function getSnippet(text = '', length = 220) {
  return String(text || '').slice(0, length).replace(/\s+/g, ' ').trim();
}

function looksLikeHtml(text = '') {
  const sample = String(text || '').trimStart().slice(0, 200).toLowerCase();
  return sample.startsWith('<!doctype html') || sample.startsWith('<html') || sample.startsWith('<head') || sample.startsWith('<body');
}

function buildDiagnostic(targetUrl, response, sourceText) {
  const contentType = response.headers.get('content-type') || '(missing content-type)';
  const markerHits = Object.fromEntries(REQUIRED_MARKERS.map((marker) => [marker, String(sourceText || '').includes(marker)]));
  return {
    bootId: BOOT_ID,
    targetUrl: targetUrl.href,
    status: response.status,
    ok: response.ok,
    contentType,
    length: String(sourceText || '').length,
    looksLikeHtml: looksLikeHtml(sourceText),
    markerHits,
    firstChunk: getSnippet(sourceText, 260),
    lastChunk: getSnippet(String(sourceText || '').slice(-260), 260),
    scriptSrc: document.querySelector('script[type="module"]')?.src || '(script src unavailable)'
  };
}

function rewriteRelativeImports(sourceText, targetUrl) {
  const baseHref = new URL('./', targetUrl).href;
  return String(sourceText || '')
    .replace(/from\s+(["'])\.\/([^"']+)\1/g, (_m, quote, relPath) => `from ${quote}${baseHref}${relPath}${quote}`)
    .replace(/import\(\s*(["'])\.\/([^"']+)\1\s*\)/g, (_m, quote, relPath) => `import(${quote}${baseHref}${relPath}${quote})`);
}


function isFreshBootBypassEnabled() {
  const search = window.location.search || '';
  const forceFreshQuery = /(?:^|[?&])(boot_nocache|bootNoCache|freshboot|freshBoot)=(1|true|yes)(?:&|$)/i.test(search);
  const debugQuery = /(?:^|[?&])(debug|devtools)=(1|true|yes)(?:&|$)/i.test(search);
  const modeMatch = /(?:^|[?&])mode=(dev|test)(?:&|$)/i.exec(search);
  const host = window.location.hostname || '';
  const devLikeHost = DEV_HOST_RE.test(host) || /(?:^|\.)test(?:[.-]|$)/i.test(host);
  return window.location.protocol === 'file:' || forceFreshQuery || debugQuery || modeMatch?.[1] === 'dev' || devLikeHost;
}

function buildTargetUrl() {
  const targetUrl = new URL(`${TARGET_ENTRY}?v=${BOOT_ID}`, import.meta.url);
  if (isFreshBootBypassEnabled()) {
    targetUrl.searchParams.set('ts', String(Date.now()));
  }
  return targetUrl;
}

function getBootFetchOptions() {
  return isFreshBootBypassEnabled() ? { cache: 'no-store' } : { cache: 'default' };
}

function classifyBootHint(err, diag = null, stage = 'boot') {
  const detail = String(err && (err.stack || err.message) ? (err.stack || err.message) : err || '');
  const lower = detail.toLowerCase();
  const urlText = String(diag?.targetUrl || '');

  if (window.location.protocol === 'file:') {
    return '目前是直接以 file:// 開啟。若分檔模組或 Firebase CDN 載入失敗，請改用本機伺服器或正式 HTTPS 網址。';
  }
  if (lower.includes('failed to fetch dynamically imported module') || lower.includes('importing a module script failed')) {
    return '主程式模組下載失敗。請優先檢查網路、快取、部署路徑與伺服器 MIME type。';
  }
  if (lower.includes('gstatic') || lower.includes('firebase') || urlText.includes('gstatic')) {
    return 'Firebase CDN 模組可能被網路、外掛或防火牆阻擋。請確認可連到 gstatic 的 firebasejs 模組網址。';
  }
  if (lower.includes('invalid or unexpected token') || lower.includes('unterminated string literal') || lower.includes('unexpected token')) {
    return '入口檔或其相依模組可能含有壞字元、未關閉字串，或部署時仍混入舊版內容。請先確認 active build tag、重新發版，並用部署後驗證腳本檢查遠端內容。';
  }
  if (lower.includes('err_blocked_by_client') || lower.includes('blocked by client')) {
    return '資源可能被瀏覽器外掛或內容阻擋機制攔截。請先停用廣告阻擋/隱私外掛後重試。';
  }
  return '';
}

function formatDiagnostic(diag) {
  const markerSummary = Object.entries(diag.markerHits || {})
    .map(([key, ok]) => `${ok ? '✓' : '✗'} ${key}`)
    .join('\n');

  return [
    `URL: ${diag.targetUrl}`,
    `HTTP: ${diag.status}`,
    `Content-Type: ${diag.contentType}`,
    `Length: ${diag.length}`,
    `Looks like HTML: ${diag.looksLikeHtml ? 'yes' : 'no'}`,
    markerSummary ? `Markers:\n${markerSummary}` : '',
    diag.firstChunk ? `First chunk: ${diag.firstChunk}` : '',
    diag.lastChunk ? `Last chunk: ${diag.lastChunk}` : ''
  ].filter(Boolean).join('\n');
}

async function importFromVerifiedSource(targetUrl, sourceText) {
  const transformed = `${rewriteRelativeImports(sourceText, targetUrl)}\n//# sourceURL=${targetUrl.href}`;
  const blobUrl = URL.createObjectURL(new Blob([transformed], { type: 'text/javascript' }));
  try {
    await import(blobUrl);
    return 'blob-verified-import';
  } finally {
    setTimeout(() => URL.revokeObjectURL(blobUrl), 0);
  }
}

function showFatal(err, diag = null, stage = 'boot') {
  const detail = err && err.stack ? err.stack : String(err || 'unknown error');
  console.error(`[boot] ${stage} failed`, err, diag || '');
  const hint = classifyBootHint(err, diag, stage);
  const hintText = hint ? `\n\n提示：${hint}` : '';
  const diagText = diag ? `\n\n${formatDiagnostic(diag)}` : '';
  setBootMessage('主程式載入失敗', `${detail}${hintText}${diagText}`);
  setLoginAvailability(false, '主程式尚未完成載入');
}

async function startBoot() {
  installCompatStubs();
  setLoginAvailability(false, '主程式載入中');

  const targetUrl = buildTargetUrl();

  if (window.location.protocol === 'file:') {
    const fileDiag = {
      bootId: BOOT_ID,
      targetUrl: targetUrl.href,
      stage: 'file-direct-import',
      contentType: '(file protocol)',
      status: 0,
      ok: false,
      looksLikeHtml: false,
      markerHits: {},
      firstChunk: '',
      fileProtocol: true,
      scriptSrc: document.querySelector('script[type="module"]')?.src || '(script src unavailable)'
    };
    window.__BOOT_DIAG = fileDiag;
    setBootMessage('偵測到 file:// 開啟，改以直接載入主程式…', '若仍失敗，請改用本機伺服器或正式 HTTPS 網址。');
    await import(`${targetUrl.href}&file=1`);
    window.__BOOT_DIAG = { ...fileDiag, importMode: 'file-direct-import' };
  } else {
    setBootMessage('檢查部署版入口檔中…');
    const response = await fetch(targetUrl.href, getBootFetchOptions());
    const sourceText = await response.text();
    const diag = buildDiagnostic(targetUrl, response, sourceText);
    window.__BOOT_DIAG = diag;

    if (!response.ok) {
      throw Object.assign(new Error(`入口檔回傳 HTTP ${response.status}`), { diag, stage: 'fetch' });
    }
    if (diag.looksLikeHtml) {
      throw Object.assign(new Error('入口檔內容看起來像 HTML，而不是 JavaScript 模組'), { diag, stage: 'validate' });
    }
    if (Object.values(diag.markerHits).some((ok) => !ok)) {
      throw Object.assign(new Error('入口檔缺少預期的核心標記，疑似混版或快取污染'), { diag, stage: 'validate' });
    }

    setBootMessage('入口檔驗證完成，載入主程式中…', `URL: ${diag.targetUrl}`);

    try {
      const importMode = await importFromVerifiedSource(targetUrl, sourceText);
      window.__BOOT_DIAG = { ...diag, importMode };
    } catch (blobErr) {
      console.warn('[boot] blob verified import failed, retrying direct import', blobErr);
      const directUrl = `${targetUrl.href}&direct=1`;
      await import(directUrl);
      window.__BOOT_DIAG = { ...diag, importMode: 'direct-import-fallback' };
    }
  }

  setLoginAvailability(true);
  const panel = document.getElementById(statusId);
  if (panel && panel.textContent && panel.textContent.includes('[boot]')) {
    panel.style.display = 'none';
  }
}

startBoot().catch((err) => {
  showFatal(err, err?.diag || window.__BOOT_DIAG || null, err?.stage || 'boot');
});
