import { currentState } from "./state.js?v=phase15phase129finalreleasegovernancereaudit";

const FLAG_DEFS = Object.freeze({
  disableAdminDashboardListener: {
    storageKey: 'shanhai.flags.disable_admin_dashboard_listener',
    aliases: ['disable_admin_dashboard_listener', 'disableAdminDashboardListener'],
    defaultValue: false,
    description: '停用 admin 儀表板 students realtime listener'
  },
  disableStudentMasterMerge: {
    storageKey: 'shanhai.flags.disable_student_master_merge',
    aliases: ['disable_student_master_merge', 'disableStudentMasterMerge'],
    defaultValue: false,
    description: '停用 student_pages 載入後的 students master merge 與學生前景 mirror'
  },
  disableStudentQuizAdminFallback: {
    storageKey: 'shanhai.flags.disable_student_quiz_admin_fallback',
    aliases: ['disable_student_quiz_admin_fallback', 'disableStudentQuizAdminFallback'],
    defaultValue: false,
    description: '停用題庫鏈中的 admin fallback / full scan'
  },
  disableClientSummaryBackfill: {
    storageKey: 'shanhai.flags.disable_client_summary_backfill',
    aliases: ['disable_client_summary_backfill', 'disableClientSummaryBackfill'],
    defaultValue: false,
    description: '停用前端 client 端 public summary backfill / refresh'
  },
  disableStudentAdminCollectionFallback: {
    storageKey: 'shanhai.flags.disable_student_admin_collection_fallback',
    aliases: ['disable_student_admin_collection_fallback', 'disableStudentAdminCollectionFallback'],
    defaultValue: true,
    description: '在學生模式下強制阻止退回 admin-only collection fallback'
  },
  logRuntimeGuards: {
    storageKey: 'shanhai.flags.log_runtime_guards',
    aliases: ['log_runtime_guards', 'logRuntimeGuards'],
    defaultValue: false,
    description: '在 guard 阻擋時輸出詳細 console log'
  }
});

function parseBooleanLike(value, fallback = false) {
  if (typeof value === 'boolean') return value;
  const raw = String(value ?? '').trim().toLowerCase();
  if (!raw) return fallback;
  if (['1', 'true', 'yes', 'on', 'enable', 'enabled'].includes(raw)) return true;
  if (['0', 'false', 'no', 'off', 'disable', 'disabled'].includes(raw)) return false;
  return fallback;
}

function safeStorageGet(key) {
  try { return globalThis?.localStorage?.getItem(key) || ''; } catch (_) { return ''; }
}

function safeStorageSet(key, value) {
  try {
    if (value == null || value === '') globalThis?.localStorage?.removeItem(key);
    else globalThis?.localStorage?.setItem(key, String(value));
    return true;
  } catch (_) {
    return false;
  }
}

function readQueryValue(aliasList = []) {
  try {
    const url = new URL(String(globalThis?.location?.href || ''), globalThis?.location?.origin || undefined);
    for (const alias of aliasList) {
      const direct = url.searchParams.get(alias);
      if (direct != null && direct !== '') return direct;
      const prefixed = url.searchParams.get(`flag.${alias}`);
      if (prefixed != null && prefixed !== '') return prefixed;
      const alt = url.searchParams.get(`runtime.${alias}`);
      if (alt != null && alt !== '') return alt;
    }
  } catch (_) {}
  return '';
}

export function getEmergencyRuntimeFlags() {
  const flags = {};
  for (const [name, def] of Object.entries(FLAG_DEFS)) {
    const aliases = [name, ...(Array.isArray(def.aliases) ? def.aliases : [])];
    const queryValue = readQueryValue(aliases);
    const storageValue = safeStorageGet(def.storageKey);
    flags[name] = parseBooleanLike(queryValue || storageValue, !!def.defaultValue);
  }
  return flags;
}

export function isEmergencyFlagEnabled(name) {
  return !!getEmergencyRuntimeFlags()?.[name];
}

export function updateEmergencyFlag(name, value) {
  const def = FLAG_DEFS[name];
  if (!def) return false;
  safeStorageSet(def.storageKey, value == null ? '' : (parseBooleanLike(value, false) ? '1' : '0'));
  try {
    currentState.emergencyRuntimeFlags = getEmergencyRuntimeFlags();
    currentState.emergencyRuntimeFlagsUpdatedAt = Date.now();
  } catch (_) {}
  return true;
}

export function refreshEmergencyRuntimeFlags() {
  const flags = getEmergencyRuntimeFlags();
  try {
    currentState.emergencyRuntimeFlags = flags;
    currentState.emergencyRuntimeFlagsUpdatedAt = Date.now();
  } catch (_) {}
  return flags;
}

export function guardLog(scope, message, payload = null) {
  if (!isEmergencyFlagEnabled('logRuntimeGuards')) return;
  if (payload == null) console.warn(`[guard:${scope}]`, message);
  else console.warn(`[guard:${scope}]`, message, payload);
}

export function attachEmergencyFlagGlobals() {
  try {
    if (typeof window === 'undefined') return;
    if (typeof window.__getEmergencyRuntimeFlags !== 'function') {
      window.__getEmergencyRuntimeFlags = () => refreshEmergencyRuntimeFlags();
    }
    if (typeof window.__setEmergencyRuntimeFlag !== 'function') {
      window.__setEmergencyRuntimeFlag = (name, value) => {
        const ok = updateEmergencyFlag(String(name || '').trim(), value);
        const flags = refreshEmergencyRuntimeFlags();
        console.log('[runtime-flags][set]', name, value, flags);
        return { ok, flags };
      };
    }
    if (typeof window.__printEmergencyRuntimeFlags !== 'function') {
      window.__printEmergencyRuntimeFlags = () => {
        const flags = refreshEmergencyRuntimeFlags();
        console.log('[runtime-flags]', flags);
        return flags;
      };
    }
  } catch (_) {}
}

attachEmergencyFlagGlobals();
refreshEmergencyRuntimeFlags();

export const EMERGENCY_FLAG_DEFS = FLAG_DEFS;
