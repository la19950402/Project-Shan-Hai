import { currentState } from "./state.js?v=phase15phase129finalreleasegovernancereaudit";

function safeNow() {
  try {
    if (typeof performance !== 'undefined' && performance && typeof performance.now === 'function') return performance.now();
  } catch (_) {}
  return Date.now();
}

function cloneValue(value) {
  if (Array.isArray(value)) return value.map((entry) => cloneValue(entry));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cloneValue(entry)]));
  return value;
}

function ensurePerfStore() {
  if (!currentState.prevalidationPerf || typeof currentState.prevalidationPerf !== 'object') {
    currentState.prevalidationPerf = {
      events: [],
      active: {},
      updatedAt: 0,
      sequence: 0,
      summaries: {
        boot: {},
        quizByAudience: {},
        student: {}
      }
    };
  }
  if (!Array.isArray(currentState.prevalidationPerf.events)) currentState.prevalidationPerf.events = [];
  if (!currentState.prevalidationPerf.active || typeof currentState.prevalidationPerf.active !== 'object') currentState.prevalidationPerf.active = {};
  if (!currentState.prevalidationPerf.summaries || typeof currentState.prevalidationPerf.summaries !== 'object') {
    currentState.prevalidationPerf.summaries = { boot: {}, quizByAudience: {}, student: {} };
  }
  return currentState.prevalidationPerf;
}

function trimEvents(store) {
  const maxEvents = 480;
  if (store.events.length > maxEvents) store.events.splice(0, store.events.length - maxEvents);
}

function syncPerfSummary() {
  const store = ensurePerfStore();
  try {
    const diagBase = (window.__BOOT_DIAG && typeof window.__BOOT_DIAG === 'object') ? window.__BOOT_DIAG : {};
    window.__BOOT_DIAG = {
      ...diagBase,
      prevalidationPerfSummary: cloneValue(store.summaries || {}),
      prevalidationPerfUpdatedAt: store.updatedAt || 0
    };
  } catch (_) {}
}

function pushEvent(event) {
  const store = ensurePerfStore();
  store.sequence = Number(store.sequence || 0) + 1;
  store.events.push({ seq: store.sequence, ...event });
  store.updatedAt = Date.now();
  trimEvents(store);
  syncPerfSummary();
}

function buildActiveKey(group, name) {
  return `${String(group || 'general')}::${String(name || 'unnamed')}`;
}

export function beginPerfSpan(group, name, meta = {}) {
  const store = ensurePerfStore();
  const key = buildActiveKey(group, name);
  const list = Array.isArray(store.active[key]) ? store.active[key] : [];
  const span = {
    group: String(group || 'general'),
    name: String(name || 'unnamed'),
    startedAt: Date.now(),
    startedPerf: safeNow(),
    meta: cloneValue(meta)
  };
  list.push(span);
  store.active[key] = list;
  pushEvent({ type: 'span-start', group: span.group, name: span.name, at: span.startedAt, perfAt: span.startedPerf, meta: span.meta });
  return cloneValue(span);
}

export function endPerfSpan(group, name, meta = {}) {
  const store = ensurePerfStore();
  const key = buildActiveKey(group, name);
  const list = Array.isArray(store.active[key]) ? store.active[key] : [];
  const span = list.pop();
  if (!span) {
    pushEvent({ type: 'span-end-missing', group: String(group || 'general'), name: String(name || 'unnamed'), at: Date.now(), meta: cloneValue(meta) });
    return null;
  }
  if (list.length) store.active[key] = list;
  else delete store.active[key];
  const endedAt = Date.now();
  const durationMs = Math.max(0, Number((safeNow() - Number(span.startedPerf || 0)).toFixed(2)));
  const payload = {
    ...span,
    endedAt,
    durationMs,
    meta: { ...(span.meta || {}), ...cloneValue(meta) }
  };
  pushEvent({ type: 'span-end', group: payload.group, name: payload.name, at: endedAt, durationMs, meta: payload.meta });
  if (payload.group === 'boot') {
    store.summaries.boot[payload.name] = { durationMs, endedAt, meta: cloneValue(payload.meta) };
  } else if (payload.group === 'quiz') {
    const audienceKey = String(payload.meta?.audienceKey || 'default');
    const bucket = store.summaries.quizByAudience[audienceKey] || {};
    bucket[payload.name] = { durationMs, endedAt, meta: cloneValue(payload.meta) };
    store.summaries.quizByAudience[audienceKey] = bucket;
  } else if (payload.group === 'student') {
    store.summaries.student[payload.name] = { durationMs, endedAt, meta: cloneValue(payload.meta) };
  }
  syncPerfSummary();
  return payload;
}

export function markPerfPoint(group, name, meta = {}) {
  const event = {
    type: 'point',
    group: String(group || 'general'),
    name: String(name || 'unnamed'),
    at: Date.now(),
    perfAt: safeNow(),
    meta: cloneValue(meta)
  };
  pushEvent(event);
  const store = ensurePerfStore();
  if (event.group === 'boot') store.summaries.boot[event.name] = { at: event.at, meta: cloneValue(event.meta) };
  else if (event.group === 'student') store.summaries.student[event.name] = { at: event.at, meta: cloneValue(event.meta) };
  syncPerfSummary();
  return event;
}

export function getPrevalidationPerf() {
  return cloneValue(ensurePerfStore());
}

export function resetPrevalidationPerf() {
  currentState.prevalidationPerf = {
    events: [],
    active: {},
    updatedAt: Date.now(),
    sequence: 0,
    summaries: {
      boot: {},
      quizByAudience: {},
      student: {}
    }
  };
  syncPerfSummary();
  return getPrevalidationPerf();
}

export function printPrevalidationPerf(scope = '') {
  const store = getPrevalidationPerf();
  const target = String(scope || '').trim();
  const rows = [];
  (store.events || []).forEach((event) => {
    if (target && event.group !== target) return;
    rows.push({
      seq: event.seq,
      type: event.type,
      group: event.group,
      name: event.name,
      durationMs: event.durationMs || '',
      at: event.at,
      meta: JSON.stringify(event.meta || {})
    });
  });
  console.table(rows);
  return rows;
}

export function attachPrevalidationPerfGlobals() {
  try {
    if (window.__prevalidationPerfGlobalsAttached) return true;
    window.__prevalidationPerfGlobalsAttached = true;
    window.__getPrevalidationPerf = () => getPrevalidationPerf();
    window.__printPrevalidationPerf = (scope) => printPrevalidationPerf(scope);
    window.__resetPrevalidationPerf = () => resetPrevalidationPerf();
    window.__markPerfPoint = (group, name, meta) => markPerfPoint(group, name, meta || {});
    window.__syncPrevalidationPerfSummary = () => syncPerfSummary();
  } catch (_) {}
  return true;
}
