export function getElementByIdSafe(id, root = globalThis?.document) {
  if (!id || !root || typeof root.getElementById !== 'function') return null;
  return root.getElementById(id);
}

export function pickElementsById(idMap = {}, root = globalThis?.document) {
  const entries = Object.entries(idMap || {});
  return entries.reduce((acc, [key, id]) => {
    acc[key] = getElementByIdSafe(id, root);
    return acc;
  }, {});
}

export function listMissingElementKeys(elements = {}, requiredKeys = []) {
  return (Array.isArray(requiredKeys) ? requiredKeys : []).filter(key => !elements?.[key]);
}

export function hasRequiredElementKeys(elements = {}, requiredKeys = []) {
  return listMissingElementKeys(elements, requiredKeys).length === 0;
}

export function buildElementContract(idMap = {}, requiredKeys = [], root = globalThis?.document) {
  const elements = pickElementsById(idMap, root);
  const missing = listMissingElementKeys(elements, requiredKeys);
  return Object.freeze({
    elements,
    missing,
    ok: missing.length === 0
  });
}
