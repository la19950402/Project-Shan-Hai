import { quizSession, QUIZ_SESSION_INITIAL_STATE, createQuizSessionSnapshot, cloneQuizSessionValue } from "./state.js?v=phase15phase96fix8quizsessionformal";

const DEFAULT_SESSION_MODE = 'quiz';

function assignQuizSessionState(nextState = {}) {
  const initialKeys = new Set(Object.keys(QUIZ_SESSION_INITIAL_STATE || {}));
  Object.keys(quizSession || {}).forEach((key) => {
    if (!initialKeys.has(key) && !(key in nextState)) delete quizSession[key];
  });
  Object.keys(nextState || {}).forEach((key) => {
    quizSession[key] = cloneQuizSessionValue(nextState[key]);
  });
  return quizSession;
}

export function clearQuizAdvanceTimer() {
  try {
    if (quizSession.advanceTimerId) clearTimeout(quizSession.advanceTimerId);
  } catch (_) {}
  quizSession.advanceTimerId = null;
  return quizSession;
}

export function resetQuizSession(overrides = {}) {
  clearQuizAdvanceTimer();
  return assignQuizSessionState(createQuizSessionSnapshot(overrides));
}

export function beginQuizSession(mode = DEFAULT_SESSION_MODE, overrides = {}) {
  const normalizedMode = String(mode || overrides.mode || quizSession.mode || QUIZ_SESSION_INITIAL_STATE.mode || DEFAULT_SESSION_MODE).trim() || DEFAULT_SESSION_MODE;
  const sessionToken = `${normalizedMode}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
  const startedAt = Date.now();
  resetQuizSession({
    mode: normalizedMode,
    sessionToken,
    startedAt,
    aborted: false,
    lastAbortReason: null,
    ...overrides
  });
  return sessionToken;
}

export function beginDailyQuizSession({ questions = [], studentData = null, remainingRewardCount = 0, mode = 'daily' } = {}) {
  const dailyData = studentData == null ? null : cloneQuizSessionValue(studentData);
  const sessionToken = beginQuizSession(mode, {
    questions: Array.isArray(questions) ? questions.map((question) => cloneQuizSessionValue(question)) : [],
    currentIndex: 0,
    score: 0,
    dailyCoinsEarned: 0,
    dailyXpEarned: 0,
    dailyRemainingAtStart: Math.max(0, Number(remainingRewardCount) || 0),
    dailyLifetimeMetricsCommitted: false,
    dailyData,
    lastDailySessionToken: ''
  });
  quizSession.lastDailySessionToken = sessionToken;
  return sessionToken;
}

export function beginBattleQuizSession(question = null, mode = 'battle') {
  return beginQuizSession(mode, {
    questions: question ? [cloneQuizSessionValue(question)] : [],
    currentIndex: 0,
    score: 0
  });
}

export function abortQuizSession(reason = 'manual_close', overrides = {}) {
  clearQuizAdvanceTimer();
  assignQuizSessionState({
    ...quizSession,
    answerPending: false,
    resultShown: false,
    aborted: true,
    lastAbortReason: reason || 'manual_close',
    ...overrides
  });
  return quizSession;
}

export function scheduleQuizAdvance(callback, delay = 900, expectedToken = quizSession.sessionToken) {
  clearQuizAdvanceTimer();
  const safeDelay = Math.max(0, Math.floor(Number(delay) || 0));
  quizSession.advanceTimerId = setTimeout(() => {
    quizSession.advanceTimerId = null;
    if (quizSession.aborted) return;
    if (expectedToken && quizSession.sessionToken !== expectedToken) return;
    try {
      callback();
    } catch (err) {
      console.error('[quiz] advance failed:', err);
    }
  }, safeDelay);
  return quizSession.advanceTimerId;
}
