
const __safeReadStorage = (key) => {
  try {
    return globalThis?.localStorage?.getItem(key) || '';
  } catch (_) {
    return '';
  }
};

const __search = String(globalThis?.location?.search || '');
const __hostname = String(globalThis?.location?.hostname || '');
const __protocol = String(globalThis?.location?.protocol || '');
const __debugQuery = /(?:^|[?&])(debug|devtools)=(1|true|yes)(?:&|$)/i.test(__search);
const __modeQuery = /(?:^|[?&])mode=(dev|test)(?:&|$)/i.exec(__search)?.[1] || '';
const __storageMode = __safeReadStorage('shanhai.runtimeMode');
const __storageDebug = __safeReadStorage('shanhai.debug');
const __isLocalHost = /^(localhost|127(?:\.\d+){0,2}\.\d+|0\.0\.0\.0)$/i.test(__hostname);
const __isTestHost = /(?:test|staging|sandbox)/i.test(__hostname);
const __isFileProtocol = __protocol === 'file:';

const runtimeMode = (() => {
  if (__modeQuery) return __modeQuery;
  if (__storageMode) return __storageMode;
  if (__isLocalHost || __isTestHost) return 'dev';
  return 'prod';
})();

export const RUNTIME_ENV = Object.freeze({
  mode: runtimeMode,
  isDev: runtimeMode === 'dev',
  isTest: runtimeMode === 'test',
  isProd: runtimeMode === 'prod',
  isLocalHost: __isLocalHost,
  isTestHost: __isTestHost,
  isFileProtocol: __isFileProtocol,
  debugRequested: __debugQuery || __storageDebug === '1'
});

const __devLike = RUNTIME_ENV.isDev || RUNTIME_ENV.isTest || RUNTIME_ENV.debugRequested;

export const DEBUG_MARKERS = Object.freeze({
  bootPanel: '@debug-removable:boot-panel',
  fallbackLogin: '@debug-removable:fallback-login',
  bootErrorCapture: '@debug-removable:boot-error-capture'
});

export const DEBUG_FLAGS = Object.freeze({
  enabled: false,
  showBootPanel: __devLike,
  enableFallbackLogin: __devLike,
  captureGlobalBootErrors: __devLike,
  enableVerboseBootStatus: __devLike,
  logFacadeMountSummary: false
});
