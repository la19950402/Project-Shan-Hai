export function getStudentTeamPanelKeyFromData(data = {}) {
  const className = String((data || {})?.class_name || '').trim();
  if (/科展團隊/.test(className)) return 'science';
  if (/學習扶助/.test(className)) return 'support';
  return '';
}

export function getActionPanelConfigForData(data = {}, teamActionPanels = {}, defaultActions = []) {
  const panelKey = getStudentTeamPanelKeyFromData(data);
  const panel = panelKey ? (teamActionPanels?.[panelKey] || null) : null;
  return {
    key: panelKey || 'default',
    title: panel?.title || '一般學習加分面板',
    hint: panel?.hint || '目前使用一般學習加分面板；系統會依五行能力顯示對應的加分事件。',
    actions: panel?.actions || defaultActions,
    attrFocus: panel?.attrFocus || {}
  };
}

export function getMaxElementFromAttributes(attrs = {}, firstGainOrder = null, elementKeys = ['metal', 'wood', 'water', 'fire', 'earth']) {
  let best = elementKeys[0] || 'metal';
  let bestVal = -Infinity;
  const orderMap = firstGainOrder || {};
  const getOrder = (key) => Number.isFinite(Number(orderMap?.[key])) ? Number(orderMap[key]) : Number.POSITIVE_INFINITY;
  for (const k of elementKeys) {
    const v = Number(attrs?.[k]) || 0;
    if (v > bestVal) {
      bestVal = v;
      best = k;
      continue;
    }
    if (v === bestVal) {
      const curOrder = getOrder(best);
      const nextOrder = getOrder(k);
      if (nextOrder < curOrder) best = k;
    }
  }
  return best;
}

export function inferElementKeyFromText(raw = '') {
  const txt = String(raw || '').replace(/[\s\[\]【】()（）]/g, '').replace(/[⚙️🌳💧🔥🪨🌟✨💊🍡🪙⭐★]/g, '');
  if (!txt) return null;
  if (txt.includes('metal') || txt.includes('金') || txt.includes('鋼')) return 'metal';
  if (txt.includes('wood') || txt.includes('木') || txt.includes('草') || txt.includes('葉')) return 'wood';
  if (txt.includes('water') || txt.includes('水')) return 'water';
  if (txt.includes('fire') || txt.includes('火')) return 'fire';
  if (txt.includes('earth') || txt.includes('土') || txt.includes('地')) return 'earth';
  return null;
}

export function ensureAttributeFirstGainOrder(data, elementKeys = ['metal', 'wood', 'water', 'fire', 'earth'], inferElement = inferElementKeyFromText) {
  if (!data || typeof data !== 'object') return {};
  const base = { metal: null, wood: null, water: null, fire: null, earth: null };
  data.attribute_first_gain_order = Object.assign(base, data.attribute_first_gain_order || {});
  let nextOrder = 1;
  for (const k of elementKeys) {
    const v = Number(data.attribute_first_gain_order[k]);
    if (Number.isFinite(v) && v > 0) nextOrder = Math.max(nextOrder, v + 1);
  }
  if (Array.isArray(data.logs) && data.logs.length) {
    const logs = data.logs.slice().sort((a, b) => (Number(a?.timestamp) || 0) - (Number(b?.timestamp) || 0));
    for (const log of logs) {
      const detail = String(log?.detail || '');
      const match = detail.match(/\(([^)]+)\)\s*$/);
      const key = inferElement(match ? match[1] : detail);
      if (!key) continue;
      const existing = Number(data.attribute_first_gain_order[key]);
      if (Number.isFinite(existing) && existing > 0) continue;
      if ((Number(data.attributes?.[key]) || 0) <= 0) continue;
      data.attribute_first_gain_order[key] = nextOrder++;
    }
  }
  for (const k of elementKeys) {
    const hasAttr = (Number(data.attributes?.[k]) || 0) > 0;
    const hasOrder = Number.isFinite(Number(data.attribute_first_gain_order[k])) && Number(data.attribute_first_gain_order[k]) > 0;
    if (hasAttr && !hasOrder) data.attribute_first_gain_order[k] = nextOrder++;
  }
  return data.attribute_first_gain_order;
}

export function markAttributeGain(data, attr, elementKeys = ['metal', 'wood', 'water', 'fire', 'earth'], ensureOrder = ensureAttributeFirstGainOrder) {
  if (!data || !elementKeys.includes(attr)) return;
  const orderMap = ensureOrder(data, elementKeys, inferElementKeyFromText);
  const existing = Number(orderMap?.[attr]);
  if (Number.isFinite(existing) && existing > 0) return;
  let nextOrder = 1;
  for (const k of elementKeys) {
    const v = Number(orderMap?.[k]);
    if (Number.isFinite(v) && v > 0) nextOrder = Math.max(nextOrder, v + 1);
  }
  data.attribute_first_gain_order[attr] = nextOrder;
}

export function addAttributeXP(data, attr, amount, elementKeys = ['metal', 'wood', 'water', 'fire', 'earth'], markGain = markAttributeGain) {
  if (!data || !elementKeys.includes(attr)) return;
  if (!data.attributes) data.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
  const before = Number(data.attributes[attr]) || 0;
  const delta = Number(amount) || 0;
  data.attributes[attr] = before + delta;
  if (delta > 0 && data.attributes[attr] > 0) markGain(data, attr, elementKeys, ensureAttributeFirstGainOrder);
}

export function getDominantElementFromData(data, elementKeys = ['metal', 'wood', 'water', 'fire', 'earth'], getMaxElement = getMaxElementFromAttributes, ensureOrder = ensureAttributeFirstGainOrder) {
  return getMaxElement(data?.attributes || {}, ensureOrder(data || {}, elementKeys, inferElementKeyFromText), elementKeys);
}
