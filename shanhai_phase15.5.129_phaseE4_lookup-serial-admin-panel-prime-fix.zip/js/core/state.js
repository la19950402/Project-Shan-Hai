export const currentState = {
  viewMode: 'login',
  authUser: null,
  isAdmin: false,
  adminDiag: {
    build: '',
    projectId: '',
    email: '', uid: '', claimAdmin: '未檢查', allowlist: '未檢查', final: '未檢查',
    lastError: '', checkedAt: '', summary: '尚未檢查'
  },
  scanIntention: 'read', currentUid: null, currentCardUid: null, studentData: null, currentToken: null,
  currentTokenValidated: false, studentLocked: false, unsubscribe: null,
  teacherTargetContext: {
    serial: null,
    currentUid: null,
    studentName: '',
    source: '',
    action: '',
    hydrated: false,
    hasStudentData: false,
    activeToken: null,
    lastResolvedAt: 0,
    lastLookupAt: 0,
    lastHydratedAt: 0,
    lastSavedAt: 0,
    lastError: ''
  },
  pendingAction: null, previousStudentsData: {}, tempSelectedTeam: [],
  currentBattleBoss: null, selectedBattleMonIndex: -1, battleData: null, tempRegName: null,
  cardForgeMode: 'xp', pendingForgeData: null, pendingAdminPanelOpened: false,
  supportBatchScanCount: 0, scienceBatchScanCount: 0,
  teacherActionSubmitting: false,
  adminDashboardListenerUnsubscribe: null, adminDashboardListenerStartedAt: 0, adminDashboardListenerLastError: '',
  emergencyRuntimeFlags: {}, emergencyRuntimeFlagsUpdatedAt: 0,
  prevalidationPerf: { events: [], active: {}, updatedAt: 0, sequence: 0, summaries: { boot: {}, quizByAudience: {}, student: {} } },
  studentLoadToken: '', studentLoadLastRenderSignature: '', studentLoadMode: '', studentLoadRequestedUid: '', studentLoadRequestedAt: 0, studentLoadActiveSerial: '',
  studentDataReadyAt: 0, studentDataLastSource: '', studentHydrationPending: false, studentHydrationError: '',
  dailyQuestStarting: false, quizExporting: false, quizBankCache: [], quizSelectedIds: [],
  studentQuizPoolCache: [], studentQuizPoolLoadedAt: 0, studentQuizPoolPromise: null, studentQuizPoolLastError: '',
  studentQuizPoolCacheByAudience: {}, studentQuizPoolLoadedAtByAudience: {}, studentQuizPoolPromiseByAudience: {},
  quizPoolDiagnostics: { byAudience: {}, lastAudienceKey: '', updatedAt: 0 },
  quizPoolSummarySyncPromise: null, quizPoolSummarySyncedAt: 0, quizPoolSummaryLastError: '', quizPoolSummaryRefreshTimer: null,
  rankingCache: [], rankingCacheLoadedAt: 0, rankingCachePromise: null, rankingCacheLastError: '',
  studentShopMode: 'preview', studentShopCatalogCache: [], studentShopCatalogLoadedAt: 0, studentShopCatalogPromise: null, studentShopCatalogLastError: '',
  studentViewWarmPromise: null, studentViewWarmStartedAt: 0,
  shopBusy: false, shopAdminSaving: false, shopGiftSending: false,
  quizLoading: false, quizSaving: false, quizDeleting: false, quizToggling: false,
  sessionIdleTimer: null, sessionActivityBound: false, lastActivityAt: 0,
  baizeHistory: [], baizeBound: false, baizeSending: false,
  aiGuideFeature: { enabled: false, hidden: true, checkedAt: 0, reason: '' },
  shopDomContract: { checkedAt: 0, missing: [], ok: false },
  supportZoneDomContract: { checkedAt: 0, missing: [], ok: false },
  scienceZoneDomContract: { checkedAt: 0, missing: [], ok: false },
  accountMgmtDomContract: { checkedAt: 0, missing: [], ok: false },
  baizeDomContract: { checkedAt: 0, missing: [], ok: false },
  scanModeDomContract: { checkedAt: 0, missing: [], ok: false },
  legendaryAdminDomContract: { checkedAt: 0, missing: [], ok: false },
  legendaryStudentDomContract: { checkedAt: 0, missing: [], ok: false },
  displayTeamDomContract: { checkedAt: 0, missing: [], ok: false },
  bulkProgressDomContract: { checkedAt: 0, missing: [], ok: false },
  registrationDomContract: { checkedAt: 0, missing: [], ok: false },
  studentInfoDomContract: { checkedAt: 0, missing: [], ok: false },
  studentActionDomContract: { checkedAt: 0, missing: [], ok: false },
  runtimeUiDomContract: { checkedAt: 0, missing: [], ok: false },
  teacherUtilityDomContract: { checkedAt: 0, missing: [], ok: false },
  zoneLinkDomContract: { checkedAt: 0, missing: [], ok: false },
  battleSetupDomContract: { checkedAt: 0, missing: [], ok: false },
  contentProfileDomContract: { checkedAt: 0, missing: [], ok: false },
  quizManagerDomContract: { checkedAt: 0, missing: [], ok: false },
  quizPlayDomContract: { checkedAt: 0, missing: [], ok: false },
  rankingDomContract: { checkedAt: 0, missing: [], ok: false },
  shopFlowDomContract: { checkedAt: 0, missing: [], ok: false },
  studentShopShowcaseDomContract: { checkedAt: 0, missing: [], ok: false },
  systemUiDomContract: { checkedAt: 0, missing: [], ok: false },
  shopAdminDomContract: { checkedAt: 0, missing: [], ok: false }
};

export const batchState = { activeStudentUid: null, timerInterval: null, timeLeftMs: 10000, comboCount: 0, lastScanTime: 0 };
export const QUIZ_SESSION_INITIAL_STATE = Object.freeze({
  questions: [],
  currentIndex: 0,
  score: 0,
  mode: 'daily',
  answerPending: false,
  resultShown: false,
  aborted: false,
  lastAbortReason: null,
  sessionToken: '',
  startedAt: 0,
  advanceTimerId: null,
  lastAnsweredIndex: -1,
  dailyData: null,
  dailyCoinsEarned: 0,
  dailyXpEarned: 0,
  dailyRemainingAtStart: 0,
  dailyLifetimeMetricsCommitted: false,
  lastDailySessionToken: ''
});

export const QUIZ_SESSION_RUNTIME_FIELDS = Object.freeze(Object.keys(QUIZ_SESSION_INITIAL_STATE));

export function cloneQuizSessionValue(value) {
  if (Array.isArray(value)) return value.map((item) => cloneQuizSessionValue(item));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cloneQuizSessionValue(entry)]));
  }
  return value;
}

export function createQuizSessionSnapshot(overrides = {}) {
  const snapshot = {};
  QUIZ_SESSION_RUNTIME_FIELDS.forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(overrides, key)) snapshot[key] = cloneQuizSessionValue(overrides[key]);
    else snapshot[key] = cloneQuizSessionValue(QUIZ_SESSION_INITIAL_STATE[key]);
  });
  Object.keys(overrides || {}).forEach((key) => {
    if (!Object.prototype.hasOwnProperty.call(snapshot, key)) snapshot[key] = cloneQuizSessionValue(overrides[key]);
  });
  return snapshot;
}

export const quizSession = createQuizSessionSnapshot();
export const radarChartInstances = { adm: null, stu: null, archive: null };

export function initializeState({ buildTag = '', projectId = '' } = {}) {
  currentState.adminDiag.build = buildTag || currentState.adminDiag.build || '';
  currentState.adminDiag.projectId = projectId || currentState.adminDiag.projectId || '';
}
