export function ensureRewardEventState(data = {}) {
  if (!Array.isArray(data.reward_events)) data.reward_events = [];
  if (!Array.isArray(data.reward_settled_ids)) data.reward_settled_ids = [];
  return data;
}

export function buildRewardEventId(type, scopeParts = []) {
  const suffix = ([]).concat(scopeParts || []).map(v => String(v || '').trim()).filter(Boolean).join(':');
  return suffix ? `${type}:${suffix}` : `${type}:${Date.now()}`;
}

export function applyRewardEventToData(dataObj, type, options = {}, deps = {}) {
  const {
    ensureRewardEventState: ensureRewardEventStateImpl = ensureRewardEventState,
    buildRewardEventId: buildRewardEventIdImpl = buildRewardEventId,
    getDominantElementFromData,
    getProfileAttributeInfo,
    addAttributeXP,
    getProfileLabels,
  } = deps;

  if (typeof getDominantElementFromData !== 'function') throw new Error('applyRewardEventToData requires getDominantElementFromData');
  if (typeof getProfileAttributeInfo !== 'function') throw new Error('applyRewardEventToData requires getProfileAttributeInfo');
  if (typeof addAttributeXP !== 'function') throw new Error('applyRewardEventToData requires addAttributeXP');
  if (typeof getProfileLabels !== 'function') throw new Error('applyRewardEventToData requires getProfileLabels');

  const data = ensureRewardEventStateImpl(JSON.parse(JSON.stringify(dataObj || {})));
  const timestamp = Number(options.timestamp) || Date.now();
  const eventId = String(options.eventId || buildRewardEventIdImpl(type, options.scopeParts || [])).trim();
  if (!eventId) return { data, applied: false, eventId: '' };
  if ((data.reward_settled_ids || []).includes(eventId)) {
    return { data, applied: false, eventId };
  }

  data.attributes = data.attributes || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
  data.logs = Array.isArray(data.logs) ? data.logs : [];

  const rewardMap = {
    daily_correct: { coins: 1, xp: 1, attrXP: 1, actionType: 'quest' },
    boss_win: { coins: 5, xp: 5, attrXP: 5, actionType: 'battle' },
    teacher_daily_compensate: { coins: 1, xp: 1, attrXP: 1, actionType: 'teacher_reward' },
    teacher_boss_compensate: { coins: 5, xp: 5, attrXP: 5, actionType: 'teacher_reward' }
  };
  const reward = rewardMap[type];
  if (!reward) return { data, applied: false, eventId };

  const maxEl = getDominantElementFromData(data);
  const attrName = getProfileAttributeInfo(maxEl, data)?.name || maxEl;
  data.coins = (Number(data.coins) || 0) + reward.coins;
  data.totalXP = (Number(data.totalXP) || 0) + reward.xp;
  addAttributeXP(data, maxEl, reward.attrXP);

  data.reward_events.push({
    id: eventId,
    type,
    timestamp,
    coins: reward.coins,
    xp: reward.xp,
    attr: maxEl,
    attrXP: reward.attrXP,
    source: options.source || 'system',
    meta: options.meta || {}
  });
  if (data.reward_events.length > 200) data.reward_events = data.reward_events.slice(-200);
  data.reward_settled_ids.push(eventId);
  if (data.reward_settled_ids.length > 400) data.reward_settled_ids = data.reward_settled_ids.slice(-400);

  const detailMap = {
    daily_correct: `[${getProfileLabels(data).dailyQuestLogPrefix || '每日修練'}] 答對 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
    boss_win: `[${getProfileLabels(data).battleTitle?.replace(/^[^\]]*\]\s*/, '') || '領域防衛'}] 成功 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
    teacher_daily_compensate: `[老師補發] 成功答題 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
    teacher_boss_compensate: `[老師補發] 成功挑戰Boss +${reward.coins}🪙 +${reward.xp}XP(${attrName})`
  };
  data.logs.push({
    timestamp,
    action_type: reward.actionType,
    reward_event_id: eventId,
    points_added: reward.xp,
    detail: detailMap[type] || `[獎勵事件] ${type}`
  });

  return { data, applied: true, eventId, attrKey: maxEl, attrName, reward };
}

export function dedupeLogs(logs = []) {
  const seen = new Set();
  return (Array.isArray(logs) ? logs : []).filter(item => {
    if (!item || typeof item !== 'object') return false;
    const key = `${Number(item.timestamp) || 0}|${String(item.action_type || '')}|${String(item.detail || '')}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a, b) => (Number(a.timestamp) || 0) - (Number(b.timestamp) || 0));
}

export function dedupeCollection(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).filter(item => {
    if (!item || typeof item !== 'object') return false;
    const key = `${String(item.type || '')}|${Number(item.timestamp) || 0}|${String(item.name || '')}|${String(item.path || item.element || item.requiredAttr || '')}|${String(item.id || item.hiddenEggId || '')}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a, b) => (Number(a.timestamp) || 0) - (Number(b.timestamp) || 0));
}
