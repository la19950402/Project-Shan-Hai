export function createForceOpenCardForgeBridge({ currentState, UI, getApp = () => globalThis?.App }) {
  return function forceOpenCardForge(evt) {
    try {
      if (evt && typeof evt.preventDefault === 'function') evt.preventDefault();
      if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();

      const app = typeof getApp === 'function' ? getApp() : null;
      if (app && typeof app.isSystemReady === 'function' && !app.isSystemReady()) {
        try {
          if (typeof app.ensureSystemReady === 'function') {
            app.ensureSystemReady('鑄造道具卡', { alert: false });
          } else {
            UI.toast('⏳ 鑄造道具卡：系統仍在初始化中');
          }
        } catch (_) {}
        return false;
      }
      if (app && typeof app.openCardForge === 'function') {
        try {
          if (typeof app.syncTeacherTargetContext === 'function') {
            try {
              app.syncTeacherTargetContext(currentState.studentData, {
                source: 'global-bridge:forceOpenCardForge',
                action: 'bridge-open-card-forge',
                serial: currentState.currentUid || currentState.studentData?.card_seq || currentState.studentData?.serial || null,
                hydrated: Boolean(currentState.studentData),
                hasStudentData: Boolean(currentState.studentData),
                touch: false,
                clearError: true
              });
            } catch (_) {}
          }
          return app.openCardForge();
        } catch (delegateErr) {
          console.warn('[card forge] delegated open failed, fallback to legacy bridge:', delegateErr?.message || delegateErr);
        }
      }

      const modal = document.getElementById('cardForgeModal');
      const formArea = document.getElementById('cfFormArea');
      const waitArea = document.getElementById('cfWaitArea');
      const nameEl = document.getElementById('cfName');
      const valueEl = document.getElementById('cfValue');
      const debuffNameEl = document.getElementById('cfDebuffName');
      const debuffStacksEl = document.getElementById('cfDebuffStacks');
      const debuffKeyEl = document.getElementById('cfDebuffKey');
      if (!modal) throw new Error('找不到加分視窗 cardForgeModal');
      modal.classList.remove('hidden');
      modal.style.display = 'flex';
      modal.style.alignItems = 'center';
      modal.style.justifyContent = 'center';
      if (formArea) formArea.classList.remove('hidden');
      if (waitArea) waitArea.classList.add('hidden');
      currentState.pendingForgeData = null;
      currentState.cardForgeMode = 'xp';
      if (nameEl) nameEl.value = '';
      if (valueEl) valueEl.value = '5';
      if (debuffNameEl) debuffNameEl.value = '';
      if (debuffStacksEl) debuffStacksEl.value = '1';
      if (debuffKeyEl) debuffKeyEl.value = 'Poison';
      try { if (app && typeof app.initCardForgePresets === 'function') app.initCardForgePresets(); } catch (e) { console.warn('[card forge] preset init failed', e); }
      try { if (app && typeof app.setCardForgeMode === 'function') app.setCardForgeMode('xp'); } catch (e) { console.warn('[card forge] mode init failed', e); }
      if (nameEl && typeof nameEl.focus === 'function') setTimeout(() => nameEl.focus(), 0);
      return false;
    } catch (e) {
      console.error('[card forge] force open failed:', e);
      try { UI.alert(`加分框開啟失敗：${e?.message || e}`, '系統通知'); } catch (_) { alert(`加分框開啟失敗：${e?.message || e}`); }
      return false;
    }
  };
}

export function buildSystemNamespace({
  APP_CONFIG,
  BUILD_TAG,
  facadeMountReport,
  globalSurfaceInventory,
  clearAssetUrlCache
}) {
  const facadeSummary = Object.freeze({
    groups: Object.freeze(Object.keys(facadeMountReport || {})),
    missing: Object.freeze(Object.entries(facadeMountReport || {}).reduce((acc, [group, status]) => {
      if (status && Array.isArray(status.missing) && status.missing.length) acc[group] = Object.freeze(status.missing.slice());
      return acc;
    }, {}))
  });

  const surfaceSummary = Object.freeze({
    appMissingRequired: Object.freeze(globalSurfaceInventory?.app?.required?.missing?.slice?.() || []),
    appMissingTransitional: Object.freeze(globalSurfaceInventory?.app?.transitional?.missing?.slice?.() || []),
    uiMissingRequired: Object.freeze(globalSurfaceInventory?.ui?.required?.missing?.slice?.() || []),
    htmlAppMissingDirect: Object.freeze(globalSurfaceInventory?.html?.appDirect?.missing?.slice?.() || []),
    htmlUiMissingDirect: Object.freeze(globalSurfaceInventory?.html?.uiDirect?.missing?.slice?.() || []),
    htmlAppOutsidePolicy: Object.freeze(globalSurfaceInventory?.html?.policyCoverage?.appOutsidePolicy?.slice?.() || []),
    htmlUiOutsidePolicy: Object.freeze(globalSurfaceInventory?.html?.policyCoverage?.uiOutsidePolicy?.slice?.() || []),
    globals: Object.freeze({ ...(globalSurfaceInventory?.globals || {}) })
  });

  return Object.freeze({
    version: APP_CONFIG?.version || '',
    buildTag: BUILD_TAG || '',
    splitBridgeEnabled: Boolean(APP_CONFIG?.splitBridge?.enabled),
    facade: facadeSummary,
    surface: surfaceSummary,
    dev: Object.freeze({
      clearAssetUrlCache
    })
  });
}

export function exposeLegacyGlobals({
  App,
  UI,
  DEBUG_FLAGS,
  RUNTIME_ENV,
  clearAssetUrlCache,
  forceOpenCardForge,
  systemNamespace,
  root = globalThis
}) {
  try { delete root.forceOpenCardForge; } catch (_) { root.forceOpenCardForge = undefined; }

  const exposeDebugHelper = Boolean(
    DEBUG_FLAGS?.enabled ||
    DEBUG_FLAGS?.showBootPanel ||
    DEBUG_FLAGS?.enableVerboseBootStatus ||
    RUNTIME_ENV?.isDev ||
    RUNTIME_ENV?.isTest ||
    RUNTIME_ENV?.debugRequested
  );

  if (exposeDebugHelper) {
    root.ShanHaiSystem = systemNamespace;
    root.__clearAssetUrlCache = clearAssetUrlCache;
  } else {
    try { delete root.ShanHaiSystem; } catch (_) { root.ShanHaiSystem = undefined; }
    try { delete root.__clearAssetUrlCache; } catch (_) { root.__clearAssetUrlCache = undefined; }
  }

  return Object.freeze({
    app: App,
    ui: UI,
    globals: Object.freeze({
      forceOpenCardForge: false,
      shanHaiSystem: exposeDebugHelper,
      clearAssetUrlCache: exposeDebugHelper
    })
  });
}
