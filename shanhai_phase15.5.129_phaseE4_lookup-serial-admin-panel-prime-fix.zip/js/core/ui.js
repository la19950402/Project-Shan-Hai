export const UI = {
  show(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
  },
  hide(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  },
  showModal(id) {
    this.show(id);
  },
  hideModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = '';
    this.hide(id);
  },
  toast(msg) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.innerText = msg;
    t.style.opacity = 1;
    setTimeout(() => { t.style.opacity = 0; }, 3000);
  },
  alert(msg, title = '系統通知') {
    const t = document.getElementById('sysAlertTitle');
    const m = document.getElementById('sysAlertMsg');
    if (t && m) {
      t.innerText = title;
      m.innerText = msg;
      this.showModal('sysAlertModal');
    } else {
      console.error('UI.alert Failed:', msg);
    }
  },
  confirm(msg, title = '請再次確認') {
    return new Promise((resolve) => {
      const t = document.getElementById('sysConfirmTitle');
      const m = document.getElementById('sysConfirmMsg');
      const confirmBtn = document.getElementById('sysConfirmBtn');
      const cancelBtn = document.getElementById('sysCancelBtn');
      if (!(t && m && confirmBtn && cancelBtn)) {
        resolve(false);
        return;
      }
      t.innerText = title;
      m.innerText = msg;
      const handleConfirm = () => { cleanup(); resolve(true); };
      const handleCancel = () => { cleanup(); resolve(false); };
      const cleanup = () => {
        confirmBtn.removeEventListener('click', handleConfirm);
        cancelBtn.removeEventListener('click', handleCancel);
        UI.hideModal('sysConfirmModal');
      };
      confirmBtn.addEventListener('click', handleConfirm);
      cancelBtn.addEventListener('click', handleCancel);
      UI.showModal('sysConfirmModal');
    });
  },
  showImageModal(src, titleText) {
    const img = document.getElementById('enlargedImg');
    const title = document.getElementById('enlargedTitle');
    if (img) img.src = src;
    if (title) title.innerText = titleText;
    this.showModal('imageModal');
  }
};
