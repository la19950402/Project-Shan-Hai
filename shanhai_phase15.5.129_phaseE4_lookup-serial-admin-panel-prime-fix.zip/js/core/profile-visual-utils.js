import { makeBadgeSvg } from "./runtime-utils.js?v=phase15phase91fix3teachersavecheck";

export function getCatVisual(source = {}, sourceItem = null, deps = {}) {
  const { CAT_VISUALS = {}, getDominantElementFromData, getProfileAttributeInfo, makeBadge = makeBadgeSvg } = deps;
  const item = sourceItem || source || {};
  const stage = Number(item?.stage ?? item?.dragon_stage ?? source?.dragon_stage ?? -1);
  const attrKey = String(item?.element || item?.path || source?.dragon_path || (typeof getDominantElementFromData === "function" ? getDominantElementFromData(source) : "neutral") || "neutral");
  const info = typeof getProfileAttributeInfo === "function"
    ? getProfileAttributeInfo(attrKey, { content_profile_id: "cat" })
    : { name: attrKey, color: "#8ab4d6", coat: attrKey, emoji: "🐈" };
  const breedCfg = CAT_VISUALS[attrKey] || null;
  const breedName = breedCfg?.breed || info.coat || info.name;
  const stageMap = {
    '-1': { name: '箱子', caption: '待救援的小紙箱', emoji: '📦' },
    '0': { name: '奶貓期', caption: '剛睜眼、毛色漸漸顯現的小奶貓', emoji: '🐈' },
    '1': { name: '幼貓期', caption: '開始探索環境、活潑好動的幼貓', emoji: '😺' },
    '2': { name: '成貓期', caption: '氣質成熟、展現品種特色的成貓', emoji: info.emoji || '🐈‍⬛' },
  };
  const st = stageMap[String(stage)] || stageMap['-1'];
  let file = null;
  if (stage < 0) {
    file = CAT_VISUALS.box?.file || null;
  } else if (breedCfg?.stages) {
    file = breedCfg.stages[String(stage)] || breedCfg.stages['0'] || null;
  }
  const sub = stage === -1 ? (breedName || '待救援小紙箱') : `${info.name} · ${breedName || info.coat || ''}`;
  return {
    file,
    img: file ? null : makeBadge(st.emoji || '🐱', st.name, info.color || '#8ab4d6', sub),
    name: stage < 0 ? '箱子' : `${breedName}`,
    caption: `${st.caption}${stage >= 0 ? `｜${breedName || info.coat || info.name}` : ''}`,
    color: info.color || '#8ab4d6',
    info,
    stageName: st.name,
    breedName,
  };
}

export function getProfileVisual(data = {}, sourceItem = null, deps = {}) {
  const { isCatProfile, getCatVisual: getCatVisualFn, getDragonVisual: getDragonVisualFn } = deps;
  if (typeof isCatProfile === 'function' && isCatProfile(data)) return getCatVisualFn(data, sourceItem);
  const vis = getDragonVisualFn(sourceItem ? {
    dragon_path: sourceItem.path || sourceItem.dragon_path || data.dragon_path,
    dragon_stage: sourceItem.stage ?? sourceItem.dragon_stage ?? data.dragon_stage,
    attributes: sourceItem.stats || sourceItem.attributes || data.attributes || {}
  } : data);
  return Object.assign({}, vis, { img: null });
}

export function getRadarLabelsForData(data = null, deps = {}) {
  const { attrOrder = [], getProfileAttributeInfo } = deps;
  return attrOrder.map((k) => {
    const info = typeof getProfileAttributeInfo === 'function' ? getProfileAttributeInfo(k, data) : { icon: '', name: String(k || '') };
    return `${info.icon}${info.name}`;
  });
}

export function buildCollectionDisplayItem(item, ownerData = null, deps = {}) {
  const { getContentProfile, getProfileAttributeInfo, isCatProfile, getProfileDebuffInfo, makeBadge = makeBadgeSvg, getCatVisual: getCatVisualFn } = deps;
  const profile = typeof getContentProfile === 'function' ? getContentProfile(ownerData) : { builtInShop: { hidden_egg: { name: '特殊異獸蛋' } } };
  const attrKey = String(item?.element || item?.path || 'neutral');
  const attrInfo = typeof getProfileAttributeInfo === 'function' ? getProfileAttributeInfo(attrKey, ownerData) : { name: attrKey, color: '#9aa0a6', coat: '' };
  if (typeof isCatProfile === 'function' && !isCatProfile(ownerData)) return null;
  if (item.type === 'legendary') {
    return { title: '特殊品種夥伴', color: 'var(--legendary-gold)', img: makeBadge('🐾', '特殊救援', '#ffb700', profile?.builtInShop?.hidden_egg?.name || '特殊異獸蛋') };
  }
  if (item.type === 'material') {
    return { title: `${attrInfo.name}玩具素材`, color: attrInfo.color, img: makeBadge('🧶', attrInfo.name, attrInfo.color, attrInfo.coat || '') };
  }
  if (item.type === 'dead_dragon') {
    const cause = typeof getProfileDebuffInfo === 'function' ? getProfileDebuffInfo(item.cause, ownerData) : { name: item.cause || '未知' };
    return { title: '照護紀錄', color: 'var(--danger)', img: makeBadge('📝', '照護紀錄', '#ff0055', cause.name) };
  }
  if (item.type === 'voucher') {
    return { title: item.status === 'redeemed' ? '已兌現憑證' : '兌換憑證', color: item.status === 'redeemed' ? 'var(--text-muted)' : 'var(--legendary-gold)', img: item.img || makeBadge('🎟️', '兌換憑證', item.status === 'redeemed' ? '#888888' : '#ffb700', item.name || '實體商品') };
  }
  if (item.type === 'dragon') {
    const vis = typeof getCatVisualFn === 'function' ? getCatVisualFn(ownerData || {}, item) : { stageName: '夥伴', color: attrInfo.color, file: null, img: null };
    return { title: `${vis.stageName}｜${attrInfo.name}`, color: vis.color, img: vis.file || vis.img };
  }
  return null;
}

export function getEggVisual(data, deps = {}) {
  const { constants = {}, getDominantElementFromData } = deps;
  const eggs = constants?.MEDIA?.DRAGON_EGGS || {};
  if (!data || (Number(data.totalXP) || 0) <= 0) return eggs.primal;
  const maxEl = typeof getDominantElementFromData === 'function' ? getDominantElementFromData(data) : 'primal';
  return eggs[maxEl] || eggs.primal;
}

export function getDragonVisual(data, deps = {}) {
  const { constants = {}, getDominantElementFromData, getEggVisual: getEggVisualFn } = deps;
  const stage = Number(data?.dragon_stage);
  const stageIdx = Number.isFinite(stage) ? stage : -1;
  const maxEl = typeof getDominantElementFromData === 'function' ? getDominantElementFromData(data) : 'neutral';
  const pathKey = data?.dragon_path || null;
  const activeHiddenEggId = String(data?.active_hidden_egg_id || '').trim();
  const activeHiddenEgg = (data?.active_hidden_egg && typeof data.active_hidden_egg === 'object') ? data.active_hidden_egg : null;
  const hiddenEggs = constants?.HIDDEN_EGGS || {};
  const attrs = constants?.ATTRIBUTES || {};
  const media = constants?.MEDIA || {};
  const activeHiddenMeta = (activeHiddenEggId && hiddenEggs[activeHiddenEggId])
    ? hiddenEggs[activeHiddenEggId]
    : (activeHiddenEggId && activeHiddenEgg?.hiddenEggId && hiddenEggs[activeHiddenEgg.hiddenEggId])
      ? hiddenEggs[activeHiddenEgg.hiddenEggId]
      : activeHiddenEgg;

  if (activeHiddenMeta && activeHiddenMeta.forms) {
    const color = (attrs[activeHiddenMeta.requiredAttr || maxEl]?.color) || (attrs[maxEl]?.color) || 'var(--cyan)';
    if (stageIdx < 0) {
      return { file: activeHiddenMeta.forms.egg || activeHiddenMeta.img || media.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.name || '特殊異獸蛋'}（孵化中）`, color, name: activeHiddenMeta.name || '特殊異獸蛋' };
    }
    if (stageIdx === 0) {
      return { file: activeHiddenMeta.forms.hatchling || activeHiddenMeta.forms.egg || activeHiddenMeta.img || media.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜破殼期`, color, name: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}（破殼期）` };
    }
    if (stageIdx === 1) {
      return { file: activeHiddenMeta.forms.juvenile || activeHiddenMeta.forms.hatchling || activeHiddenMeta.img || media.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜成長期`, color, name: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}（成長期）` };
    }
    return { file: activeHiddenMeta.forms.adult || activeHiddenMeta.forms.juvenile || activeHiddenMeta.img || media.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜成熟期`, color, name: activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸' };
  }

  if (stageIdx < 0) {
    const egg = typeof getEggVisualFn === 'function' ? getEggVisualFn(data) : (media.DRAGON_EGGS || {}).primal;
    const color = attrs[maxEl]?.color || 'var(--cyan)';
    return { file: egg?.file, caption: `${egg?.caption || ''}`, color, name: '龍蛋' };
  }

  const paths = media.DRAGON_PATHS || {};
  const useKey = pathKey || maxEl;
  const p = paths[useKey];

  if (p && p.stages && p.stages[stageIdx]) {
    const st = p.stages[stageIdx];
    const color = attrs[useKey]?.color || attrs[maxEl]?.color || 'var(--cyan)';
    return { file: st.file, caption: `${st.name}`, color, name: st.name };
  }

  const egg = (media.DRAGON_EGGS && media.DRAGON_EGGS[useKey]) ? media.DRAGON_EGGS[useKey] : (typeof getEggVisualFn === 'function' ? getEggVisualFn(data) : media.PLACEHOLDER_SVG);
  const color = attrs[useKey]?.color || 'var(--cyan)';
  return { file: egg?.file, caption: '進化型態待設定', color, name: '未設定' };
}

export function isDirectVisualSource(ref) {
  const s = String(ref || '').trim();
  return /^https?:\/\//i.test(s) || /^data:image\//i.test(s) || /^blob:/i.test(s);
}

export function splitBattleVisualRef(ref, fallbackImg = '', isDirectVisualSourceFn = isDirectVisualSource) {
  const raw = String(ref || '').trim();
  if (!raw) return { img_file: '', img: fallbackImg };
  if (typeof isDirectVisualSourceFn === 'function' && isDirectVisualSourceFn(raw)) return { img_file: '', img: raw };
  return { img_file: raw, img: fallbackImg };
}
