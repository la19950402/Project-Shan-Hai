export function normalizeQuizGradeToken(raw) {
  const s = String(raw || '').trim();
  if (!s) return '';
  const normalized = s.replace(/\s+/g, '').replace(/年級|年|班/g, '');
  const map = { '一': '1', '二': '2', '三': '3', '四': '4', '五': '5', '六': '6' };
  const first = normalized.charAt(0);
  return map[first] || (/^[1-6]/.test(normalized) ? normalized.charAt(0) : normalized);
}

export function isQuizEnabled(q = {}) {
  if (q.isActive === false) return false;
  if (q.active === false) return false;
  if (q.enabled === false) return false;
  if (String(q.status || '').trim() === 'disabled') return false;
  return true;
}

export function quizMatchesStudentGrade(q = {}, userGrade = '', isSupportClass = false, deps = {}) {
  const normalize = deps.normalizeQuizGradeToken || normalizeQuizGradeToken;
  const raw = String(q.grade || q.class_name || q.gradeName || '').trim();
  if (!raw) return false;
  if (isSupportClass) return /學習扶助/.test(raw);
  if (/學習扶助/.test(raw)) return false;
  const quizGrade = normalize(raw);
  const studentGrade = normalize(userGrade);
  return !!quizGrade && !!studentGrade && quizGrade === studentGrade;
}

export function getStudentGradeInfo(data = {}) {
  const className = String(data?.class_name || '').trim();
  const isSupportClass = /學習扶助/.test(className);
  const gradeMatch = className.match(/[1-6一二三四五六]/);
  const gradeToken = isSupportClass ? 'support' : (({ '一':'1', '二':'2', '三':'3', '四':'4', '五':'5', '六':'6' }[(gradeMatch || [])[0]] || ((gradeMatch || [])[0] || '')));
  const audienceKey = isSupportClass ? 'support' : (gradeToken ? `grade${gradeToken}` : 'default');
  return { className, isSupportClass, gradeToken, audienceKey };
}

export function getBattleAudienceOptions() {
  return [
    { key: 'grade4', label: '四年級' },
    { key: 'grade5', label: '五年級' },
    { key: 'support', label: '學習扶助班' },
    { key: 'default', label: '全體通用（備援）' }
  ];
}

export function normalizeBossDiceCount(value, fallback = 3) {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.max(1, Math.min(12, Math.round(num)));
}

export function normalizeBattleTowerDoc(raw = {}, deps = {}) {
  const normalizeDice = deps.normalizeBossDiceCount || normalizeBossDiceCount;
  const base = raw && typeof raw === 'object' ? JSON.parse(JSON.stringify(raw)) : {};
  const audiences = (base.audiences && typeof base.audiences === 'object') ? base.audiences : {};
  const normalizeAudienceCfg = (cfg = {}, key = 'default') => ({
    id: cfg.id || cfg.bossId || cfg.legendaryId || '',
    bossId: cfg.bossId || cfg.id || cfg.legendaryId || '',
    name: cfg.name || cfg.bossName || '',
    img: cfg.img || cfg.image || '',
    typeKey: cfg.typeKey || cfg.type || cfg.element || cfg.bossType || '',
    gatekeeperQuizId: cfg.gatekeeperQuizId || cfg.quizId || cfg.quiz_id || cfg.questionId || 'random',
    bossDiceCount: normalizeDice(cfg.bossDiceCount || cfg.diceCount || cfg.bossDice || 3, 3),
    timestamp: cfg.timestamp || cfg.updatedAt || 0,
    audienceKey: cfg.audienceKey || key,
    audienceLabel: cfg.audienceLabel || cfg.groupLabel || (key === 'default' ? '全體通用（備援）' : key)
  });
  if (!Object.keys(audiences).length && (base.id || base.bossId || base.legendaryId || base.typeKey || base.type || base.element || base.gatekeeperQuizId || base.quizId || base.quiz_id || base.questionId)) {
    audiences.default = normalizeAudienceCfg(base, 'default');
  }
  Object.keys(audiences).forEach((key) => {
    audiences[key] = normalizeAudienceCfg(audiences[key] || {}, key);
  });
  return { version: base.version || 'battle_tower_v2', audiences };
}

export function getBattleBossConfigForAudience(rawDoc = {}, audienceKey = 'default', deps = {}) {
  const normalize = deps.normalizeBattleTowerDoc || normalizeBattleTowerDoc;
  const normalized = normalize(rawDoc);
  const audiences = normalized.audiences || {};
  return audiences[audienceKey] || audiences.default || null;
}

export function getBattleBossConfigForStudent(studentData = {}, rawDoc = {}, deps = {}) {
  const getInfo = deps.getStudentGradeInfo || getStudentGradeInfo;
  const getForAudience = deps.getBattleBossConfigForAudience || getBattleBossConfigForAudience;
  const info = getInfo(studentData);
  return getForAudience(rawDoc, info.audienceKey) || getForAudience(rawDoc, 'default');
}

export function getBattleMonStage(mon = {}, ownerData = {}) {
  if (mon?.type === 'legendary') return 2;
  const raw = mon?.stage ?? mon?.dragon_stage ?? ownerData?.dragon_stage;
  const stage = Number(raw);
  return Number.isFinite(stage) ? stage : -1;
}

export function getBattleMonDiceCount(mon = {}, ownerData = {}, deps = {}) {
  const getStage = deps.getBattleMonStage || getBattleMonStage;
  const stage = getStage(mon, ownerData);
  if (stage >= 2) return 6;
  if (stage === 1) return 5;
  if (stage === 0) return 4;
  return 3;
}

export function getBattleStageLabel(stage, ownerData = null, deps = {}) {
  const isCat = deps.isCatProfile || (() => false);
  if (isCat(ownerData)) {
    if (stage >= 2) return '成貓期';
    if (stage === 1) return '幼貓期';
    if (stage === 0) return '奶貓期';
    return '箱子';
  }
  if (stage >= 2) return '成熟期';
  if (stage === 1) return '成長期';
  if (stage === 0) return '破殼期';
  return '蛋形態';
}
