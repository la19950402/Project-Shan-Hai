export function isDirectVisualSource(ref) {
  const s = String(ref || '').trim();
  return /^https?:\/\//i.test(s) || /^data:image\//i.test(s) || /^blob:/i.test(s);
}

export function splitBattleVisualRef(ref, fallbackImg = '') {
  const raw = String(ref || '').trim();
  if (!raw) return { img_file: '', img: fallbackImg };
  if (isDirectVisualSource(raw)) return { img_file: '', img: raw };
  return { img_file: raw, img: fallbackImg };
}

export function buildAssetObjectPaths(assetKey, {
  assetPaths = {},
  mediaExts = null,
  mediaExt = 'png',
  mediaFolder = ''
} = {}) {
  const key = String(assetKey || '').trim();
  if (!key) return [];

  const mapped = assetPaths[key];
  if (Array.isArray(mapped)) return mapped.filter(Boolean);
  if (typeof mapped === 'string' && mapped) return [mapped];

  const exts = (Array.isArray(mediaExts) && mediaExts.length)
    ? mediaExts
    : [mediaExt || 'png'];

  if (key.includes('/')) {
    if (/\.[a-z0-9]+$/i.test(key)) return [key];
    return exts.map(ext => `${key}.${ext}`);
  }

  const prefix = mediaFolder ? `${mediaFolder}/` : '';
  return exts.map(ext => `${prefix}${key}.${ext}`);
}

export function getCachedAssetUrlFromFileBaseName(fileBaseName, {
  mediaConfig = {},
  assetUrlCache = new Map()
} = {}) {
  const paths = buildAssetObjectPaths(fileBaseName, {
    assetPaths: (mediaConfig && mediaConfig.ASSET_PATHS) ? mediaConfig.ASSET_PATHS : {},
    mediaExts: (mediaConfig && mediaConfig.MEDIA_EXTS) ? mediaConfig.MEDIA_EXTS : null,
    mediaExt: (mediaConfig && mediaConfig.MEDIA_EXT) ? mediaConfig.MEDIA_EXT : 'png',
    mediaFolder: (mediaConfig && mediaConfig.MEDIA_FOLDER) ? mediaConfig.MEDIA_FOLDER : ''
  });

  if (!paths.length) return mediaConfig.PLACEHOLDER_SVG || '';

  const p0 = paths[0];
  if (typeof p0 === 'string' && /^https?:\/\//i.test(p0)) return p0;
  if (assetUrlCache && typeof assetUrlCache.has === 'function' && assetUrlCache.has(p0)) {
    return assetUrlCache.get(p0);
  }
  return mediaConfig.PLACEHOLDER_SVG || '';
}
