import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { initializeFirestore, memoryLocalCache, persistentLocalCache, collection, doc, getDoc, getDocs, writeBatch, setDoc, onSnapshot, updateDoc, addDoc, deleteDoc, query, where, orderBy, limit } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signInAnonymously, signOut, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-functions.js";
import { getStorage, ref as storageRef, getDownloadURL, updateMetadata } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js";

export const firebaseConfig = {
  apiKey: "AIzaSyDUpGQ1jklUSugZ4ALRpJxhJC21F6sSHhs",
  authDomain: "project-shan-hai.firebaseapp.com",
  projectId: "project-shan-hai",
  storageBucket: "project-shan-hai.firebasestorage.app",
  messagingSenderId: "262124728011",
  appId: "1:262124728011:web:3681797a6fdb518ad9f54e",
  measurementId: "G-J51V3R07MJ"
};

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

function shouldForceLongPolling() {
  try {
    const forced = String(window?.localStorage?.getItem('firestore_force_long_polling') || '').trim();
    if (forced === '1' || /^true$/i.test(forced)) return true;
  } catch (_) {}
  const ua = String(globalThis?.navigator?.userAgent || '').toLowerCase();
  return /android/.test(ua) && (/wv/.test(ua) || /; wv\)/.test(ua) || /version\//.test(ua));
}

function createFirestore() {
  const settings = shouldForceLongPolling()
    ? {
        localCache: persistentLocalCache(),
        experimentalForceLongPolling: true
      }
    : {
        localCache: persistentLocalCache(),
        experimentalAutoDetectLongPolling: true
      };
  try {
    return initializeFirestore(app, settings);
  } catch (error) {
    console.warn('[firebase] initializeFirestore persistent cache failed, fallback to memory cache:', error);
    return initializeFirestore(app, {
      localCache: memoryLocalCache(),
      experimentalAutoDetectLongPolling: true
    });
  }
}

export const db = createFirestore();
export const auth = getAuth(app);
export const functions = getFunctions(app, 'asia-east1');
export const storage = getStorage(app, `gs://${firebaseConfig.storageBucket}`);
setPersistence(auth, browserLocalPersistence).catch((e) => console.warn('[auth] persistence failed:', e));

export {
  collection, doc, getDoc, getDocs, writeBatch, setDoc, onSnapshot, updateDoc, addDoc, deleteDoc, query, where, orderBy, limit,
  onAuthStateChanged, signInWithEmailAndPassword, signInAnonymously, signOut, setPersistence, browserLocalPersistence,
  httpsCallable, storageRef, getDownloadURL, updateMetadata
};
