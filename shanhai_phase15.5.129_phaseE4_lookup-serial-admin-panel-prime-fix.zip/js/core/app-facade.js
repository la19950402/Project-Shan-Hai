
const bindMethods = (target, source, methods, bindTarget = target) => {
  const bound = [];
  const missing = [];
  for (const method of methods) {
    if (source && typeof source[method] === 'function') {
      target[method] = source[method].bind(bindTarget);
      bound.push(method);
    } else {
      missing.push(method);
    }
  }
  return { bound, missing };
};

const preserveAliases = (target, aliasMap) => {
  const preserved = [];
  for (const [aliasName, sourceName] of Object.entries(aliasMap)) {
    if (typeof target[sourceName] === 'function') {
      target[aliasName] = target[sourceName].bind(target);
      preserved.push(aliasName);
    }
  }
  return preserved;
};

const aliasMethods = (target, aliasMap) => {
  const aliased = [];
  for (const [aliasName, sourceName] of Object.entries(aliasMap)) {
    if (typeof target[sourceName] === 'function') {
      target[aliasName] = target[sourceName];
      aliased.push(aliasName);
    }
  }
  return aliased;
};

export const APP_FACADE_METHODS = Object.freeze({
  auth: Object.freeze([
    'bindAuthControls','ensureStudentAuth','isCurrentUserAdmin','renderAdminDiagnostics','tryAutoEnterAdmin',
    'logoutAdmin','bindSessionActivityWatchers','getSessionIdleMode','handleIdleTimeout','resetSessionIdleTimer'
  ]),
  studentApp: Object.freeze(['loadStudentData','checkDebuffRecovery','refreshStudentRewardPanel','refreshStudentIdentityLabels']),
  studentUI: Object.freeze(['updateDragonImage','updateCollectionGallery','updateStudentAttributes','renderRadarChartRaw','updateStatusContainer','updatePanel']),
  teacherActions: Object.freeze([
    'setCardForgeMode','initCardForgePresets','applyForgeXpPreset','ensureTeacherTargetData','openCardForge',
    'startCardForge','cancelCardForge','prepareAction','prepareActionFromButton','commitAction','checkDeathTrigger',
    'forceDebuff','applyTeacherCompensation'
  ]),
  batch: Object.freeze(['enterBatchMode','exitBatchMode','setBatchStudent','startBatchTimer','endBatchSession','resetBatchState','persistBatchStudentData','executeBatchAction']),
  battle: Object.freeze([
    'startBattleChallenge','selectBattleMon','confirmBattleSelection','handleBattleQuizAnswer','prepareBattleArena',
    'rollDice','showBattleSettlement','backToBattleResult','closeBattleArenaAndRefresh','endBattle',
    'checkBattleTowerStatus','updateBattleTowerStatus','resetDailyAndBattleChallenges','populateBattleQuizOptions',
    'updateBattleTowerAdminAudienceView','openBattleTowerSetup','publishBattleBoss','clearBattleBoss'
  ]),
  shop: Object.freeze([
    'getBuiltInShopItems','getShopEffectLabel','getShopButtonHtml','setShopBusy','setShopAdminSaving','setShopGiftSending','isShopInteractionLocked','renderShopItems','populateHiddenEggSelect',
    'updateShopAdminFormState','resetShopAdminForm','resetShopGiftForm','setShopAdminTab','getAdminGiftableShopItems',
    'loadShopGiftOptions','pickShopGiftItem','lookupShopGiftTarget','getShopGiftItemMeta','applyAdminGiftEffect',
    'sendShopGift','openShopAdmin','loadShopAdminList','editShopProduct','saveShopProduct','deleteShopProduct',
    'openShop','applyShopEffect','handleShopPurchase'
  ]),
  quiz: Object.freeze([
    'resetQuizForm','fillQuizForm','openEditQuiz','cancelQuizEdit','readQuizFormData','setQuizBusy','isQuizBusy','importQuizBulk','exportQuizBank',
    'updateQuizSelectionSummary','updateQuizFilterState','getFilteredQuizzes','toggleQuizSelection','toggleAllQuizSelections',
    'renderQuizBankList','batchSetQuizActive','batchDeleteSelectedQuizzes','loadQuizBank','saveNewQuiz','saveEditedQuiz',
    'deleteQuiz','toggleQuizActive','startDailyQuest','renderQuizQuestion','selectQuizOption'
  ]),
  ranking: Object.freeze(['showRanking']),
  contentProfile: Object.freeze(['getProfilePayloadFromForm','applyCurrentStudentProfile','quickApplyCatProfile','quickApplyShanhaiProfile','activateHiddenEggFromArchive']),
  zones: Object.freeze([
    'buildSupportZoneUrl','buildScienceZoneUrl','openRequestedAdminPanel','getSupportTagMeta','populateSupportBatchFacetSelect',
    'getSelectedSupportStudentMeta','renderSupportSelectedMeta','updateSupportBatchStatus','loadSupportStudentsList',
    'useCurrentStudentInSupportZone','handleSupportStudentChange','getSupportRecordDocRef','collectSupportDailyForm',
    'fillSupportDailyForm','renderSupportTodayRecord','loadSupportTodayRecord','saveSupportRecordForStudent',
    'saveSupportRecord','supportCheckIn','saveSupportDailyRecord','supportCheckOut','markSupportAbsent','copySupportZoneUrl',
    'writeSupportZoneLinkToNfc','startSupportBatchScan','stopSupportBatchScan','applySupportRewardToStudent','handleSupportBatchScan',
    'openSupportZone','exportSupportHistoryCurrent','exportSupportHistoryAll','getScienceTagMeta','populateScienceBatchFacetSelect',
    'getSelectedScienceStudentMeta','renderScienceSelectedMeta','updateScienceBatchStatus','loadScienceStudentsList',
    'useCurrentStudentInScienceZone','handleScienceStudentChange','getScienceRecordDocRef','collectScienceDailyForm',
    'fillScienceDailyForm','renderScienceTodayRecord','loadScienceTodayRecord','saveScienceRecordForStudent','saveScienceRecord',
    'scienceCheckIn','saveScienceDailyRecord','scienceCheckOut','markScienceAbsent','copyScienceZoneUrl','writeScienceZoneLinkToNfc',
    'startScienceBatchScan','stopScienceBatchScan','applyScienceRewardToStudent','handleScienceBatchScan','openScienceZone',
    'exportScienceHistoryCurrent','exportScienceHistoryAll'
  ]),
  aliases: Object.freeze({
    battle: Object.freeze({ attackBoss: 'startBattleChallenge' }),
    auth: Object.freeze({ login: 'bindAuthControls', loginAdmin: 'bindAuthControls' })
  }),
  legacyAliases: Object.freeze({
    shop: Object.freeze({ handleShopPurchaseLegacy: 'handleShopPurchase', applyShopEffectLegacy: 'applyShopEffect' }),
    quiz: Object.freeze({
      importQuizBulkLegacy: 'importQuizBulk', exportQuizBankLegacy: 'exportQuizBank', updateQuizFilterStateLegacy: 'updateQuizFilterState',
      getFilteredQuizzesLegacy: 'getFilteredQuizzes', toggleAllQuizSelectionsLegacy: 'toggleAllQuizSelections',
      renderQuizBankListLegacy: 'renderQuizBankList', batchSetQuizActiveLegacy: 'batchSetQuizActive',
      batchDeleteSelectedQuizzesLegacy: 'batchDeleteSelectedQuizzes', startDailyQuestLegacy: 'startDailyQuest',
      renderQuizQuestionLegacy: 'renderQuizQuestion', selectQuizOptionLegacy: 'selectQuizOption'
    }),
    zones: Object.freeze({
      loadSupportStudentsListLegacy: 'loadSupportStudentsList', useCurrentStudentInSupportZoneLegacy: 'useCurrentStudentInSupportZone',
      handleSupportStudentChangeLegacy: 'handleSupportStudentChange', loadSupportTodayRecordLegacy: 'loadSupportTodayRecord',
      saveSupportRecordForStudentLegacy: 'saveSupportRecordForStudent', saveSupportRecordLegacy: 'saveSupportRecord',
      supportCheckInLegacy: 'supportCheckIn', saveSupportDailyRecordLegacy: 'saveSupportDailyRecord',
      supportCheckOutLegacy: 'supportCheckOut', markSupportAbsentLegacy: 'markSupportAbsent',
      copySupportZoneUrlLegacy: 'copySupportZoneUrl', writeSupportZoneLinkToNfcLegacy: 'writeSupportZoneLinkToNfc',
      openSupportZoneLegacy: 'openSupportZone', exportSupportHistoryCurrentLegacy: 'exportSupportHistoryCurrent',
      exportSupportHistoryAllLegacy: 'exportSupportHistoryAll', loadScienceStudentsListLegacy: 'loadScienceStudentsList',
      useCurrentStudentInScienceZoneLegacy: 'useCurrentStudentInScienceZone', handleScienceStudentChangeLegacy: 'handleScienceStudentChange',
      loadScienceTodayRecordLegacy: 'loadScienceTodayRecord', saveScienceRecordForStudentLegacy: 'saveScienceRecordForStudent',
      saveScienceRecordLegacy: 'saveScienceRecord', scienceCheckInLegacy: 'scienceCheckIn',
      saveScienceDailyRecordLegacy: 'saveScienceDailyRecord', scienceCheckOutLegacy: 'scienceCheckOut',
      markScienceAbsentLegacy: 'markScienceAbsent', copyScienceZoneUrlLegacy: 'copyScienceZoneUrl',
      writeScienceZoneLinkToNfcLegacy: 'writeScienceZoneLinkToNfc', openScienceZoneLegacy: 'openScienceZone',
      exportScienceHistoryCurrentLegacy: 'exportScienceHistoryCurrent', exportScienceHistoryAllLegacy: 'exportScienceHistoryAll'
    })
  })
});

export function mountAppFacade({ App, UI, apis, debugFlags }) {
  const report = {};
  report.auth = bindMethods(App, apis.authApi, APP_FACADE_METHODS.auth, App);
  report.studentApp = bindMethods(App, apis.studentApi, APP_FACADE_METHODS.studentApp, App);
  report.studentUI = bindMethods(UI, apis.studentApi, APP_FACADE_METHODS.studentUI, UI);
  report.teacherActions = bindMethods(App, apis.teacherActionsApi, APP_FACADE_METHODS.teacherActions, App);
  report.batch = bindMethods(App, apis.batchApi, APP_FACADE_METHODS.batch, App);
  report.battle = bindMethods(App, apis.battleApi, APP_FACADE_METHODS.battle, App);

  report.legacyShop = preserveAliases(App, APP_FACADE_METHODS.legacyAliases.shop);
  report.shop = bindMethods(App, apis.shopApi, APP_FACADE_METHODS.shop, App);

  report.legacyQuiz = preserveAliases(App, APP_FACADE_METHODS.legacyAliases.quiz);
  report.quiz = bindMethods(App, apis.quizApi, APP_FACADE_METHODS.quiz, App);

  report.ranking = bindMethods(App, apis.rankingApi, APP_FACADE_METHODS.ranking, App);
  report.contentProfile = bindMethods(App, apis.contentProfileApi, APP_FACADE_METHODS.contentProfile, App);

  report.legacyZones = preserveAliases(App, APP_FACADE_METHODS.legacyAliases.zones);
  report.zones = bindMethods(App, apis.zonesApi, APP_FACADE_METHODS.zones, App);

  report.aliasBattle = aliasMethods(App, APP_FACADE_METHODS.aliases.battle);
  report.aliasAuth = aliasMethods(App, APP_FACADE_METHODS.aliases.auth);

  if (debugFlags?.logFacadeMountSummary) {
    console.info('[facade] mount summary', report);
  }
  return Object.freeze(report);
}

export function exposeGlobalFacade({ App, UI, root = globalThis }) {
  root.App = App;
  root.UI = UI;
  return { App, UI };
}
