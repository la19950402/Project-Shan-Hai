import { APP_FACADE_METHODS } from './app-facade.js?v=phase15phase93fix5studentloadunify';
const flattenFacadeMethods = (groups) => {
  const out = [];
  for (const group of groups) {
    if (Array.isArray(group)) out.push(...group);
  }
  return [...new Set(out)].sort();
};

const freeze = (value) => Object.freeze(value);
const freezeSortedUnique = (values) => freeze([...new Set(values || [])].sort());

export const INDEX_HTML_DIRECT_APP_METHODS = freezeSortedUnique([
  'activateHiddenEggFromArchive','amLoadReissue','amLookupSerial','amStartReissue','applyCurrentStudentProfile','applyTeacherCompensation',
  'backToBattleResult','backToDashboard','batchDeleteSelectedQuizzes','batchSetQuizActive','bulkRepairStudentPages','bulkUpdateProgressAndGrade',
  'cancelCardForge','cancelQuizEdit','claimQuizReward','clearBattleBoss','closeBaizeModal','closeBattleArenaAndRefresh',
  'confirmBattleSelection','copyScienceZoneUrl','copySupportZoneUrl','enterBatchMode','enterScanMode','executeStudentRename',
  'exitBatchMode','exportQuizBank','exportScienceHistoryAll','exportScienceHistoryCurrent','exportSupportHistoryAll','exportSupportHistoryCurrent',
  'fillShopGiftCurrentStudent','forceDebuff','forceOpenCardForge','importQuizBulk','loadLegendaryAdmin','loadQuizBank',
  'loadScienceStudentsList','loadSupportStudentsList','logoutAdmin','lookupShopGiftTarget','markScienceAbsent','markSupportAbsent',
  'openAccountMgmt','openBaizeModal','openBattleTowerSetup','openBulkProgressModal','openDisplayTeamEditor','openScienceZone',
  'openShopAdmin','openSupportZone','publishBattleBoss','publishLegendary','quickApplyCatProfile',
  'quickApplyShanhaiProfile','refreshAdminDiagnostics','renderQuizBankList','resetDailyAndBattleChallenges','resetShopAdminForm',
  'resetShopGiftForm','rollDice','rollRegistrationName','saveDisplayTeam','saveNewQuiz','saveScienceDailyRecord',
  'saveShopProduct','saveSupportDailyRecord','scienceCheckIn','scienceCheckOut','sendBaizeMessage','sendShopGift','setAccountMgmtTab',
  'setCardForgeMode','setShopAdminTab','showBattleSettlement','showRanking','startBattleChallenge','startCardForge','startDailyQuest',
  'startScienceBatchScan','startSupportBatchScan','startWebNfc','stopScienceBatchScan','stopSupportBatchScan','studentRerollName',
  'supportCheckIn','supportCheckOut','toggleAdminDiagPanel','toggleAllQuizSelections','useCurrentStudentInScienceZone',
  'useCurrentStudentInSupportZone'
]);

export const INDEX_HTML_DIRECT_UI_METHODS = freezeSortedUnique([
  'hideModal','showArchiveModal','showAttrInfo','showImageModal','showModal','showStatusInfo'
]);

export const INDEX_HTML_INLINE_HANDLER_SUMMARY = freeze({
  total: 154,
  appCalls: 111,
  uiCalls: 35,
  otherInlineCalls: 7,
  windowCalls: 1,
  otherExpressions: freeze([
    "location.reload()",
    "document.getElementById('qmBulkImport').value=''",
    'event.stopPropagation()'
  ])
});

export const UI_GLOBAL_SURFACE = freeze([
  'show','hide','showModal','hideModal','toast','alert','confirm','showImageModal','showArchiveModal','showStatusInfo','showAttrInfo',
  'updateDragonImage','updateCollectionGallery','updateStudentAttributes','renderRadarChartRaw','updateStatusContainer','updatePanel'
]);

export const APP_GLOBAL_SURFACE_POLICY = freeze({
  required: freeze(flattenFacadeMethods([
    APP_FACADE_METHODS.auth,
    APP_FACADE_METHODS.studentApp,
    APP_FACADE_METHODS.teacherActions,
    APP_FACADE_METHODS.batch,
    APP_FACADE_METHODS.battle,
    APP_FACADE_METHODS.shop,
    APP_FACADE_METHODS.quiz,
    APP_FACADE_METHODS.ranking,
    APP_FACADE_METHODS.contentProfile,
    APP_FACADE_METHODS.zones
  ])),
  transitional: freeze([
    ...Object.keys(APP_FACADE_METHODS.aliases.battle),
    ...Object.keys(APP_FACADE_METHODS.aliases.auth),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.shop),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.quiz),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.zones),
    ...INDEX_HTML_DIRECT_APP_METHODS
  ].sort())
});

export const LEGACY_GLOBAL_POLICY = freeze({
  required: freeze(['App','UI']),
  debugOnly: freeze(['ShanHaiSystem','__clearAssetUrlCache'])
});

const pickFunctionKeys = (obj) => Object.keys(obj || {}).filter((key) => typeof obj[key] === 'function').sort();

const buildGroupStatus = (surfaceKeys, expected) => ({
  present: freeze(expected.filter((key) => surfaceKeys.includes(key))),
  missing: freeze(expected.filter((key) => !surfaceKeys.includes(key)))
});

const buildHtmlEntryStatus = (appKeys, uiKeys) => {
  const appDirect = buildGroupStatus(appKeys, INDEX_HTML_DIRECT_APP_METHODS);
  const uiDirect = buildGroupStatus(uiKeys, INDEX_HTML_DIRECT_UI_METHODS);
  const appOutsidePolicy = INDEX_HTML_DIRECT_APP_METHODS.filter((key) => !APP_GLOBAL_SURFACE_POLICY.required.includes(key) && !APP_GLOBAL_SURFACE_POLICY.transitional.includes(key));
  const uiOutsidePolicy = INDEX_HTML_DIRECT_UI_METHODS.filter((key) => !UI_GLOBAL_SURFACE.includes(key));
  return freeze({
    appDirect: freeze(appDirect),
    uiDirect: freeze(uiDirect),
    policyCoverage: freeze({
      appOutsidePolicy: freeze(appOutsidePolicy),
      uiOutsidePolicy: freeze(uiOutsidePolicy)
    }),
    inlineSummary: INDEX_HTML_INLINE_HANDLER_SUMMARY
  });
};

export function buildGlobalSurfaceInventory({ App, UI, root = globalThis }) {
  const appKeys = pickFunctionKeys(App);
  const uiKeys = pickFunctionKeys(UI);
  const appRequired = buildGroupStatus(appKeys, APP_GLOBAL_SURFACE_POLICY.required);
  const appTransitional = buildGroupStatus(appKeys, APP_GLOBAL_SURFACE_POLICY.transitional);
  const uiRequired = buildGroupStatus(uiKeys, UI_GLOBAL_SURFACE);
  const htmlEntries = buildHtmlEntryStatus(appKeys, uiKeys);
  const unexpectedApp = freeze(appKeys.filter((key) => !APP_GLOBAL_SURFACE_POLICY.required.includes(key) && !APP_GLOBAL_SURFACE_POLICY.transitional.includes(key)));
  const unexpectedUi = freeze(uiKeys.filter((key) => !UI_GLOBAL_SURFACE.includes(key)));
  const globalPresence = {};
  for (const key of [...LEGACY_GLOBAL_POLICY.required, ...LEGACY_GLOBAL_POLICY.debugOnly]) {
    globalPresence[key] = Object.prototype.hasOwnProperty.call(root, key) && root[key] != null;
  }
  return freeze({
    app: freeze({ keys: freeze(appKeys), required: freeze(appRequired), transitional: freeze(appTransitional), unexpected: unexpectedApp }),
    ui: freeze({ keys: freeze(uiKeys), required: freeze(uiRequired), unexpected: unexpectedUi }),
    html: htmlEntries,
    globals: freeze(globalPresence)
  });
}

export function attachSurfaceMetadata({ App, UI, inventory }) {
  const define = (target, key, value) => {
    if (!target || typeof target !== 'object') return;
    Object.defineProperty(target, key, { value, configurable: true, enumerable: false, writable: false });
  };
  define(App, '__surfacePolicy', APP_GLOBAL_SURFACE_POLICY);
  define(App, '__surfaceInventory', inventory?.app || null);
  define(App, '__htmlEntryPolicy', freeze({ app: INDEX_HTML_DIRECT_APP_METHODS, ui: INDEX_HTML_DIRECT_UI_METHODS, inlineSummary: INDEX_HTML_INLINE_HANDLER_SUMMARY }));
  define(App, '__htmlEntryInventory', inventory?.html || null);
  define(UI, '__surfacePolicy', UI_GLOBAL_SURFACE);
  define(UI, '__surfaceInventory', inventory?.ui || null);
  define(UI, '__htmlEntryPolicy', INDEX_HTML_DIRECT_UI_METHODS);
  define(UI, '__htmlEntryInventory', inventory?.html?.uiDirect || null);
  return inventory;
}

export function logSurfaceWarnings(inventory, { debugFlags, logger = console } = {}) {
  if (!debugFlags?.enabled && !debugFlags?.logFacadeMountSummary && !(debugFlags?.enableVerboseBootStatus)) return inventory;
  const hasAppMissing = Boolean(inventory?.app?.required?.missing?.length || inventory?.app?.transitional?.missing?.length);
  const hasUiMissing = Boolean(inventory?.ui?.required?.missing?.length);
  const hasHtmlEntryMissing = Boolean(
    inventory?.html?.appDirect?.missing?.length ||
    inventory?.html?.uiDirect?.missing?.length ||
    inventory?.html?.policyCoverage?.appOutsidePolicy?.length ||
    inventory?.html?.policyCoverage?.uiOutsidePolicy?.length
  );
  if (hasAppMissing || hasUiMissing || hasHtmlEntryMissing || inventory?.app?.unexpected?.length || inventory?.ui?.unexpected?.length) {
    logger.warn('[facade-surface] inventory warnings', inventory);
  }
  return inventory;
}
