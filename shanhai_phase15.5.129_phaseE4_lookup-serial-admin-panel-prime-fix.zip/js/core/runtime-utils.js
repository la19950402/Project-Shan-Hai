export function colorToRgba(color, alpha = 0.28) {
  const c = String(color || '').trim();
  if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(c)) {
    let hex = c.slice(1);
    if (hex.length === 3) hex = hex.split('').map(ch => ch + ch).join('');
    const n = parseInt(hex, 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  return `rgba(0, 229, 255, ${alpha})`;
}

export function fillProfileTemplate(str, vars = {}) {
  return String(str || '').replace(/\{(\w+)\}/g, (_, key) => (vars[key] ?? ''));
}

export function formatLocalDateKey(ts = Date.now()) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function formatLocalDateTime(ts) {
  const n = Number(ts) || 0;
  if (!n) return '—';
  const d = new Date(n);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function csvEscape(value) {
  const raw = value == null ? '' : String(value);
  return '"' + raw.replace(/"/g, '""') + '"';
}

export function downloadCsvFile(filename, rows) {
  const csv = rows.map(row => row.map(csvEscape).join(',')).join('\n');
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function downloadTextFile(filename, content, mimeType = 'text/plain;charset=utf-8;') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function svgDataUri(svg) {
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

export function makeBadgeSvg(mainEmoji, title, accent = '#00e5ff', sub = '') {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='420' height='420'>
    <defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop offset='0%' stop-color='#141927'/><stop offset='100%' stop-color='#080b12'/></linearGradient></defs>
    <rect width='420' height='420' rx='28' fill='url(#g)'/>
    <circle cx='210' cy='158' r='102' fill='none' stroke='${accent}' stroke-width='10' opacity='0.45'/>
    <text x='50%' y='42%' text-anchor='middle' dominant-baseline='middle' font-size='108'>${mainEmoji}</text>
    <text x='50%' y='72%' text-anchor='middle' fill='#ffffff' opacity='0.92' font-family='Noto Sans TC' font-size='30' font-weight='700'>${title}</text>
    <text x='50%' y='82%' text-anchor='middle' fill='${accent}' opacity='0.92' font-family='Noto Sans TC' font-size='22'>${sub}</text>
  </svg>`;
  return svgDataUri(svg);
}

export function getMostRecentNoonTimestamp(nowTs = Date.now()) {
  const d = new Date(nowTs);
  const noon = new Date(d);
  noon.setHours(12, 0, 0, 0);
  if (d.getTime() < noon.getTime()) noon.setDate(noon.getDate() - 1);
  return noon.getTime();
}

export function getNextNoonTimestamp(nowTs = Date.now()) {
  const d = new Date(nowTs);
  const noon = new Date(d);
  noon.setHours(12, 0, 0, 0);
  if (d.getTime() >= noon.getTime()) noon.setDate(noon.getDate() + 1);
  return noon.getTime();
}

export function isSameNoonWindow(lastTime, nowTs = Date.now()) {
  const last = Number(lastTime) || 0;
  if (!last) return false;
  return last >= getMostRecentNoonTimestamp(nowTs);
}

export function getDailyResetAnchor(data = {}, nowTs = Date.now()) {
  return Math.max(getMostRecentNoonTimestamp(nowTs), Number(data?.daily_reset_override_at) || 0);
}

export function getBattleResetAnchor(data = {}, nowTs = Date.now()) {
  return Math.max(getMostRecentNoonTimestamp(nowTs), Number(data?.battle_reset_override_at) || 0);
}

export function getTodayDailyRewardCount(data = {}, nowTs = Date.now()) {
  const anchor = getDailyResetAnchor(data, nowTs);
  const storedCountDate = Number(data?.today_quiz_reward_date) || 0;
  const storedCount = Number(data?.today_quiz_reward_count);
  if (Number.isFinite(storedCount) && storedCountDate >= anchor) {
    return Math.max(0, storedCount);
  }
  const events = Array.isArray(data?.reward_events) ? data.reward_events : [];
  return events.filter(evt => evt && evt.type === 'daily_correct' && (Number(evt.timestamp) || 0) >= anchor).length;
}

export function getTodayDailyRemaining(data = {}, nowTs = Date.now()) {
  return Math.max(0, 10 - getTodayDailyRewardCount(data, nowTs));
}

export function hasBattleAttemptRemaining(data = {}, nowTs = Date.now()) {
  const anchor = getBattleResetAnchor(data, nowTs);
  const lastBattle = Number(data?.last_battle_time) || 0;
  if (lastBattle >= anchor) return false;
  const used = data?.today_battle_used === true;
  const usedDate = Number(data?.today_battle_date) || 0;
  if (used && usedDate >= anchor) return false;
  return true;
}

export function formatCountdown(ms) {
  const remain = Math.max(0, Number(ms) || 0);
  const h = Math.floor(remain / 3600000);
  const m = Math.floor((remain % 3600000) / 60000);
  return `${h} 小時 ${m} 分鐘`;
}
