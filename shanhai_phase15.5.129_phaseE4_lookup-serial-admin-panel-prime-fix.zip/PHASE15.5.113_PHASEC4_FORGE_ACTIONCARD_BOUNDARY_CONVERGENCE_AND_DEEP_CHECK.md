# PHASE15.5.113 — Phase C-4 Forge / Action-Card Boundary Convergence + Deep Check

## 本輪目標
把 `forge / action-card / pending forge` 這條仍殘留在 `js/main.entry.js` 的邊界，再往模組收一輪，避免主入口繼續持有：

- 巡堂道具模式啟動
- 巡堂道具卡執行
- forged action card 綁定成功流程
- `handleCardScan()` 中 `student_prop / forge` 兩段分支本體

本輪維持原則：

- **不改 BOOT_ID / BUILD_TAG**
- **不改 canonical active chain**
- **不碰大 UI 結構**
- **先收邏輯邊界，再做保存匯流點瘦身**

---

## 本輪實際改動

### 1. `js/main.entry.js`
把下面這些從主入口本體撤出，只保留 delegate / orchestration：

- `handleCardScan()` 內的 `student_prop` 分支
- `handleCardScan()` 內的 `forge` 分支
- `startStudentPropScan()`
- `executeStudentPropAction()`

現在主入口改成：

- `student_prop` -> `teacherActionsApi.handleStudentPropScan.call(this, rawKey)`
- `forge` -> `teacherActionsApi.handleForgeScan.call(this, rawKey)`
- `startStudentPropScan()` -> delegate 到 `teacherActionsApi`
- `executeStudentPropAction()` -> delegate 到 `teacherActionsApi`

### 2. `js/modules/teacher-actions.js`
新增並承接以下 forge / action-card 專責流程：

- `handleForgeScan(rawKey)`
- `startStudentPropScan()`
- `handleStudentPropScan(rawKey)`
- `executeStudentPropAction(action)`

這代表：

- forged action card 綁定成功流程，已不在主入口
- action-card 掃描後切學生 / 套用效果，也已不在主入口
- 巡堂道具模式的啟動與效果執行，正式有模組邊界

### 3. `teacherActionsApi` 掛載依賴補齊
主入口在 mount `teacherActionsApi` 時，補入：

- `getActionCardPayload`
- `bindPendingForgeActionCard`
- `resolveStudentRecordFromScanKey`

因此資料儲存層仍由 `student-access` 承接，老師行為邊界則由 `teacher-actions` 統一承接。

### 4. 新增深檢腳本
新增：

- `scripts/deep-check-phasec-forge-actioncard-boundaries.mjs`

這支腳本用來確認：

- 主入口是否真的只剩 delegate
- `student_prop / forge` 是否真的已移到 `teacher-actions`
- action-card storage 是否仍留在 `student-access`
- 不是只把寫法換個名字、實際邊界沒收斂

---

## 量化結果

### 主入口規模
- `js/main.entry.js`: **5605 → 5522 行**

### 主入口直接 DB 操作
- `getDoc(...)`: **0**
- `getDocs(...)`: **0**
- `setDoc(...)`: **0**

### 主入口保存匯流點引用
- `main_saveToDB_count`: **15 → 13**

這一輪最重要的不是再把 Firestore 讀寫降成 0（上一輪已達成），而是把 **forge / action-card / pending forge** 這種仍由主入口直接持有的高風險行為邊界，再收進模組。

---

## 深度檢查結果

### Syntax / active chain
- `node --check js/modules/teacher-actions.js` ✅
- `node --check js/main.entry.js` ✅
- `scripts/validate-active-chain.mjs` ✅

### 既有深檢
- `scripts/deep-check-active-flow.mjs` ✅
- `scripts/deep-check-phasec-collection-boundaries.mjs` ✅
- `scripts/deep-check-phasec-evolution-boundaries.mjs` ✅
- `scripts/deep-check-phasec-collection-editor-boundaries.mjs` ✅

### 本輪新增深檢
- `scripts/deep-check-phasec-forge-actioncard-boundaries.mjs` ✅

### 深檢關鍵結論
1. `main.entry.js` 仍維持 `getDoc/getDocs/setDoc = 0`
2. `student_prop / forge` 已不再由主入口直接處理本體
3. `teacher-actions.js` 已正式承接：
   - 巡堂道具模式啟動
   - 巡堂道具執行
   - forged card 綁定成功流程
4. `student-access.js` 仍保有 action-card storage 職責，分工正確
5. canonical `BOOT_ID / BUILD_TAG` **未變更**

---

## 目前階段判定

### 已完成
- **Phase A**：student / token / mirror / account 主鏈基本完成
- **Phase B**：summary / batch bulk progress 收斂完成
- **Phase C-1**：collection boundary 完成
- **Phase C-2**：evolution boundary 完成
- **Phase C-3**：collection editor UI boundary 完成
- **Phase C-4**：forge / action-card / pending forge boundary 完成

### 現在所在位置
目前專案已經從「主入口仍持有多條高風險行為鏈」進一步推進到：

> **主入口幾乎只剩 orchestration + 保存匯流點 + 少量 legacy 邊界。**

這代表目前真正剩下的核心，不再是「主入口還有多少查詢」，而是：

1. `saveToDB()` 匯流點仍偏大
2. 少數 teacher/student 舊式依賴鏈還在
3. archive / deploy governance / Firestore Rules 還沒進最後治理收口

---

## 剩餘主要風險

### 1. `saveToDB()` 仍是主入口最大保存匯流點
雖然主入口直接 Firestore 讀寫已清空，但正式保存仍高度集中在 `saveToDB()`。

這表示：
- 邊界已比前面乾淨很多
- 但保存責任仍是下一個真正的高值收斂點

### 2. teacher / student 舊式依賴鏈仍需回掃
目前 `teacher-actions / student / batch / auth` 雖然已比早期清楚很多，但還是存在一些舊式依賴方式，需要後續再做 Phase D 回掃。

### 3. archive / deploy governance / rules 未收口
這些不會立刻炸主鏈，但會持續增加：
- 誤修風險
- grep 混淆
- 部署前檢查成本
- Firestore Rules 對照成本

---

## 建議的下一階段

### Phase C-5：`saveToDB()` 匯流點瘦身
建議下一輪直接做這件事，因為它現在是最值得收的主入口殘留責任。

優先方向：
- 盤點 `saveToDB()` 內各種保存分支
- 先把 student / teacher / public summary / mirror 類可切出的分支，抽成 helper 或模組化 handler
- 讓主入口保留「保存協調」，而不是直接持有太多分支細節

### 接續規劃
- **Phase D**：`batch / auth / student` 舊式依賴鏈回掃
- **Phase E**：archive / deploy governance / Firestore Rules 收尾

---

## 本輪一句話結論

**Phase C-4 完成後，主入口已不再直接持有 forge / action-card / pending forge 的核心行為本體；現在最合理的下一步，是轉進 `saveToDB()` 匯流點瘦身。**
