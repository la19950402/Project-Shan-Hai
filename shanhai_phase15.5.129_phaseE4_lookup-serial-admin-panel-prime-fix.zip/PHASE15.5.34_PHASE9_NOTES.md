# Phase 15.5.34 — Risk Reduction Phase 9

## Focus
- Continue reducing active-chain `this.*` dependency risk without adding globals
- Re-check teacher manual XP / debuff save chain hardening
- Convert `auth` and `batch` active modules to module-local API flow

## Changes
1. `auth.js`
   - internal self-calls now go through `authApi` instead of `this`
   - `openRequestedAdminPanel` and `lockStudentAccess` are injected explicitly from `App`
2. `batch.js`
   - internal self-calls now go through `batchApi`
   - cross-module helpers are injected explicitly: `startWebNfc`, `saveToDB`, `syncStudentMirrorForSerial`, `applyDataMigration`, `getActiveTokenForSerial`, `checkDeathTrigger`, `processEvolution`
3. `teacher-actions.js`
   - added `persistTeacherData(data, explicitSerial)`
   - manual XP / debuff / compensation flows now save with an explicit target serial
   - reduces risk of saving against stale `currentUid`
4. `main.entry.js`
   - active chain bumped to `phase15phase9`
   - `createAuthModule` and `createBatchModule` now receive explicit helper injections

## Why this is low-risk
- no new globals
- no new entry-file variants
- keeps canonical active chain
- scope limited to active modules and dependency wiring
