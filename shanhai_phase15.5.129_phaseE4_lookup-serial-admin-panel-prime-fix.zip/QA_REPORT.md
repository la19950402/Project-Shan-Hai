# QA REPORT

- PASS syntax: `js/core/api-surface.js`
- PASS syntax: `js/core/app-facade.js`
- PASS syntax: `js/core/debug-flags.js`
- PASS syntax: `js/core/firebase.js`
- PASS syntax: `js/core/global-bridge.js`
- PASS syntax: `js/core/state.js`
- PASS syntax: `js/core/ui.js`
- PASS syntax: `js/main.js`
- PASS syntax: `js/modules/auth.js`
- PASS syntax: `js/modules/batch.js`
- PASS syntax: `js/modules/battle.js`
- PASS syntax: `js/modules/content-profile.js`
- PASS syntax: `js/modules/quiz.js`
- PASS syntax: `js/modules/ranking.js`
- PASS syntax: `js/modules/shop.js`
- PASS syntax: `js/modules/student.js`
- PASS syntax: `js/modules/teacher-actions.js`
- PASS syntax: `js/modules/zones.js`

## Spot checks
- PASS: null-safe scanNfcBtn listener
- PASS: null-safe submitRegBtn listener
- PASS: null-safe writeNfcLinkBtn listener
- PASS: auth callback try/catch
- PASS: snapshot null-safe admin check
- PASS: version token updated