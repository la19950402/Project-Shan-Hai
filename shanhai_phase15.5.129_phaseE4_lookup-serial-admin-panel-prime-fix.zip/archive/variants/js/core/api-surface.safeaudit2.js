/*
 * ARCHIVED VARIANT NOTICE
 * File: js/core/api-surface.safeaudit2.js
 * Status: archived / rollback-only
 * Active chain: js/bootstrap-entry.js -> js/main.entry.js
 * Active core: js/core/app-facade.js + js/core/api-surface.js
 * Reason: historical recovery / forensic reference; do not edit before checking canonical active files.
 */
import { APP_FACADE_METHODS } from './app-facade.quizbankfix.js?v=phase15quizbanksafe1';
const flattenFacadeMethods = (groups) => {
  const out = [];
  for (const group of groups) {
    if (Array.isArray(group)) out.push(...group);
  }
  return [...new Set(out)].sort();
};

const freeze = (value) => Object.freeze(value);

export const UI_GLOBAL_SURFACE = freeze([
  'show','hide','showModal','hideModal','toast','alert','confirm','showImageModal',
  'updateDragonImage','updateCollectionGallery','updateStudentAttributes','renderRadarChartRaw','updateStatusContainer','updatePanel'
]);

export const APP_GLOBAL_SURFACE_POLICY = freeze({
  required: freeze(flattenFacadeMethods([
    APP_FACADE_METHODS.auth,
    APP_FACADE_METHODS.studentApp,
    APP_FACADE_METHODS.teacherActions,
    APP_FACADE_METHODS.batch,
    APP_FACADE_METHODS.battle,
    APP_FACADE_METHODS.shop,
    APP_FACADE_METHODS.quiz,
    APP_FACADE_METHODS.ranking,
    APP_FACADE_METHODS.contentProfile,
    APP_FACADE_METHODS.zones
  ])),
  transitional: freeze([
    ...Object.keys(APP_FACADE_METHODS.aliases.battle),
    ...Object.keys(APP_FACADE_METHODS.aliases.auth),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.shop),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.quiz),
    ...Object.keys(APP_FACADE_METHODS.legacyAliases.zones)
  ].sort())
});

export const LEGACY_GLOBAL_POLICY = freeze({
  required: freeze(['App','UI','forceOpenCardForge','ShanHaiSystem']),
  debugOnly: freeze(['__clearAssetUrlCache'])
});

const pickFunctionKeys = (obj) => Object.keys(obj || {}).filter((key) => typeof obj[key] === 'function').sort();

const buildGroupStatus = (surfaceKeys, expected) => ({
  present: expected.filter((key) => surfaceKeys.includes(key)),
  missing: expected.filter((key) => !surfaceKeys.includes(key))
});

export function buildGlobalSurfaceInventory({ App, UI, root = globalThis }) {
  const appKeys = pickFunctionKeys(App);
  const uiKeys = pickFunctionKeys(UI);
  const appRequired = buildGroupStatus(appKeys, APP_GLOBAL_SURFACE_POLICY.required);
  const appTransitional = buildGroupStatus(appKeys, APP_GLOBAL_SURFACE_POLICY.transitional);
  const uiRequired = buildGroupStatus(uiKeys, UI_GLOBAL_SURFACE);
  const unexpectedApp = appKeys.filter((key) => !APP_GLOBAL_SURFACE_POLICY.required.includes(key) && !APP_GLOBAL_SURFACE_POLICY.transitional.includes(key));
  const unexpectedUi = uiKeys.filter((key) => !UI_GLOBAL_SURFACE.includes(key));
  const globalPresence = {};
  for (const key of [...LEGACY_GLOBAL_POLICY.required, ...LEGACY_GLOBAL_POLICY.debugOnly]) {
    globalPresence[key] = Object.prototype.hasOwnProperty.call(root, key) && root[key] != null;
  }
  return freeze({
    app: freeze({ keys: freeze(appKeys), required: freeze(appRequired), transitional: freeze(appTransitional), unexpected: freeze(unexpectedApp) }),
    ui: freeze({ keys: freeze(uiKeys), required: freeze(uiRequired), unexpected: freeze(unexpectedUi) }),
    globals: freeze(globalPresence)
  });
}

export function attachSurfaceMetadata({ App, UI, inventory }) {
  const define = (target, key, value) => {
    if (!target || typeof target !== 'object') return;
    Object.defineProperty(target, key, { value, configurable: true, enumerable: false, writable: false });
  };
  define(App, '__surfacePolicy', APP_GLOBAL_SURFACE_POLICY);
  define(App, '__surfaceInventory', inventory?.app || null);
  define(UI, '__surfacePolicy', UI_GLOBAL_SURFACE);
  define(UI, '__surfaceInventory', inventory?.ui || null);
  return inventory;
}

export function logSurfaceWarnings(inventory, { debugFlags, logger = console } = {}) {
  if (!debugFlags?.enabled && !debugFlags?.logFacadeMountSummary && !(debugFlags?.enableVerboseBootStatus)) return inventory;
  if (inventory?.app?.missing?.length || inventory?.ui?.missing?.length || inventory?.app?.unexpected?.length || inventory?.ui?.unexpected?.length) {
    logger.warn('[facade-surface] inventory warnings', inventory);
  }
  return inventory;
}
