/*
 * ARCHIVED VARIANT NOTICE
 * File: js/modules/battle.stability1.js
 * Status: archived / rollback-only
 * Active chain: js/bootstrap-entry.js -> js/main.entry.js
 * Active core: js/core/app-facade.js + js/core/api-surface.js
 * Reason: historical recovery / forensic reference; do not edit before checking canonical active files.
 */
import { currentState, quizSession } from "../core/state.js?v=phase15quizbanksafe1";
import { UI } from "../core/ui.js?v=phase15quizbanksafe1";

export function createBattleModule(deps = {}) {
  const BATTLE_TOWER_DOC_ID = '_BATTLE_TOWER_BOSS_';

  function normalizeQuizQuestionRecord(raw = {}, id = '') {
    const source = raw && typeof raw === 'object' ? raw : {};
    const normalized = { ...source, id: id || source.id || '' };
    normalized.question = String(source.question || source.questionText || source.q || source.title || source.prompt || source.stem || source.text || '').trim();

    const parseAnswerIndex = (value) => {
      if (typeof value === 'number' && Number.isFinite(value)) {
        return value >= 1 && value <= 4 ? value - 1 : value;
      }
      const str = String(value ?? '').trim();
      if (!str) return -1;
      if (/^[1-4]$/.test(str)) return Number(str) - 1;
      if (/^[A-Da-d]$/.test(str)) return str.toUpperCase().charCodeAt(0) - 65;
      return -1;
    };

    let answerIndex = -1;
    const answerCandidates = [
      source.answer,
      source.correctAnswer,
      source.correct_option,
      source.correctOption,
      source.correctIndex,
      source.correct,
      source.correct_choice,
      source.correctChoice
    ];
    for (const candidate of answerCandidates) {
      answerIndex = parseAnswerIndex(candidate);
      if (answerIndex >= 0) break;
    }

    const optionCandidates = Array.isArray(source.options)
      ? source.options
      : Array.isArray(source.choices)
        ? source.choices
        : Array.isArray(source.selections)
          ? source.selections
          : [source.option1, source.option2, source.option3, source.option4, source.a, source.b, source.c, source.d];

    normalized.options = optionCandidates
      .slice(0, 4)
      .map((opt, idx) => {
        if (typeof opt === 'string') return { text: opt.trim(), isCorrect: idx === answerIndex };
        return {
          text: String(opt?.text ?? opt?.label ?? opt ?? '').trim(),
          isCorrect: !!opt?.isCorrect || idx === answerIndex
        };
      })
      .filter((opt) => !!opt.text);

    if (!normalized.unit && source.category) normalized.unit = source.category;
    return normalized;
  }

  function isPlayableQuizQuestion(q = {}) {
    if (!String(q.question || '').trim()) return false;
    const options = Array.isArray(q.options) ? q.options : [];
    if (options.length < 2) return false;
    if (!options.every((opt) => String(opt?.text || '').trim())) return false;
    return options.some((opt) => !!opt?.isCorrect);
  }


  function matchesBattleAudienceQuestion(q, gradeInfo) {
    if (!q) return false;
    if (gradeInfo?.isSupportClass) {
      return quizMatchesStudentGrade(q, '學習扶助班', true);
    }
    return quizMatchesStudentGrade(q, gradeInfo?.gradeToken, false);
  }

  async function pickRandomGatekeeperQuestion(gradeInfo) {
    const s = await getDocs(collection(db, 'quiz_bank'));
    const pool = [];
    const fallback = [];
    s.forEach(d => {
      if (d.id === BATTLE_TOWER_DOC_ID) return;
      const q = normalizeQuizQuestionRecord(d.data() || {}, d.id);
      if (!isQuizEnabled(q) || !isPlayableQuizQuestion(q)) return;
      if (matchesBattleAudienceQuestion(q, gradeInfo)) pool.push(q);
      else if (!/學習扶助/.test(String(q.grade || q.class_name || q.gradeName || '').trim())) fallback.push(q);
    });
    const candidatePool = pool.length ? pool : fallback;
    return candidatePool.length ? candidatePool[Math.floor(Math.random() * candidatePool.length)] : null;
  }

  const {
    db,
    doc,
    getDoc,
    getDocs,
    collection,
    writeBatch,
    setDoc,
    deleteDoc,
    CONSTANTS,
    TYPE_INFO,
    COLLECTION_NAME,
    STUDENT_PAGE_COLLECTION,
    hasBattleAttemptRemaining,
    buildBattleTeamForStudent,
    getDragonVisual,
    splitBattleVisualRef,
    buildCollectionDisplayItem,
    getProfileAttributeInfo,
    getBattleMonDiceCount,
    getBattleStageLabel,
    getBattleMonStage,
    isDirectVisualSource,
    hydrateStorageImages,
    getStudentGradeInfo,
    isQuizEnabled,
    quizMatchesStudentGrade,
    isCatProfile,
    getProfileLabels,
    normalizeBossDiceCount,
    createBattleDiceFaces,
    applyProfileStaticTexts,
    fillProfileTemplate,
    getBattleResetAnchor,
    formatCountdown,
    getNextNoonTimestamp,
    getBattleBossConfigForStudent,
    getBattleAudienceOptions,
    getBattleBossConfigForAudience,
    normalizeBattleTowerDoc,
    getCatBossVisualByType,
    __updateLegendarySelectPreview
  } = deps;

  return {
    async startBattleChallenge() {
      if (!currentState.studentData) {
        UI.alert('尚未載入學生資料，請重新整理後再試。', '無法挑戰');
        return;
      }
      if (typeof buildBattleTeamForStudent !== 'function') {
        UI.alert('戰鬥模組初始化不完整，請重新整理頁面後再試。', '系統異常');
        return;
      }
      if (!hasBattleAttemptRemaining(currentState.studentData)) {
        UI.alert('今日 BOSS 挑戰次數已用完，將於中午 12:00 重置。若老師已手動重置，請重新整理後再試。', '今日挑戰已用完');
        this.updateBattleTowerStatus();
        return;
      }
      try {
        await this.updateBattleTowerStatus(currentState.studentData);
      } catch (e) {
        console.warn('[startBattleChallenge] refresh status failed:', e);
      }
      if (!currentState.currentBattleBoss) {
        UI.alert('目前沒有可挑戰的 Boss 設定。請先確認老師端已發布今日 Boss，或重新整理後再試。', '無法挑戰');
        return;
      }
      const g = document.getElementById('bsGrid');
      if (!g) return;
      g.innerHTML = '';

      const builtTeam = buildBattleTeamForStudent(currentState.studentData);
      const team = Array.isArray(builtTeam) ? builtTeam : [];
      const selectableTeam = team.filter(i => i && !i.isHologram && i.type !== 'dead_dragon');
      if (!selectableTeam.length) {
        UI.alert('目前沒有可出戰的龍獸或夥伴，請先確認圖鑑中有可用成員。', '無法挑戰');
        return;
      }

      team.forEach((m) => {
        if (m && m.type === 'dragon' && !m.img_file) {
          try {
            const vis = getDragonVisual({
              dragon_path: m.path || m.dragon_path,
              dragon_stage: m.stage ?? m.dragon_stage,
              attributes: m.stats || m.attributes || {}
            });
            const visualRef = splitBattleVisualRef(vis?.file, vis?.img || m.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
            if (!m.img_file && visualRef.img_file) m.img_file = visualRef.img_file;
            if (!m.img && visualRef.img) m.img = visualRef.img;
          } catch (e) {}
        }
      });

      team.forEach((i, idx) => {
        if (!i || i.isHologram || i.type === 'dead_dragon') return;
        const tk = i.type === 'legendary' ? 'neutral' : (i.typeKey || i.element || i.path || 'neutral');
        let disp = buildCollectionDisplayItem(i, currentState.studentData);
        if (!disp && i.type === 'hidden_egg') {
          const hiddenMeta = CONSTANTS.HIDDEN_EGGS[String(i.hiddenEggId || '')] || currentState.studentData?.active_hidden_egg || {};
          const hiddenAttr = getProfileAttributeInfo(hiddenMeta.requiredAttr || tk, currentState.studentData);
          disp = { title: i.name || (hiddenMeta.beastName ? `${hiddenMeta.beastName}｜當前出戰` : (hiddenMeta.name || '特殊異獸蛋')), color: hiddenAttr.color, img: i.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG };
        }
        const src = (disp && disp.img) || i.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        const nm = (disp && disp.title) || i.name || '---';
        const cColor = TYPE_INFO[tk] ? TYPE_INFO[tk].color : '#ccc';
        const diceCount = getBattleMonDiceCount(i, currentState.studentData);
        const stageLabel = getBattleStageLabel(getBattleMonStage(i, currentState.studentData), currentState.studentData);
        const fileBase = i.img_file || '';
        const useAsset = fileBase && !isDirectVisualSource(fileBase);
        const imgSrc = useAsset ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (src || fileBase || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
        const dataAttr = useAsset ? ('data-asset="' + String(fileBase).replace(/"/g, '&quot;') + '"') : '';
        g.innerHTML += `<div class="team-item-btn" id="bsItem_${idx}" onclick="App.selectBattleMon(${idx})" style="border-color:${cColor};"><img src="${imgSrc}" ${dataAttr}><span style="font-size:0.7em; color:${cColor}; margin-top:5px; text-align:center;">${nm}<br><small style="opacity:0.8;">${stageLabel}｜${diceCount}骰</small></span></div>`;
      });

      currentState.currentBattleTeam = team;
      currentState.selectedBattleMonIndex = -1;
      try { hydrateStorageImages(g); } catch (e) { console.warn('[startBattleChallenge] hydrate images failed:', e); }
      UI.showModal('battleSelectionModal');
    },

    selectBattleMon(idx) {
      currentState.selectedBattleMonIndex = idx;
      currentState.selectedBattleMon = Array.isArray(currentState.currentBattleTeam) ? currentState.currentBattleTeam[idx] || null : null;
      document.querySelectorAll('#bsGrid .team-item-btn').forEach(e => e.style.background = 'rgba(0,0,0,0.6)');
      const item = document.getElementById(`bsItem_${idx}`);
      if (item) item.style.background = 'rgba(255,0,85,0.3)';
    },

    async confirmBattleSelection() {
      if (!hasBattleAttemptRemaining(currentState.studentData)) {
        UI.alert('今日 BOSS 挑戰次數已用完，請勿重複點擊。', '今日挑戰已用完');
        this.updateBattleTowerStatus();
        return;
      }
      if (currentState.selectedBattleMonIndex === -1) return UI.toast('請選擇出戰龍獸！');
      const btn = document.querySelector('#battleSelectionModal .btn-solid');
      if (!btn) {
        UI.alert('找不到出戰確認按鈕，請重新整理頁面後再試。', '系統異常');
        return;
      }
      btn.disabled = true;
      btn.innerText = '讀取中...';

      try {
        let b = currentState.currentBattleBoss;
        if (!b) {
          try {
            await this.checkBattleTowerStatus(currentState.studentData);
            b = currentState.currentBattleBoss;
          } catch (e) {
            console.warn('[confirmBattleSelection] refresh boss failed:', e);
          }
        }
        if (!b) {
          UI.hideModal('battleSelectionModal');
          UI.alert('目前沒有可挑戰的 Boss，請稍後重新整理再試。', '無法挑戰');
          return;
        }
        const selectedMon = Array.isArray(currentState.currentBattleTeam) ? currentState.currentBattleTeam[currentState.selectedBattleMonIndex] : null;
        if (!selectedMon || selectedMon.isHologram || selectedMon.type === 'dead_dragon') {
          UI.toast('請先選擇有效的出戰成員！');
          return;
        }
        let qD = null;
        const gatekeeperQuizId = String(b.gatekeeperQuizId || b.quizId || b.quiz_id || b.questionId || 'random');
        const gradeInfo = getStudentGradeInfo(currentState.studentData || {});
        if (gatekeeperQuizId === 'random' || !gatekeeperQuizId) {
          qD = await pickRandomGatekeeperQuestion(gradeInfo);
        } else {
          const s = await getDoc(doc(db, 'quiz_bank', gatekeeperQuizId));
          if (s.exists()) {
            const normalized = normalizeQuizQuestionRecord(s.data() || {}, s.id || gatekeeperQuizId);
            if (isQuizEnabled(normalized) && isPlayableQuizQuestion(normalized)) {
              qD = normalized;
            }
          }
          if (!qD) {
            console.warn('[battle] configured gatekeeper quiz is missing or invalid, fallback to random', gatekeeperQuizId);
            qD = await pickRandomGatekeeperQuestion(gradeInfo);
          }
        }

        UI.hideModal('battleSelectionModal');
        if (!qD) return UI.alert('題庫中沒有可用的 Boss 題目，或目前指定題目格式不相容。\n請老師先確認題庫題目與 Boss 指定設定。', '挑戰失敗');

        quizSession.mode = 'battle';
        quizSession.questions = [qD];
        quizSession.currentIndex = 0;
        quizSession.score = 0;

        const titleEl = document.getElementById('quizPlayTitle');
        if (titleEl) {
          titleEl.innerText = isCatProfile(currentState.studentData) ? '🐾 領域防衛問答' : '⚔️ 守門員挑戰 ⚔️';
          titleEl.style.color = 'var(--danger)';
        }
        const modalContent = document.querySelector('#quizPlayModal .modal-content');
        if (modalContent) modalContent.style.borderColor = 'var(--danger)';

        UI.hide('quizResultArea');
        UI.show('quizPlayArea');
        UI.showModal('quizPlayModal');
        this.renderQuizQuestion();
      } catch (e) {
        console.error(e);
        UI.alert('載入戰鬥發生錯誤：' + e.message, '系統異常');
      } finally {
        btn.disabled = false;
        btn.innerText = '確認出戰，前往答題';
      }
    },

    async handleBattleQuizAnswer(isCorrect) {
      UI.hideModal('quizPlayModal');
      if (isCorrect) {
        UI.toast('✅ 答題正確！進入戰鬥！');
        this.prepareBattleArena();
      } else {
        UI.alert('答錯了！守門員將你擊退。\n（已消耗今日挑戰次數，請明日再來！）', '挑戰失敗');
        const data = JSON.parse(JSON.stringify(currentState.studentData || {}));
        data.last_battle_time = Date.now();
        try {
          const saved = await this.saveToDB(data);
          this.refreshStudentRewardPanel(saved || data, true);
        } catch (e) {
          console.error('[handleBattleQuizAnswer] save failed:', e);
          this.refreshStudentRewardPanel(currentState.studentData || data, true);
          UI.toast('戰鬥結果保存失敗，請通知老師協助處理');
        }
      }
    },

    prepareBattleArena() {
      const b = currentState.currentBattleBoss;
      if (!b) {
        UI.alert('目前找不到 Boss 設定，請重新整理後再試。', '無法開始戰鬥');
        return;
      }
      const pI = currentState.selectedBattleMonIndex;
      const team = Array.isArray(currentState.currentBattleTeam) && currentState.currentBattleTeam.length
        ? currentState.currentBattleTeam
        : buildBattleTeamForStudent(currentState.studentData);
      const fallbackTeam = typeof buildBattleTeamForStudent === 'function' ? (buildBattleTeamForStudent(currentState.studentData) || []) : [];
      const pM = (currentState.selectedBattleMon || team[pI] || team[0] || fallbackTeam[0]);
      if (!pM) {
        UI.alert('目前找不到可出戰的成員，請重新選擇後再試。', '無法開始戰鬥');
        return;
      }
      const labels = getProfileLabels(currentState.studentData);

      const pTk = (pM.type === 'legendary') ? 'neutral' : (pM.typeKey || pM.element || pM.path || 'neutral');
      const playerDiceCount = getBattleMonDiceCount(pM, currentState.studentData);
      const bossDiceCount = normalizeBossDiceCount(b?.bossDiceCount, 3);

      const pImgEl = document.getElementById('baPlayerImg');
      if (pImgEl) {
        pImgEl.removeAttribute('data-asset');
        const disp = buildCollectionDisplayItem(pM, currentState.studentData);
        const fileBase = String(pM.img_file || '').trim();
        let pSrc = (disp && disp.img) || pM.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;
        if (fileBase && !isDirectVisualSource(fileBase)) {
          pSrc = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          pImgEl.setAttribute('data-asset', fileBase);
        } else if (fileBase && isDirectVisualSource(fileBase)) {
          pSrc = fileBase;
        }
        pImgEl.src = pSrc;
      }

      const pInfo = getProfileAttributeInfo(pTk, currentState.studentData);
      const pTypeEl = document.getElementById('baPlayerType');
      if (pTypeEl) {
        pTypeEl.innerText = pInfo?.name || '無';
        pTypeEl.style.color = pInfo?.color || '#fff';
      }
      const playerLabel = document.getElementById('baPlayerLabel');
      if (playerLabel) playerLabel.innerText = `${isCatProfile(currentState.studentData) ? '我的夥伴' : '我的龍獸'}（${playerDiceCount}骰）`;

      const bImgEl = document.getElementById('baBossImg');
      if (bImgEl) {
        bImgEl.removeAttribute('data-asset');
        const catBossVis = isCatProfile(currentState.studentData) ? getCatBossVisualByType(b?.typeKey || 'metal') : null;
        const fileBase = String(b?.img_file || '').trim();
        let bSrc = isCatProfile(currentState.studentData) ? (catBossVis?.file || catBossVis?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG) : (b?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
        if (fileBase && !isDirectVisualSource(fileBase) && !isCatProfile(currentState.studentData)) {
          bSrc = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          bImgEl.setAttribute('data-asset', fileBase);
        } else if (fileBase && isDirectVisualSource(fileBase)) {
          bSrc = fileBase;
        }
        bImgEl.src = bSrc;
      }

      const bInfo = getProfileAttributeInfo(b?.typeKey || 'neutral', currentState.studentData);
      const bTypeEl = document.getElementById('baBossType');
      if (bTypeEl) {
        bTypeEl.innerText = bInfo?.name || '無';
        bTypeEl.style.color = bInfo?.color || '#fff';
      }
      const bossLabel = document.getElementById('baBossLabel');
      if (bossLabel) bossLabel.innerText = `${labels.bossLabel || '塔中首領'}（${bossDiceCount}骰）`;

      createBattleDiceFaces('baPlayerDice', playerDiceCount);
      createBattleDiceFaces('baBossDice', bossDiceCount);
      document.querySelectorAll('#battleArenaModal .dice').forEach(d => { d.innerText = '?'; d.classList.remove('rolling'); });
      const defaults = ['baPlayerMult', 'baPlayerScore', 'baBossMult', 'baBossScore', 'baResultText'];
      const values = { baPlayerMult: '1.0x', baPlayerScore: '0', baBossMult: '1.0x', baBossScore: '0', baResultText: '---' };
      defaults.forEach(id => { const el = document.getElementById(id); if (el) el.innerText = values[id]; });
      const rewardSummaryEl = document.getElementById('baRewardSummary');
      if (rewardSummaryEl) { rewardSummaryEl.style.display = 'none'; rewardSummaryEl.innerHTML = ''; }
      const confirmBtn = document.getElementById('baConfirmBtn');
      if (confirmBtn) { confirmBtn.style.display = 'none'; confirmBtn.disabled = false; }
      const mainStage = document.getElementById('baMainStage');
      if (mainStage) mainStage.style.display = 'block';
      const settlementPanel = document.getElementById('baSettlementPanel');
      if (settlementPanel) settlementPanel.style.display = 'none';
      const settlementTitle = document.getElementById('baSettlementTitle');
      if (settlementTitle) settlementTitle.innerText = isCatProfile(currentState.studentData) ? '🐾 防衛結果結算' : '🏆 討伐獎勵結算';
      const settlementDesc = document.getElementById('baSettlementDesc');
      if (settlementDesc) settlementDesc.innerText = isCatProfile(currentState.studentData) ? '請確認本次領域防衛結果與獎勵，再退出返回學生面板。' : '請確認本次 Boss 討伐結果與獎勵，再退出返回學生面板。';
      ['baSettlementResult', 'baSettlementReward', 'baSettlementCoins', 'baSettlementXP', 'baSettlementLog'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerText = id === 'baSettlementCoins' || id === 'baSettlementXP' ? '0' : '---';
      });
      const xpLabel = document.getElementById('baSettlementXpLabel');
      if (xpLabel) xpLabel.innerText = `目前${getProfileLabels(currentState.studentData).xp || (isCatProfile(currentState.studentData) ? '成長能量' : '進化能量')}`;
      applyProfileStaticTexts(currentState.studentData, true);

      currentState.battleData = {
        playerRoll: 0,
        bossRoll: 0,
        pType: pTk,
        bType: b?.typeKey || 'neutral',
        playerDiceCount,
        bossDiceCount
      };

      const actionBtn = document.getElementById('baActionBtn');
      if (actionBtn) { actionBtn.style.display = 'block'; actionBtn.disabled = false; }
      const confirmBtn2 = document.getElementById('baConfirmBtn');
      if (confirmBtn2) { confirmBtn2.style.display = 'none'; confirmBtn2.disabled = false; }

      UI.showModal('battleArenaModal');
      try { hydrateStorageImages(document.getElementById('battleArenaModal')); } catch (_) {}
    },

    rollDice() {
      const labels = getProfileLabels(currentState.studentData);
      const actionBtn = document.getElementById('baActionBtn');
      if (actionBtn) actionBtn.style.display = 'none';
      document.querySelectorAll('#battleArenaModal .dice').forEach(d => d.classList.add('rolling'));
      const resultEl = document.getElementById('baResultText');
      if (resultEl) resultEl.innerText = labels.battleComputing || '靈力流動中...';

      setTimeout(async () => {
        document.querySelectorAll('#battleArenaModal .dice').forEach(d => d.classList.remove('rolling'));

        let pR = 0;
        document.querySelectorAll('#baPlayerDice .dice').forEach(d => { const v = Math.floor(Math.random() * 6) + 1; d.innerText = v; pR += v; });
        let bR = 0;
        document.querySelectorAll('#baBossDice .dice').forEach(d => { const v = Math.floor(Math.random() * 6) + 1; d.innerText = v; bR += v; });

        const getE = () => 1.0;
        const pM = getE(currentState.battleData.pType, currentState.battleData.bType);
        const bM = getE(currentState.battleData.bType, currentState.battleData.pType);
        const pF = Math.floor(pR * pM);
        const bF = Math.floor(bR * bM);
        const gD = (m) => m === 2 ? '效果絕佳(x2)' : m === 0.5 ? '效果不好(x0.5)' : m === 0 ? '沒有效果(x0)' : '正常(x1)';

        const playerMultEl = document.getElementById('baPlayerMult');
        const playerScoreEl = document.getElementById('baPlayerScore');
        const bossMultEl = document.getElementById('baBossMult');
        const bossScoreEl = document.getElementById('baBossScore');
        if (playerMultEl) playerMultEl.innerText = fillProfileTemplate(labels.battleStat, { roll: pR, detail: gD(pM) });
        if (playerScoreEl) playerScoreEl.innerText = pF;
        if (bossMultEl) bossMultEl.innerText = fillProfileTemplate(labels.battleStat, { roll: bR, detail: gD(bM) });
        if (bossScoreEl) bossScoreEl.innerText = bF;

        if (pF === bF) {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${labels.battleTie || '靈力平手！重新判定！'}</span>`;
          setTimeout(() => this.rollDice(), 2000);
        } else if (pF > bF) {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--cyan)'>${labels.battleWin || '🎉 討伐成功！'}</span>`;
          await this.endBattle(true);
        } else {
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${labels.battleLose || '💀 討伐失敗...'}</span>`;
          await this.endBattle(false);
        }
      }, 1500);
    },

    showBattleSettlement() {
      const mainStage = document.getElementById('baMainStage');
      const settlement = document.getElementById('baSettlementPanel');
      if (mainStage) mainStage.style.display = 'none';
      if (settlement) settlement.style.display = 'block';
    },

    backToBattleResult() {
      const mainStage = document.getElementById('baMainStage');
      const settlement = document.getElementById('baSettlementPanel');
      if (settlement) settlement.style.display = 'none';
      if (mainStage) mainStage.style.display = 'block';
    },

    closeBattleArenaAndRefresh() {
      const latest = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || {})));
      UI.hideModal('battleArenaModal');
      UI.updatePanel(latest, true);
    },

    async endBattle(isWin) {
      const baselineData = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || {})));
      let d = this.applyDataMigration(JSON.parse(JSON.stringify(baselineData)));
      const resultEl = document.getElementById('baResultText');
      const rewardSummaryEl = document.getElementById('baRewardSummary');
      if (rewardSummaryEl) { rewardSummaryEl.style.display = 'none'; rewardSummaryEl.innerHTML = ''; }
      let battleSaveSucceeded = false;
      let pendingToast = '';
      let settlementRewardText = '本次未獲得獎勵';
      let settlementLogText = '';
      let settlementResultText = isWin ? (isCatProfile(d) ? '領域防衛成功' : 'Boss 討伐成功') : (isCatProfile(d) ? '領域防衛失敗' : 'Boss 討伐失敗');
      let settlementResultColor = isWin ? 'var(--color-grass)' : 'var(--danger)';

      const bossKey = currentState.currentBattleBoss?.id || currentState.currentBattleBoss?.legendaryId || currentState.currentBattleBoss?.name || 'boss';
      const monKey = currentState.selectedBattleMonIndex;
      const serial = this.normalizeSerial(d.card_seq || d.serial || currentState.currentUid || '000') || '000';
      const eventId = this.buildBattleRewardEventId(d, bossKey, monKey);

      try {
        if (isWin) {
          let settle = null;
          let settleErrorMessage = '';
          try {
            settle = await this.settleRewardViaServer('boss_win', {
              eventId,
              source: 'battle_tower',
              bossId: bossKey,
              battleMonIndex: monKey,
              serial,
              battleResetAnchor: getBattleResetAnchor(d, Date.now())
            });
          } catch (settleErr) {
            settleErrorMessage = String(settleErr?.message || settleErr || '獎勵結算失敗').trim();
            settle = { ok: false, applied: false, message: settleErrorMessage };
          }

          const recordBase = settle?.student
            ? this.applyDataMigration(JSON.parse(JSON.stringify(settle.student)))
            : await this.resolveBattleRecordBase(serial, baselineData);

          const recordPayload = this.buildBattleOutcomeRecord(recordBase, {
            isWin: true,
            settle,
            saveStatus: 'pending',
            eventId,
            bossKey,
            monKey,
            errorMessage: settleErrorMessage
          });
          const savedBattleData = await this.saveToDB(recordPayload);
          if (savedBattleData) {
            battleSaveSucceeded = true;
            d = this.applyDataMigration(JSON.parse(JSON.stringify(savedBattleData)));
            currentState.studentData = d;
            this.refreshStudentRewardPanel(d, true);
          } else {
            d = recordPayload;
            currentState.studentData = this.applyDataMigration(JSON.parse(JSON.stringify(recordBase || baselineData)));
            this.refreshStudentRewardPanel(currentState.studentData, true);
          }

          const rewardDisplay = this.getBattleRewardDisplay(d, settle);
          settlementRewardText = settle?.ok && settle?.applied
            ? `+${rewardDisplay.coins} 金幣・+${rewardDisplay.xp} ${rewardDisplay.attrName}${rewardDisplay.xpUnit}`
            : (settle?.ok ? '本次未新增獎勵' : '獎勵結算失敗');

          if (settle?.ok && settle?.applied && battleSaveSucceeded) {
            const labels = getProfileLabels(d);
            const rewardSummary = `${rewardDisplay.coins} 金幣、${rewardDisplay.xp} 點${rewardDisplay.attrName}${rewardDisplay.xpUnit}`;
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--color-grass)'>${fillProfileTemplate(labels.battleReward, { reward: rewardSummary })}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `目前金幣：<b>${Number(d.coins) || 0}</b>　｜　目前${rewardDisplay.xpUnit}：<b>${Number(d.totalXP) || 0}</b>`;
            }
            pendingToast = `${isCatProfile(d) ? '領域防衛成功' : '對戰塔討伐成功'}：+${rewardDisplay.coins}🪙 +${rewardDisplay.xp} 點${rewardDisplay.attrName}${rewardDisplay.xpUnit}`;
            settlementLogText = '已完成結算：本次戰鬥獎勵與戰鬥紀錄都已寫入學生資料。';
          } else if (settle?.ok && !settle?.applied && battleSaveSucceeded) {
            const msg = settle?.message || '戰鬥已判定成功，但本次沒有新增獎勵。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `<span style="color:var(--warning)">${msg}</span>`;
            }
            pendingToast = msg;
            settlementResultColor = 'var(--warning)';
            settlementLogText = '戰鬥結果已記錄，但本次沒有新增獎勵。';
          } else if (!settle?.ok && battleSaveSucceeded) {
            const msg = settle?.message || '獎勵結算失敗，請稍後重新整理確認是否入帳。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--warning)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = `<span style="color:var(--warning)">${msg}<br>戰鬥結果已記錄，獎勵狀態請稍後確認。</span>`;
            }
            pendingToast = `戰鬥結果已記錄，但獎勵結算失敗：${msg}`;
            settlementResultColor = 'var(--warning)';
            settlementLogText = `戰鬥結果已記錄，但獎勵結算失敗：${msg}`;
          } else {
            const msg = settle?.message || '戰鬥結果保存失敗，請通知老師協助處理。';
            if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${msg}</span>`;
            if (rewardSummaryEl) {
              rewardSummaryEl.style.display = 'block';
              rewardSummaryEl.innerHTML = '<span style="color:var(--danger)">戰鬥結果與獎勵狀態未能完整保存，請通知老師協助處理。</span>';
            }
            settlementResultColor = 'var(--danger)';
            settlementLogText = `戰鬥結果保存失敗：${msg}`;
          }
        } else {
          const recordPayload = this.buildBattleOutcomeRecord(d, {
            isWin: false,
            settle: null,
            saveStatus: 'pending',
            eventId,
            bossKey,
            monKey
          });
          const savedBattleData = await this.saveToDB(recordPayload);
          if (savedBattleData) {
            battleSaveSucceeded = true;
            d = this.applyDataMigration(JSON.parse(JSON.stringify(savedBattleData)));
            currentState.studentData = d;
            this.refreshStudentRewardPanel(d, true);
          } else {
            currentState.studentData = baselineData;
            this.refreshStudentRewardPanel(baselineData, true);
          }
          if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${getProfileLabels(baselineData).battleConsume || '💀 討伐失敗，本日挑戰機會已消耗。'}</span>`;
          settlementLogText = battleSaveSucceeded
            ? '本次戰鬥未獲得獎勵，今日挑戰次數已消耗，可於下次重置後再次挑戰。'
            : '本次戰鬥結果未能成功保存，請通知老師協助處理。';
        }
      } catch (battleErr) {
        console.error('[endBattle] failed:', battleErr);
        const msg = String(battleErr?.message || battleErr || '戰鬥結算失敗').trim();
        if (resultEl) resultEl.innerHTML = `<span style='color:var(--danger)'>${msg}</span>`;
        if (rewardSummaryEl) {
          rewardSummaryEl.style.display = 'block';
          rewardSummaryEl.innerHTML = '<span style="color:var(--danger)">戰鬥結算失敗，請稍後重試或通知老師協助處理。</span>';
        }
        settlementResultText = 'Boss 結算失敗';
        settlementResultColor = 'var(--danger)';
        settlementRewardText = '未完成結算';
        settlementLogText = `戰鬥結算失敗：${msg}`;
        currentState.studentData = baselineData;
        this.refreshStudentRewardPanel(baselineData, true);
      }

      const actionBtn = document.getElementById('baActionBtn');
      if (actionBtn) actionBtn.style.display = 'none';
      const confirmBtn = document.getElementById('baConfirmBtn');
      if (confirmBtn) {
        confirmBtn.style.display = 'block';
        confirmBtn.innerText = '查看結算';
      }
      if (pendingToast) UI.toast(pendingToast);
      if (!isWin && rewardSummaryEl) {
        const xpUnit = getProfileLabels(d).xp || (isCatProfile(d) ? '成長能量' : '進化能量');
        rewardSummaryEl.style.display = 'block';
        rewardSummaryEl.innerHTML = `目前金幣：<b>${Number(d.coins) || 0}</b>　｜　目前${xpUnit}：<b>${Number(d.totalXP) || 0}</b>`;
      }

      const settlementResult = document.getElementById('baSettlementResult');
      if (settlementResult) {
        settlementResult.innerText = settlementResultText;
        settlementResult.style.color = settlementResultColor;
      }
      const settlementReward = document.getElementById('baSettlementReward');
      if (settlementReward) {
        settlementReward.innerText = settlementRewardText;
        settlementReward.style.color = isWin && battleSaveSucceeded ? 'var(--color-grass)' : (settlementResultColor === 'var(--danger)' ? 'var(--danger)' : 'var(--text-muted)');
      }
      const settlementCoins = document.getElementById('baSettlementCoins');
      if (settlementCoins) settlementCoins.innerText = String(Number(d.coins) || 0);
      const settlementXP = document.getElementById('baSettlementXP');
      if (settlementXP) settlementXP.innerText = String(Number(d.totalXP) || 0);
      const settlementLog = document.getElementById('baSettlementLog');
      if (settlementLog) settlementLog.innerText = settlementLogText;
    },

    async checkBattleTowerStatus(studentData) {
      try {
        if (!studentData) {
          currentState.currentBattleBoss = null;
          UI.hide('stuBattleTowerArea');
          return;
        }
        const snap = await getDoc(doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_'));
        if (!snap.exists()) {
          UI.hide('stuBattleTowerArea');
          currentState.currentBattleBoss = null;
          return;
        }
        const rawBossDoc = snap.data() || {};
        const boss = getBattleBossConfigForStudent(studentData, rawBossDoc);
        if (!boss) {
          UI.hide('stuBattleTowerArea');
          currentState.currentBattleBoss = null;
          return;
        }
        currentState.currentBattleBoss = boss;
        UI.show('stuBattleTowerArea');

        const typeInfo = getProfileAttributeInfo(boss.typeKey, studentData) || null;
        const labels = getProfileLabels(studentData);
        const catBossVis = isCatProfile(studentData) ? getCatBossVisualByType(boss.typeKey) : null;
        const gradeInfo = getStudentGradeInfo(studentData);
        const audienceText = boss.audienceLabel || (gradeInfo.isSupportClass ? '學習扶助班' : (gradeInfo.gradeToken ? `${gradeInfo.gradeToken}年級` : '全體'));
        const nameEl = document.getElementById('btBossName');
        if (nameEl) nameEl.innerText = isCatProfile(studentData) ? `${catBossVis?.breedName || labels.bossName || '入侵浪貓'}（${audienceText}）` : `${labels.bossName || boss.name || '---'}｜${audienceText}`;
        const imgEl = document.getElementById('btBossImg');
        if (imgEl) imgEl.src = isCatProfile(studentData) ? (catBossVis?.file || catBossVis?.img || '') : (boss.img || '');
        const typeEl = document.getElementById('btBossType');
        if (typeEl) {
          typeEl.innerText = typeInfo ? typeInfo.name : '未知';
          typeEl.style.color = typeInfo ? typeInfo.color : '#fff';
          typeEl.style.borderColor = typeInfo ? typeInfo.color : '#555';
        }

        const btn = document.getElementById('btChallengeBtn');
        const st = document.getElementById('btStatusText');

        if (!hasBattleAttemptRemaining(studentData)) {
          if (btn) { btn.disabled = true; btn.style.background = '#333'; btn.style.borderColor = '#555'; }
          if (st) st.innerText = fillProfileTemplate(labels.battleCooldown, { countdown: formatCountdown(getNextNoonTimestamp(Date.now()) - Date.now()) });
        } else {
          if (btn) { btn.disabled = false; btn.style.background = 'var(--danger)'; btn.style.borderColor = 'var(--danger)'; }
          if (st) st.innerText = `${labels.battleReady || '狀態就緒，點擊發起挑戰！（每日中午 12:00 重置）'}｜本日對應群組：${audienceText}。`;
        }
      } catch (e) {
        console.error('對戰塔狀態檢查失敗:', e);
      }
    },

    async updateBattleTowerStatus(studentData) {
      return this.checkBattleTowerStatus(studentData || currentState.studentData);
    },

    async resetDailyAndBattleChallenges() {
      let hasAdmin = !!currentState.isAdmin;
      if (!hasAdmin) {
        try {
          hasAdmin = await this.isCurrentUserAdmin();
          currentState.isAdmin = !!hasAdmin;
        } catch (e) {
          console.warn('[resetDailyAndBattleChallenges] admin recheck failed:', e);
        }
      }
      if (!hasAdmin) {
        UI.alert('請先以管理員身分登入後再操作。', '無法重置');
        return;
      }

      const confirmed = await UI.confirm(
        '此操作會將所有學生的「今日歷練」與「BOSS 挑戰」重置為可再次計算。\n\n已獲得的金幣、經驗與既有紀錄不會被回收。\n\n確定要執行嗎？',
        '確認重置今日挑戰'
      );
      if (!confirmed) return;

      const now = Date.now();
      const targets = [COLLECTION_NAME, STUDENT_PAGE_COLLECTION];
      let touched = 0;

      try {
        for (const colName of targets) {
          const snap = await getDocs(collection(db, colName));
          const docs = [];
          snap.forEach(docSnap => docs.push(docSnap));

          for (let i = 0; i < docs.length; i += 400) {
            const batch = writeBatch(db);
            const chunk = docs.slice(i, i + 400);

            chunk.forEach(docSnap => {
              const raw = docSnap.data ? (docSnap.data() || {}) : {};
              const previousDailyAnchor = this.getDailyResetAnchor ? this.getDailyResetAnchor(raw, now - 1) : 0;
              const previousBattleAnchor = getBattleResetAnchor(raw, now - 1);
              const rewardEvents = Array.isArray(raw.reward_events) ? raw.reward_events : [];
              const keptRewardEvents = rewardEvents.filter(evt => {
                if (!evt || typeof evt !== 'object') return false;
                const ts = Number(evt.timestamp) || 0;
                if (evt.type === 'daily_correct' && ts >= previousDailyAnchor) return false;
                if (evt.type === 'boss_win' && ts >= previousBattleAnchor) return false;
                return true;
              }).slice(-200);

              const payload = {
                daily_reset_override_at: now,
                battle_reset_override_at: now,
                today_quiz_reward_count: 0,
                today_quiz_reward_date: now,
                today_battle_used: false,
                today_battle_date: now,
                last_practice_time: 0,
                last_battle_time: 0,
                reward_events: keptRewardEvents,
                reward_settled_ids: [],
                updatedAt: now
              };

              const logs = Array.isArray(raw.logs) ? raw.logs.slice(-49) : [];
              logs.push({
                timestamp: now,
                action_type: 'system',
                detail: '[教師操作] 已手動重置今日歷練與 BOSS 挑戰次數（含每日十題上限、當日結算旗標與挑戰紀錄）'
              });
              payload.logs = logs;

              batch.set(docSnap.ref, payload, { merge: true });
            });

            await batch.commit();
            touched += chunk.length;
          }
        }

        if (currentState.studentData) {
          currentState.studentData.daily_reset_override_at = now;
          currentState.studentData.battle_reset_override_at = now;
          currentState.studentData.today_quiz_reward_count = 0;
          currentState.studentData.today_quiz_reward_date = now;
          currentState.studentData.today_battle_used = false;
          currentState.studentData.today_battle_date = now;
          currentState.studentData.last_practice_time = 0;
          currentState.studentData.last_battle_time = 0;
          currentState.studentData.reward_settled_ids = [];
          this.refreshStudentRewardPanel(currentState.studentData, true);
          try { if (typeof UI.updateDailyQuestTimer === 'function') UI.updateDailyQuestTimer(); } catch (e) {}
          try { await this.checkBattleTowerStatus(currentState.studentData); } catch (e) {}
        }

        UI.alert(`已完成重置。\n\n共更新 ${touched} 筆資料（students + student_pages）。\n學生重新整理頁面後，今日歷練與 BOSS 挑戰都會重新開放。`, '重置完成');
      } catch (e) {
        console.error('[resetDailyAndBattleChallenges] failed:', e);
        UI.alert(`重置失敗：${e?.message || e}`, '重置失敗');
      }
    },

    async populateBattleQuizOptions(audienceKey = 'default') {
      const quizSelect = document.getElementById('btSetQuiz');
      if (!quizSelect) return [];
      quizSelect.innerHTML = '<option value="">載入題庫中...</option>';
      const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
      const snapshot = await getDocs(collection(db, 'quiz_bank'));
      const quizzes = [];
      snapshot.forEach(d => {
        if (d.id === BATTLE_TOWER_DOC_ID) return;
        const q = normalizeQuizQuestionRecord(d.data() || {}, d.id);
        if (!isQuizEnabled(q) || !isPlayableQuizQuestion(q)) return;
        quizzes.push(q);
      });
      quizzes.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      const audience = String(audienceKey || 'default');
      const desiredGrade = audience.startsWith('grade') ? audience.replace('grade', '') : '';
      const isSupportClass = audience === 'support';
      const filtered = quizzes.filter(q => {
        if (audience === 'default') return true;
        if (isSupportClass) return quizMatchesStudentGrade(q, '學習扶助班', true);
        return quizMatchesStudentGrade(q, desiredGrade, false) || !String(q.grade || q.class_name || q.gradeName || '').trim();
      });
      const finalList = filtered.length ? filtered : quizzes;
      quizSelect.innerHTML = '<option value="random">(隨機) 依群組自動抽題</option>';
      finalList.forEach(q => {
        const gradeText = q.grade ? (/^[1-6][上下]$/.test(String(q.grade)) ? `${String(q.grade).charAt(0)}年級(${String(q.grade).slice(1)})` : String(q.grade)) : '';
        const unitText = q.unit || '';
        const prefix = [gradeText, unitText].filter(Boolean).join(' | ');
        let qShort = (q.question || '').replace(/\s+/g, ' ').trim();
        if (qShort.length > 26) qShort = qShort.slice(0, 26) + '…';
        quizSelect.innerHTML += `<option value="${esc(q.id)}">${prefix ? `[${esc(prefix)}] ` : ''}${esc(qShort)}</option>`;
      });
      return finalList;
    },

    updateBattleTowerAdminAudienceView(rawDoc = {}) {
      const audienceSel = document.getElementById('btAudienceSelect');
      const audienceKey = String(audienceSel?.value || 'grade4');
      const statusEl = document.getElementById('btAudienceStatus');
      const cfg = getBattleBossConfigForAudience(rawDoc, audienceKey);
      if (statusEl) {
        statusEl.innerHTML = cfg
          ? `已設定：<span style="color:#fff; font-weight:bold;">${cfg.name || '未命名 Boss'}</span><br>題目：${cfg.gatekeeperQuizId === 'random' ? '隨機抽題' : '指定題目'}<br>Boss骰數：${normalizeBossDiceCount(cfg.bossDiceCount, 3)}${cfg.timestamp ? `<br><span style="color:var(--text-muted);">更新：${new Date(cfg.timestamp).toLocaleString()}</span>` : ''}`
          : '此群組目前尚未設定，學生會改用「全體通用（備援）」設定。';
      }
      const bossSel = document.getElementById('btSetBoss');
      const typeSel = document.getElementById('btSetType');
      const quizSel = document.getElementById('btSetQuiz');
      const diceInput = document.getElementById('btSetBossDiceCount');
      if (bossSel) bossSel.value = String(cfg?.bossId || cfg?.id || '');
      if (typeSel) typeSel.value = String(cfg?.typeKey || '');
      if (quizSel) quizSel.value = String(cfg?.gatekeeperQuizId || 'random');
      if (diceInput) diceInput.value = String(normalizeBossDiceCount(cfg?.bossDiceCount, 3));
      if (typeof __updateLegendarySelectPreview === 'function') __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName');
    },

    async openBattleTowerSetup() {
      UI.showModal('battleTowerAdminModal');
      const audienceSel = document.getElementById('btAudienceSelect');
      if (audienceSel && !audienceSel.dataset.bound) {
        audienceSel.dataset.bound = '1';
        audienceSel.addEventListener('change', async () => {
          try {
            await this.populateBattleQuizOptions(audienceSel.value || 'default');
            const snap = await getDoc(doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_'));
            this.updateBattleTowerAdminAudienceView(snap.exists() ? (snap.data() || {}) : {});
          } catch (e) {
            console.error('[battle tower] audience change failed:', e);
          }
        });
      }
      if (audienceSel && !audienceSel.value) audienceSel.value = 'grade4';
      try {
        await this.populateBattleQuizOptions(audienceSel?.value || 'grade4');
        const cur = await getDoc(doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_'));
        this.updateBattleTowerAdminAudienceView(cur.exists() ? (cur.data() || {}) : {});
      } catch (e) {
        console.error(e);
        const quizSelect = document.getElementById('btSetQuiz');
        if (quizSelect) quizSelect.innerHTML = '<option value="random">(隨機) 依群組自動抽題</option>';
        UI.alert('載入題庫失敗：' + (e.message || e), '系統異常');
      }
    },

    async publishBattleBoss() {
      const audienceKey = String(document.getElementById('btAudienceSelect')?.value || 'grade4');
      const audienceMeta = getBattleAudienceOptions().find(item => item.key === audienceKey) || { key: audienceKey, label: audienceKey };
      const bossId = document.getElementById('btSetBoss') ? document.getElementById('btSetBoss').value : '';
      const typeKey = document.getElementById('btSetType') ? document.getElementById('btSetType').value : '';
      const quizId = document.getElementById('btSetQuiz') ? document.getElementById('btSetQuiz').value : '';
      const bossDiceCount = normalizeBossDiceCount(document.getElementById('btSetBossDiceCount') ? document.getElementById('btSetBossDiceCount').value : 3, 3);
      const gatekeeperQuizId = quizId || 'random';

      if (!bossId || !typeKey) return UI.alert('請先選擇 Boss 與屬性。', '發布失敗');

      const bossInfo = (CONSTANTS.LEGENDARIES || []).find(l => String(l.id) === String(bossId));
      if (!bossInfo) return UI.alert('找不到對應的 Boss 資料。', '系統錯誤');

      const audiencePayload = {
        id: String(bossId),
        bossId: String(bossId),
        name: bossInfo.name,
        img: bossInfo.img,
        typeKey: String(typeKey),
        gatekeeperQuizId: String(gatekeeperQuizId),
        bossDiceCount,
        timestamp: Date.now(),
        audienceKey,
        audienceLabel: audienceMeta.label
      };

      try {
        const ref = doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_');
        const snap = await getDoc(ref);
        const normalized = normalizeBattleTowerDoc(snap.exists() ? (snap.data() || {}) : {});
        normalized.version = 'battle_tower_v2';
        normalized.audiences = normalized.audiences || {};
        normalized.audiences[audienceKey] = audiencePayload;
        if (audienceKey === 'default') Object.assign(normalized, audiencePayload);
        await setDoc(ref, normalized);
        UI.toast(`✅ ${audienceMeta.label} Boss 已更新`);
        this.updateBattleTowerAdminAudienceView(normalized);
        if (currentState.studentData) this.checkBattleTowerStatus(currentState.studentData);
      } catch (e) {
        console.error(e);
        UI.alert('發布失敗：' + (e.message || e), '系統異常');
      }
    },

    async clearBattleBoss() {
      const audienceKey = String(document.getElementById('btAudienceSelect')?.value || 'grade4');
      const audienceMeta = getBattleAudienceOptions().find(item => item.key === audienceKey) || { label: audienceKey };
      const isConfirmed = await UI.confirm(`確定要清除此群組（${audienceMeta.label}）的對戰塔設定嗎？\n\n學生之後會改用全體通用設定；若全體通用也沒設定，則暫時無法進入對戰塔。`, '清除群組 Boss 設定');
      if (!isConfirmed) return;

      try {
        const ref = doc(db, 'quiz_bank', '_BATTLE_TOWER_BOSS_');
        const snap = await getDoc(ref);
        const normalized = normalizeBattleTowerDoc(snap.exists() ? (snap.data() || {}) : {});
        if (normalized.audiences && normalized.audiences[audienceKey]) delete normalized.audiences[audienceKey];
        if (audienceKey === 'default') {
          delete normalized.id;
          delete normalized.bossId;
          delete normalized.name;
          delete normalized.img;
          delete normalized.typeKey;
          delete normalized.gatekeeperQuizId;
          delete normalized.timestamp;
        }
        if (!Object.keys(normalized.audiences || {}).length) {
          await deleteDoc(ref);
        } else {
          await setDoc(ref, normalized);
        }
        UI.toast(`✅ 已清除 ${audienceMeta.label} 設定`);
        this.updateBattleTowerAdminAudienceView(normalized);
        currentState.currentBattleBoss = null;
        if (currentState.studentData) await this.checkBattleTowerStatus(currentState.studentData);
        else UI.hide('stuBattleTowerArea');
      } catch (e) {
        console.error(e);
        UI.alert('清除失敗：' + (e.message || e), '系統異常');
      }
    }
  };
}
