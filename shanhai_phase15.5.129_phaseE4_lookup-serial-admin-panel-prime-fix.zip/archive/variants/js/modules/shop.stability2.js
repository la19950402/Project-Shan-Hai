import { UI } from "../core/ui.js?v=phase15quizbankfix1";
import { currentState } from "../core/state.js?v=phase15quizbankfix1";
import { db, collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc } from "../core/firebase.js?v=phase15quizbankfix1";

export function createShopModule({ SHOP_COLLECTION, COLLECTION_NAME, CONSTANTS, getContentProfile }) {
  const getShopAdminFormElements = () => ({
    name: document.getElementById('shopAdminName'),
    cost: document.getElementById('shopAdminCost'),
    desc: document.getElementById('shopAdminDesc'),
    effect: document.getElementById('shopAdminEffect'),
    qty: document.getElementById('shopAdminQty'),
    hiddenEgg: document.getElementById('shopAdminHiddenEgg'),
    active: document.getElementById('shopAdminActive')
  });

  const hasCompleteShopAdminForm = (els = getShopAdminFormElements()) => !!(els.name && els.cost && els.desc && els.effect && els.qty && els.hiddenEgg && els.active);

  return {
    getBuiltInShopItems() {
      const profile = getContentProfile(currentState.studentData);
      const alias = profile.builtInShop || {};
      return [
        { id: 'antidote', name: alias.antidote?.name || '💊 萬靈藥', desc: alias.antidote?.desc || '清除所有負面狀態', cost: 10, borderColor: 'var(--color-grass)', effectType: 'antidote', quantity: null, active: true, builtIn: true },
        { id: 'evo_stone', name: alias.evo_stone?.name || '✨ 各系進化石', desc: alias.evo_stone?.desc || '指定屬性直接 +30 XP', cost: 20, borderColor: 'var(--color-fire)', effectType: 'evo_stone', quantity: null, active: true, builtIn: true },
        { id: 'wonder_stone', name: alias.wonder_stone?.name || '🌟 進化奇石', desc: alias.wonder_stone?.desc || '指定屬性素材 +1', cost: 50, borderColor: 'var(--color-fairy)', effectType: 'wonder_stone', quantity: null, active: true, builtIn: true },
        { id: 'azure_kirin_egg', name: '🌊 碧瀾麒麟蛋', desc: '水屬性隱藏異獸蛋；沿用原本經驗累積與進化節奏，最終可轉化為碧瀾麒麟（★100）', cost: 100, borderColor: 'var(--color-water)', effectType: 'hidden_egg', hiddenEggId: 'azure_kirin', quantity: null, active: true, builtIn: true },
        { id: 'marshmallow_physical', name: '🍡 烤棉花糖(實體)', desc: '需在老師面前購買才能獲得（否則不算數）', cost: 50, borderColor: 'var(--color-electric)', effectType: 'physical_reward', quantity: null, active: true, builtIn: true }
      ];
    },
    getShopEffectLabel(effectType) {
      const alias = (getContentProfile(currentState.studentData).builtInShop || {});
      const map = { antidote: alias.antidote?.name || '萬靈藥', evo_stone: alias.evo_stone?.name || '進化石', wonder_stone: alias.wonder_stone?.name || '進化奇石', physical_reward: '實體兌換品', hidden_egg: alias.hidden_egg?.name || '特殊異獸蛋' };
      return map[effectType] || effectType || '自訂商品';
    },
    getShopButtonHtml(item) {
      const cost = Number(item.cost) || 0;
      const qty = (item.quantity === null || item.quantity === undefined || item.quantity === '') ? null : Math.max(0, Number(item.quantity) || 0);
      const soldOut = qty !== null && qty <= 0;
      const inactive = item.active === false;
      const borderColor = (soldOut || inactive) ? '#666' : (item.borderColor || 'var(--color-electric)');
      const extra = item.effectType === 'hidden_egg' && item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId] ? `<br/><span style="font-size:0.68em; color:var(--legendary-gold); font-family:'Noto Sans TC';">${CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].desc}</span>` : '';
      const statusLabel = inactive ? '未上架' : (qty === null ? '不限量' : (soldOut ? '售罄' : `剩餘 ${qty}`));
      const statusColor = inactive ? 'var(--text-muted)' : (soldOut ? '#999' : (item.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--cyan)'));
      return `<button class="btn shop-item" onclick="App.handleShopPurchase('${item.id}', ${cost}, ${item.builtIn ? 'true' : 'false'})" ${soldOut || inactive ? 'disabled' : ''} style="text-align:left; border-color:${borderColor}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.55' : '1'};">${String(item.name || '未命名商品')} (${cost} 🪙)<br/><span style="font-size:0.7em; color:${soldOut || inactive ? '#999' : 'var(--text-muted)'}; font-family:'Noto Sans TC';">${String(item.desc || '—')}</span>${extra}<div class="tech-font" style="margin-top:6px; font-size:0.72em; color:${statusColor};">${statusLabel}</div></button>`;
    },
    setShopBusy(flag = true) { currentState.shopBusy = !!flag; },
    setShopAdminSaving(flag = true) { currentState.shopAdminSaving = !!flag; },
    setShopGiftSending(flag = true) { currentState.shopGiftSending = !!flag; },
    isShopInteractionLocked() { return !!(currentState.shopBusy || currentState.shopAdminSaving || currentState.shopGiftSending); },
    async renderShopItems() {
      const container = document.getElementById('shopItemsContainer');
      if (!container) return;
      let items = this.getBuiltInShopItems();
      try {
        const snap = await getDocs(collection(db, SHOP_COLLECTION));
        snap.forEach(d => {
          const data = d.data() || {};
          items.push({ id: d.id, builtIn: false, name: data.name || '未命名商品', desc: data.desc || '', cost: Number(data.cost) || 0, quantity: data.quantity ?? 0, active: data.active !== false, effectType: data.effectType || 'physical_reward', hiddenEggId: data.hiddenEggId || '', borderColor: data.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--color-electric)' });
        });
      } catch (e) { console.warn('[shop] load catalog failed:', e); }
      items = items.filter(item => item.builtIn || item.active !== false);
      items.sort((a, b) => { const aq = (a.quantity === null || a.quantity === undefined || a.quantity === '') ? Infinity : Number(a.quantity); const bq = (b.quantity === null || b.quantity === undefined || b.quantity === '') ? Infinity : Number(b.quantity); const aSold = Number.isFinite(aq) && aq <= 0 ? 1 : 0; const bSold = Number.isFinite(bq) && bq <= 0 ? 1 : 0; return aSold - bSold || (Number(a.cost) || 0) - (Number(b.cost) || 0); });
      container.innerHTML = items.map(item => this.getShopButtonHtml(item)).join('') || `<div style="color:var(--text-muted); text-align:center;">目前沒有上架商品</div>`;
    },
    populateHiddenEggSelect() { const sel = document.getElementById('shopAdminHiddenEgg'); if (!sel) return; const current = sel.value; sel.innerHTML = `<option value="">— 非異獸蛋商品可忽略 —</option>` + Object.values(CONSTANTS.HIDDEN_EGGS).map(item => `<option value="${item.id}">${item.name} / ${CONSTANTS.ATTRIBUTES[item.requiredAttr]?.name || item.requiredAttr} / ★${item.points}</option>`).join(''); if (current) sel.value = current; },
    updateShopAdminFormState() {
      const effect = document.getElementById('shopAdminEffect'); const egg = document.getElementById('shopAdminHiddenEgg'); const hint = document.getElementById('shopAdminHint'); const qty = document.getElementById('shopAdminQty'); const isHiddenEgg = effect && effect.value === 'hidden_egg';
      if (egg) { egg.disabled = !isHiddenEgg; egg.style.opacity = isHiddenEgg ? '1' : '0.6'; }
      if (qty && !qty.value && !currentState.editingShopProductId) qty.value = '1';
      if (hint) hint.textContent = isHiddenEgg ? '特殊異獸蛋已實裝；請選擇蛋種，並填入可販售數量。學生購買後會先進入孵化紀錄，完成養成才會轉成隱藏積分。' : '一般商品可直接上架。若數量設為 0，學生商店會顯示灰色「售罄」。';
    },
    resetShopAdminForm() { ['shopAdminName','shopAdminCost','shopAdminDesc'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; }); const qtyEl = document.getElementById('shopAdminQty'); if (qtyEl) qtyEl.value = '1'; const effect = document.getElementById('shopAdminEffect'); if (effect) effect.value = 'antidote'; const active = document.getElementById('shopAdminActive'); if (active) active.checked = true; const egg = document.getElementById('shopAdminHiddenEgg'); if (egg) egg.value = ''; currentState.editingShopProductId = null; this.updateShopAdminFormState(); },
    resetShopGiftForm() { const seq = document.getElementById('shopGiftTargetSeq'); if (seq) seq.value = ''; const note = document.getElementById('shopGiftNote'); if (note) note.value = ''; const attr = document.getElementById('shopGiftAttrSelect'); if (attr) attr.value = 'metal'; const info = document.getElementById('shopGiftTargetInfo'); if (info) info.innerHTML = '請先輸入卡序，確認要送禮的學生。'; },
    setShopAdminTab(tab = 'catalog') { currentState.shopAdminTab = tab; const catalogPane = document.getElementById('shopAdminCatalogPane'); const giftPane = document.getElementById('shopAdminGiftPane'); const btnCatalog = document.getElementById('shopAdminTabBtnCatalog'); const btnGift = document.getElementById('shopAdminTabBtnGift'); if (catalogPane) catalogPane.classList.toggle('hidden', tab !== 'catalog'); if (giftPane) giftPane.classList.toggle('hidden', tab !== 'gift'); if (btnCatalog) { btnCatalog.classList.toggle('btn-solid', tab === 'catalog'); btnCatalog.style.background = tab === 'catalog' ? 'var(--legendary-gold)' : 'transparent'; btnCatalog.style.color = tab === 'catalog' ? '#000' : 'var(--legendary-gold)'; btnCatalog.style.borderColor = 'var(--legendary-gold)'; } if (btnGift) { btnGift.classList.toggle('btn-solid', tab === 'gift'); btnGift.style.background = tab === 'gift' ? 'var(--cyan)' : 'transparent'; btnGift.style.color = tab === 'gift' ? '#041018' : 'var(--cyan)'; btnGift.style.borderColor = 'var(--cyan)'; } },
    getAdminGiftableShopItems() { return this.getBuiltInShopItems().map(item => ({ ...item, sourceId: `builtin:${item.id}` })); },
    async loadShopGiftOptions(preferredId = '') { const sel = document.getElementById('shopGiftItemSelect'); const list = document.getElementById('shopGiftCatalogList'); if (!sel || !list) return; sel.innerHTML = '<option value="">載入中...</option>'; list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>'; let items = this.getAdminGiftableShopItems(); try { const snap = await getDocs(collection(db, SHOP_COLLECTION)); snap.forEach(d => { const row = d.data() || {}; items.push({ id: d.id, sourceId: d.id, builtIn: false, name: row.name || '未命名商品', desc: row.desc || '', cost: Number(row.cost) || 0, quantity: Math.max(0, Number(row.quantity) || 0), active: row.active !== false, effectType: row.effectType || 'physical_reward', hiddenEggId: row.hiddenEggId || '' }); }); } catch (e) { console.warn('[shop gift] load options failed:', e); } sel.innerHTML = '<option value="">請選擇要贈送的物品</option>' + items.map(item => { const qty = item.builtIn ? null : Math.max(0, Number(item.quantity) || 0); const qtyText = qty === null ? '不限量' : `庫存 ${qty}`; const stateText = item.builtIn ? '內建' : (item.active === false ? '未上架' : (qty <= 0 ? '售罄' : '上架中')); return `<option value="${item.sourceId}" ${preferredId === item.sourceId ? 'selected' : ''}>${String(item.name || '未命名商品')}｜${this.getShopEffectLabel(item.effectType)}｜${qtyText}｜${stateText}</option>`; }).join(''); list.innerHTML = items.map(item => { const soldOut = !item.builtIn && Math.max(0, Number(item.quantity) || 0) <= 0; const inactive = !item.builtIn && item.active === false; const border = soldOut || inactive ? '#666' : 'var(--legendary-gold)'; const state = item.builtIn ? '內建' : (inactive ? '未上架' : (soldOut ? '售罄' : `庫存 ${Math.max(0, Number(item.quantity) || 0)}`)); return `<button class="btn" onclick="App.pickShopGiftItem('${item.sourceId}')" style="text-align:left; border-color:${border}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.62' : '1'};">${String(item.name || '未命名商品')}<br><div style="font-size:0.76em; color:${soldOut || inactive ? '#999' : '#ccc'}; margin-top:4px; font-family:'Noto Sans TC';">${this.getShopEffectLabel(item.effectType)} / ${state}</div></button>`; }).join('') || '<div style="color:var(--text-muted); text-align:center;">目前沒有可贈送商品</div>'; },
    pickShopGiftItem(sourceId) { const sel = document.getElementById('shopGiftItemSelect'); if (sel) sel.value = sourceId || ''; this.lookupShopGiftTarget(); },
    async lookupShopGiftTarget() { const input = document.getElementById('shopGiftTargetSeq'); const info = document.getElementById('shopGiftTargetInfo'); const serial = this.normalizeSerial(input?.value || ''); if (!serial) { if (info) info.innerHTML = '請先輸入卡序，確認要送禮的學生。'; return; } try { const snap = await getDoc(doc(db, COLLECTION_NAME, serial)); if (!snap.exists()) { if (info) info.innerHTML = `<span style="color:var(--danger);">找不到卡序 ${serial} 的學生。</span>`; return; } const d = this.applyDataMigration(JSON.parse(JSON.stringify(snap.data() || {}))); const profileName = this.isCatProfile ? (this.isCatProfile(d) ? '貓咪版' : '山海版') : '學生'; if (info) info.innerHTML = `<div style="color:var(--legendary-gold); font-weight:bold;">${d.name || '未命名學生'}｜卡序 ${serial}</div><div style="margin-top:4px; color:#ddd;">${d.class_name || '未分班'} / ${profileName} / 總能量 ${Number(d.totalXP) || 0} / 金幣 ${Number(d.coins) || 0}</div>`; } catch (e) { console.error(e); if (info) info.innerHTML = `<span style="color:var(--danger);">查詢失敗：${e.message || e}</span>`; } },
    async getShopGiftItemMeta(sourceId) { if (!sourceId) return null; if (String(sourceId).startsWith('builtin:')) { const builtId = String(sourceId).slice('builtin:'.length); const item = this.getBuiltInShopItems().find(x => x.id === builtId); return item ? { ...item, sourceId } : null; } const snap = await getDoc(doc(db, SHOP_COLLECTION, sourceId)); if (!snap.exists()) return null; const row = snap.data() || {}; return { id: sourceId, sourceId, builtIn: false, name: row.name || '未命名商品', desc: row.desc || '', cost: Number(row.cost) || 0, quantity: Math.max(0, Number(row.quantity) || 0), active: row.active !== false, effectType: row.effectType || 'physical_reward', hiddenEggId: row.hiddenEggId || '' }; },
    async applyAdminGiftEffect(data, itemMeta, targetSerial, selectedAttr = 'metal', note = '') { if (!data || !itemMeta) return { applied: false }; const noteSuffix = note ? `（備註：${note}）` : ''; const next = this.applyDataMigration(JSON.parse(JSON.stringify(data || {}))); next.logs = Array.isArray(next.logs) ? next.logs : []; if (itemMeta.effectType === 'antidote') { next.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 }; next.debuffs_timestamp = null; next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '萬靈藥'}，已清除異常狀態${noteSuffix}` }); await this.saveToDB(next, targetSerial); return { applied: true }; } if (itemMeta.effectType === 'evo_stone') { next.totalXP = (Number(next.totalXP) || 0) + 30; this.addAttributeXP ? this.addAttributeXP(next, selectedAttr, 30) : null; next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化石'}（${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr} +30 XP）${noteSuffix}` }); const evolved = this.processEvolution(next); await this.saveToDB(evolved, targetSerial); return { applied: true }; } if (itemMeta.effectType === 'wonder_stone') { next.collection = Array.isArray(next.collection) ? next.collection : []; next.collection.push({ type: 'material', element: selectedAttr, name: `${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr}系素材`, img: CONSTANTS.MEDIA.PLACEHOLDER_SVG, stats: { ...(next.attributes || {}) }, timestamp: Date.now() }); next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化奇石'}（${CONSTANTS.ATTRIBUTES[selectedAttr]?.name || selectedAttr}系素材）${noteSuffix}` }); await this.saveToDB(next, targetSerial); return { applied: true }; } next.collection = Array.isArray(next.collection) ? next.collection : []; next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '商城物品'}${noteSuffix}` }); await this.saveToDB(next, targetSerial); return { applied: true }; },
    async sendShopGift() {
      if (currentState.shopGiftSending) { UI.toast('贈禮送出中，請稍候'); return; }
      const targetInput = document.getElementById('shopGiftTargetSeq');
      const itemSel = document.getElementById('shopGiftItemSelect');
      const attrSel = document.getElementById('shopGiftAttrSelect');
      const noteEl = document.getElementById('shopGiftNote');
      const targetSerial = this.normalizeSerial(targetInput?.value || '');
      const sourceId = itemSel?.value || '';
      const selectedAttr = attrSel?.value || 'metal';
      const note = (noteEl?.value || '').trim();
      if (!targetSerial) { UI.toast('請先輸入指定卡序'); return; }
      if (!sourceId) { UI.toast('請先選擇要贈送的物品'); return; }
      try {
        this.setShopGiftSending(true);
        const targetSnap = await getDoc(doc(db, COLLECTION_NAME, targetSerial));
        if (!targetSnap.exists()) { UI.alert('找不到指定卡序的學生資料。', '贈禮失敗'); return; }
        const itemMeta = await this.getShopGiftItemMeta(sourceId);
        if (!itemMeta) {
          UI.alert('找不到此商城物品，請重新整理後再試。', '贈禮失敗');
          await this.loadShopGiftOptions();
          return;
        }
        const targetData = this.applyDataMigration(JSON.parse(JSON.stringify(targetSnap.data() || {})));
        const ok = await UI.confirm(`確定要將「${itemMeta.name || '商城物品'}」送給 ${targetData.name || '這位學生'}（卡序 ${targetSerial}）嗎？`, '確認送出贈禮');
        if (!ok) return;
        const result = await this.applyAdminGiftEffect(targetData, itemMeta, targetSerial, selectedAttr, note);
        if (!result || !result.applied) return;
        await this.loadShopAdminList();
        await this.loadShopGiftOptions(sourceId);
        await this.renderShopItems();
        await this.lookupShopGiftTarget();
        UI.toast(`已送出：${itemMeta.name || '商城物品'}`);
      } catch (e) {
        console.error(e);
        UI.alert(`贈禮失敗：${e.message || e}`, '贈禮失敗');
      } finally {
        this.setShopGiftSending(false);
      }
    },
    async openShopAdmin() { if (!document.getElementById('shopAdminModal')) { UI.alert('找不到商城管理面板，請重新整理頁面後再試。', '系統異常'); return; } this.populateHiddenEggSelect(); this.resetShopAdminForm(); this.resetShopGiftForm(); const effect = document.getElementById('shopAdminEffect'); if (effect && !effect.dataset.boundChange) { effect.addEventListener('change', () => this.updateShopAdminFormState()); effect.dataset.boundChange = '1'; } await this.loadShopAdminList(); await this.loadShopGiftOptions(); this.updateShopAdminFormState(); this.setShopAdminTab('catalog'); UI.showModal('shopAdminModal'); },
    async loadShopAdminList() { const list = document.getElementById('shopAdminList'); if (!list) return; list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>'; try { const snap = await getDocs(collection(db, SHOP_COLLECTION)); if (snap.empty) { list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">目前沒有自訂商品。</div>'; return; } const rows = []; snap.forEach(d => rows.push({ id: d.id, ...(d.data() || {}) })); rows.sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''))); list.innerHTML = rows.map(item => { const soldOut = Math.max(0, Number(item.quantity) || 0) <= 0; const hiddenMeta = item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId] ? ` / ${CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].name}` : ''; return `<div style="background:rgba(0,0,0,0.45); border:1px solid ${soldOut ? '#666' : 'var(--legendary-gold)'}; border-radius:8px; padding:10px;"><div style="display:flex; justify-content:space-between; gap:10px; align-items:flex-start;"><div style="flex:1;"><div style="color:${soldOut ? '#aaa' : 'var(--legendary-gold)'}; font-weight:bold; font-family:'Noto Sans TC';">${item.name || '未命名商品'}</div><div style="font-size:0.78em; color:#ccc; margin-top:4px; font-family:'Noto Sans TC';">${this.getShopEffectLabel(item.effectType)}${hiddenMeta} / ${Number(item.cost) || 0} 🪙 / 庫存 ${Math.max(0, Number(item.quantity) || 0)} / ${item.active === false ? '未上架' : (soldOut ? '售罄' : '上架中')}</div><div style="font-size:0.74em; color:var(--text-muted); margin-top:4px; font-family:'Noto Sans TC';">${item.desc || '—'}</div></div><div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;"><button class="btn" onclick="App.pickShopGiftItem('${item.id}'); App.setShopAdminTab('gift')" style="padding:4px 8px; border-color:var(--legendary-gold); color:var(--legendary-gold);">贈送</button><button class="btn" onclick="App.editShopProduct('${item.id}')" style="padding:4px 8px; border-color:var(--cyan); color:var(--cyan);">編輯</button><button class="btn" onclick="App.deleteShopProduct('${item.id}')" style="padding:4px 8px; border-color:var(--danger); color:var(--danger);">刪除</button></div></div></div>`; }).join(''); } catch (e) { console.error(e); list.innerHTML = '<div style="color:var(--danger); text-align:center;">商品讀取失敗</div>'; } },
    async editShopProduct(productId) { try { const snap = await getDoc(doc(db, SHOP_COLLECTION, productId)); if (!snap.exists()) { UI.toast('商品不存在'); return; } const form = getShopAdminFormElements(); if (!hasCompleteShopAdminForm(form)) { UI.alert('商城管理表單不完整，請重新整理頁面後再試。', '系統異常'); return; } const d = snap.data() || {}; form.name.value = d.name || ''; form.cost.value = Number(d.cost) || 0; form.desc.value = d.desc || ''; form.effect.value = d.effectType || 'antidote'; form.qty.value = Math.max(0, Number(d.quantity) || 0); form.hiddenEgg.value = d.hiddenEggId || ''; form.active.checked = d.active !== false; currentState.editingShopProductId = productId; this.updateShopAdminFormState(); UI.showModal('shopAdminModal'); } catch (e) { console.error(e); UI.toast('商品讀取失敗'); } },
    async saveShopProduct() {
      if (currentState.shopAdminSaving) { UI.toast('商品儲存中，請稍候'); return; }
      const form = getShopAdminFormElements();
      if (!hasCompleteShopAdminForm(form)) { UI.alert('商城管理表單不完整，請重新整理頁面後再試。', '系統異常'); return; }
      const name = (form.name.value || '').trim();
      const cost = Math.max(0, Number(form.cost.value) || 0);
      const rawDesc = (form.desc.value || '').trim();
      const effectType = form.effect.value || 'antidote';
      const quantity = Math.max(0, Number(form.qty.value) || 0);
      const hiddenEggId = effectType === 'hidden_egg' ? (form.hiddenEgg.value || '') : '';
      const active = !!form.active.checked;
      if (!name) { UI.toast('請輸入商品名稱'); return; }
      if (!currentState.editingShopProductId && quantity <= 0) { UI.toast('新增商品請填入數量（至少 1），否則會直接顯示為售罄'); return; }
      if (effectType === 'hidden_egg' && !hiddenEggId) { UI.toast('請選擇特殊異獸蛋'); return; }
      const eggMeta = effectType === 'hidden_egg' ? CONSTANTS.HIDDEN_EGGS[hiddenEggId || ''] : null;
      const desc = rawDesc || (eggMeta ? eggMeta.desc : '');
      const payload = { name, cost, desc, effectType, quantity, hiddenEggId, active, updatedAt: Date.now(), createdAt: Date.now() };
      try {
        this.setShopAdminSaving(true);
        if (currentState.editingShopProductId) {
          const ref = doc(db, SHOP_COLLECTION, currentState.editingShopProductId);
          const old = await getDoc(ref);
          payload.createdAt = old.exists() ? (old.data().createdAt || Date.now()) : Date.now();
          await setDoc(ref, payload, { merge: true });
        } else {
          const id = `custom_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
          await setDoc(doc(db, SHOP_COLLECTION, id), payload, { merge: false });
        }
        this.resetShopAdminForm();
        await this.loadShopAdminList();
        await this.renderShopItems();
        if (quantity <= 0) UI.alert(`商品已儲存：${name}
目前數量為 0，學生端會顯示為灰色「售罄」。`, '商品已儲存');
        else UI.toast(`商品已儲存：${name}`);
      } catch (e) {
        console.error(e);
        UI.alert(`商品儲存失敗：${e.message || e}`, '商品儲存失敗');
      } finally {
        this.setShopAdminSaving(false);
      }
    },
    async deleteShopProduct(productId) {
      if (!productId) return UI.toast('找不到商品 ID');
      if (currentState.shopAdminSaving) { UI.toast('商品作業進行中，請稍候'); return; }
      const ok = await UI.confirm('確定要刪除此商品嗎？售出紀錄不會被刪除。', '刪除商品');
      if (!ok) return;
      try {
        this.setShopAdminSaving(true);
        await deleteDoc(doc(db, SHOP_COLLECTION, productId));
        if (currentState.editingShopProductId === productId) this.resetShopAdminForm();
        await this.loadShopAdminList();
        await this.renderShopItems();
        UI.toast('商品已刪除');
      } catch (e) {
        console.error(e);
        UI.alert(`商品刪除失敗：${e.message || e}`, '商品刪除失敗');
      } finally {
        this.setShopAdminSaving(false);
      }
    },
    async openShop() { const coinsEl = document.getElementById('shopCoins'); UI.showModal('shopModal'); const hasStudent = !!currentState.studentData; if (coinsEl) coinsEl.innerText = hasStudent ? (currentState.studentData.coins || 0) : '...'; await this.renderShopItems(); if (!hasStudent) { if (currentState.currentUid) UI.toast('⏳ 學生資料載入中…'); else UI.alert('請先掃描學生卡或查詢卡序，載入學生資料後才能兌換。', '需要學生資料'); } },
    async applyShopEffect(data, itemMeta, cost) { return this.applyShopEffectLegacy ? this.applyShopEffectLegacy(data, itemMeta, cost) : { applied: false }; },
    async handleShopPurchase(itemId, cost, isBuiltIn = false) {
      if (currentState.shopBusy) { UI.toast('商城處理中，請稍候'); return; }
      if (!currentState.studentData) { UI.alert('請先載入學生資料後再兌換。', '需要學生資料'); return; }
      if (!this.handleShopPurchaseLegacy) { UI.alert('商店流程尚未掛接。', '系統通知'); return; }
      try {
        this.setShopBusy(true);
        return await this.handleShopPurchaseLegacy(itemId, cost, isBuiltIn);
      } catch (e) {
        console.error(e);
        UI.alert(`商城購買失敗：${e.message || e}`, '商城購買失敗');
      } finally {
        this.setShopBusy(false);
        try { await this.renderShopItems(); } catch (renderErr) { console.warn('[shop] render after purchase failed:', renderErr); }
      }
    }
  };
}
