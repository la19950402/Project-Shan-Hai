/*
 * ARCHIVED VARIANT NOTICE
 * File: js/modules/quiz.quizbanksafe.js
 * Status: archived / rollback-only
 * Active chain: js/bootstrap-entry.js -> js/main.entry.js
 * Active core: js/core/app-facade.js + js/core/api-surface.js
 * Reason: historical recovery / forensic reference; do not edit before checking canonical active files.
 */
import { UI } from "../core/ui.js?v=phase15quizbanksafe1";
import { currentState, quizSession } from "../core/state.js?v=phase15quizbanksafe1";
import { db, collection, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc, writeBatch } from "../core/firebase.js?v=phase15quizbanksafe1";

export function createQuizModule({ isQuizEnabled, quizMatchesStudentGrade, getProfileLabels, isCatProfile, buildRewardEventId, formatLocalDateKey }) {
  function normalizeQuizQuestionRecord(raw = {}, id = '') {
    const source = raw && typeof raw === 'object' ? raw : {};
    const normalized = { ...source, id: id || source.id || '' };
    normalized.question = String(source.question || source.questionText || source.q || source.title || source.prompt || source.stem || source.text || '').trim();

    const parseAnswerIndex = (value) => {
      if (typeof value === 'number' && Number.isFinite(value)) return value >= 1 && value <= 4 ? value - 1 : value;
      const str = String(value ?? '').trim();
      if (!str) return -1;
      if (/^[1-4]$/.test(str)) return Number(str) - 1;
      if (/^[A-Da-d]$/.test(str)) return str.toUpperCase().charCodeAt(0) - 65;
      return -1;
    };

    let answerIndex = -1;
    for (const candidate of [source.answer, source.correctAnswer, source.correct_option, source.correctOption, source.correctIndex, source.correct, source.correct_choice, source.correctChoice]) {
      answerIndex = parseAnswerIndex(candidate);
      if (answerIndex >= 0) break;
    }

    let optionCandidates = [];
    if (Array.isArray(source.options)) optionCandidates = source.options;
    else if (Array.isArray(source.choices)) optionCandidates = source.choices;
    else if (Array.isArray(source.selections)) optionCandidates = source.selections;
    else optionCandidates = [source.option1, source.option2, source.option3, source.option4, source.a, source.b, source.c, source.d];

    normalized.options = optionCandidates.slice(0, 4).map((opt, idx) => {
      if (typeof opt === 'string') return { text: opt.trim(), isCorrect: idx === answerIndex };
      return {
        text: String(opt?.text ?? opt?.label ?? opt?.content ?? opt ?? '').trim(),
        isCorrect: !!opt?.isCorrect || idx === answerIndex
      };
    }).filter(opt => !!opt.text);

    if (!normalized.unit && source.category) normalized.unit = source.category;
    if (!normalized.grade && source.gradeName) normalized.grade = source.gradeName;
    return normalized;
  }

  function isQuestionLikeRecord(q = {}) {
    return !!String(q.question || '').trim() || (Array.isArray(q.options) && q.options.some(opt => String(opt?.text || '').trim()));
  }

  return {
    resetQuizForm() { const formTitle = document.getElementById('qmFormTitle'); const editId = document.getElementById('qmEditId'); const saveBtn = document.getElementById('qmSaveBtn'); const cancelBtn = document.getElementById('qmCancelEditBtn'); if (formTitle) formTitle.innerText = '[ 新增題目 ]'; if (editId) editId.value = ''; if (saveBtn) { saveBtn.innerText = '儲存題目'; saveBtn.setAttribute('onclick', 'App.saveNewQuiz()'); } if (cancelBtn) cancelBtn.classList.add('hidden'); const grade = document.getElementById('qmGrade'); const unit = document.getElementById('qmUnit'); const question = document.getElementById('qmQuestion'); const opts = [0,1,2,3].map(i => document.getElementById(`qmOpt${i}`)); if (grade) grade.value = '5上'; if (unit) unit.value = ''; if (question) question.value = ''; opts.forEach(el => { if (el) el.value = ''; }); const firstRadio = document.querySelector('input[name="qmCorrect"][value="0"]'); if (firstRadio) firstRadio.checked = true; },
    fillQuizForm(quizId, quizData = {}) { const formTitle = document.getElementById('qmFormTitle'); const editId = document.getElementById('qmEditId'); const saveBtn = document.getElementById('qmSaveBtn'); const cancelBtn = document.getElementById('qmCancelEditBtn'); if (formTitle) formTitle.innerText = '[ 修改題目 EDIT ENTRY ]'; if (editId) editId.value = quizId || ''; if (saveBtn) { saveBtn.innerText = 'UPDATE ENTRY (儲存修改)'; saveBtn.setAttribute('onclick', 'App.saveEditedQuiz()'); } if (cancelBtn) cancelBtn.classList.remove('hidden'); const gradeEl = document.getElementById('qmGrade'); const unitEl = document.getElementById('qmUnit'); const questionEl = document.getElementById('qmQuestion'); if (gradeEl) gradeEl.value = quizData.grade || '5上'; if (unitEl) unitEl.value = quizData.unit || ''; if (questionEl) questionEl.value = quizData.question || ''; const options = Array.isArray(quizData.options) ? quizData.options : []; for (let i=0;i<4;i++) { const opt = options[i] || {}; const input = document.getElementById(`qmOpt${i}`); if (input) input.value = opt.text || ''; const radio = document.querySelector(`input[name="qmCorrect"][value="${i}"]`); if (radio) radio.checked = !!opt.isCorrect; } if (!Array.from(document.querySelectorAll('input[name="qmCorrect"]')).some(r => r.checked)) { const firstRadio = document.querySelector('input[name="qmCorrect"][value="0"]'); if (firstRadio) firstRadio.checked = true; } const box = document.getElementById('quizManagerModal')?.querySelector('.modal-content'); if (box) box.scrollTo({ top: 0, behavior: 'smooth' }); },
    async openEditQuiz(id) { try { const snap = await getDoc(doc(db, 'quiz_bank', id)); if (!snap.exists()) return UI.toast('找不到題目資料'); this.fillQuizForm(id, snap.data()); } catch (e) { console.error(e); UI.toast('讀取題目失敗'); } },
    cancelQuizEdit() { this.resetQuizForm(); },
    readQuizFormData() { const qGrade = document.getElementById('qmGrade')?.value || '5上'; const qUnit = document.getElementById('qmUnit')?.value.trim() || '未分類'; const qText = document.getElementById('qmQuestion')?.value.trim() || ''; const opts = [0,1,2,3].map(i => (document.getElementById(`qmOpt${i}`)?.value || '').trim()); const checked = document.querySelector('input[name="qmCorrect"]:checked'); const correctVal = checked ? String(checked.value) : '0'; if (!qText || opts.some(v => !v)) { UI.toast('請填寫完整題目！'); return null; } return { grade:qGrade, unit:qUnit, question:qText, options: opts.map((text, idx) => ({ text, isCorrect: correctVal === String(idx) })) }; },
    setQuizBusy(kind, flag = true) { currentState[kind] = !!flag; },
    isQuizBusy() { return !!(currentState.quizLoading || currentState.quizSaving || currentState.quizDeleting || currentState.quizToggling || currentState.quizExporting); },
    async importQuizBulk() { return this.importQuizBulkLegacy ? this.importQuizBulkLegacy() : UI.toast('題庫匯入邏輯仍保留於主系統'); },
    async exportQuizBank(format='json') { return this.exportQuizBankLegacy ? this.exportQuizBankLegacy(format) : UI.toast('題庫匯出邏輯仍保留於主系統'); },
    updateQuizSelectionSummary(visibleIds = null) { const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []; const counter = document.getElementById('qmSelectedCount'); if (counter) counter.innerText = `已勾選 ${selectedIds.length} 題`; const allCheckbox = document.getElementById('qmSelectAll'); if (allCheckbox) { const visible = Array.isArray(visibleIds) ? visibleIds : []; const selectedVisible = visible.filter(id => selectedIds.includes(id)).length; allCheckbox.checked = visible.length > 0 && selectedVisible === visible.length; allCheckbox.indeterminate = selectedVisible > 0 && selectedVisible < visible.length; } },
    updateQuizFilterState() { return this.updateQuizFilterStateLegacy ? this.updateQuizFilterStateLegacy() : void 0; },
    getFilteredQuizzes() { return this.getFilteredQuizzesLegacy ? this.getFilteredQuizzesLegacy() : []; },
    toggleQuizSelection(id, checked) { const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []); if (checked) selected.add(id); else selected.delete(id); currentState.quizSelectedIds = Array.from(selected); const visibleIds = this.getFilteredQuizzes().map(q => q.id); this.updateQuizSelectionSummary(visibleIds); },
    toggleAllQuizSelections(checked) { return this.toggleAllQuizSelectionsLegacy ? this.toggleAllQuizSelectionsLegacy(checked) : void 0; },
    renderQuizBankList() { return this.renderQuizBankListLegacy ? this.renderQuizBankListLegacy() : void 0; },
    async batchSetQuizActive(active) { return this.batchSetQuizActiveLegacy ? this.batchSetQuizActiveLegacy(active) : void 0; },
    async batchDeleteSelectedQuizzes() { return this.batchDeleteSelectedQuizzesLegacy ? this.batchDeleteSelectedQuizzesLegacy() : void 0; },
    async loadQuizBank() {
      if (currentState.quizLoading) return;
      UI.showModal('quizManagerModal');
      this.resetQuizForm();
      const container = document.getElementById('quizListContainer');
      if (container) container.innerHTML = '<div style="text-align:center;">載入中...</div>';
      currentState.quizSelectedIds = [];
      currentState.quizBankLoadDiag = { startedAt: Date.now(), skipped: [], loaded: 0, totalDocs: 0, renderError: null, fetchError: null };
      try {
        this.setQuizBusy('quizLoading', true);
        const snapshot = await getDocs(collection(db, 'quiz_bank'));
        const quizzes = [];
        const skipped = [];
        currentState.quizBankLoadDiag.totalDocs = Number(snapshot?.size || 0);

        snapshot.forEach(docSnap => {
          if (docSnap.id === '_BATTLE_TOWER_BOSS_') return;
          try {
            const raw = docSnap.data() || {};
            const normalized = normalizeQuizQuestionRecord(raw, docSnap.id);
            if (!isQuestionLikeRecord(normalized)) {
              skipped.push({ id: docSnap.id, reason: 'not-question-like' });
              return;
            }
            quizzes.push(normalized);
          } catch (err) {
            skipped.push({ id: docSnap.id, reason: err?.message || String(err) });
          }
        });

        quizzes.sort((a, b) => (b.timestamp || b.updatedAt || 0) - (a.timestamp || a.updatedAt || 0));
        currentState.quizBankCache = quizzes;
        currentState.quizBankLoadDiag.loaded = quizzes.length;
        currentState.quizBankLoadDiag.skipped = skipped;

        const total = document.getElementById('qmTotalCount');
        if (total) total.innerText = String(quizzes.length);
        if (skipped.length) console.warn('[quiz] skipped malformed or non-question docs', skipped);

        if (!quizzes.length) {
          if (container) container.innerHTML = '<div style="text-align:center; color:#555;">題庫為空！</div>';
          try { this.updateQuizFilterState(); } catch (err) { console.warn('[quiz] updateQuizFilterState failed on empty quiz bank', err); }
          this.updateQuizSelectionSummary([]);
          return;
        }

        try { this.updateQuizFilterState(); } catch (err) { console.warn('[quiz] updateQuizFilterState failed', err); }
        try { this.renderQuizBankList(); } catch (err) {
          currentState.quizBankLoadDiag.renderError = err?.message || String(err);
          console.error('[quiz] renderQuizBankList failed', err);
          if (container) container.innerHTML = '<div style="text-align:center; color:var(--danger);">題庫已載入，但畫面渲染失敗</div>';
          throw err;
        }
      } catch (e) {
        currentState.quizBankLoadDiag.fetchError = e?.message || String(e);
        console.error(e);
        currentState.quizBankCache = [];
        if (container) container.innerHTML = '<div style="text-align:center; color:var(--danger);">題庫載入失敗</div>';
        this.updateQuizSelectionSummary([]);
        UI.alert(`題庫載入失敗：${e.message || e}`, '題庫載入失敗');
      } finally {
        this.setQuizBusy('quizLoading', false);
      }
    },
    async saveNewQuiz() {
      if (currentState.quizSaving) { UI.toast('題庫儲存中，請稍候'); return; }
      const formData = this.readQuizFormData();
      if (!formData) return;
      const newQuiz = { ...formData, isActive: false, timestamp: Date.now() };
      try {
        this.setQuizBusy('quizSaving', true);
        await addDoc(collection(db, 'quiz_bank'), newQuiz);
        UI.toast('✅ 新增成功！');
        this.resetQuizForm();
        await this.loadQuizBank();
      } catch(e) {
        console.error(e);
        UI.alert(`新增失敗：${e.message || e}`, '題庫新增失敗');
      } finally {
        this.setQuizBusy('quizSaving', false);
      }
    },
    async saveEditedQuiz() {
      if (currentState.quizSaving) { UI.toast('題庫儲存中，請稍候'); return; }
      const editId = document.getElementById('qmEditId')?.value;
      if (!editId) return UI.toast('找不到要修改的題目');
      const formData = this.readQuizFormData();
      if (!formData) return;
      try {
        this.setQuizBusy('quizSaving', true);
        const oldSnap = await getDoc(doc(db, 'quiz_bank', editId));
        const oldData = oldSnap.exists() ? oldSnap.data() : {};
        await updateDoc(doc(db, 'quiz_bank', editId), { ...formData, isActive: oldData.isActive === true, timestamp: oldData.timestamp || Date.now(), updatedAt: Date.now() });
        UI.toast('✏️ 題目已更新');
        this.resetQuizForm();
        await this.loadQuizBank();
      } catch (e) {
        console.error(e);
        UI.alert(`修改失敗：${e.message || e}`, '題庫修改失敗');
      } finally {
        this.setQuizBusy('quizSaving', false);
      }
    },
    async deleteQuiz(id) {
      if (currentState.quizDeleting) { UI.toast('刪除進行中，請稍候'); return; }
      const isConfirmed = await UI.confirm(`確定要永久刪除這筆資料嗎？
(此操作無法復原)`, '刪除確認');
      if (!isConfirmed) return;
      try {
        this.setQuizBusy('quizDeleting', true);
        await deleteDoc(doc(db, 'quiz_bank', id));
        UI.toast('🗑️ 已刪除');
        this.resetQuizForm();
        await this.loadQuizBank();
      } catch(e) {
        console.error(e);
        UI.alert(`刪除失敗：${e.message || e}`, '題庫刪除失敗');
      } finally {
        this.setQuizBusy('quizDeleting', false);
      }
    },
    async toggleQuizActive(id, currentStatus) {
      if (currentState.quizToggling) { UI.toast('狀態切換中，請稍候'); return; }
      try {
        this.setQuizBusy('quizToggling', true);
        await updateDoc(doc(db, 'quiz_bank', id), { isActive: !currentStatus, updatedAt: Date.now() });
        await this.loadQuizBank();
      } catch(e) {
        console.error(e);
        UI.alert(`切換失敗：${e.message || e}`, '題庫切換失敗');
      } finally {
        this.setQuizBusy('quizToggling', false);
      }
    },
    async startDailyQuest() { return this.startDailyQuestLegacy ? this.startDailyQuestLegacy() : UI.toast('每日歷練流程仍保留於主系統'); },
    renderQuizQuestion() { return this.renderQuizQuestionLegacy ? this.renderQuizQuestionLegacy() : void 0; },
    async selectQuizOption(selectedIndex, isCorrect) { return this.selectQuizOptionLegacy ? this.selectQuizOptionLegacy(selectedIndex, isCorrect) : void 0; }
  };
}
