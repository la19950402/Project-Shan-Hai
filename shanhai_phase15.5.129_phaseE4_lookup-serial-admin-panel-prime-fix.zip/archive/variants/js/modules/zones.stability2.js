import { UI } from "../core/ui.js?v=phase15quizbankfix1";
import { currentState } from "../core/state.js?v=phase15quizbankfix1";
import { db, collection, doc, getDoc, getDocs, setDoc } from "../core/firebase.js?v=phase15quizbankfix1";

const ensureSupportZoneCache = () => {
  if (!currentState.supportZoneCache || typeof currentState.supportZoneCache !== 'object') {
    currentState.supportZoneCache = { students: [], todayRecord: null };
  }
  return currentState.supportZoneCache;
};

const ensureScienceZoneCache = () => {
  if (!currentState.scienceZoneCache || typeof currentState.scienceZoneCache !== 'object') {
    currentState.scienceZoneCache = { students: [], todayRecord: null };
  }
  return currentState.scienceZoneCache;
};

const ensureSupportBatchCounter = () => {
  if (!Number.isFinite(Number(currentState.supportBatchScanCount))) currentState.supportBatchScanCount = 0;
  return Number(currentState.supportBatchScanCount) || 0;
};

const ensureScienceBatchCounter = () => {
  if (!Number.isFinite(Number(currentState.scienceBatchScanCount))) currentState.scienceBatchScanCount = 0;
  return Number(currentState.scienceBatchScanCount) || 0;
};

export function createZonesModule({ COLLECTION_NAME, SUPPORT_ZONE_COLLECTION, SCIENCE_ZONE_COLLECTION, CONSTANTS, ELEMENT_KEYS, addAttributeXP, formatLocalDateKey, formatLocalDateTime, downloadCsvFile }) {
  const hasSupportZoneDom = () => !!(document.getElementById('supportZoneModal') && document.getElementById('supportStudentSelect') && document.getElementById('supportTodayRecordSummary'));
  const hasScienceZoneDom = () => !!(document.getElementById('scienceZoneModal') && document.getElementById('scienceStudentSelect') && document.getElementById('scienceTodayRecordSummary'));

  return {
    buildSupportZoneUrl() {
      const url = new URL(window.location.origin + window.location.pathname);
      url.searchParams.set('panel', 'support-zone');
      return url.toString();
    },
    buildScienceZoneUrl() {
      const url = new URL(window.location.origin + window.location.pathname);
      url.searchParams.set('panel', 'science-zone');
      return url.toString();
    },
    async openRequestedAdminPanel() {
      const panel = this.getRequestedAdminPanel();
      if (!panel || !currentState.isAdmin || currentState.pendingAdminPanelOpened) return;
      currentState.pendingAdminPanelOpened = true;
      if (panel === 'support-zone') return this.openSupportZone();
      if (panel === 'science-zone') return this.openScienceZone();
    },
    getSupportTagMeta() {
      return (CONSTANTS.TEAM_ACTION_PANELS?.support?.attrFocus) || {};
    },
    populateSupportBatchFacetSelect() {
      const sel = document.getElementById('supportBatchFacetSelect');
      if (!sel) return;
      const attrFocus = this.getSupportTagMeta();
      sel.innerHTML = '<option value="">僅點名，不加分</option>' + ELEMENT_KEYS.map(attr => {
        const info = attrFocus[attr] || {};
        const attrName = CONSTANTS.ATTRIBUTES?.[attr]?.name || attr;
        return `<option value="${attr}">${info.label || attrName}｜${attrName}｜每次 +10</option>`;
      }).join('');
    },
    getSelectedSupportStudentMeta() {
      const sel = document.getElementById('supportStudentSelect');
      if (!sel || !sel.value) return null;
      const cardSeq = String(sel.value || '').trim();
      const picked = ensureSupportZoneCache().students.find(s => String(s.card_seq) === cardSeq) || null;
      return picked;
    },
    renderSupportSelectedMeta(student) {
      const metaEl = document.getElementById('supportSelectedStudentMeta');
      if (!metaEl) return;
      if (!student) {
        metaEl.innerHTML = '尚未選擇學生。';
        return;
      }
      metaEl.innerHTML = `目前學生：<span style="color:#fff; font-weight:bold;">${student.name || '未命名'}</span>｜卡序 <span style="color:var(--legendary-gold);">${student.card_seq || '—'}</span>｜${student.class_name || '學習扶助班'}${student.seat_number ? `｜座號 ${student.seat_number}` : ''}`;
    },
    updateSupportBatchStatus(message, append = false) {
      const box = document.getElementById('supportBatchStatus');
      if (!box) return;
      const counter = `<div style="margin-bottom:6px; color:var(--warning);">本輪已掃描：<span style="color:#fff; font-weight:bold;">${ensureSupportBatchCounter()}</span> 張</div>`;
      if (!append) {
        box.innerHTML = counter + `<div>${message}</div>`;
        return;
      }
      box.innerHTML = counter + `<div>${message}</div>` + (box.dataset.lastLog ? `<div style="margin-top:8px; color:var(--text-muted);">${box.dataset.lastLog}</div>` : '');
      box.dataset.lastLog = message;
    },
    async loadSupportStudentsList() {
      try {
        const sel = document.getElementById('supportStudentSelect');
        if (sel) sel.innerHTML = '<option value="">讀取中...</option>';
        const snap = await getDocs(collection(db, COLLECTION_NAME));
        const students = [];
        snap.forEach(ds => {
          const d = ds.data() || {};
          students.push({
            card_seq: String(d.card_seq || ds.id || '').trim(),
            name: d.name || '未命名',
            class_name: d.class_name || '學習扶助班',
            seat_number: d.seat_number || '',
            uid: d.uid || ''
          });
        });
        const studentsFiltered = students.filter(s => /學習扶助/.test(String(s.class_name || '').trim()));
        studentsFiltered.sort((a,b) => String(a.seat_number).localeCompare(String(b.seat_number), 'zh-Hant-u-nu-hanidec') || String(a.card_seq).localeCompare(String(b.card_seq)));
        ensureSupportZoneCache().students = studentsFiltered;
        if (sel) {
          sel.innerHTML = '<option value="">請選擇學生</option>' + studentsFiltered.map(s => `<option value="${String(s.card_seq).replace(/"/g,'&quot;')}">${s.name}｜卡序 ${s.card_seq}${s.seat_number ? `｜座號 ${s.seat_number}` : ''}</option>`).join('');
          sel.onchange = () => { this.handleSupportStudentChange(); };
        }
        this.renderSupportSelectedMeta(null);
        this.populateSupportBatchFacetSelect();
        const urlEl = document.getElementById('supportZoneUrlDisplay');
        if (urlEl) urlEl.value = this.buildSupportZoneUrl();
        if (!studentsFiltered.length) UI.toast('目前找不到「學習扶助」或「學習扶助班」學生資料');
      } catch (e) {
        console.error('[support zone] load students failed:', e);
        UI.alert('讀取學習扶助名單失敗，請稍後再試。', '系統通知');
      }
    },
    async useCurrentStudentInSupportZone() {
      const d = currentState.studentData || null;
      if (!d || !/學習扶助/.test(String(d.class_name || '').trim())) {
        return UI.toast('目前管理面板尚未讀到「學習扶助」或「學習扶助班」學生。');
      }
      const sel = document.getElementById('supportStudentSelect');
      if (!sel) return;
      const cache = ensureSupportZoneCache();
      if (!cache.students.some(s => String(s.card_seq) === String(d.card_seq))) {
        cache.students.push({ card_seq: String(d.card_seq), name: d.name || '未命名', class_name: d.class_name || '學習扶助班', seat_number: d.seat_number || '', uid: d.uid || '' });
        sel.innerHTML += `<option value="${String(d.card_seq).replace(/"/g,'&quot;')}">${d.name || '未命名'}｜卡序 ${d.card_seq}${d.seat_number ? `｜座號 ${d.seat_number}` : ''}</option>`;
      }
      sel.value = String(d.card_seq);
      await this.handleSupportStudentChange();
    },
    async handleSupportStudentChange() {
      const student = this.getSelectedSupportStudentMeta();
      this.renderSupportSelectedMeta(student);
      await this.loadSupportTodayRecord();
    },
    getSupportRecordDocRef(cardSeq, dateKey = formatLocalDateKey()) {
      const safeCardSeq = String(cardSeq || '').trim();
      return doc(db, SUPPORT_ZONE_COLLECTION, `${safeCardSeq}_${dateKey}`);
    },
    collectSupportDailyForm() {
      const attendance = document.getElementById('supportAttendanceSelect')?.value || '出席';
      const learningStatus = document.getElementById('supportLearningStatusSelect')?.value || '穩定投入';
      const tags = Array.from(document.querySelectorAll('#supportPerformanceTags input[type="checkbox"]:checked')).map(el => el.value);
      const note = String(document.getElementById('supportTeacherNote')?.value || '').trim();
      return { attendance_status: attendance, learning_status: learningStatus, performance_tags: tags, teacher_note: note };
    },
    fillSupportDailyForm(record = null) {
      const attendanceSel = document.getElementById('supportAttendanceSelect');
      const statusSel = document.getElementById('supportLearningStatusSelect');
      const noteEl = document.getElementById('supportTeacherNote');
      if (attendanceSel) attendanceSel.value = record?.attendance_status || '出席';
      if (statusSel) statusSel.value = record?.learning_status || '穩定投入';
      if (noteEl) noteEl.value = record?.teacher_note || '';
      const checked = new Set(Array.isArray(record?.performance_tags) ? record.performance_tags : []);
      document.querySelectorAll('#supportPerformanceTags input[type="checkbox"]').forEach(el => { el.checked = checked.has(el.value); });
    },
    renderSupportTodayRecord(record = null) {
      const box = document.getElementById('supportTodayRecordSummary');
      if (!box) return;
      if (!record) {
        box.innerHTML = '尚無今日紀錄。';
        return;
      }
      const tags = Array.isArray(record.performance_tags) && record.performance_tags.length ? record.performance_tags.join('、') : '尚未勾選';
      box.innerHTML = `<div>日期：<span style="color:#fff;">${record.date_key || formatLocalDateKey()}</span></div><div>出缺狀態：<span style="color:#fff;">${record.attendance_status || '出席'}</span></div><div>簽到時間：<span style="color:#fff;">${formatLocalDateTime(record.check_in_time)}</span></div><div>學習狀況：<span style="color:#fff;">${record.learning_status || '穩定投入'}</span></div><div>表現標記：<span style="color:#fff;">${tags}</span></div><div>老師備註：<span style="color:#fff;">${record.teacher_note || '—'}</span></div><div>簽退時間：<span style="color:#fff;">${formatLocalDateTime(record.check_out_time)}</span></div>`;
    },
    async loadSupportTodayRecord() {
      const student = this.getSelectedSupportStudentMeta();
      if (!student?.card_seq) {
        ensureSupportZoneCache().todayRecord = null;
        this.fillSupportDailyForm(null);
        this.renderSupportTodayRecord(null);
        return;
      }
      try {
        const snap = await getDoc(this.getSupportRecordDocRef(student.card_seq));
        const data = snap.exists() ? (snap.data() || null) : null;
        ensureSupportZoneCache().todayRecord = data;
        this.fillSupportDailyForm(data);
        this.renderSupportTodayRecord(data);
      } catch (e) {
        console.error('[support zone] load today record failed:', e);
        UI.toast('讀取今日紀錄失敗');
      }
    },
    async saveSupportRecordForStudent(student, patch = {}, toastMessage = '') {
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      try {
        const now = Date.now();
        const dateKey = formatLocalDateKey(now);
        const ref = this.getSupportRecordDocRef(student.card_seq, dateKey);
        const existingSnap = await getDoc(ref);
        const existing = existingSnap.exists() ? (existingSnap.data() || {}) : {};
        const base = this.collectSupportDailyForm();
        const mergedTags = Array.from(new Set([...(Array.isArray(existing.performance_tags) ? existing.performance_tags : []), ...(Array.isArray(base.performance_tags) ? base.performance_tags : []), ...(Array.isArray(patch.performance_tags) ? patch.performance_tags : [])]));
        const payload = {
          card_seq: String(student.card_seq),
          name: student.name || '',
          class_name: student.class_name || '學習扶助班',
          seat_number: student.seat_number || '',
          date_key: dateKey,
          updated_at: now,
          attendance_status: patch.attendance_status ?? base.attendance_status ?? existing.attendance_status ?? '出席',
          learning_status: patch.learning_status ?? base.learning_status ?? existing.learning_status ?? '穩定投入',
          teacher_note: patch.teacher_note ?? (base.teacher_note || existing.teacher_note || ''),
          performance_tags: mergedTags,
          check_in_time: patch.check_in_time !== undefined ? patch.check_in_time : (existing.check_in_time ?? null),
          check_out_time: patch.check_out_time !== undefined ? patch.check_out_time : (existing.check_out_time ?? null),
          batch_scan_count: Number(existing.batch_scan_count || 0) + (Number(patch.batch_scan_count_delta) || 0)
        };
        Object.keys(patch || {}).forEach(k => {
          if (k === 'performance_tags' || k === 'batch_scan_count_delta') return;
          payload[k] = patch[k];
        });
        await setDoc(ref, payload, { merge: true });
        const selected = this.getSelectedSupportStudentMeta();
        if (selected && String(selected.card_seq) === String(student.card_seq)) {
          await this.loadSupportTodayRecord();
        }
        if (toastMessage) UI.toast(toastMessage);
        return payload;
      } catch (e) {
        console.error('[support zone] save record failed:', e);
        UI.alert('儲存學習扶助紀錄失敗，請稍後再試。', '系統通知');
      }
    },
    async saveSupportRecord(patch = {}, toastMessage = '已更新學習扶助紀錄') {
      const student = this.getSelectedSupportStudentMeta();
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      return this.saveSupportRecordForStudent(student, patch, toastMessage);
    },
    async supportCheckIn() {
      const patch = { check_in_time: Date.now() };
      const attendance = document.getElementById('supportAttendanceSelect')?.value;
      if (!attendance || attendance === '請假' || attendance === '缺席') patch.attendance_status = '出席';
      await this.saveSupportRecord(patch, '已完成簽到');
    },
    async saveSupportDailyRecord() {
      await this.saveSupportRecord({}, '已儲存今日學習表現');
    },
    async supportCheckOut() {
      await this.saveSupportRecord({ check_out_time: Date.now() }, '已完成簽退');
    },
    async markSupportAbsent() {
      const attendance = document.getElementById('supportAttendanceSelect')?.value || '缺席';
      await this.saveSupportRecord({ attendance_status: attendance, check_in_time: null, check_out_time: null }, `已記錄為${attendance}`);
    },
    async copySupportZoneUrl() {
      const url = this.buildSupportZoneUrl();
      try {
        await navigator.clipboard.writeText(url);
        UI.toast('已複製學習扶助專區網址');
      } catch (e) {
        UI.alert(`請手動複製以下網址：
${url}`, '複製失敗');
      }
    },
    async writeSupportZoneLinkToNfc() {
      if (!("NDEFReader" in window)) { UI.alert('裝置不支援 Web NFC。', '硬體錯誤'); return; }
      if (!window.isSecureContext) { UI.alert('Web NFC 需要在 HTTPS 安全環境下使用。', '硬體錯誤'); return; }
      const shouldRestart = !!currentState.scanIntention && currentState.scanIntention !== 'read';
      const restoreIntention = currentState.scanIntention;
      try {
        this.stopWebNfc();
        const ndef = new NDEFReader();
        const url = this.buildSupportZoneUrl();
        await ndef.write({ records: [{ recordType: 'url', data: url }] });
        const urlEl = document.getElementById('supportZoneUrlDisplay');
        if (urlEl) urlEl.value = url;
        UI.toast('✅ 學習扶助專區網址已寫入 NFC 卡片');
      } catch (e) {
        console.error('[support zone] write nfc failed:', e);
        UI.alert(`寫入失敗：${e.message || e}`, '寫入異常');
      } finally {
        if (shouldRestart) {
          currentState.scanIntention = restoreIntention;
          try { await this.startWebNfc(false); } catch (_) {}
        }
      }
    },
    async startSupportBatchScan() {
      currentState.scanIntention = 'support-batch';
      currentState.supportBatchScanCount = 0;
      this.updateSupportBatchStatus('批量掃描已啟動，請依序感應學生 NTAG。');
      const ok = await this.startWebNfc(true);
      if (!ok) currentState.scanIntention = 'read';
    },
    stopSupportBatchScan() {
      if (currentState.scanIntention === 'support-batch') currentState.scanIntention = 'read';
      this.stopWebNfc();
      this.updateSupportBatchStatus('批量掃描已停止。');
    },
    async applySupportRewardToStudent(serial, studentData, attr) {
      const rewardMap = this.getSupportTagMeta();
      const label = rewardMap?.[attr]?.label || (CONSTANTS.ATTRIBUTES?.[attr]?.name || attr);
      let data = this.applyDataMigration(JSON.parse(JSON.stringify(studentData || {})));
      if (!data.logs) data.logs = [];
      if (!data.streaks) data.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      if (!data.attr_event_counts) data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.totalXP = (Number(data.totalXP) || 0) + 10;
      addAttributeXP(data, attr, 10);
      ELEMENT_KEYS.forEach(k => { data.streaks[k] = (k === attr ? 1 : 0); });
      data.attr_event_counts[attr] = (Number(data.attr_event_counts[attr]) || 0) + 1;
      data.logs.push({ timestamp: Date.now(), action_type: 'support_zone', points_added: 10, detail: `[學習扶助專區] ${label} -> +10XP (${CONSTANTS.ATTRIBUTES[attr]?.name || attr})` });
      data = this.processEvolution(data);
      await this.saveToDB(data, serial);
      return label;
    },
    async handleSupportBatchScan(serial) {
      try {
        const stuSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
        if (!stuSnap.exists()) {
          UI.toast('❌ 找不到這張卡片對應的學生資料');
          return;
        }
        const data = stuSnap.data() || {};
        if (!/學習扶助/.test(String(data.class_name || '').trim())) {
          UI.toast(`⚠️ ${data.name || serial} 不是學習扶助學生，已略過`);
          return;
        }
        const student = { card_seq: String(data.card_seq || serial), name: data.name || '未命名', class_name: data.class_name || '學習扶助班', seat_number: data.seat_number || '', uid: data.uid || '' };
        const sel = document.getElementById('supportStudentSelect');
        const cache = ensureSupportZoneCache();
        if (sel) {
          if (!cache.students.some(s => String(s.card_seq) === String(student.card_seq))) {
            cache.students.push(student);
            sel.innerHTML += `<option value="${String(student.card_seq).replace(/"/g,'&quot;')}">${student.name}｜卡序 ${student.card_seq}${student.seat_number ? `｜座號 ${student.seat_number}` : ''}</option>`;
          }
          sel.value = String(student.card_seq);
        }
        this.renderSupportSelectedMeta(student);

        const attr = String(document.getElementById('supportBatchFacetSelect')?.value || '').trim();
        const autoCheckIn = !!document.getElementById('supportBatchAutoCheckIn')?.checked;
        const perfTags = [];
        const attrFocus = this.getSupportTagMeta();
        if (attr && attrFocus[attr]?.label) perfTags.push(attrFocus[attr].label);
        const patch = { batch_scan_count_delta: 1, performance_tags: perfTags };
        if (autoCheckIn) {
          const todaySnap = await getDoc(this.getSupportRecordDocRef(student.card_seq));
          const today = todaySnap.exists() ? (todaySnap.data() || {}) : {};
          if (!today.check_in_time) patch.check_in_time = Date.now();
          if (!today.attendance_status || today.attendance_status === '缺席' || today.attendance_status === '請假') patch.attendance_status = '出席';
        }
        await this.saveSupportRecordForStudent(student, patch, '');
        let rewardLabel = '';
        if (attr && ELEMENT_KEYS.includes(attr)) {
          rewardLabel = await this.applySupportRewardToStudent(student.card_seq, data, attr);
        }
        currentState.supportBatchScanCount = ensureSupportBatchCounter() + 1;
        const summary = rewardLabel ? `已為 ${student.name} 完成點名，並記錄「${rewardLabel}」+10。` : `已為 ${student.name} 完成點名。`;
        this.updateSupportBatchStatus(summary, true);
        await this.loadSupportTodayRecord();
        UI.toast(`✅ ${student.name}${rewardLabel ? `｜${rewardLabel} +10` : '｜已點名'}`);
      } catch (e) {
        console.error('[support zone] batch scan failed:', e);
        UI.alert('批量掃描處理失敗，請稍後再試。', '系統通知');
      }
    },
    async openSupportZone() {
      if (!hasSupportZoneDom()) { UI.alert('找不到學習扶助專區面板，請重新整理頁面後再試。', '系統異常'); return; }
      UI.showModal('supportZoneModal');
      const urlEl = document.getElementById('supportZoneUrlDisplay');
      if (urlEl) urlEl.value = this.buildSupportZoneUrl();
      this.populateSupportBatchFacetSelect();
      await this.loadSupportStudentsList();
      if (currentState.studentData && /學習扶助/.test(String(currentState.studentData.class_name || '').trim())) {
        await this.useCurrentStudentInSupportZone();
      }
    },
    async exportSupportHistoryCurrent() {
      const student = this.getSelectedSupportStudentMeta();
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      try {
        const snap = await getDocs(collection(db, SUPPORT_ZONE_COLLECTION));
        const rows = [['卡序','姓名','日期','出缺狀態','簽到時間','學習狀況','表現標記','老師備註','簽退時間']];
        const items = [];
        snap.forEach(ds => { const d = ds.data() || {}; if (String(d.card_seq) === String(student.card_seq)) items.push(d); });
        items.sort((a,b) => String(a.date_key||'').localeCompare(String(b.date_key||'')));
        items.forEach(d => rows.push([d.card_seq || '', d.name || '', d.date_key || '', d.attendance_status || '', formatLocalDateTime(d.check_in_time), d.learning_status || '', Array.isArray(d.performance_tags) ? d.performance_tags.join('、') : '', d.teacher_note || '', formatLocalDateTime(d.check_out_time)]));
        if (rows.length === 1) return UI.toast('目前學生尚無可匯出的歷史紀錄');
        downloadCsvFile(`support_history_${student.card_seq}.csv`, rows);
      } catch (e) {
        console.error('[support zone] export current failed:', e);
        UI.alert('匯出目前學生歷史紀錄失敗。', '系統通知');
      }
    },
    async exportSupportHistoryAll() {
      try {
        const snap = await getDocs(collection(db, SUPPORT_ZONE_COLLECTION));
        const rows = [['卡序','姓名','班別','座號','日期','出缺狀態','簽到時間','學習狀況','表現標記','老師備註','簽退時間','最後更新']];
        const items = [];
        snap.forEach(ds => items.push(ds.data() || {}));
        items.sort((a,b) => (String(a.card_seq||'').localeCompare(String(b.card_seq||'')) || String(a.date_key||'').localeCompare(String(b.date_key||''))));
        items.forEach(d => rows.push([d.card_seq || '', d.name || '', d.class_name || '', d.seat_number || '', d.date_key || '', d.attendance_status || '', formatLocalDateTime(d.check_in_time), d.learning_status || '', Array.isArray(d.performance_tags) ? d.performance_tags.join('、') : '', d.teacher_note || '', formatLocalDateTime(d.check_out_time), formatLocalDateTime(d.updated_at)]));
        if (rows.length === 1) return UI.toast('目前沒有可匯出的學習扶助紀錄');
        downloadCsvFile(`support_history_all_${formatLocalDateKey()}.csv`, rows);
      } catch (e) {
        console.error('[support zone] export all failed:', e);
        UI.alert('匯出全部學習扶助紀錄失敗。', '系統通知');
      }
    },
    getScienceTagMeta() {
      return (CONSTANTS.TEAM_ACTION_PANELS?.science?.attrFocus) || {};
    },
    populateScienceBatchFacetSelect() {
      const sel = document.getElementById('scienceBatchFacetSelect');
      if (!sel) return;
      const attrFocus = this.getScienceTagMeta();
      sel.innerHTML = '<option value="">僅點名，不加分</option>' + ELEMENT_KEYS.map(attr => {
        const info = attrFocus[attr] || {};
        const attrName = CONSTANTS.ATTRIBUTES?.[attr]?.name || attr;
        return `<option value="${attr}">${info.label || attrName}｜${attrName}｜每次 +10</option>`;
      }).join('');
    },
    getSelectedScienceStudentMeta() {
      const sel = document.getElementById('scienceStudentSelect');
      if (!sel || !sel.value) return null;
      const cardSeq = String(sel.value || '').trim();
      const picked = ensureScienceZoneCache().students.find(s => String(s.card_seq) === cardSeq) || null;
      return picked;
    },
    renderScienceSelectedMeta(student) {
      const metaEl = document.getElementById('scienceSelectedStudentMeta');
      if (!metaEl) return;
      if (!student) {
        metaEl.innerHTML = '尚未選擇學生。';
        return;
      }
      metaEl.innerHTML = `目前學生：<span style="color:#fff; font-weight:bold;">${student.name || '未命名'}</span>｜卡序 <span style="color:var(--legendary-gold);">${student.card_seq || '—'}</span>｜${student.class_name || '科展團隊'}${student.seat_number ? `｜座號 ${student.seat_number}` : ''}`;
    },
    updateScienceBatchStatus(message, append = false) {
      const box = document.getElementById('scienceBatchStatus');
      if (!box) return;
      const counter = `<div style="margin-bottom:6px; color:var(--warning);">本輪已掃描：<span style="color:#fff; font-weight:bold;">${ensureScienceBatchCounter()}</span> 張</div>`;
      if (!append) {
        box.innerHTML = counter + `<div>${message}</div>`;
        return;
      }
      box.innerHTML = counter + `<div>${message}</div>` + (box.dataset.lastLog ? `<div style="margin-top:8px; color:var(--text-muted);">${box.dataset.lastLog}</div>` : '');
      box.dataset.lastLog = message;
    },
    async loadScienceStudentsList() {
      try {
        const sel = document.getElementById('scienceStudentSelect');
        if (sel) sel.innerHTML = '<option value="">讀取中...</option>';
        const snap = await getDocs(collection(db, COLLECTION_NAME));
        const students = [];
        snap.forEach(ds => {
          const d = ds.data() || {};
          students.push({
            card_seq: String(d.card_seq || ds.id || '').trim(),
            name: d.name || '未命名',
            class_name: d.class_name || '科展團隊',
            seat_number: d.seat_number || '',
            uid: d.uid || ''
          });
        });
        const studentsFiltered = students.filter(s => /科展團隊/.test(String(s.class_name || '').trim()));
        studentsFiltered.sort((a,b) => String(a.seat_number).localeCompare(String(b.seat_number), 'zh-Hant-u-nu-hanidec') || String(a.card_seq).localeCompare(String(b.card_seq)));
        ensureScienceZoneCache().students = studentsFiltered;
        if (sel) {
          sel.innerHTML = '<option value="">請選擇學生</option>' + studentsFiltered.map(s => `<option value="${String(s.card_seq).replace(/"/g,'&quot;')}">${s.name}｜卡序 ${s.card_seq}${s.seat_number ? `｜座號 ${s.seat_number}` : ''}</option>`).join('');
          sel.onchange = () => { this.handleScienceStudentChange(); };
        }
        this.renderScienceSelectedMeta(null);
        this.populateScienceBatchFacetSelect();
        const urlEl = document.getElementById('scienceZoneUrlDisplay');
        if (urlEl) urlEl.value = this.buildScienceZoneUrl();
        if (!studentsFiltered.length) UI.toast('目前找不到「科展團隊」學生資料');
      } catch (e) {
        console.error('[science zone] load students failed:', e);
        UI.alert('讀取科展團隊名單失敗，請稍後再試。', '系統通知');
      }
    },
    async useCurrentStudentInScienceZone() {
      const d = currentState.studentData || null;
      if (!d || !/科展團隊/.test(String(d.class_name || '').trim())) {
        return UI.toast('目前管理面板尚未讀到「科展團隊」學生。');
      }
      const sel = document.getElementById('scienceStudentSelect');
      if (!sel) return;
      const cache = ensureScienceZoneCache();
      if (!cache.students.some(s => String(s.card_seq) === String(d.card_seq))) {
        cache.students.push({ card_seq: String(d.card_seq), name: d.name || '未命名', class_name: d.class_name || '科展團隊', seat_number: d.seat_number || '', uid: d.uid || '' });
        sel.innerHTML += `<option value="${String(d.card_seq).replace(/"/g,'&quot;')}">${d.name || '未命名'}｜卡序 ${d.card_seq}${d.seat_number ? `｜座號 ${d.seat_number}` : ''}</option>`;
      }
      sel.value = String(d.card_seq);
      await this.handleScienceStudentChange();
    },
    async handleScienceStudentChange() {
      const student = this.getSelectedScienceStudentMeta();
      this.renderScienceSelectedMeta(student);
      await this.loadScienceTodayRecord();
    },
    getScienceRecordDocRef(cardSeq, dateKey = formatLocalDateKey()) {
      const safeCardSeq = String(cardSeq || '').trim();
      return doc(db, SCIENCE_ZONE_COLLECTION, `${safeCardSeq}_${dateKey}`);
    },
    collectScienceDailyForm() {
      const attendance = document.getElementById('scienceAttendanceSelect')?.value || '出席';
      const researchStatus = document.getElementById('scienceResearchStatusSelect')?.value || '穩定推進';
      const tags = Array.from(document.querySelectorAll('#sciencePerformanceTags input[type="checkbox"]:checked')).map(el => el.value);
      const note = String(document.getElementById('scienceTeacherNote')?.value || '').trim();
      return { attendance_status: attendance, research_status: researchStatus, performance_tags: tags, teacher_note: note };
    },
    fillScienceDailyForm(record = null) {
      const attendanceSel = document.getElementById('scienceAttendanceSelect');
      const statusSel = document.getElementById('scienceResearchStatusSelect');
      const noteEl = document.getElementById('scienceTeacherNote');
      if (attendanceSel) attendanceSel.value = record?.attendance_status || '出席';
      if (statusSel) statusSel.value = record?.research_status || '穩定推進';
      if (noteEl) noteEl.value = record?.teacher_note || '';
      const checked = new Set(Array.isArray(record?.performance_tags) ? record.performance_tags : []);
      document.querySelectorAll('#sciencePerformanceTags input[type="checkbox"]').forEach(el => { el.checked = checked.has(el.value); });
    },
    renderScienceTodayRecord(record = null) {
      const box = document.getElementById('scienceTodayRecordSummary');
      if (!box) return;
      if (!record) {
        box.innerHTML = '尚無今日紀錄。';
        return;
      }
      const tags = Array.isArray(record.performance_tags) && record.performance_tags.length ? record.performance_tags.join('、') : '尚未勾選';
      box.innerHTML = `<div>日期：<span style="color:#fff;">${record.date_key || formatLocalDateKey()}</span></div><div>出缺狀態：<span style="color:#fff;">${record.attendance_status || '出席'}</span></div><div>簽到時間：<span style="color:#fff;">${formatLocalDateTime(record.check_in_time)}</span></div><div>研究狀況：<span style="color:#fff;">${record.research_status || '穩定推進'}</span></div><div>表現標記：<span style="color:#fff;">${tags}</span></div><div>老師備註：<span style="color:#fff;">${record.teacher_note || '—'}</span></div><div>簽退時間：<span style="color:#fff;">${formatLocalDateTime(record.check_out_time)}</span></div>`;
    },
    async loadScienceTodayRecord() {
      const student = this.getSelectedScienceStudentMeta();
      if (!student?.card_seq) {
        ensureScienceZoneCache().todayRecord = null;
        this.fillScienceDailyForm(null);
        this.renderScienceTodayRecord(null);
        return;
      }
      try {
        const snap = await getDoc(this.getScienceRecordDocRef(student.card_seq));
        const data = snap.exists() ? (snap.data() || null) : null;
        ensureScienceZoneCache().todayRecord = data;
        this.fillScienceDailyForm(data);
        this.renderScienceTodayRecord(data);
      } catch (e) {
        console.error('[science zone] load today record failed:', e);
        UI.toast('讀取今日紀錄失敗');
      }
    },
    async saveScienceRecordForStudent(student, patch = {}, toastMessage = '') {
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      try {
        const now = Date.now();
        const dateKey = formatLocalDateKey(now);
        const ref = this.getScienceRecordDocRef(student.card_seq, dateKey);
        const existingSnap = await getDoc(ref);
        const existing = existingSnap.exists() ? (existingSnap.data() || {}) : {};
        const base = this.collectScienceDailyForm();
        const mergedTags = Array.from(new Set([...(Array.isArray(existing.performance_tags) ? existing.performance_tags : []), ...(Array.isArray(base.performance_tags) ? base.performance_tags : []), ...(Array.isArray(patch.performance_tags) ? patch.performance_tags : [])]));
        const payload = {
          card_seq: String(student.card_seq),
          name: student.name || '',
          class_name: student.class_name || '科展團隊',
          seat_number: student.seat_number || '',
          date_key: dateKey,
          updated_at: now,
          attendance_status: patch.attendance_status ?? base.attendance_status ?? existing.attendance_status ?? '出席',
          research_status: patch.research_status ?? base.research_status ?? existing.research_status ?? '穩定推進',
          teacher_note: patch.teacher_note ?? (base.teacher_note || existing.teacher_note || ''),
          performance_tags: mergedTags,
          check_in_time: patch.check_in_time !== undefined ? patch.check_in_time : (existing.check_in_time ?? null),
          check_out_time: patch.check_out_time !== undefined ? patch.check_out_time : (existing.check_out_time ?? null),
          batch_scan_count: Number(existing.batch_scan_count || 0) + (Number(patch.batch_scan_count_delta) || 0)
        };
        Object.keys(patch || {}).forEach(k => {
          if (k === 'performance_tags' || k === 'batch_scan_count_delta') return;
          payload[k] = patch[k];
        });
        await setDoc(ref, payload, { merge: true });
        const selected = this.getSelectedScienceStudentMeta();
        if (selected && String(selected.card_seq) === String(student.card_seq)) {
          await this.loadScienceTodayRecord();
        }
        if (toastMessage) UI.toast(toastMessage);
        return payload;
      } catch (e) {
        console.error('[science zone] save record failed:', e);
        UI.alert('儲存科展團隊紀錄失敗，請稍後再試。', '系統通知');
      }
    },
    async saveScienceRecord(patch = {}, toastMessage = '已更新科展團隊紀錄') {
      const student = this.getSelectedScienceStudentMeta();
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      return this.saveScienceRecordForStudent(student, patch, toastMessage);
    },
    async scienceCheckIn() {
      const patch = { check_in_time: Date.now() };
      const attendance = document.getElementById('scienceAttendanceSelect')?.value;
      if (!attendance || attendance === '請假' || attendance === '缺席') patch.attendance_status = '出席';
      await this.saveScienceRecord(patch, '已完成簽到');
    },
    async saveScienceDailyRecord() {
      await this.saveScienceRecord({}, '已儲存今日研究紀錄');
    },
    async scienceCheckOut() {
      await this.saveScienceRecord({ check_out_time: Date.now() }, '已完成簽退');
    },
    async markScienceAbsent() {
      const attendance = document.getElementById('scienceAttendanceSelect')?.value || '缺席';
      await this.saveScienceRecord({ attendance_status: attendance, check_in_time: null, check_out_time: null }, `已記錄為${attendance}`);
    },
    async copyScienceZoneUrl() {
      const url = this.buildScienceZoneUrl();
      try {
        await navigator.clipboard.writeText(url);
        UI.toast('已複製科展團隊專區網址');
      } catch (e) {
        UI.alert(`請手動複製以下網址：
${url}`, '複製失敗');
      }
    },
    async writeScienceZoneLinkToNfc() {
      if (!("NDEFReader" in window)) { UI.alert('裝置不支援 Web NFC。', '硬體錯誤'); return; }
      if (!window.isSecureContext) { UI.alert('Web NFC 需要在 HTTPS 安全環境下使用。', '硬體錯誤'); return; }
      const shouldRestart = !!currentState.scanIntention && currentState.scanIntention !== 'read';
      const restoreIntention = currentState.scanIntention;
      try {
        this.stopWebNfc();
        const ndef = new NDEFReader();
        const url = this.buildScienceZoneUrl();
        await ndef.write({ records: [{ recordType: 'url', data: url }] });
        const urlEl = document.getElementById('scienceZoneUrlDisplay');
        if (urlEl) urlEl.value = url;
        UI.toast('✅ 科展團隊專區網址已寫入 NFC 卡片');
      } catch (e) {
        console.error('[science zone] write nfc failed:', e);
        UI.alert(`寫入失敗：${e.message || e}`, '寫入異常');
      } finally {
        if (shouldRestart) {
          currentState.scanIntention = restoreIntention;
          try { await this.startWebNfc(false); } catch (_) {}
        }
      }
    },
    async startScienceBatchScan() {
      currentState.scanIntention = 'science-batch';
      currentState.scienceBatchScanCount = 0;
      this.updateScienceBatchStatus('批量掃描已啟動，請依序感應學生 NTAG。');
      const ok = await this.startWebNfc(true);
      if (!ok) currentState.scanIntention = 'read';
    },
    stopScienceBatchScan() {
      if (currentState.scanIntention === 'science-batch') currentState.scanIntention = 'read';
      this.stopWebNfc();
      this.updateScienceBatchStatus('批量掃描已停止。');
    },
    async applyScienceRewardToStudent(serial, studentData, attr) {
      const rewardMap = this.getScienceTagMeta();
      const label = rewardMap?.[attr]?.label || (CONSTANTS.ATTRIBUTES?.[attr]?.name || attr);
      let data = this.applyDataMigration(JSON.parse(JSON.stringify(studentData || {})));
      if (!data.logs) data.logs = [];
      if (!data.streaks) data.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      if (!data.attr_event_counts) data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.totalXP = (Number(data.totalXP) || 0) + 10;
      addAttributeXP(data, attr, 10);
      ELEMENT_KEYS.forEach(k => { data.streaks[k] = (k === attr ? 1 : 0); });
      data.attr_event_counts[attr] = (Number(data.attr_event_counts[attr]) || 0) + 1;
      data.logs.push({ timestamp: Date.now(), action_type: 'science_zone', points_added: 10, detail: `[科展團隊專區] ${label} -> +10XP (${CONSTANTS.ATTRIBUTES[attr]?.name || attr})` });
      data = this.processEvolution(data);
      await this.saveToDB(data, serial);
      return label;
    },
    async handleScienceBatchScan(serial) {
      try {
        const stuSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
        if (!stuSnap.exists()) {
          UI.toast('❌ 找不到這張卡片對應的學生資料');
          return;
        }
        const data = stuSnap.data() || {};
        if (!/科展團隊/.test(String(data.class_name || '').trim())) {
          UI.toast(`⚠️ ${data.name || serial} 不是科展團隊學生，已略過`);
          return;
        }
        const student = { card_seq: String(data.card_seq || serial), name: data.name || '未命名', class_name: data.class_name || '科展團隊', seat_number: data.seat_number || '', uid: data.uid || '' };
        const sel = document.getElementById('scienceStudentSelect');
        const cache = ensureScienceZoneCache();
        if (sel) {
          if (!cache.students.some(s => String(s.card_seq) === String(student.card_seq))) {
            cache.students.push(student);
            sel.innerHTML += `<option value="${String(student.card_seq).replace(/"/g,'&quot;')}">${student.name}｜卡序 ${student.card_seq}${student.seat_number ? `｜座號 ${student.seat_number}` : ''}</option>`;
          }
          sel.value = String(student.card_seq);
        }
        this.renderScienceSelectedMeta(student);
        const attr = String(document.getElementById('scienceBatchFacetSelect')?.value || '').trim();
        const autoCheckIn = !!document.getElementById('scienceBatchAutoCheckIn')?.checked;
        const perfTags = [];
        const attrFocus = this.getScienceTagMeta();
        if (attr && attrFocus[attr]?.label) perfTags.push(attrFocus[attr].label);
        const patch = { batch_scan_count_delta: 1, performance_tags: perfTags };
        if (autoCheckIn) {
          const todaySnap = await getDoc(this.getScienceRecordDocRef(student.card_seq));
          const today = todaySnap.exists() ? (todaySnap.data() || {}) : {};
          if (!today.check_in_time) patch.check_in_time = Date.now();
          if (!today.attendance_status || today.attendance_status === '缺席' || today.attendance_status === '請假') patch.attendance_status = '出席';
        }
        await this.saveScienceRecordForStudent(student, patch, '');
        let rewardLabel = '';
        if (attr && ELEMENT_KEYS.includes(attr)) {
          rewardLabel = await this.applyScienceRewardToStudent(student.card_seq, data, attr);
        }
        currentState.scienceBatchScanCount = ensureScienceBatchCounter() + 1;
        const summary = rewardLabel ? `已為 ${student.name} 完成點名，並記錄「${rewardLabel}」+10。` : `已為 ${student.name} 完成點名。`;
        this.updateScienceBatchStatus(summary, true);
        await this.loadScienceTodayRecord();
        UI.toast(`✅ ${student.name}${rewardLabel ? `｜${rewardLabel} +10` : '｜已點名'}`);
      } catch (e) {
        console.error('[science zone] batch scan failed:', e);
        UI.alert('批量掃描處理失敗，請稍後再試。', '系統通知');
      }
    },
    async openScienceZone() {
      if (!hasScienceZoneDom()) { UI.alert('找不到科展團隊專區面板，請重新整理頁面後再試。', '系統異常'); return; }
      UI.showModal('scienceZoneModal');
      const urlEl = document.getElementById('scienceZoneUrlDisplay');
      if (urlEl) urlEl.value = this.buildScienceZoneUrl();
      this.populateScienceBatchFacetSelect();
      await this.loadScienceStudentsList();
      if (currentState.studentData && /科展團隊/.test(String(currentState.studentData.class_name || '').trim())) {
        await this.useCurrentStudentInScienceZone();
      }
    },
    async exportScienceHistoryCurrent() {
      const student = this.getSelectedScienceStudentMeta();
      if (!student?.card_seq) return UI.toast('請先選擇學生');
      try {
        const snap = await getDocs(collection(db, SCIENCE_ZONE_COLLECTION));
        const rows = [['卡序','姓名','日期','出缺狀態','簽到時間','研究狀況','表現標記','老師備註','簽退時間']];
        const items = [];
        snap.forEach(ds => { const d = ds.data() || {}; if (String(d.card_seq) === String(student.card_seq)) items.push(d); });
        items.sort((a,b) => String(a.date_key||'').localeCompare(String(b.date_key||'')));
        items.forEach(d => rows.push([d.card_seq || '', d.name || '', d.date_key || '', d.attendance_status || '', formatLocalDateTime(d.check_in_time), d.research_status || '', Array.isArray(d.performance_tags) ? d.performance_tags.join('、') : '', d.teacher_note || '', formatLocalDateTime(d.check_out_time)]));
        if (rows.length === 1) return UI.toast('目前學生尚無可匯出的歷史紀錄');
        downloadCsvFile(`science_history_${student.card_seq}.csv`, rows);
      } catch (e) {
        console.error('[science zone] export current failed:', e);
        UI.alert('匯出目前學生歷史紀錄失敗。', '系統通知');
      }
    },
    async exportScienceHistoryAll() {
      try {
        const snap = await getDocs(collection(db, SCIENCE_ZONE_COLLECTION));
        const rows = [['卡序','姓名','班別','座號','日期','出缺狀態','簽到時間','研究狀況','表現標記','老師備註','簽退時間','最後更新']];
        const items = [];
        snap.forEach(ds => items.push(ds.data() || {}));
        items.sort((a,b) => (String(a.card_seq||'').localeCompare(String(b.card_seq||'')) || String(a.date_key||'').localeCompare(String(b.date_key||''))));
        items.forEach(d => rows.push([d.card_seq || '', d.name || '', d.class_name || '', d.seat_number || '', d.date_key || '', d.attendance_status || '', formatLocalDateTime(d.check_in_time), d.research_status || '', Array.isArray(d.performance_tags) ? d.performance_tags.join('、') : '', d.teacher_note || '', formatLocalDateTime(d.check_out_time), formatLocalDateTime(d.updated_at)]));
        if (rows.length === 1) return UI.toast('目前沒有可匯出的科展團隊紀錄');
        downloadCsvFile(`science_history_all_${formatLocalDateKey()}.csv`, rows);
      } catch (e) {
        console.error('[science zone] export all failed:', e);
        UI.alert('匯出全部科展團隊紀錄失敗。', '系統通知');
      }
    }
  };
}
