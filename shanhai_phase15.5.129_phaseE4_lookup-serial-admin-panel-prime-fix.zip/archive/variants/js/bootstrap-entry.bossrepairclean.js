/*
 * ARCHIVED VARIANT NOTICE
 * File: js/bootstrap-entry.bossrepairclean.js
 * Status: archived / rollback-only
 * Active chain: js/bootstrap-entry.js -> js/main.entry.js
 * Active core: js/core/app-facade.js + js/core/api-surface.js
 * Reason: historical recovery / forensic reference; do not edit before checking canonical active files.
 */
const BOOT_ID = 'phase15quizbankfix1';
const statusId = 'bootStatusPanel';
const TARGET_ENTRY = './main.entry.bossrepairclean.js';
const REQUIRED_MARKERS = [
  'const BUILD_TAG =',
  'exposeGlobalFacade({ App, UI });',
  '__bootstrapShanHaiApp'
];

function installCompatStubs() {
  const App = (window.App = window.App || {});
  const UI = (window.UI = window.UI || {});

  if (typeof App.bindAuthControls !== 'function') App.bindAuthControls = () => false;
  if (typeof App.prepareActionFromButton !== 'function') App.prepareActionFromButton = () => false;
  if (typeof UI.alert !== 'function') {
    UI.alert = (message, title = '系統通知') => {
      try {
        window.alert(`${title}\n\n${message}`);
      } catch (_) {}
    };
  }
}

function setBootMessage(message, detail = '') {
  const panel = document.getElementById(statusId);
  if (!panel) return;
  panel.style.display = 'block';
  const safeDetail = detail ? `\n${detail}` : '';
  panel.textContent = `[boot] ${message}${safeDetail}`;
}

function setLoginAvailability(isReady, reason = '') {
  const loginBtn = document.getElementById('loginBtn');
  if (!loginBtn) return;
  loginBtn.disabled = !isReady;
  loginBtn.title = isReady ? '' : (reason || '主程式尚未完成載入');
}

function getSnippet(text = '', length = 220) {
  return String(text || '').slice(0, length).replace(/\s+/g, ' ').trim();
}

function looksLikeHtml(text = '') {
  const sample = String(text || '').trimStart().slice(0, 200).toLowerCase();
  return sample.startsWith('<!doctype html') || sample.startsWith('<html') || sample.startsWith('<head') || sample.startsWith('<body');
}

function buildDiagnostic(targetUrl, response, sourceText) {
  const contentType = response.headers.get('content-type') || '(missing content-type)';
  const markerHits = Object.fromEntries(REQUIRED_MARKERS.map((marker) => [marker, String(sourceText || '').includes(marker)]));
  return {
    bootId: BOOT_ID,
    targetUrl: targetUrl.href,
    status: response.status,
    ok: response.ok,
    contentType,
    length: String(sourceText || '').length,
    looksLikeHtml: looksLikeHtml(sourceText),
    markerHits,
    firstChunk: getSnippet(sourceText, 260),
    scriptSrc: document.querySelector('script[type="module"]')?.src || '(script src unavailable)'
  };
}

function rewriteRelativeImports(sourceText, targetUrl) {
  const baseHref = new URL('./', targetUrl).href;
  return String(sourceText || '')
    .replace(/from\s+(["'])\.\/([^"']+)\1/g, (_m, quote, relPath) => `from ${quote}${baseHref}${relPath}${quote}`)
    .replace(/import\(\s*(["'])\.\/([^"']+)\1\s*\)/g, (_m, quote, relPath) => `import(${quote}${baseHref}${relPath}${quote})`);
}

function formatDiagnostic(diag) {
  const markerSummary = Object.entries(diag.markerHits || {})
    .map(([key, ok]) => `${ok ? '✓' : '✗'} ${key}`)
    .join('\n');

  return [
    `URL: ${diag.targetUrl}`,
    `HTTP: ${diag.status}`,
    `Content-Type: ${diag.contentType}`,
    `Length: ${diag.length}`,
    `Looks like HTML: ${diag.looksLikeHtml ? 'yes' : 'no'}`,
    markerSummary ? `Markers:\n${markerSummary}` : '',
    diag.firstChunk ? `First chunk: ${diag.firstChunk}` : ''
  ].filter(Boolean).join('\n');
}

async function importFromVerifiedSource(targetUrl, sourceText) {
  const transformed = `${rewriteRelativeImports(sourceText, targetUrl)}\n//# sourceURL=${targetUrl.href}`;
  const blobUrl = URL.createObjectURL(new Blob([transformed], { type: 'text/javascript' }));
  try {
    await import(blobUrl);
    return 'blob-verified-import';
  } finally {
    setTimeout(() => URL.revokeObjectURL(blobUrl), 0);
  }
}

function showFatal(err, diag = null, stage = 'boot') {
  const detail = err && err.stack ? err.stack : String(err || 'unknown error');
  console.error(`[boot] ${stage} failed`, err, diag || '');
  const diagText = diag ? `\n\n${formatDiagnostic(diag)}` : '';
  setBootMessage('主程式載入失敗', `${detail}${diagText}`);
  setLoginAvailability(false, '主程式尚未完成載入');
}

async function startBoot() {
  installCompatStubs();
  setLoginAvailability(false, '主程式載入中');
  setBootMessage('檢查部署版入口檔中…');

  const targetUrl = new URL(`${TARGET_ENTRY}?v=${BOOT_ID}&ts=${Date.now()}`, import.meta.url);
  const response = await fetch(targetUrl.href, { cache: 'no-store' });
  const sourceText = await response.text();
  const diag = buildDiagnostic(targetUrl, response, sourceText);
  window.__BOOT_DIAG = diag;

  if (!response.ok) {
    throw Object.assign(new Error(`入口檔回傳 HTTP ${response.status}`), { diag, stage: 'fetch' });
  }
  if (diag.looksLikeHtml) {
    throw Object.assign(new Error('入口檔內容看起來像 HTML，而不是 JavaScript 模組'), { diag, stage: 'validate' });
  }
  if (Object.values(diag.markerHits).some((ok) => !ok)) {
    throw Object.assign(new Error('入口檔缺少預期的核心標記，疑似混版或快取污染'), { diag, stage: 'validate' });
  }

  setBootMessage('入口檔驗證完成，載入主程式中…', `URL: ${diag.targetUrl}`);

  try {
    const importMode = await importFromVerifiedSource(targetUrl, sourceText);
    window.__BOOT_DIAG = { ...diag, importMode };
  } catch (blobErr) {
    console.warn('[boot] blob verified import failed, retrying direct import', blobErr);
    const directUrl = `${targetUrl.href}&direct=1`;
    await import(directUrl);
    window.__BOOT_DIAG = { ...diag, importMode: 'direct-import-fallback' };
  }

  setLoginAvailability(true);
  const panel = document.getElementById(statusId);
  if (panel && panel.textContent && panel.textContent.includes('[boot]')) {
    panel.style.display = 'none';
  }
}

startBoot().catch((err) => {
  showFatal(err, err?.diag || window.__BOOT_DIAG || null, err?.stage || 'boot');
});
