/*
 * ARCHIVED VARIANT NOTICE
 * File: js/main.entry.quizbankfix.js
 * Status: archived / rollback-only
 * Active chain: js/bootstrap-entry.js -> js/main.entry.js
 * Active core: js/core/app-facade.js + js/core/api-surface.js
 * Reason: historical recovery / forensic reference; do not edit before checking canonical active files.
 */
import { app, db, auth, functions, storage, firebaseConfig, collection, doc, getDoc, getDocs, writeBatch, setDoc, onSnapshot, updateDoc, addDoc, deleteDoc, query, where, orderBy, limit, onAuthStateChanged, signInWithEmailAndPassword, signInAnonymously, signOut, httpsCallable, storageRef, getDownloadURL, updateMetadata } from "./core/firebase.js?v=phase15quizbankfix1";
    import { createAuthModule } from "./modules/auth.js?v=phase15quizbankfix1";
    import { createStudentModule } from "./modules/student.js?v=phase15quizbankfix1";
import { currentState, batchState, quizSession, radarChartInstances, initializeState } from "./core/state.js?v=phase15quizbankfix1";
import { UI as baseUI } from "./core/ui.js?v=phase15quizbankfix1";
import { createTeacherActionsModule } from "./modules/teacher-actions.js?v=phase15quizbankfix1";
import { createBatchModule } from "./modules/batch.js?v=phase15quizbankfix1";
import { createBattleModule } from "./modules/battle.quizbankfix.js?v=phase15quizbankfix1";
import { createShopModule } from "./modules/shop.js?v=phase15quizbankfix1";
import { createQuizModule } from "./modules/quiz.quizbankfix.js?v=phase15quizbankfix1";
import { createRankingModule } from "./modules/ranking.js?v=phase15quizbankfix1";
import { createContentProfileModule } from "./modules/content-profile.js?v=phase15quizbankfix1";
import { createZonesModule } from "./modules/zones.js?v=phase15quizbankfix1";
import { mountAppFacade, exposeGlobalFacade, APP_FACADE_METHODS } from "./core/app-facade.quizbankfix.js?v=phase15quizbankfix1";
import { DEBUG_FLAGS, RUNTIME_ENV, DEBUG_MARKERS } from "./core/debug-flags.js?v=phase15quizbankfix1";
import { createForceOpenCardForgeBridge, exposeLegacyGlobals, buildSystemNamespace } from "./core/global-bridge.js?v=phase15quizbankfix1";
import { buildGlobalSurfaceInventory, attachSurfaceMetadata, logSurfaceWarnings } from "./core/api-surface.quizbankfix.js?v=phase15quizbankfix1";
    const BUILD_TAG = 'v15.5.22-quizbankfix1-20260314';
    let authApi = null; // @phase9-split:auth-api
    let studentApi = null; // @phase9-split:student-api
    let teacherActionsApi = null; // @phase10-split:teacher-actions-api
    let batchApi = null; // @phase11-split:batch-api
    let battleApi = null; // @phase12-split:battle-api
    let shopApi = null; // @phase13-split:shop-api
    let quizApi = null; // @phase13-split:quiz-api
    let rankingApi = null; // @phase13-split:ranking-api
    let contentProfileApi = null; // @phase13-split:content-profile-api
    let zonesApi = null; // @phase13-split:zones-api
    const APP_CONFIG = Object.freeze({
      version: '4.4-split-bridge-1',
      eventPrefix: 'shanhai',
      collections: Object.freeze({
        students: 'students',
        tokens: 'tag_tokens',
        shop: 'shop_catalog',
        studentPages: 'student_pages',
        supportZone: 'support_zone_records',
        scienceZone: 'science_zone_records'
      }),
      splitBridge: Object.freeze({
        enabled: true,
        allowModuleRegistration: true,
        useSafeBootstrap: true
      })
    });

    const COLLECTION_NAME = APP_CONFIG.collections.students;
    const TOKEN_COLLECTION = APP_CONFIG.collections.tokens;
    const SHOP_COLLECTION = APP_CONFIG.collections.shop;
    const STUDENT_PAGE_COLLECTION = APP_CONFIG.collections.studentPages;
    const SUPPORT_ZONE_COLLECTION = APP_CONFIG.collections.supportZone;
    const SCIENCE_ZONE_COLLECTION = APP_CONFIG.collections.scienceZone;
const TYPE_INFO = {
      neutral: { name: '無', color: '#9aa0a6' },
      metal:  { name: '金', color: 'var(--color-metal)' },
      wood:   { name: '木', color: 'var(--color-wood)' },
      water:  { name: '水', color: 'var(--color-water)' },
      fire:   { name: '火', color: 'var(--color-fire)' },
      earth:  { name: '土', color: 'var(--color-earth)' }
    };



    const CONTENT_PROFILES = {
      shanhai: {
        id: 'shanhai',
        labels: {
          xp: '進化能量',
          collection: '幻獸繪卷',
          journey: '龍蛋的成長旅程',
          dailyQuestButton: '⚔️ 前往修練場（今日歷練）',
          dailyQuestReady: '[ 狀態就緒 ] 今日歷練已重置，可再次出發（每日中午 12:00）',
          dailyQuestCooldown: '[ 系統冷卻中 ] 今日歷練將於中午 12:00 重置，尚需 {countdown}',
          dailyQuestLogPrefix: '歷練紀錄',
          dailyQuestSummary: '今日歷練完成！你答對 {earned} 題，獲得 {earned} 枚金幣，並為目前最高的五行屬性注入 {earned} 點進化能量。',
          battleTitle: '⚔️ [ 對戰塔 ] 今日討伐任務',
          battleSelectionTitle: '⚔️ 選擇出戰的龍獸',
          battleSelectionDesc: '請從圖鑑中挑選一隻龍獸，迎戰今日鎮守高塔的異獸首領！<br/><span style="color:var(--warning);">(注意：答錯題目或戰敗，都會消耗今日機會)</span>',
          battleArenaHeading: '⚔️ 討伐開始 ⚔️',
          battleArenaDesc: '雙方各進行 3 次靈力判定，累積的靈力總值再乘上屬性相剋倍率，就會形成最終戰鬥力！',
          battleAction: '開始靈力判定',
          battleComputing: '靈力流動中...',
          battleStat: '靈力總值 {roll}（{detail}）',
          battleTie: '靈力不分上下，再判定一次！',
          battleWin: '🎉 討伐成功！',
          battleLose: '💀 討伐失利...',
          battleConsume: '💀 討伐失利，本日挑戰機會已消耗。',
          battleReward: '🎉 討伐成功！獲得 {reward}',
          battleRewardAlertTitle: '對戰塔討伐獎勵',
          battleReady: '狀態就緒，點擊發起今日討伐任務！（每日中午 12:00 重置）',
          battleCooldown: '今日挑戰次數已用完，將於中午 12:00 重置（尚需 {countdown}）。',
          bossName: null,
          playerLabel: '我的龍獸',
          bossLabel: '塔中首領',
          statusHealthy: '狀態穩定',
          legendaryEmptySpeech: '這週暫時沒有新的稀有異獸線索。先繼續培育你的龍獸，等研究站有新發現時，再一起迎接下一位夥伴吧！',
          legendarySpeechPrefix: '研究站最近追蹤到 {names} 的蹤跡！如果你願意提供對應屬性的龍獸素材 <span class="speech-highlight">協助研究</span>，就有機會迎來新的異獸夥伴。',
          legendaryRequirement: '[ 研究需求 ] {current} / {need} 份 {attrName}屬性龍獸素材',
          legendaryExchange: '進行交換',
          legendaryInsufficient: '條件不足',
          galleryEmpty: '尚未建立圖鑑紀錄'
        },
        attributes: {
          metal: { icon: '🛡️', name: '金', color: 'var(--color-metal)', char: '精準守時', desc: '金象徵凝鍊與規範，像打磨後的金屬一樣俐落明確。能守時、重視步驟、做事有條理，就會慢慢累積金屬性的力量。' },
          wood:  { icon: '🌿', name: '木', color: 'var(--color-wood)', char: '探究成長', desc: '木象徵生長與延伸，像樹木向上伸展枝葉。願意觀察、提問、分享發現，並持續探索新知，木屬性就會穩穩成長。' },
          water: { icon: '🌊', name: '水', color: 'var(--color-water)', char: '關懷協作', desc: '水象徵流動與滋養，能讓周遭變得平順而有力量。願意整理環境、照顧器材、和同伴友善合作，就是在培養水屬性的力量。' },
          fire:  { icon: '🔥', name: '火', color: 'var(--color-fire)', char: '熱情精進', desc: '火象徵熱力與光亮，會在努力中越燃越旺。主動投入學習、勇敢接受挑戰、展現亮眼成果，都能點燃火屬性的能量。' },
          earth: { icon: '⛰️', name: '土', color: 'var(--color-earth)', char: '沉著自律', desc: '土象徵穩定與承載，像大地一樣可靠厚實。能長時間專注、按步驟完成任務、保持自律與耐心，就會累積土屬性的根基。' },
          neutral: { icon: '🥚', name: '無', color: '#9aa0a6', char: '尚待覺醒', desc: '龍蛋仍在安靜吸收力量。只要你在日常學習中持續累積好表現，屬性的方向就會一點一點清楚起來。' }
        },
        debuffs: {
          Poison: { name: '中毒', color: 'var(--color-psychic)', desc: '龍獸處於中毒狀態。結算時獲得的總經驗值，將依據『中毒層數』大幅減少。' },
          Frozen: { name: '冰凍', color: 'var(--color-ice)', desc: '龍獸處於冰凍狀態。狀態解除前，即使經驗值達到 100 也無法進行進化結算。' },
          Paralyzed: { name: '麻痺', color: 'var(--color-electric)', desc: '龍獸處於麻痺狀態。結算進化金幣時，金幣轉換比例將依據『麻痺層數』大幅降低！' },
          Confusion: { name: '混亂', color: 'var(--danger)', desc: '龍獸處於混亂狀態。操作加分時，獲取的分數將不受控制，完全隨機分配至非目標的其他屬性上。' }
        },
        builtInShop: {
          antidote: { name: '💊 萬靈藥', desc: '清除所有負面狀態' },
          evo_stone: { name: '✨ 各系進化石', desc: '指定屬性直接 +30 XP' },
          wonder_stone: { name: '🌟 進化奇石', desc: '指定屬性素材 +1' },
          hidden_egg: { name: '特殊異獸蛋', desc: '完成後可轉化為隱藏異獸' }
        }
      },
      cat: {
        id: 'cat',
        labels: {
          xp: '成長能量',
          collection: '貓咪寄宿系統',
          journey: '小貓的成長歷程',
          dailyQuestButton: '🐈 進入後院 (每日抓老鼠)',
          dailyQuestReady: '[ 狀態就緒 ] 後院巡查已重置（每日中午 12:00）',
          dailyQuestCooldown: '[ 系統冷卻中 ] 後院巡查將於中午 12:00 重置，尚需 {countdown}',
          dailyQuestLogPrefix: '後院巡查',
          dailyQuestSummary: '今日後院巡查結束！答對 {earned} 題，抓到 {earned} 隻小老鼠，獲得 {earned} 金幣與 {earned} 點最高特質成長。',
          battleTitle: '🐾 [ 領域防衛 ] 擊退入侵貓咪',
          battleSelectionTitle: '🐾 選擇出動的貓咪夥伴',
          battleSelectionDesc: '請從寄宿紀錄中挑選一隻貓咪夥伴來進行領域防衛！<br/><span style="color:var(--warning);">(注意：答錯題目或失敗，皆算消耗今日機會)</span>',
          battleArenaHeading: '🐾 領域防衛開始',
          battleArenaDesc: '雙方進行 3 次敏捷爆發判定，爆發總值越高的一方就能守住領地！',
          battleAction: '開始敏捷判定',
          battleComputing: '敏捷判定中...',
          battleStat: '爆發數值 {roll} ({detail})',
          battleTie: '平手！重新判定！',
          battleWin: '🎉 成功守住領地！',
          battleLose: '🙀 防衛失敗...',
          battleConsume: '🙀 防衛失敗，本日挑戰機會已消耗。',
          battleReward: '🎉 成功守住領地！獲得 {reward}',
          battleRewardAlertTitle: '領域防衛獎勵',
          battleReady: '狀態就緒，點擊開始領域防衛！（每日中午 12:00 重置）',
          battleCooldown: '今日領域防衛次數已用完，將於中午 12:00 重置（尚需 {countdown}）。',
          bossName: '入侵浪貓',
          playerLabel: '我的貓咪',
          bossLabel: '入侵者',
          statusHealthy: '狀態穩定',
          legendaryEmptySpeech: '目前後院很平靜，這週還沒有新的特殊品種救援消息。請繼續照顧你的貓咪夥伴吧！',
          legendarySpeechPrefix: '這週後院傳來了 {names} 的救援消息！如果你願意提供對應特質的照護紀錄 <span class="speech-highlight">協助救援</span>，我就把新夥伴交給你！',
          legendaryRequirement: '[ 救援需求 ] {current} / {need} {attrName}',
          legendaryExchange: '完成救援',
          legendaryInsufficient: '條件不足',
          galleryEmpty: '尚未建立寄宿紀錄'
        },
        attributes: {
          metal: { icon: '🤍', name: '洞察', color: '#d7d7df', char: '觀察力、專注、守時', desc: '像 Chinchilla Persian 一樣敏銳細心，能留意細節、準時完成事情，展現穩定的洞察力。', coat: 'Chinchilla Persian', emoji: '🐈' },
          wood:  { icon: '🐯', name: '活力', color: '#7cc96b', char: '好奇、探索、敏捷', desc: '像 Bengal cat 一樣充滿好奇，願意探索新事物、快速行動，展現蓬勃活力。', coat: 'Bengal cat', emoji: '🐯' },
          water: { icon: '🩶', name: '溫和', color: '#8ab4d6', char: '包容、整潔、照顧他人', desc: '像 Russian Blue 一樣溫柔安定，能照顧環境、關心同伴，讓人感到安心。', coat: 'Russian Blue', emoji: '🐈' },
          fire:  { icon: '🧡', name: '熱情', color: '#ff9e57', char: '勇敢、積極、熱心助人', desc: '像 Orange Tabby 一樣元氣十足，勇於嘗試、主動參與，也願意熱心幫助別人。', coat: 'Orange Tabby', emoji: '🐈' },
          earth: { icon: '🖤', name: '沉穩', color: '#6f6158', char: '耐心、自律、踏實', desc: '像 Garfield 一樣安靜可靠，能耐心完成任務，展現沉著又踏實的力量。', coat: 'Garfield', emoji: '🐈‍⬛' },
          neutral: { icon: '📦', name: '待救援', color: '#9aa0a6', char: '尚未展現鮮明特質', desc: '小貓還在紙箱裡慢慢適應新環境。只要持續累積好表現，就會顯現自己的特色。', coat: '待救援小紙箱', emoji: '📦' }
        },
        debuffs: {
          Poison: { name: '生病', color: 'var(--color-psychic)', desc: '影響心情，導致獲得經驗減少。' },
          Frozen: { name: '驚嚇', color: 'var(--color-ice)', desc: '躲在角落不出來，暫時無法進行階段成長。' },
          Paralyzed: { name: '嗜睡', color: 'var(--color-electric)', desc: '睡翻了，導致金幣轉換效率變差。' },
          Confusion: { name: '暴走', color: 'var(--danger)', desc: '突然進入 zoomies 模式，屬性加分可能亂跳。' }
        },
        builtInShop: {
          antidote: { name: '🌿 特效除蚤藥 / 頂級貓草', desc: '清除所有負面狀態' },
          evo_stone: { name: '🥫 高級主食罐頭', desc: '指定特質直接 +30 成長值' },
          wonder_stone: { name: '🧶 特製貓玩具', desc: '指定特質素材 +1' },
          hidden_egg: { name: '🐾 特殊品種貓救援任務', desc: '完成後可帶回稀有貓咪夥伴' }
        }
      }
    };


    const CAT_VISUALS = {
      box: {
        file: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2Fbox%2Fbox_800x800.webp?alt=media&token=8285e096-bccc-4f2c-b73d-2973912c5710'
      },
      metal: {
        breed: 'Chinchilla Persian',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FChinchilla%20Persian%2FChinchilla%20Persian(Hatchling)_800x800.webp?alt=media&token=dd4612b7-f3df-47c2-a306-0a88ae675a02'
        }
      },
      wood: {
        breed: 'Bengal cat',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FBengal%20cat%2FBengal%20cat(Hatchling)_800x800.webp?alt=media&token=5ba2a4ce-e068-4269-a1e7-00589675b010'
        }
      },
      water: {
        breed: 'Russian Blue',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FRussian%20Blue%2FRussian%20Blue(Hatchling)_800x800.webp?alt=media&token=adb7188a-cca0-4468-a89d-765016dd4629'
        }
      },
      fire: {
        breed: 'Orange Tabby',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FOrange%20Tabby%2FOrange%20Tabby(Hatchling)_800x800.webp?alt=media&token=eeb54ab9-91a2-4760-88e1-8d9bc5f396c5'
        }
      },
      earth: {
        breed: 'Garfield',
        stages: {
          '0': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9',
          '1': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9',
          '2': 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FGarfield%2FGarfield(Hatchling)_800x800.webp?alt=media&token=6ff1fd52-57de-441a-9787-5ecc495f8cc9'
        }
      }
    };

    function colorToRgba(color, alpha = 0.28) {
      const c = String(color || '').trim();
      if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(c)) {
        let hex = c.slice(1);
        if (hex.length === 3) hex = hex.split('').map(ch => ch + ch).join('');
        const n = parseInt(hex, 16);
        const r = (n >> 16) & 255;
        const g = (n >> 8) & 255;
        const b = n & 255;
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
      }
      return `rgba(0, 229, 255, ${alpha})`;
    }

    function fillProfileTemplate(str, vars = {}) {
      return String(str || '').replace(/\{(\w+)\}/g, (_, key) => (vars[key] ?? ''));
    }

    function getContentProfile(data = null) {
      const src = data || currentState?.studentData || {};
      const queryProfile = new URLSearchParams(window.location.search).get('profile');
      const inferredCat = (
        src?.content_profile_id === 'cat' ||
        src?.ui_variant === 'muslim_friendly' ||
        src?.profile_flags?.use_cat_theme === true ||
        queryProfile === 'cat'
      );
      const id = String(src?.content_profile_id || (inferredCat ? 'cat' : 'shanhai')).trim() || 'shanhai';
      return CONTENT_PROFILES[id] || CONTENT_PROFILES.shanhai;
    }

    function isCatProfile(data = null) {
      const src = data || currentState?.studentData || {};
      const query = new URLSearchParams(window.location.search);
      const qp = String(query.get('profile') || '').trim().toLowerCase();
      const qg = String(query.get('guide') || '').trim().toLowerCase();
      return (
        qp === 'cat' ||
        qg === 'cat' ||
        src?.content_profile_id === 'cat' ||
        src?.ui_variant === 'muslim_friendly' ||
        src?.profile_flags?.use_cat_theme === true ||
        src?.profile_flags?.hide_fantasy === true ||
        src?.profile_flags?.use_safe_random_label === true ||
        getContentProfile(src).id === 'cat'
      );
    }

    function getCatBossVisualByType(typeKey = 'neutral') {
      const normalized = ELEMENT_KEYS.includes(typeKey) ? typeKey : 'metal';
      const pseudo = {
        content_profile_id: 'cat',
        dragon_stage: 0,
        dragon_path: normalized,
        attributes: ELEMENT_KEYS.reduce((acc, key) => { acc[key] = key === normalized ? 1 : 0; return acc; }, {})
      };
      return getCatVisual(pseudo);
    }

    function formatLocalDateKey(ts = Date.now()) {
      const d = new Date(ts);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    }

    function formatLocalDateTime(ts) {
      const n = Number(ts) || 0;
      if (!n) return '—';
      const d = new Date(n);
      return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
    }

    function csvEscape(value) {
      const raw = value == null ? '' : String(value);
      return '"' + raw.replace(/"/g, '""') + '"';
    }

    function downloadCsvFile(filename, rows) {
      const csv = rows.map(row => row.map(csvEscape).join(',')).join('\n');
      const blob = new Blob(["﻿" + csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }

    function downloadTextFile(filename, content, mimeType = 'text/plain;charset=utf-8;') {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }

    function getProfileAttributeInfo(attrKey, data = null) {
      const p = getContentProfile(data);
      return (p.attributes && p.attributes[attrKey]) || p.attributes?.neutral || CONSTANTS.ATTRIBUTES[attrKey] || { icon: '❓', name: attrKey, color: 'var(--cyan)', char: '' };
    }

    function getProfileDebuffInfo(statusKey, data = null) {
      const p = getContentProfile(data);
      return (p.debuffs && p.debuffs[statusKey]) || CONSTANTS.DEBUFF_INFO[statusKey] || { name: statusKey, color: 'var(--danger)', desc: '' };
    }

    function getProfileLabels(data = null) {
      return getContentProfile(data).labels || {};
    }

    function getProfileFlags(data = null) {
      const src = data || currentState?.studentData || {};
      return Object.assign({ hide_fantasy: false, use_cat_theme: isCatProfile(src), use_safe_random_label: isCatProfile(src) }, src?.profile_flags || {});
    }

    function svgDataUri(svg) {
      return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
    }

    function makeBadgeSvg(mainEmoji, title, accent = '#00e5ff', sub = '') {
      const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='420' height='420'>
        <defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop offset='0%' stop-color='#141927'/><stop offset='100%' stop-color='#080b12'/></linearGradient></defs>
        <rect width='420' height='420' rx='28' fill='url(#g)'/>
        <circle cx='210' cy='158' r='102' fill='none' stroke='${accent}' stroke-width='10' opacity='0.45'/>
        <text x='50%' y='42%' text-anchor='middle' dominant-baseline='middle' font-size='108'>${mainEmoji}</text>
        <text x='50%' y='72%' text-anchor='middle' fill='#ffffff' opacity='0.92' font-family='Noto Sans TC' font-size='30' font-weight='700'>${title}</text>
        <text x='50%' y='82%' text-anchor='middle' fill='${accent}' opacity='0.92' font-family='Noto Sans TC' font-size='22'>${sub}</text>
      </svg>`;
      return svgDataUri(svg);
    }

    function getCatVisual(source = {}, sourceItem = null) {
      const item = sourceItem || source || {};
      const stage = Number(item?.stage ?? item?.dragon_stage ?? source?.dragon_stage ?? -1);
      const attrKey = String(item?.element || item?.path || source?.dragon_path || getDominantElementFromData(source) || 'neutral');
      const info = getProfileAttributeInfo(attrKey, { content_profile_id: 'cat' });
      const breedCfg = CAT_VISUALS[attrKey] || null;
      const breedName = breedCfg?.breed || info.coat || info.name;
      const stageMap = {
        '-1': { name: '箱子', caption: '待救援的小紙箱', emoji: '📦' },
        '0': { name: '奶貓期', caption: '剛睜眼、毛色漸漸顯現的小奶貓', emoji: '🐈' },
        '1': { name: '幼貓期', caption: '開始探索環境、活潑好動的幼貓', emoji: '😺' },
        '2': { name: '成貓期', caption: '氣質成熟、展現品種特色的成貓', emoji: info.emoji || '🐈‍⬛' },
      };
      const st = stageMap[String(stage)] || stageMap['-1'];
      let file = null;
      if (stage < 0) {
        file = CAT_VISUALS.box.file;
      } else if (breedCfg?.stages) {
        file = breedCfg.stages[String(stage)] || breedCfg.stages['0'] || null;
      }
      const sub = stage === -1 ? (breedName || '待救援小紙箱') : `${info.name} · ${breedName || info.coat || ''}`;
      return {
        file,
        img: file ? null : makeBadgeSvg(st.emoji || '🐱', st.name, info.color || '#8ab4d6', sub),
        name: stage < 0 ? '箱子' : `${breedName}`,
        caption: `${st.caption}${stage >= 0 ? `｜${breedName || info.coat || info.name}` : ''}`,
        color: info.color || '#8ab4d6',
        info,
        stageName: st.name,
        breedName,
      };
    }

    function getProfileVisual(data = {}, sourceItem = null) {
      if (isCatProfile(data)) return getCatVisual(data, sourceItem);
      const vis = getDragonVisual(sourceItem ? {
        dragon_path: sourceItem.path || sourceItem.dragon_path || data.dragon_path,
        dragon_stage: sourceItem.stage ?? sourceItem.dragon_stage ?? data.dragon_stage,
        attributes: sourceItem.stats || sourceItem.attributes || data.attributes || {}
      } : data);
      return Object.assign({}, vis, { img: null });
    }

    function getRadarLabelsForData(data = null) {
      return CONSTANTS.ATTR_ORDER.map(k => {
        const info = getProfileAttributeInfo(k, data);
        return `${info.icon}${info.name}`;
      });
    }

    function buildCollectionDisplayItem(item, ownerData = null) {
      const profile = getContentProfile(ownerData);
      const attrKey = String(item?.element || item?.path || 'neutral');
      const attrInfo = getProfileAttributeInfo(attrKey, ownerData);
      if (!isCatProfile(ownerData)) return null;
      if (item.type === 'legendary') {
        return { title: `特殊品種夥伴`, color: 'var(--legendary-gold)', img: makeBadgeSvg('🐾', '特殊救援', '#ffb700', profile.builtInShop.hidden_egg.name) };
      }
      if (item.type === 'material') {
        return { title: `${attrInfo.name}玩具素材`, color: attrInfo.color, img: makeBadgeSvg('🧶', attrInfo.name, attrInfo.color, attrInfo.coat || '') };
      }
      if (item.type === 'dead_dragon') {
        const cause = getProfileDebuffInfo(item.cause, ownerData);
        return { title: `照護紀錄`, color: 'var(--danger)', img: makeBadgeSvg('📝', '照護紀錄', '#ff0055', cause.name) };
      }
      if (item.type === 'voucher') {
        return { title: item.status === 'redeemed' ? '已兌現憑證' : '兌換憑證', color: item.status === 'redeemed' ? 'var(--text-muted)' : 'var(--legendary-gold)', img: item.img || makeBadgeSvg('🎟️', '兌換憑證', item.status === 'redeemed' ? '#888888' : '#ffb700', item.name || '實體商品') };
      }
      if (item.type === 'dragon') {
        const vis = getCatVisual(ownerData || {}, item);
        return { title: `${vis.stageName}｜${attrInfo.name}`, color: vis.color, img: vis.file || vis.img };
      }
      return null;
    }


    function normalizeQuizGradeToken(raw) {
      const s = String(raw || '').trim();
      if (!s) return '';
      const normalized = s.replace(/\s+/g, '').replace(/年級|年|班/g, '');
      const map = { '一': '1', '二': '2', '三': '3', '四': '4', '五': '5', '六': '6' };
      const first = normalized.charAt(0);
      return map[first] || (/^[1-6]/.test(normalized) ? normalized.charAt(0) : normalized);
    }

    function isQuizEnabled(q = {}) {
      if (q.isActive === false) return false;
      if (q.active === false) return false;
      if (q.enabled === false) return false;
      if (String(q.status || '').trim() === 'disabled') return false;
      return true;
    }

    function quizMatchesStudentGrade(q = {}, userGrade = '', isSupportClass = false) {
      const raw = String(q.grade || q.class_name || q.gradeName || '').trim();
      if (!raw) return false;
      if (isSupportClass) return /學習扶助/.test(raw);
      if (/學習扶助/.test(raw)) return false;
      const quizGrade = normalizeQuizGradeToken(raw);
      const studentGrade = normalizeQuizGradeToken(userGrade);
      return !!quizGrade && !!studentGrade && quizGrade === studentGrade;
    }

    function getStudentGradeInfo(data = {}) {
      const className = String(data?.class_name || '').trim();
      const isSupportClass = /學習扶助/.test(className);
      const gradeMatch = className.match(/[1-6一二三四五六]/);
      const gradeToken = isSupportClass ? 'support' : (({ '一':'1', '二':'2', '三':'3', '四':'4', '五':'5', '六':'6' }[(gradeMatch || [])[0]] || ((gradeMatch || [])[0] || '')));
      const audienceKey = isSupportClass ? 'support' : (gradeToken ? `grade${gradeToken}` : 'default');
      return { className, isSupportClass, gradeToken, audienceKey };
    }

    function getBattleAudienceOptions() {
      return [
        { key: 'grade4', label: '四年級' },
        { key: 'grade5', label: '五年級' },
        { key: 'support', label: '學習扶助班' },
        { key: 'default', label: '全體通用（備援）' }
      ];
    }

    function normalizeBattleTowerDoc(raw = {}) {
      const base = raw && typeof raw === 'object' ? JSON.parse(JSON.stringify(raw)) : {};
      const audiences = (base.audiences && typeof base.audiences === 'object') ? base.audiences : {};
      const normalizeAudienceCfg = (cfg = {}, key = 'default') => ({
        id: cfg.id || cfg.bossId || cfg.legendaryId || '',
        bossId: cfg.bossId || cfg.id || cfg.legendaryId || '',
        name: cfg.name || cfg.bossName || '',
        img: cfg.img || cfg.image || '',
        typeKey: cfg.typeKey || cfg.type || cfg.element || cfg.bossType || '',
        gatekeeperQuizId: cfg.gatekeeperQuizId || cfg.quizId || cfg.quiz_id || cfg.questionId || 'random',
        bossDiceCount: normalizeBossDiceCount(cfg.bossDiceCount || cfg.diceCount || cfg.bossDice || 3, 3),
        timestamp: cfg.timestamp || cfg.updatedAt || 0,
        audienceKey: cfg.audienceKey || key,
        audienceLabel: cfg.audienceLabel || cfg.groupLabel || (key === 'default' ? '全體通用（備援）' : key)
      });
      if (!Object.keys(audiences).length && (base.id || base.bossId || base.legendaryId || base.typeKey || base.type || base.element || base.gatekeeperQuizId || base.quizId || base.quiz_id || base.questionId)) {
        audiences.default = normalizeAudienceCfg(base, 'default');
      }
      Object.keys(audiences).forEach((key) => {
        audiences[key] = normalizeAudienceCfg(audiences[key] || {}, key);
      });
      return { version: base.version || 'battle_tower_v2', audiences };
    }

    function getBattleBossConfigForAudience(rawDoc = {}, audienceKey = 'default') {
      const normalized = normalizeBattleTowerDoc(rawDoc);
      const audiences = normalized.audiences || {};
      return audiences[audienceKey] || audiences.default || null;
    }

    function getBattleBossConfigForStudent(studentData = {}, rawDoc = {}) {
      const info = getStudentGradeInfo(studentData);
      return getBattleBossConfigForAudience(rawDoc, info.audienceKey) || getBattleBossConfigForAudience(rawDoc, 'default');
    }

    function ensureRewardEventState(data = {}) {
      if (!Array.isArray(data.reward_events)) data.reward_events = [];
      if (!Array.isArray(data.reward_settled_ids)) data.reward_settled_ids = [];
      return data;
    }

    function buildRewardEventId(type, scopeParts = []) {
      const suffix = ([]).concat(scopeParts || []).map(v => String(v || '').trim()).filter(Boolean).join(':');
      return suffix ? `${type}:${suffix}` : `${type}:${Date.now()}`;
    }

    function applyRewardEventToData(dataObj, type, options = {}) {
      const data = ensureRewardEventState(JSON.parse(JSON.stringify(dataObj || {})));
      const timestamp = Number(options.timestamp) || Date.now();
      const eventId = String(options.eventId || buildRewardEventId(type, options.scopeParts || [])).trim();
      if (!eventId) return { data, applied: false, eventId: '' };
      if ((data.reward_settled_ids || []).includes(eventId)) {
        return { data, applied: false, eventId };
      }

      data.attributes = data.attributes || { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      data.logs = Array.isArray(data.logs) ? data.logs : [];

      const rewardMap = {
        daily_correct: { coins: 1, xp: 1, attrXP: 1, actionType: 'quest' },
        boss_win: { coins: 5, xp: 5, attrXP: 5, actionType: 'battle' },
        teacher_daily_compensate: { coins: 1, xp: 1, attrXP: 1, actionType: 'teacher_reward' },
        teacher_boss_compensate: { coins: 5, xp: 5, attrXP: 5, actionType: 'teacher_reward' }
      };
      const reward = rewardMap[type];
      if (!reward) return { data, applied: false, eventId };

      const maxEl = getDominantElementFromData(data);
      const attrName = getProfileAttributeInfo(maxEl, data)?.name || maxEl;
      data.coins = (Number(data.coins) || 0) + reward.coins;
      data.totalXP = (Number(data.totalXP) || 0) + reward.xp;
      addAttributeXP(data, maxEl, reward.attrXP);

      data.reward_events.push({
        id: eventId,
        type,
        timestamp,
        coins: reward.coins,
        xp: reward.xp,
        attr: maxEl,
        attrXP: reward.attrXP,
        source: options.source || 'system',
        meta: options.meta || {}
      });
      if (data.reward_events.length > 200) data.reward_events = data.reward_events.slice(-200);
      data.reward_settled_ids.push(eventId);
      if (data.reward_settled_ids.length > 400) data.reward_settled_ids = data.reward_settled_ids.slice(-400);

      const detailMap = {
        daily_correct: `[${getProfileLabels(data).dailyQuestLogPrefix || '每日修練'}] 答對 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
        boss_win: `[${getProfileLabels(data).battleTitle?.replace(/^[^\]]*\]\s*/, '') || '領域防衛'}] 成功 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
        teacher_daily_compensate: `[老師補發] 成功答題 +${reward.coins}🪙 +${reward.xp}XP(${attrName})`,
        teacher_boss_compensate: `[老師補發] 成功挑戰Boss +${reward.coins}🪙 +${reward.xp}XP(${attrName})`
      };
      data.logs.push({
        timestamp,
        action_type: reward.actionType,
        reward_event_id: eventId,
        points_added: reward.xp,
        detail: detailMap[type] || `[獎勵事件] ${type}`
      });

      return { data, applied: true, eventId, attrKey: maxEl, attrName, reward };
    }

    function applyProfileStaticTexts(data, isStudentMode = false) {
      const labels = getProfileLabels(data);
      const pfx = isStudentMode ? 'stu' : 'adm';
      const xpEl = document.getElementById(`${pfx}XpLabel`);
      if (xpEl) xpEl.innerText = labels.xp || '成長能量';
      const collectionEl = document.getElementById(`${pfx}CollectionTitle`);
      if (collectionEl) collectionEl.innerText = labels.collection || '圖鑑與寄宿紀錄';
      if (isStudentMode) {
        const qBtn = document.getElementById('stuDailyQuestBtn'); if (qBtn) qBtn.innerText = labels.dailyQuestButton || qBtn.innerText;
        const journey = document.getElementById('stuJourneyTitle'); if (journey) journey.innerText = labels.journey || journey.innerText;
        const battleTitle = document.getElementById('stuBattleTitle'); if (battleTitle) battleTitle.innerText = labels.battleTitle || battleTitle.innerText;
        const selTitle = document.getElementById('battleSelectionTitle'); if (selTitle) selTitle.innerText = labels.battleSelectionTitle || selTitle.innerText;
        const selDesc = document.getElementById('battleSelectionDesc'); if (selDesc) selDesc.innerHTML = labels.battleSelectionDesc || selDesc.innerHTML;
        const arenaTitle = document.getElementById('battleArenaHeading'); if (arenaTitle) arenaTitle.innerText = labels.battleArenaHeading || arenaTitle.innerText;
        const arenaDesc = document.getElementById('battleArenaDesc'); if (arenaDesc) arenaDesc.innerText = labels.battleArenaDesc || arenaDesc.innerText;
        const arenaBtn = document.getElementById('baActionBtn'); if (arenaBtn) arenaBtn.innerText = labels.battleAction || arenaBtn.innerText;
        const playerLabel = document.getElementById('baPlayerLabel'); if (playerLabel) playerLabel.innerText = labels.playerLabel || playerLabel.innerText;
        const bossLabel = document.getElementById('baBossLabel'); if (bossLabel) bossLabel.innerText = labels.bossLabel || bossLabel.innerText;
      }
    }

    function syncProfileForm(data) {
      const src = data || {};
      const flags = getProfileFlags(src);
      const p = getContentProfile(src);
      const sel = document.getElementById('profileSelect'); if (sel) sel.value = p.id;
      const variant = document.getElementById('profileVariantSelect'); if (variant) variant.value = src?.ui_variant || (p.id === 'cat' ? 'muslim_friendly' : 'default');
      const guideModeSelect = document.getElementById('guideModeSelect'); if (guideModeSelect) guideModeSelect.value = (String(src?.guide_mode || '').trim().toLowerCase() === 'baize' ? 'baize' : (String(src?.guide_mode || '').trim().toLowerCase() === 'cat' ? 'cat' : (p.id === 'cat' ? 'cat' : 'baize')));
      const guideModeLocked = document.getElementById('guideModeLocked'); if (guideModeLocked) guideModeLocked.checked = src?.guide_mode_locked !== false;
      const f1 = document.getElementById('flagHideFantasy'); if (f1) f1.checked = !!flags.hide_fantasy;
      const f2 = document.getElementById('flagUseCatTheme'); if (f2) f2.checked = !!flags.use_cat_theme;
      const f3 = document.getElementById('flagSafeRandom'); if (f3) f3.checked = !!flags.use_safe_random_label;
    }

    const TYPE_CHART = {}; // 倍率固定為 1.0（不使用相性表）

    const CONSTANTS = {
      DEBUFF_CD_MS: 7 * 24 * 60 * 60 * 1000, 
      DEBUFF_INFO: {
        Poison: { name: '中毒', color: 'var(--color-psychic)', desc: '龍獸處於中毒狀態。結算時獲得的總經驗值，將依據『中毒層數』大幅減少。' },
        Frozen: { name: '冰凍', color: 'var(--color-ice)', desc: '龍獸處於冰凍狀態。狀態解除前，即使經驗值達到 100 也無法進行進化結算。' },
        Paralyzed: { name: '麻痺', color: 'var(--color-electric)', desc: '龍獸處於麻痺狀態。結算進化金幣時，金幣轉換比例將依據『麻痺層數』大幅降低！' },
        Confusion: { name: '混亂', color: 'var(--danger)', desc: '龍獸處於混亂狀態。操作加分時，獲取的分數將不受控制，完全隨機分配至非目標的其他屬性上。' }
      },
      MEDIA: {
        // Firebase Storage: 建議把圖片放在 monsters/ 資料夾，檔名請與下方對應
        MEDIA_BUCKET: firebaseConfig.storageBucket, // 例：xxx.firebasestorage.app 或 xxx.appspot.com
        MEDIA_FOLDER: "images/monster pictures",
        MEDIA_EXT: "png",
        MEDIA_EXTS: ["png","jpg","jpeg","webp"],
        // 圖檔位置對照表（已依你在 Storage 的路徑建立）
        ASSET_PATHS: {
          "teacher": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fteacher%2Fteacher_800x800.webp?alt=media&token=d8cb0c56-6e21-419d-b6d2-55d7bca96361",
          "Primal Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FPrimal%20Dragon%20Egg_800x800.webp?alt=media&token=f9347d54-7037-4e0c-9aff-b5aee43f1754",
          "Fire Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FFire%20Dragon%20Egg_800x800.webp?alt=media&token=14e55e1d-4414-4309-9e7f-ed32f697c95b",
          "Water Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Dragon%20Egg_800x800.webp?alt=media&token=b9a5753b-c7fc-4baa-9de5-e006a5d43df0",
          "Earth Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FEarth%20Dragon%20Egg_800x800.webp?alt=media&token=88877c80-3f59-49b4-8785-426c6298c8f1",
          "Metal Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FMetal%20Dragon%20Egg_800x800.webp?alt=media&token=4153102f-eaf0-49f7-adca-4a89d081f47f",
          "Wood Dragon Egg": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWood%20Dragon%20Egg_800x800.webp?alt=media&token=013fe80e-dbfb-4471-b8f2-6a6f4a0a569d",
          "Chiwen (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Hatchling)_800x800.webp?alt=media&token=fc17ab60-9aec-4a98-bd8e-252697d5bfe9",
          "Chiwen (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Juvenile)_800x800.webp?alt=media&token=f7519672-afec-436e-9f16-fec089b4c403",
          "Chiwen (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FChiwen%2FChiwen%20(Adult)_800x800.webp?alt=media&token=b261f0b2-c797-4b34-8bc9-0b7c1ba76074",
          "Yazi (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Hatchling)_800x800.webp?alt=media&token=5ab5d293-a48e-4ba6-b9c8-a54b85d376f8",
          "Yazi (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Juvenile)_800x800.webp?alt=media&token=09b1dff7-f8c0-4d1b-b73c-4573a8ff5ae2",
          "Yazi (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FYazi%2FYazi%20(Adult)_800x800.webp?alt=media&token=99eb7d20-a49d-4b36-a608-0e7d5a4ce0ee",
          "Suanni (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Hatchling)_800x800.webp?alt=media&token=67185a35-793e-42f6-b2ad-e94a8247ef8f",
          "Suanni (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Juvenile)_800x800.webp?alt=media&token=b09b298f-6a40-4c17-8b79-4298501171fb",
          "Suanni (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FSuanni%2FSuanni%20(Adult)_800x800.webp?alt=media&token=29ce43db-a6d2-4cb0-a0f8-fd228f75ac92",
          "Bixi (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Hatchling)_800x800.webp?alt=media&token=15d591b4-4d40-4ebc-a7a1-87401c96deb0",
          "Bixi (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Juvenile)_800x800.webp?alt=media&token=e786db30-fc84-4b38-ae8c-89b736d946c0",
          "Bixi (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBixi%2FBixi%20(Adult)_800x800.webp?alt=media&token=79c204c9-0a2b-449e-a145-f70811ce9c13",
          "Bi'an (Hatchling)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Hatchling)_800x800.webp?alt=media&token=7a85fca9-1263-42f7-ba91-45aa27c42d3a",
          "Bi'an (Juvenile)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Juvenile)_800x800.webp?alt=media&token=43b78ffc-d297-49ba-9449-ddc011a6547e",
          "Bi'an (Adult)": "https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBi'an%2FBi'an%20(Adult)_800x800.webp?alt=media&token=23e152c0-6d42-4d27-89d0-1fff613ee0fc"
        },
        mediaUrl(objectPath) {
          // objectPath 例："images/monster pictures/dragon egg/Primal Dragon Egg.png"
          const bucket = this.MEDIA_BUCKET;
          return `https://firebasestorage.googleapis.com/v0/b/${bucket}/o/${encodeURIComponent(objectPath)}?alt=media`;
        },
        imageUrl(fileBaseName) {
          return this.mediaUrl(`${this.MEDIA_FOLDER}/${fileBaseName}.${this.MEDIA_EXT}`);
        },

        // 龍蛋（總經驗 < 100 時顯示）
        DRAGON_EGGS: {
          primal: { file: "Primal Dragon Egg", caption: "尚未甦醒的龍蛋" },
          fire:   { file: "Fire Dragon Egg",   caption: "蘊藏熾焰氣息的龍蛋" },
          water:  { file: "Water Dragon Egg",  caption: "流轉清泉氣息的龍蛋" },
          earth:  { file: "Earth Dragon Egg",  caption: "蘊藏厚土氣息的龍蛋" },
          metal:  { file: "Metal Dragon Egg",  caption: "散發銳金光澤的龍蛋" },
          wood:   { file: "Wood Dragon Egg",   caption: "蘊藏青木生機的龍蛋" }
        },

        // 破殼後的進化路線（每滿 100 XP 升級一次：破殼期 -> 成長期 -> 成年期）
        DRAGON_PATHS: {
          water: {
            species: "Chiwen",
            stages: [
              { file: "Chiwen (Hatchling)", name: "螭吻(破殼期)" },
              { file: "Chiwen (Juvenile)",  name: "螭吻(成長期)" },
              { file: "Chiwen (Adult)",     name: "螭吻(成年期)" }
            ]
          },
          metal: {
            species: "Yazi",
            stages: [
              { file: "Yazi (Hatchling)", name: "睚眥(破殼期)" },
              { file: "Yazi (Juvenile)",  name: "睚眥(成長期)" },
              { file: "Yazi (Adult)",     name: "睚眥(成年期)" }
            ]
          },
          fire: {
            species: "Suanni",
            stages: [
              { file: "Suanni (Hatchling)", name: "狻猊(破殼期)" },
              { file: "Suanni (Juvenile)",  name: "狻猊(成長期)" },
              { file: "Suanni (Adult)",     name: "狻猊(成年期)" }
            ]
          },
          earth: {
            species: "Bixi",
            stages: [
              { file: "Bixi (Hatchling)", name: "贔屭(破殼期)" },
              { file: "Bixi (Juvenile)",  name: "贔屭(成長期)" },
              { file: "Bixi (Adult)",     name: "贔屭(成年期)" }
            ]
          },
          wood: {
            species: "Bi'an",
            stages: [
              { file: "Bi'an (Hatchling)", name: "狴犴(破殼期)" },
              { file: "Bi'an (Juvenile)",  name: "狴犴(成長期)" },
              { file: "Bi'an (Adult)",     name: "狴犴(成年期)" }
            ]
          }
        },

        // 內建佔位圖（避免顯示舊版龍獸圖源）
        PLACEHOLDER_SVG: "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='256' height='256'><rect width='256' height='256' fill='%23020813'/><circle cx='128' cy='128' r='84' fill='none' stroke='%2300e5ff' stroke-width='6' opacity='0.35'/><path d='M128 56 L188 92 L188 164 L128 200 L68 164 L68 92 Z' fill='none' stroke='%2300e5ff' stroke-width='6' opacity='0.55'/><text x='50%' y='52%' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' opacity='0.75' font-family='Noto Sans TC' font-size='18'>異獸</text></svg>`)
      },
      ATTRIBUTES: {
        metal: { icon: '🛡️', name: '金', color: 'var(--color-metal)', char: '精準守時', desc: '金象徵凝鍊與規範，對應守時、重視步驟，以及俐落完成任務的能力。' },
        wood:  { icon: '🌿', name: '木', color: 'var(--color-wood)',  char: '探究成長', desc: '木象徵生長與延伸，對應觀察、提問、分享發現與持續探索的能力。' },
        water: { icon: '🌊', name: '水', color: 'var(--color-water)', char: '關懷協作', desc: '水象徵流動與滋養，對應整理環境、照顧器材，以及友善合作的能力。' },
        fire:  { icon: '🔥', name: '火', color: 'var(--color-fire)',  char: '熱情精進', desc: '火象徵熱力與光亮，對應主動投入、勇於挑戰，以及展現學習成果的能力。' },
        earth: { icon: '⛰️', name: '土', color: 'var(--color-earth)', char: '沉著自律', desc: '土象徵穩定與承載，對應專注、自律，以及耐心完成任務的能力。' }
      },
      ATTR_ORDER: ['metal','wood','water','fire','earth'],

      // 顯示用：進化型態名稱（用於寄放系統/放大預覽，不影響屬性判定）
      DRAGON_NAMES: {},

      LEGENDARIES: [],
      HIDDEN_EGGS: {
        starlight_kirin: { id: 'starlight_kirin', name: '星輝麒麟蛋', requiredAttr: 'metal', points: 18, icon: '🌠', desc: '養成金系成年龍獸後，轉化為隱藏版異獸「星輝麒麟」，提供 18 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FMetal%20Dragon%20Egg_800x800.webp?alt=media&token=4153102f-eaf0-49f7-adca-4a89d081f47f' },
        verdant_phoenix: { id: 'verdant_phoenix', name: '翠羽鳳凰蛋', requiredAttr: 'wood', points: 16, icon: '🪶', desc: '養成木系成年龍獸後，轉化為隱藏版異獸「翠羽鳳凰」，提供 16 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWood%20Dragon%20Egg_800x800.webp?alt=media&token=013fe80e-dbfb-4471-b8f2-6a6f4a0a569d' },
        abyssal_kun: { id: 'abyssal_kun', name: '滄淵鯤蛋', requiredAttr: 'water', points: 20, icon: '🌊', desc: '養成水系成年龍獸後，轉化為隱藏版異獸「滄淵鯤」，提供 20 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Dragon%20Egg_800x800.webp?alt=media&token=b9a5753b-c7fc-4baa-9de5-e006a5d43df0' },
        ember_qilin: { id: 'ember_qilin', name: '熾焰麒獸蛋', requiredAttr: 'fire', points: 22, icon: '🔥', desc: '養成火系成年龍獸後，轉化為隱藏版異獸「熾焰麒獸」，提供 22 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FFire%20Dragon%20Egg_800x800.webp?alt=media&token=14e55e1d-4414-4309-9e7f-ed32f697c95b' },
        gaia_basilisk: { id: 'gaia_basilisk', name: '蓋亞巨蜥蛋', requiredAttr: 'earth', points: 19, icon: '🪨', desc: '養成土系成年龍獸後，轉化為隱藏版異獸「蓋亞巨蜥」，提供 19 點隱藏積分。', img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FEarth%20Dragon%20Egg_800x800.webp?alt=media&token=88877c80-3f59-49b4-8785-426c6298c8f1' },
        azure_kirin: {
          id: 'azure_kirin',
          name: '碧瀾麒麟蛋',
          beastName: '碧瀾麒麟',
          requiredAttr: 'water',
          points: 100,
          icon: '🩵',
          cost: 100,
          desc: '購買後會進入孵化紀錄；沿用原本的經驗累積與進化節奏，最終可轉化為水屬性隱藏異獸「碧瀾麒麟」，提供 100 點隱藏積分。',
          img: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Kirin%20egg_800x800.webp?alt=media&token=3e256b90-6870-4e83-9b43-70bab4a0a8f0',
          forms: {
            egg: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fdragon%20egg%2FWater%20Kirin%20egg_800x800.webp?alt=media&token=3e256b90-6870-4e83-9b43-70bab4a0a8f0',
            hatchling: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20Kirin%20egg(Hatchling)_800x800.webp?alt=media&token=77a30a86-622a-4eb7-b72c-51d475571b0b',
            juvenile: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20KirinYazi%20(Juvenile)_800x800.webp?alt=media&token=947ef8e6-8296-4f4d-bf2c-6a5ffc3b06d0',
            adult: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FWater%20Kirin%2FWater%20KirinYazi%20(Adult)_800x800.webp?alt=media&token=8796cbb8-e4c6-47ed-9379-e9a890524d68'
          }
        }
      },
      LAP_TITLES: { 1: "初心者", 2: "館主", 3: "四天王", 4: "地區冠軍" },
      TRAINER_RANKS: [
  "見習守護員",
  "初階守護員",
  "進階守護員",
  "資深守護員",
  "卓越守護員",
  "榮譽守護師",
  "傳奇守護者",
  "殿堂守護者"
],
// 進化結算金幣匯率（100 / rate）
// 依你選擇的策略 2：階級越高優惠越好，且升級後永久保留相同/更佳優惠
TRAINER_RATE_BY_RANK: { 0: 5, 1: 4, 2: 3, 3: 3, 4: 2, 5: 2, 6: 2, 7: 2 },
ACTION_LIST: {
        metal: [{ desc: "準時完成並繳交任務，展現守時與條理", val: 5 }, { desc: "做事俐落、步驟清楚，能有效率完成工作", val: 5 }],
        wood:  [{ desc: "主動參與討論並提出自己的想法，展現探索精神", val: 20 }, { desc: "主動觀察並分享新發現，讓學習持續向外延伸", val: 15 }],
        water: [{ desc: "主動整理器材並確實歸位，照顧共同使用的空間", val: 5 }, { desc: "用心打掃並維護學習環境，讓大家都能安心學習", val: 10 }],
        fire:  [{ desc: "學習表現優良（90–94），展現主動投入的成果", val: 20 }, { desc: "學習表現亮眼（95–99），持續燃起精進的動力", val: 25 }, { desc: "學習表現卓越（100），展現全力以赴的光芒", val: 30 }],
        earth: [{ desc: "長時間專注完成學習任務，展現穩定與耐心", val: 5 }, { desc: "作品完整扎實，足以作為同學參考的優良示範", val: 20 }]
      },

TEAM_ACTION_PANELS: {
  science: {
    id: 'science',
    title: '科展團隊專屬加分面板',
    hint: '依據科展團隊的任務面向，將表現對應到五行能力。每次點選固定 +10 點經驗，方便老師快速記錄研究歷程中的亮點表現。',
    attrFocus: {
      metal: { label: '紀錄扎實', summary: '資料整理清楚、標示完整，讓研究脈絡一目了然。' },
      wood: { label: '創意發想', summary: '提出新方法、新問題或改良點，讓研究持續生長。' },
      water: { label: '口語表達', summary: '能溫和清楚地說明發現，並接住夥伴的想法。' },
      fire: { label: '操作用心', summary: '主動動手、反覆測試，讓作品持續進步。' },
      earth: { label: '作業優良', summary: '準時完成、內容完整，是團隊穩定推進的基石。' }
    },
    actions: {
      metal: [
        { desc: '實驗紀錄完整，時間、步驟與結果都標示清楚', val: 10 },
        { desc: '數據整理整齊，能用表格或圖示讓發現更清楚', val: 10 }
      ],
      wood: [
        { desc: '提出可行的新點子，讓作品更有特色或更完善', val: 10 },
        { desc: '主動延伸問題，替研究找到下一步方向', val: 10 }
      ],
      water: [
        { desc: '能清楚向同學說明操作流程與研究發現', val: 10 },
        { desc: '回答提問有條理，也能補充隊友的說明', val: 10 }
      ],
      fire: [
        { desc: '操作專注用心，願意反覆測試與調整細節', val: 10 },
        { desc: '主動協助器材準備與實作，讓實驗更順利', val: 10 }
      ],
      earth: [
        { desc: '科展作業準時且內容完整，展現可靠態度', val: 10 },
        { desc: '展板或書面成果扎實，可作為團隊示範', val: 10 }
      ]
    }
  },
  support: {
    id: 'support',
    title: '學習扶助專屬加分面板',
    hint: '聚焦學習扶助常見的學習表現，將每一次努力都轉成可見的成長紀錄。每次點選固定 +10 點經驗，方便老師穩定累積學生信心。',
    attrFocus: {
      metal: { label: '作業繳交', summary: '準時完成、條理清楚，幫助自己建立穩定節奏。' },
      wood: { label: '學習成效', summary: '願意挑戰、持續進步，把今天學會的帶到明天。' },
      water: { label: '組間合作', summary: '願意傾聽、互相幫忙，讓學習更有力量。' },
      fire: { label: '學習態度', summary: '主動投入、勇敢嘗試，不怕從錯誤中學習。' },
      earth: { label: '學習秩序', summary: '專心穩定、遵守規範，讓大家都能安心學習。' }
    },
    actions: {
      metal: [
        { desc: '作業準時繳交，內容完整清楚', val: 10 },
        { desc: '訂正確實，能看見自己一步步修正', val: 10 }
      ],
      wood: [
        { desc: '比前一次更進步，能看見自己的成長', val: 10 },
        { desc: '願意挑戰較難題型，持續向前探索', val: 10 }
      ],
      water: [
        { desc: '能和同學互相提醒，一起完成任務', val: 10 },
        { desc: '主動幫助組員理解題目，合作氣氛良好', val: 10 }
      ],
      fire: [
        { desc: '上課主動投入，願意舉手或回答問題', val: 10 },
        { desc: '遇到困難仍願意再試一次，保持學習熱情', val: 10 }
      ],
      earth: [
        { desc: '能安靜專心完成任務，維持良好學習秩序', val: 10 },
        { desc: '遵守約定與上課流程，展現自律與耐心', val: 10 }
      ]
    }
  }
},
      ANONYMOUS_CODES: [
        // 🌌 天文與星象 (Astronomy)
        "宇宙", "星辰", "銀河", "穹蒼", "彗星", "恆星", "星雲", "軌道", "日冕", "曜日",
        "皎月", "朔望", "弦月", "璇璣", "奇點", "穹宇", "寰宇", "虛空", "視界", "緯度",
        "星軌", "光年", "日珥", "繁星", "孤星", "雙星", "星團", "星弧", "極光", "幻日",
        // 🌍 地質與氣象 (Earth & Weather)
        "山嵐", "峽谷", "季風", "冰川", "斷層", "沉積", "潮汐", "霞光", "晨露", "山脈",
        "盆地", "丘陵", "高原", "平原", "荒漠", "綠洲", "苔原", "凍土", "冰山", "融雪",
        // 🌊 海洋與生態 (Marine & Ecology)
        "珊瑚", "礁岩", "深淵", "海溝", "洋流", "劍尾", "藍血", "蛻皮", "潮間", "浮游",
        "橈足", "底棲", "洄游", "成體", "甲殼", "觸角", "複眼", "側眼", "步足", "鰓弧",
        // 🌿 植物與微觀 (Botany & Microscopic)
        "蒼松", "翠竹", "葉脈", "根系", "孢子", "蕨類", "花萼", "樹冠", "苔蘚", "地衣",
        "雙子", "單子", "胚軸", "子葉", "根冠", "根毛", "皮層", "內皮", "中柱", "韌皮",
        // 🧬 演化與科學 (Science & Systems)
        "基因", "突觸", "遺傳", "轉化", "演化", "適應", "篩選", "隔離", "物種", "復育",
        "保育", "多樣", "豐度", "均度", "歧異", "染色", "密碼", "轉錄", "轉譯", "表現",
        // ⚛️ 物理與力學 (Physics & Mechanics)
        "慣性", "動量", "向量", "矩陣", "標量", "質心", "槓桿", "阻力", "滑輪", "軌跡",
        "速度", "加速", "位移", "距離", "質量", "重量", "重力", "引力", "彈力", "浮力",
        // ⚡ 電磁與科技 (Electromagnetism & Tech)
        "磁場", "電極", "晶片", "電荷", "庫侖", "電場", "電位", "電壓", "電流", "電阻",
        "電導", "電容", "電感", "串聯", "並聯", "歐姆", "安培", "伏特", "法拉", "亨利",
        // 🧪 化學與元素 (Chemistry & Elements)
        "離子", "晶格", "催化", "昇華", "凝華", "溶解", "沉澱", "萃取", "蒸餾", "結晶",
        "元素", "週期", "族群", "鹼金", "鹼土", "鹵素", "惰性", "過渡", "稀土", "錒系",
        // 📐 數學與幾何 (Math & Geometry)
        "幾何", "象限", "座標", "維度", "演繹", "歸納", "函數", "極限", "微分", "積分",
        "導數", "偏導", "級數", "數列", "行列", "張量", "純量", "空間", "拓樸", "流形",
        // ⏳ 理性與思維 (Reasoning & Philosophy)
        "剎那", "須臾", "永恆", "瞬息", "規律", "秩序", "均衡", "守恆", "輪迴", "起源",
        "黎明", "創世", "新生", "世紀", "紀元", "世代", "歲月", "光陰", "韶華", "流年"
      ]
    };
    // ===== 初始化：將「成熟期異獸」加入 Boss / 異獸基因庫下拉選單 =====
    (function __initAdultBeastsAsLegendaries() {
      try {
        const list = Array.isArray(CONSTANTS.LEGENDARIES) ? CONSTANTS.LEGENDARIES.slice() : [];
        const paths = (CONSTANTS.MEDIA && CONSTANTS.MEDIA.DRAGON_PATHS) ? CONSTANTS.MEDIA.DRAGON_PATHS : {};
        const assetMap = (CONSTANTS.MEDIA && CONSTANTS.MEDIA.ASSET_PATHS) ? CONSTANTS.MEDIA.ASSET_PATHS : {};
        const seen = new Set(list.map(x => String(x && x.id)));

        for (const [typeKey, p] of Object.entries(paths)) {
          const st = p && p.stages && p.stages[2]; // 成熟期/成年期
          if (!st) continue;

          const species = (p.species || '').trim() || String(st.file || '').trim();
          const id = `${species}_Adult`.replace(/[^\w\-]/g, '_');
          if (seen.has(id)) continue;
          seen.add(id);

          const imgUrl = (typeof assetMap[st.file] === 'string' && /^https?:\/\//i.test(assetMap[st.file]))
            ? assetMap[st.file]
            : CONSTANTS.MEDIA.PLACEHOLDER_SVG;

          list.push({
            id,
            name: st.name || species,
            img: imgUrl,
            typeKey,       // 建議屬性（五行）
            assetKey: st.file
          });
        }

        // 排序：依五行順序
        const order = Array.isArray(CONSTANTS.ATTR_ORDER) ? CONSTANTS.ATTR_ORDER : ['metal','wood','water','fire','earth'];
        list.sort((a, b) => (order.indexOf(a.typeKey) - order.indexOf(b.typeKey)) || String(a.name).localeCompare(String(b.name)));

        CONSTANTS.LEGENDARIES = list;
      } catch (e) {
        console.warn('[init] adult beasts list failed:', e?.message || e);
      }
    })();



    // ===== 五行屬 / 龍蛋成長系統 =====
    const ELEMENT_KEYS = CONSTANTS.ATTR_ORDER || ['metal','wood','water','fire','earth'];

function getStudentTeamPanelKey(data = null) {
  const className = String((data || currentState?.studentData || {})?.class_name || '').trim();
  if (/科展團隊/.test(className)) return 'science';
  if (/學習扶助/.test(className)) return 'support';
  return '';
}

function getActionPanelConfig(data = null) {
  const panelKey = getStudentTeamPanelKey(data);
  const panel = panelKey ? (CONSTANTS.TEAM_ACTION_PANELS?.[panelKey] || null) : null;
  return {
    key: panelKey || 'default',
    title: panel?.title || '一般學習加分面板',
    hint: panel?.hint || '目前使用一般學習加分面板；系統會依五行能力顯示對應的加分事件。',
    actions: panel?.actions || CONSTANTS.ACTION_LIST,
    attrFocus: panel?.attrFocus || {}
  };
}


    function getMostRecentNoonTimestamp(nowTs = Date.now()) {
      const d = new Date(nowTs);
      const noon = new Date(d);
      noon.setHours(12, 0, 0, 0);
      if (d.getTime() < noon.getTime()) noon.setDate(noon.getDate() - 1);
      return noon.getTime();
    }

    function getNextNoonTimestamp(nowTs = Date.now()) {
      const d = new Date(nowTs);
      const noon = new Date(d);
      noon.setHours(12, 0, 0, 0);
      if (d.getTime() >= noon.getTime()) noon.setDate(noon.getDate() + 1);
      return noon.getTime();
    }

    function isSameNoonWindow(lastTime, nowTs = Date.now()) {
      const last = Number(lastTime) || 0;
      if (!last) return false;
      return last >= getMostRecentNoonTimestamp(nowTs);
    }

    function getDailyResetAnchor(data = {}, nowTs = Date.now()) {
      return Math.max(getMostRecentNoonTimestamp(nowTs), Number(data?.daily_reset_override_at) || 0);
    }

    function getBattleResetAnchor(data = {}, nowTs = Date.now()) {
      return Math.max(getMostRecentNoonTimestamp(nowTs), Number(data?.battle_reset_override_at) || 0);
    }

    function getTodayDailyRewardCount(data = {}, nowTs = Date.now()) {
      const anchor = getDailyResetAnchor(data, nowTs);
      const storedCountDate = Number(data?.today_quiz_reward_date) || 0;
      const storedCount = Number(data?.today_quiz_reward_count);
      if (Number.isFinite(storedCount) && storedCountDate >= anchor) {
        return Math.max(0, storedCount);
      }
      const events = Array.isArray(data?.reward_events) ? data.reward_events : [];
      return events.filter(evt => evt && evt.type === 'daily_correct' && (Number(evt.timestamp) || 0) >= anchor).length;
    }

    function getTodayDailyRemaining(data = {}, nowTs = Date.now()) {
      return Math.max(0, 10 - getTodayDailyRewardCount(data, nowTs));
    }

    function hasBattleAttemptRemaining(data = {}, nowTs = Date.now()) {
      const anchor = getBattleResetAnchor(data, nowTs);
      const lastBattle = Number(data?.last_battle_time) || 0;
      if (lastBattle >= anchor) return false;
      const used = data?.today_battle_used === true;
      const usedDate = Number(data?.today_battle_date) || 0;
      if (used && usedDate >= anchor) return false;
      return true;
    }

    function formatCountdown(ms) {
      const remain = Math.max(0, Number(ms) || 0);
      const h = Math.floor(remain / 3600000);
      const m = Math.floor((remain % 3600000) / 60000);
      return `${h} 小時 ${m} 分鐘`;
    }

    function getMaxElementFromAttributes(attrs = {}, firstGainOrder = null) {
      let best = ELEMENT_KEYS[0] || 'metal';
      let bestVal = -Infinity;
      const orderMap = firstGainOrder || {};
      const getOrder = (key) => Number.isFinite(Number(orderMap?.[key])) ? Number(orderMap[key]) : Number.POSITIVE_INFINITY;
      for (const k of ELEMENT_KEYS) {
        const v = Number(attrs?.[k]) || 0;
        if (v > bestVal) {
          bestVal = v;
          best = k;
          continue;
        }
        if (v === bestVal) {
          const curOrder = getOrder(best);
          const nextOrder = getOrder(k);
          if (nextOrder < curOrder) best = k;
        }
      }
      return best;
    }

    function inferElementKeyFromText(raw = '') {
      const txt = String(raw || '').replace(/[\s\[\]【】()（）]/g, '').replace(/[⚙️🌳💧🔥🪨🌟✨💊🍡🪙⭐★]/g, '');
      if (!txt) return null;
      if (txt.includes('metal') || txt.includes('金') || txt.includes('鋼')) return 'metal';
      if (txt.includes('wood') || txt.includes('木') || txt.includes('草') || txt.includes('葉')) return 'wood';
      if (txt.includes('water') || txt.includes('水')) return 'water';
      if (txt.includes('fire') || txt.includes('火')) return 'fire';
      if (txt.includes('earth') || txt.includes('土') || txt.includes('地')) return 'earth';
      return null;
    }

    function ensureAttributeFirstGainOrder(data) {
      if (!data || typeof data !== 'object') return {};
      const base = { metal: null, wood: null, water: null, fire: null, earth: null };
      data.attribute_first_gain_order = Object.assign(base, data.attribute_first_gain_order || {});
      let nextOrder = 1;
      for (const k of ELEMENT_KEYS) {
        const v = Number(data.attribute_first_gain_order[k]);
        if (Number.isFinite(v) && v > 0) nextOrder = Math.max(nextOrder, v + 1);
      }
      if (Array.isArray(data.logs) && data.logs.length) {
        const logs = data.logs.slice().sort((a, b) => (Number(a?.timestamp) || 0) - (Number(b?.timestamp) || 0));
        for (const log of logs) {
          const detail = String(log?.detail || '');
          const match = detail.match(/\(([^)]+)\)\s*$/);
          const key = inferElementKeyFromText(match ? match[1] : detail);
          if (!key) continue;
          const existing = Number(data.attribute_first_gain_order[key]);
          if (Number.isFinite(existing) && existing > 0) continue;
          if ((Number(data.attributes?.[key]) || 0) <= 0) continue;
          data.attribute_first_gain_order[key] = nextOrder++;
        }
      }
      for (const k of ELEMENT_KEYS) {
        const hasAttr = (Number(data.attributes?.[k]) || 0) > 0;
        const hasOrder = Number.isFinite(Number(data.attribute_first_gain_order[k])) && Number(data.attribute_first_gain_order[k]) > 0;
        if (hasAttr && !hasOrder) data.attribute_first_gain_order[k] = nextOrder++;
      }
      return data.attribute_first_gain_order;
    }

    function markAttributeGain(data, attr) {
      if (!data || !ELEMENT_KEYS.includes(attr)) return;
      const orderMap = ensureAttributeFirstGainOrder(data);
      const existing = Number(orderMap?.[attr]);
      if (Number.isFinite(existing) && existing > 0) return;
      let nextOrder = 1;
      for (const k of ELEMENT_KEYS) {
        const v = Number(orderMap?.[k]);
        if (Number.isFinite(v) && v > 0) nextOrder = Math.max(nextOrder, v + 1);
      }
      data.attribute_first_gain_order[attr] = nextOrder;
    }

    function addAttributeXP(data, attr, amount) {
      if (!data || !ELEMENT_KEYS.includes(attr)) return;
      if (!data.attributes) data.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
      const before = Number(data.attributes[attr]) || 0;
      const delta = Number(amount) || 0;
      data.attributes[attr] = before + delta;
      if (delta > 0 && data.attributes[attr] > 0) markAttributeGain(data, attr);
    }

    function getDominantElementFromData(data) {
      return getMaxElementFromAttributes(data?.attributes || {}, ensureAttributeFirstGainOrder(data || {}));
    }

    function getEggVisual(data) {
      const eggs = CONSTANTS.MEDIA.DRAGON_EGGS;
      if (!data || (Number(data.totalXP) || 0) <= 0) return eggs.primal;
      const maxEl = getDominantElementFromData(data);
      return eggs[maxEl] || eggs.primal;
    }

    function getDragonVisual(data) {
      // data.dragon_stage: -1(蛋) / 0(破殼期) / 1(成長期) / 2(成年期)
      const stage = Number(data?.dragon_stage);
      const stageIdx = Number.isFinite(stage) ? stage : -1;
      const maxEl = getDominantElementFromData(data);
      const pathKey = data?.dragon_path || null;
      const activeHiddenEggId = String(data?.active_hidden_egg_id || '').trim();
      const activeHiddenEgg = (data?.active_hidden_egg && typeof data.active_hidden_egg === 'object') ? data.active_hidden_egg : null;
      const activeHiddenMeta = (activeHiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEggId])
        ? CONSTANTS.HIDDEN_EGGS[activeHiddenEggId]
        : (activeHiddenEggId && activeHiddenEgg?.hiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId])
          ? CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId]
          : activeHiddenEgg;

      if (activeHiddenMeta && activeHiddenMeta.forms) {
        const color = (CONSTANTS.ATTRIBUTES[activeHiddenMeta.requiredAttr || maxEl]?.color) || (CONSTANTS.ATTRIBUTES[maxEl]?.color) || 'var(--cyan)';
        if (stageIdx < 0) {
          return { file: activeHiddenMeta.forms.egg || activeHiddenMeta.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.name || '特殊異獸蛋'}（孵化中）`, color, name: activeHiddenMeta.name || '特殊異獸蛋' };
        }
        if (stageIdx === 0) {
          return { file: activeHiddenMeta.forms.hatchling || activeHiddenMeta.forms.egg || activeHiddenMeta.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜破殼期`, color, name: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}（破殼期）` };
        }
        if (stageIdx === 1) {
          return { file: activeHiddenMeta.forms.juvenile || activeHiddenMeta.forms.hatchling || activeHiddenMeta.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜成長期`, color, name: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}（成長期）` };
        }
        return { file: activeHiddenMeta.forms.adult || activeHiddenMeta.forms.juvenile || activeHiddenMeta.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG, caption: `${activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}｜成熟期`, color, name: activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸' };
      }

      // 仍在龍蛋階段（未破殼）
      if (stageIdx < 0) {
        const egg = getEggVisual(data);
        const color = (CONSTANTS.ATTRIBUTES[maxEl]?.color) || 'var(--cyan)';
        return { file: egg.file, caption: `${egg.caption}`, color, name: "龍蛋" };
      }

      // 已破殼：有設定路線就使用對應圖；沒設定就先用該屬性的龍蛋佔位
      const paths = CONSTANTS.MEDIA.DRAGON_PATHS || {};
      const useKey = pathKey || maxEl;
      const p = paths[useKey];

      if (p && p.stages && p.stages[stageIdx]) {
        const st = p.stages[stageIdx];
        const color = (CONSTANTS.ATTRIBUTES[useKey]?.color) || (CONSTANTS.ATTRIBUTES[maxEl]?.color) || 'var(--cyan)';
        return { file: st.file, caption: `${st.name}`, color, name: st.name };
      }

      // fallback：尚未設定的屬性路線
      const egg = (CONSTANTS.MEDIA.DRAGON_EGGS && CONSTANTS.MEDIA.DRAGON_EGGS[useKey]) ? CONSTANTS.MEDIA.DRAGON_EGGS[useKey] : getEggVisual(data);
      const color = (CONSTANTS.ATTRIBUTES[useKey]?.color) || 'var(--cyan)';
      return { file: egg.file, caption: "進化型態待設定", color, name: "未設定" };
    }


    function normalizeBossDiceCount(value, fallback = 3) {
      const num = Number(value);
      if (!Number.isFinite(num)) return fallback;
      return Math.max(1, Math.min(12, Math.round(num)));
    }

    function isDirectVisualSource(ref) {
      const s = String(ref || '').trim();
      return /^https?:\/\//i.test(s) || /^data:image\//i.test(s) || /^blob:/i.test(s);
    }

    function splitBattleVisualRef(ref, fallbackImg = CONSTANTS.MEDIA.PLACEHOLDER_SVG) {
      const raw = String(ref || '').trim();
      if (!raw) return { img_file: '', img: fallbackImg };
      if (isDirectVisualSource(raw)) return { img_file: '', img: raw };
      return { img_file: raw, img: fallbackImg };
    }

    function getBattleMonStage(mon = {}, ownerData = {}) {
      if (mon?.type === 'legendary') return 2;
      const raw = mon?.stage ?? mon?.dragon_stage ?? ownerData?.dragon_stage;
      const stage = Number(raw);
      return Number.isFinite(stage) ? stage : -1;
    }

    function getBattleMonDiceCount(mon = {}, ownerData = {}) {
      const stage = getBattleMonStage(mon, ownerData);
      if (stage >= 2) return 6;
      if (stage === 1) return 5;
      if (stage === 0) return 4;
      return 3;
    }

    function getBattleStageLabel(stage, ownerData = null) {
      if (isCatProfile(ownerData)) {
        if (stage >= 2) return '成貓期';
        if (stage === 1) return '幼貓期';
        if (stage === 0) return '奶貓期';
        return '箱子';
      }
      if (stage >= 2) return '成熟期';
      if (stage === 1) return '成長期';
      if (stage === 0) return '破殼期';
      return '蛋形態';
    }

    function createBattleDiceFaces(containerId, count = 3) {
      const container = document.getElementById(containerId);
      if (!container) return;
      const safeCount = Math.max(1, Math.min(12, Number(count) || 3));
      container.innerHTML = Array.from({ length: safeCount }, () => '<div class="dice">?</div>').join('');
    }

    function buildActiveBattleMon(studentData = {}) {
      const vis = getProfileVisual(studentData);
      const stage = Number(studentData?.dragon_stage);
      const stageIdx = Number.isFinite(stage) ? stage : -1;
      const dominant = getDominantElementFromData(studentData) || 'neutral';
      const pathKey = studentData?.dragon_path || dominant || 'neutral';
      const activeHiddenEggId = String(studentData?.active_hidden_egg_id || '').trim();
      const activeHiddenEgg = (studentData?.active_hidden_egg && typeof studentData.active_hidden_egg === 'object') ? studentData.active_hidden_egg : null;
      const activeHiddenMeta = (activeHiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEggId])
        ? CONSTANTS.HIDDEN_EGGS[activeHiddenEggId]
        : (activeHiddenEggId && activeHiddenEgg?.hiddenEggId && CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId])
          ? CONSTANTS.HIDDEN_EGGS[activeHiddenEgg.hiddenEggId]
          : activeHiddenEgg;
      const visualRef = splitBattleVisualRef(vis?.file, vis?.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG);
      const attrInfo = getProfileAttributeInfo(pathKey, studentData);
      const activeName = (() => {
        if (activeHiddenMeta) {
          if (stageIdx < 0) return `當前型態｜${activeHiddenMeta.name || '特殊異獸蛋'}`;
          return `當前型態｜${vis?.name || activeHiddenMeta.beastName || activeHiddenMeta.name || '特殊異獸'}`;
        }
        if (isCatProfile(studentData)) {
          return `當前型態｜${vis?.stageName || vis?.name || '夥伴'}`;
        }
        if (stageIdx < 0) {
          const eggName = (Number(studentData?.totalXP) || 0) > 0 ? `${attrInfo.name}龍蛋` : '初始龍蛋';
          return `當前型態｜${eggName}`;
        }
        return `當前型態｜${vis?.name || attrInfo.name || '龍獸'}`;
      })();
      return {
        isActiveCurrent: true,
        hiddenEggId: activeHiddenMeta?.id || activeHiddenMeta?.hiddenEggId || activeHiddenEggId || '',
        name: activeName,
        img_file: visualRef.img_file,
        img: visualRef.img,
        type: activeHiddenMeta ? 'hidden_egg' : (stageIdx < 0 ? 'egg' : 'dragon'),
        typeKey: (activeHiddenMeta?.requiredAttr || pathKey || dominant || 'neutral'),
        element: pathKey || dominant || 'neutral',
        path: pathKey || dominant || 'neutral',
        stage: stageIdx,
        dragon_stage: stageIdx,
        dragon_path: pathKey || dominant || 'neutral',
        stats: { ...(studentData.attributes || {}) }
      };
    }

    function buildBattleTeamForStudent(studentData = {}) {
      const col = Array.isArray(studentData?.collection) ? studentData.collection : [];
      return [
        buildActiveBattleMon(studentData),
        ...col.filter(i => (i.type === 'dragon' || i.type === 'legendary') && i.type !== 'dead_dragon' && !i.isHologram)
      ];
    }

        function __objectPathsForAssetKey(assetKey) {
      const key = String(assetKey || '').trim();
      if (!key) return [];

      const map = (CONSTANTS.MEDIA && CONSTANTS.MEDIA.ASSET_PATHS) ? CONSTANTS.MEDIA.ASSET_PATHS : {};
      const mapped = map[key];
      if (Array.isArray(mapped)) return mapped.filter(Boolean);
      if (typeof mapped === 'string' && mapped) return [mapped];

      const exts = (CONSTANTS.MEDIA.MEDIA_EXTS && CONSTANTS.MEDIA.MEDIA_EXTS.length)
        ? CONSTANTS.MEDIA.MEDIA_EXTS
        : [CONSTANTS.MEDIA.MEDIA_EXT || 'png'];

      // 若 key 已是 Storage object path
      if (key.includes('/')) {
        // 已包含副檔名
        if (/\.[a-z0-9]+$/i.test(key)) return [key];
        // 沒副檔名：嘗試多種 ext
        return exts.map(ext => `${key}.${ext}`);
      }

      const folder = CONSTANTS.MEDIA.MEDIA_FOLDER || '';
      const prefix = folder ? `${folder}/` : '';
      return exts.map(ext => `${prefix}${key}.${ext}`);
    }

    function assetUrlFromFileBaseName(fileBaseName) {
      // 圖片 URL 解析：
      // 1) 先看 ASSET_PATHS 是否有對應到你 Storage 的完整路徑
      // 2) 若 local cache 已有對應路徑的 downloadURL，直接回傳（避免閃爍）
      // 3) 否則回傳 placeholder，後續由 setImgFromFileBaseName() 非同步替換
      const paths = __objectPathsForAssetKey(fileBaseName);
      if (!paths.length) return CONSTANTS.MEDIA.PLACEHOLDER_SVG;

      const p0 = paths[0];
      // 若已是 downloadURL（https://...），可直接回傳，避免再打 storage 解析
      if (typeof p0 === 'string' && /^https?:\/\//i.test(p0)) return p0;
      if (__assetUrlCache.has(p0)) return __assetUrlCache.get(p0);
      return CONSTANTS.MEDIA.PLACEHOLDER_SVG;
    }

    // --- Firebase Storage (downloadURL/token) image resolver --- (downloadURL/token) image resolver ---
    const __assetUrlCache = new Map();
    const __assetUrlCacheLSKey = 'shan_hai_asset_url_cache_v2';
    // Debug helper: 清除圖片 URL 快取（正式環境不直接暴露為全域，由 global bridge 視模式決定是否掛載）
    function __clearAssetUrlCache() {
      try { localStorage.removeItem(__assetUrlCacheLSKey); } catch (e) {}
      try { __assetUrlCache.clear(); } catch (e) {}
      try { location.reload(); } catch (e) {}
    }


    (function __loadAssetCacheFromLS() {
      try {
        const raw = localStorage.getItem(__assetUrlCacheLSKey);
        if (!raw) return;
        const obj = JSON.parse(raw);
        if (!obj || typeof obj !== 'object') return;
        Object.entries(obj).forEach(([k, v]) => {
          if (typeof k === 'string' && typeof v === 'string' && v.startsWith('http')) __assetUrlCache.set(k, v);
        });
      } catch (e) { /* ignore */ }
    })();

    function __persistAssetCacheToLS() {
      try {
        const obj = {};
        // 限制寫入大小：最多 200 筆，避免 localStorage 過大
        let count = 0;
        for (const [k, v] of __assetUrlCache.entries()) {
          obj[k] = v; count += 1;
          if (count >= 200) break;
        }
        localStorage.setItem(__assetUrlCacheLSKey, JSON.stringify(obj));
      } catch (e) { /* ignore */ }
    }

    // --- Firebase Storage Cache-Control helper ---
    // 註：Storage 物件的 Cache-Control 需要寫在「檔案 metadata」中才會真的影響瀏覽器快取。
    // 這裡提供「管理端/測試模式」下的自動補上 cacheControl（不阻塞圖片載入，失敗會忽略）。
    const __cacheControlLSKey = 'shan_hai_asset_cachecontrol_v1';
    const __cacheControlDone = new Set();
    const __DEFAULT_CACHE_CONTROL = 'public,max-age=31536000,immutable';

    (function __loadCacheControlDoneFromLS() {
      try {
        const raw = localStorage.getItem(__cacheControlLSKey);
        if (!raw) return;
        const arr = JSON.parse(raw);
        if (!Array.isArray(arr)) return;
        arr.forEach((p) => { if (typeof p === 'string') __cacheControlDone.add(p); });
      } catch (e) { /* ignore */ }
    })();

    function __persistCacheControlDoneToLS() {
      try {
        const arr = Array.from(__cacheControlDone.values()).slice(0, 200);
        localStorage.setItem(__cacheControlLSKey, JSON.stringify(arr));
      } catch (e) { /* ignore */ }
    }

    function __maybeSetCacheControl(objectPath) {
      try {
        if (!objectPath) return;
        // 只在管理端/測試模式嘗試（避免學生端增加額外寫入）
        if (!(currentState?.viewMode === 'admin' || currentState?.viewMode === 'test')) return;
        if (__cacheControlDone.has(objectPath)) return;

        // fire-and-forget：不阻塞圖片載入
        updateMetadata(storageRef(storage, objectPath), { cacheControl: __DEFAULT_CACHE_CONTROL })
          .then(() => {
            __cacheControlDone.add(objectPath);
            __persistCacheControlDoneToLS();
          })
          .catch(() => { /* ignore (likely permission/rules) */ });
      } catch (e) { /* ignore */ }
    }

        async function resolveAssetUrlFromFileBaseName(fileBaseName) {

      const key = String(fileBaseName || '').trim();
      if (!key) return CONSTANTS.MEDIA.PLACEHOLDER_SVG;

      const paths = __objectPathsForAssetKey(key);
      if (!paths.length) return CONSTANTS.MEDIA.PLACEHOLDER_SVG;

      for (let i = 0; i < paths.length; i++) {
        const objectPath = paths[i];

        // 已是 downloadURL（https://...）：直接使用，不再呼叫 getDownloadURL
        if (typeof objectPath === 'string' && /^https?:\/\//i.test(objectPath)) {
          __assetUrlCache.set(objectPath, objectPath);
          __persistAssetCacheToLS();
          return objectPath;
        }

        // cache hit
        if (__assetUrlCache.has(objectPath)) return __assetUrlCache.get(objectPath);

        try {
          const url = await getDownloadURL(storageRef(storage, objectPath));
          __assetUrlCache.set(objectPath, url);
          __persistAssetCacheToLS();
          __maybeSetCacheControl(objectPath);
          return url;
        } catch (e) {
          if (i === paths.length - 1) {
            console.warn('[storage] getDownloadURL failed:', { assetKey: key, objectPath }, e?.message || e);
          }
        }
      }

      // fallback：若你把對應路徑設成 public read，也可用直連
      try { return CONSTANTS.MEDIA.mediaUrl(paths[0]); }
      catch { return CONSTANTS.MEDIA.PLACEHOLDER_SVG; }
    }

    function setImgFromFileBaseName(imgEl, fileBaseName, { shadowColor } = {}) {
      if (!imgEl) return;
      imgEl.dataset.asset = fileBaseName || '';
      // 先放 placeholder，避免破圖閃爍
      imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      if (shadowColor) imgEl.style.filter = `drop-shadow(0 0 20px ${shadowColor})`;

      // 非同步替換成帶 token 的 URL
      (async () => {
        const base = String(fileBaseName || '');
        if (!base) return;
        const url = await resolveAssetUrlFromFileBaseName(base);
        // 確保沒有被其他更新覆蓋
        if (imgEl.dataset.asset === base) imgEl.src = url;
      })();
    }

    function hydrateStorageImages(root = document) {
      const imgs = Array.from(root.querySelectorAll('img[data-asset]'));
      imgs.forEach((img) => {
        const base = img.dataset.asset;
        if (!base) return;
        // 避免重複觸發
        if (img.dataset.assetHydrated === '1') return;
        img.dataset.assetHydrated = '1';
        setImgFromFileBaseName(img, base);
      });
    }

    
    function __updateLegendarySelectPreview(selectId, imgId, nameId) {
      try {
        const sel = document.getElementById(selectId);
        const img = document.getElementById(imgId);
        const name = document.getElementById(nameId);
        if (!sel || !img || !name) return;

        const val = sel.value;
        const info = (CONSTANTS.LEGENDARIES || []).find(l => String(l.id) === String(val));
        name.innerText = info ? (info.name || val) : '---';
        img.src = info ? (info.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG) : CONSTANTS.MEDIA.PLACEHOLDER_SVG;
      } catch (e) {
        console.warn('[ui] preview update failed:', e?.message || e);
      }
    }

const DomBridge = {
      cache: new Map(),
      get(id) {
        if (!id) return null;
        const cached = this.cache.get(id);
        if (cached && document.body.contains(cached)) return cached;
        const el = document.getElementById(id);
        if (el) this.cache.set(id, el);
        return el;
      },
      getAll(selector, root = document) {
        return Array.from((root || document).querySelectorAll(selector));
      },
      clear(id) {
        if (id) this.cache.delete(id);
        else this.cache.clear();
      }
    };

    const ModuleBridge = {
      modules: new Map(),
      hooks: { beforeInit: [], afterInit: [], afterRoute: [], afterAuth: [] },
      ready: false,
      context: null,
      register(name, moduleDef = {}) {
        const key = String(name || '').trim();
        if (!key) throw new Error('module name is required');
        this.modules.set(key, moduleDef);
        return moduleDef;
      },
      get(name) { return this.modules.get(String(name || '').trim()) || null; },
      has(name) { return this.modules.has(String(name || '').trim()); },
      list() { return Array.from(this.modules.keys()); },
      on(hookName, handler) {
        if (!this.hooks[hookName]) this.hooks[hookName] = [];
        if (typeof handler === 'function') this.hooks[hookName].push(handler);
        return handler;
      },
      async run(hookName, context) {
        const queue = this.hooks[hookName] || [];
        for (const handler of queue) {
          try {
            await handler(context);
          } catch (err) {
            console.warn(`[split-bridge] hook ${hookName} failed:`, err?.message || err);
          }
        }
      },
      markReady(context) {
        this.ready = true;
        this.context = context || this.context;
        try {
          window.dispatchEvent(new CustomEvent(`${APP_CONFIG.eventPrefix}:ready`, {
            detail: {
              version: APP_CONFIG.version,
              modules: this.list()
            }
          }));
        } catch (err) {
          console.warn('[split-bridge] ready event failed:', err?.message || err);
        }
      },
      whenReady(handler) {
        if (typeof handler !== 'function') return;
        if (this.ready && this.context) {
          handler(this.context);
          return;
        }
        const onceHandler = () => {
          window.removeEventListener(`${APP_CONFIG.eventPrefix}:ready`, onceHandler);
          handler(this.context);
        };
        window.addEventListener(`${APP_CONFIG.eventPrefix}:ready`, onceHandler);
      }
    };

initializeState({ buildTag: BUILD_TAG, projectId: firebaseConfig.projectId });

    // ==========================================
    // 【全新升級】：拔除所有原生 alert 與 confirm，自建全域防護模組
    // ==========================================
    const UI = Object.assign(baseUI, {
      show(id) { 
        const el = document.getElementById(id);
        if (el) el.classList.remove('hidden'); 
      },
      hide(id) { 
        const el = document.getElementById(id);
        if (el) el.classList.add('hidden'); 
      },
      showModal(id) { 
        this.show(id);
      },
      hideModal(id) { const el = document.getElementById(id); if (el) el.style.display = ''; this.hide(id); },
      toast(msg) {
        const t = document.getElementById('toast');
        if(!t) return;
        t.innerText = msg; t.style.opacity = 1;
        setTimeout(() => t.style.opacity = 0, 3000);
      },
      alert(msg, title = "系統通知") {
        const t = document.getElementById('sysAlertTitle');
        const m = document.getElementById('sysAlertMsg');
        if(t && m) {
          t.innerText = title; m.innerText = msg;
          this.showModal('sysAlertModal');
        } else {
          console.error("UI.alert Failed:", msg);
        }
      },
      confirm(msg, title = "請再次確認") {
        return new Promise((resolve) => {
          const t = document.getElementById('sysConfirmTitle');
          const m = document.getElementById('sysConfirmMsg');
          const confirmBtn = document.getElementById('sysConfirmBtn');
          const cancelBtn = document.getElementById('sysCancelBtn');
          
          if(t && m && confirmBtn && cancelBtn) {
            t.innerText = title; m.innerText = msg;
            
            const handleConfirm = () => { cleanup(); resolve(true); };
            const handleCancel = () => { cleanup(); resolve(false); };
            
            const cleanup = () => {
              confirmBtn.removeEventListener('click', handleConfirm);
              cancelBtn.removeEventListener('click', handleCancel);
              this.hideModal('sysConfirmModal');
            };
            
            confirmBtn.addEventListener('click', handleConfirm);
            cancelBtn.addEventListener('click', handleCancel);
            
            this.showModal('sysConfirmModal');
          } else {
            resolve(false);
          }
        });
      },
      showImageModal(src, titleText) {
        const imgEl = document.getElementById('enlargedImg');
        const titleEl = document.getElementById('enlargedTitle');
        if (!imgEl || !titleEl) {
          UI.toast('圖片預覽元件不存在');
          return;
        }
        imgEl.src = src;
        titleEl.innerText = titleText;
        this.showModal('imageModal');
      },
      showArchiveModal(index) {
        const item = currentState.studentData.collection[index];
        currentState.archiveIndex = index;
        const titleEl = document.getElementById('archiveTitle');
        const imgEl = document.getElementById('archiveImg');
        const holoText = document.getElementById('archiveHoloText');
        const primaryBtn = document.getElementById('archivePrimaryActionBtn');
        holoText.classList.add('hidden');
        if (primaryBtn) {
          primaryBtn.classList.add('hidden');
          primaryBtn.innerText = '設為目前孵化中的蛋';
        }

        const isUnsafeUrl = (u) => {
          const s = String(u || '');
          if (!s) return false;
          if (s.startsWith('data:')) return false;
          if (!/^https?:\/\//i.test(s)) return false;
          return !/firebasestorage\.googleapis\.com\/v0\/b\//i.test(s);
        };
        const safeImg = (u) => (isUnsafeUrl(u) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (u || CONSTANTS.MEDIA.PLACEHOLDER_SVG));

        if (item.type === 'legendary') {
          const disp = buildCollectionDisplayItem(item, currentState.studentData);
          titleEl.innerText = isCatProfile(currentState.studentData) ? `[ 特殊救援夥伴 ]` : `[ 異獸夥伴・${item.name || '稀有異獸'} ]`;
          titleEl.style.color = 'var(--legendary-gold)';
          imgEl.src = (buildCollectionDisplayItem(item, currentState.studentData)?.img) || safeImg(item.img);
          imgEl.style.filter = `drop-shadow(0 0 30px var(--legendary-gold))`;
          this.renderRadarChartRaw({metal:100, wood:100, water:100, fire:100, earth:100}, 'archiveRadarChart', 'archive', 'rgba(255,183,0,1)', 'rgba(255,183,0,0.2)');
        }
        else if (item.type === 'dead_dragon') {
          const causeName = getProfileDebuffInfo(item.cause, currentState.studentData)?.name || '未知異常';
          titleEl.innerText = isCatProfile(currentState.studentData) ? `[ 照護紀錄 - ${causeName} ]` : `[ 死亡紀錄 - 死於${causeName} ]`;
          titleEl.style.color = 'var(--danger)';
          imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          imgEl.style.filter = `brightness(0.9) opacity(0.65) drop-shadow(0 0 20px var(--danger))`;
          this.renderRadarChartRaw(item.stats || {metal:0,wood:0,water:0,fire:0,earth:0}, 'archiveRadarChart', 'archive', 'rgba(255,0,85,1)', 'rgba(255,0,85,0.2)');
        }
        else if (item.type === 'dragon') {
          const info = getProfileAttributeInfo(item.element, currentState.studentData) || { icon:'❓', name:'?', color:'var(--cyan)' };
          titleEl.innerText = isCatProfile(currentState.studentData) ? `[ ${buildCollectionDisplayItem(item, currentState.studentData)?.title || '貓咪夥伴'} ]` : `[ ${item.name || '龍獸'} - 成長結算能量 ]`;
          titleEl.style.color = info.color;
          if (isCatProfile(currentState.studentData)) {
            imgEl.src = (buildCollectionDisplayItem(item, currentState.studentData)?.img) || safeImg(item.img);
            imgEl.style.filter = `drop-shadow(0 0 30px ${info.color})`;
          } else if (item.img_file) {
            setImgFromFileBaseName(imgEl, item.img_file, { shadowColor: info.color });
          } else {
            imgEl.src = safeImg(item.img);
            imgEl.style.filter = `drop-shadow(0 0 30px ${info.color})`;
          }
          this.renderRadarChartRaw(item.stats || {metal:0,wood:0,water:0,fire:0,earth:0}, 'archiveRadarChart', 'archive', info.color, 'rgba(255,255,255,0.1)');
        }
        else if (item.type === 'hidden_egg') {
          const eggMeta = CONSTANTS.HIDDEN_EGGS[item.hiddenEggId || item.id] || item;
          const isActiveEgg = String(currentState.studentData?.active_hidden_egg_id || '') === String(item.hiddenEggId || item.id || '');
          titleEl.innerText = `[ ${eggMeta.name || '特殊異獸蛋'} ]`;
          titleEl.style.color = 'var(--color-water)';
          imgEl.src = (eggMeta.forms && eggMeta.forms.egg) || safeImg(item.img || eggMeta.img);
          imgEl.style.filter = `drop-shadow(0 0 28px var(--color-water))`;
          this.renderRadarChartRaw(item.stats || currentState.studentData?.attributes || {metal:0,wood:0,water:0,fire:0,earth:0}, 'archiveRadarChart', 'archive', 'rgba(0,180,255,1)', 'rgba(0,180,255,0.18)');
          if (primaryBtn) {
            primaryBtn.classList.remove('hidden');
            primaryBtn.innerText = isActiveEgg ? '目前已是這顆蛋' : '設為目前孵化中的蛋';
            primaryBtn.disabled = isActiveEgg;
            primaryBtn.style.opacity = isActiveEgg ? '0.6' : '1';
          }
        }
        else if (item.type === 'material') {
          const info = CONSTANTS.ATTRIBUTES[item.element] || { icon:'❓', name:'?', color:'var(--cyan)' };
          titleEl.innerText = isCatProfile(currentState.studentData) ? `[ ${buildCollectionDisplayItem(item, currentState.studentData)?.title || (info.name + '素材')} ]` : `[ 素材 - ${item.name || (info.name + '系素材')} ]`;
          titleEl.style.color = info.color;
          if (item.img_file) {
            setImgFromFileBaseName(imgEl, item.img_file, { shadowColor: info.color });
          } else {
            imgEl.src = safeImg(item.img);
            imgEl.style.filter = `drop-shadow(0 0 25px ${info.color})`;
          }
          this.renderRadarChartRaw(item.stats || {metal:0,wood:0,water:0,fire:0,earth:0}, 'archiveRadarChart', 'archive', info.color, 'rgba(255,255,255,0.08)');
        }
        else if (item.type === 'voucher') {
          const disp = buildCollectionDisplayItem(item, currentState.studentData);
          const active = item.status !== 'redeemed';
          titleEl.innerText = `[ ${item.name || (active ? '兌換憑證' : '已兌現憑證')} ]`;
          titleEl.style.color = active ? 'var(--legendary-gold)' : 'var(--text-muted)';
          imgEl.src = (disp && disp.img) || safeImg(item.img);
          imgEl.style.filter = `drop-shadow(0 0 26px ${active ? 'var(--legendary-gold)' : 'rgba(255,255,255,0.35)'})`;
          this.renderRadarChartRaw(item.stats || currentState.studentData?.attributes || {metal:0,wood:0,water:0,fire:0,earth:0}, 'archiveRadarChart', 'archive', active ? 'rgba(255,183,0,1)' : 'rgba(180,180,180,1)', active ? 'rgba(255,183,0,0.12)' : 'rgba(255,255,255,0.08)');
          if (primaryBtn) {
            const isAdminView = !document.getElementById('adminView')?.classList.contains('hidden');
            primaryBtn.classList.remove('hidden');
            primaryBtn.innerText = active ? (isAdminView ? '老師兌現憑證' : '向老師出示憑證') : '此憑證已兌現';
            primaryBtn.disabled = !active || !isAdminView;
            primaryBtn.style.opacity = (!active || !isAdminView) ? '0.6' : '1';
            if (isAdminView && active) {
              primaryBtn.onclick = () => App.redeemCollectionVoucher(index);
            } else {
              primaryBtn.onclick = null;
            }
          }
        }
        else {
          // 舊版封存
          if (primaryBtn) {
            primaryBtn.classList.add('hidden');
            primaryBtn.disabled = false;
            primaryBtn.style.opacity = '1';
          }
          titleEl.innerText = `[ 舊版封存資料 ]`;
          titleEl.style.color = 'var(--text-muted)';
          imgEl.src = CONSTANTS.MEDIA.PLACEHOLDER_SVG;
          imgEl.style.filter = `drop-shadow(0 0 15px rgba(255,255,255,0.15))`;
          this.renderRadarChartRaw({metal:0, wood:0, water:0, fire:0, earth:0}, 'archiveRadarChart', 'archive', 'rgba(0,229,255,0.4)', 'rgba(0,229,255,0.08)');
        }

        this.showModal('archiveModal');
      },
      showStatusInfo(statusKey) {
        const info = getProfileDebuffInfo(statusKey, currentState.studentData);
        const titleEl = document.getElementById('statusDescTitle');
        const textEl = document.getElementById('statusDescText');
        if (!titleEl || !textEl) {
          UI.toast('狀態說明面板不存在');
          return;
        }
        titleEl.innerText = `[ 異常狀態：${info.name} ]`;
        titleEl.style.color = info.color;
        textEl.innerHTML = info.desc;
        this.showModal('statusDescModal');
      },
      showAttrInfo(attrKey) {
        const info = getProfileAttributeInfo(attrKey, currentState.studentData);
        const panelConfig = getActionPanelConfig(currentState.studentData);
        const actions = (panelConfig.actions && panelConfig.actions[attrKey]) || CONSTANTS.ACTION_LIST[attrKey] || [];
        const modalContent = document.querySelector('#attrInfoModal .modal-content');
        const title = document.getElementById('attrInfoTitle');
        const iconEl = document.getElementById('attrInfoIcon');
        const charEl = document.getElementById('attrInfoChar');
        const descEl = document.getElementById('attrInfoDesc');
        const list = document.getElementById('attrInfoList');
        if (!modalContent || !title || !iconEl || !charEl || !list) {
          UI.toast('屬性說明面板不存在');
          return;
        }
        modalContent.style.borderColor = info.color;
        modalContent.style.boxShadow = `0 0 25px ${info.color}66`;
        const isCat = isCatProfile(currentState.studentData);
        title.innerText = `[ ${info.name}｜${isCat ? '特質說明' : '五行學習指標'} ]`;
        title.style.color = info.color;
        iconEl.innerText = info.icon;
        charEl.innerText = `${isCat ? '代表特質' : '核心能力'}：${info.char || '—'}`;
        if (descEl) descEl.innerText = info.desc || '';
        list.innerHTML = '';
        actions.forEach(act => {
           list.innerHTML += `<li style="border-bottom: 1px dashed rgba(255,255,255,0.1); padding: 6px 0;"><span style="color:#ddd;">${act.desc}</span> <span style="color:${info.color}; font-family:'Orbitron'; float:right; font-weight:bold;">+${act.val}</span></li>`;
        });
        this.showModal('attrInfoModal');
      },
      showHackerAlert(data, diff) {
         currentState.hackerUid = data.uid;
         const nameEl = document.getElementById('haTargetName');
         const diffEl = document.getElementById('haXpDiff');
         if (!nameEl || !diffEl) {
           UI.toast('警示面板不存在');
           return;
         }
         nameEl.innerText = `${data.class_name} | ID:${data.seat_number} | ${data.name}`;
         diffEl.innerText = `+${diff}`;
         this.showModal('hackerAlertModal');
      },
      updateDailyQuestTimer() {
        const studentView = document.getElementById('studentView');
        if (!currentState.studentData || !studentView || studentView.classList.contains('hidden')) return;
        const lastTime = Number(currentState.studentData.last_practice_time) || 0;
        const btn = document.getElementById('stuDailyQuestBtn');
        const timerText = document.getElementById('stuDailyQuestTimer');
        if (!btn || !timerText) return;
        const labels = getProfileLabels(currentState.studentData);
        if (isSameNoonWindow(lastTime)) {
            btn.disabled = true;
            const remain = getNextNoonTimestamp(Date.now()) - Date.now();
            timerText.innerText = fillProfileTemplate(labels.dailyQuestCooldown, { countdown: formatCountdown(remain) });
            timerText.style.color = 'var(--danger)';
        } else {
            btn.disabled = false;
            timerText.innerText = labels.dailyQuestReady || `[ 狀態就緒 ] 每日修練已重置（每日中午 12:00）`;
            timerText.style.color = 'var(--color-grass)';
        }
      },
initActionGrid() {
  const grid = document.getElementById('actionGrid');
  const hintEl = document.getElementById('actionGridModeHint');
  if (!grid) return;
  const panelConfig = getActionPanelConfig(currentState.studentData);
  if (hintEl) {
    hintEl.innerHTML = `<span style="color:var(--legendary-gold); font-weight:bold;">${panelConfig.title}</span><br>${panelConfig.hint}`;
  }
  grid.innerHTML = '';
  for (const attr of CONSTANTS.ATTR_ORDER) {
    const data = (panelConfig.actions && panelConfig.actions[attr]) || CONSTANTS.ACTION_LIST[attr] || [];
    const info = getProfileAttributeInfo(attr, currentState.studentData);
    const focus = panelConfig.attrFocus?.[attr] || null;
    const heading = focus?.label ? `${info.icon} ${focus.label}` : `${info.icon} ${info.char}`;
    let html = `<div class="attr-card attr-${attr}"><h4 style="color:${info.color};">${heading}</h4>`;
    if (focus?.summary) {
      html += `<div style="font-size:0.78em; line-height:1.6; color:var(--text-muted); margin:-2px 0 10px;">${info.name}對應：${focus.summary}</div>`;
    }
    data.forEach(act => {
      const safeDesc = String(act.desc ?? '')
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      html += `<button type="button" class="action-btn" data-attr="${attr}" data-val="${act.val}" data-desc="${safeDesc}" onclick="App.prepareActionFromButton(this); return false;">
                  <span style="font-family:'Noto Sans TC';">${act.desc}</span> <span style="font-family:'Orbitron'; color:${info.color}">+${act.val}</span>
               </button>`;
    });
    html += `</div>`;
    grid.innerHTML += html;
  }
},
      updateDragonImage(data, imgElementId) { return studentApi.updateDragonImage.apply(this, arguments);; },
      updateCollectionGallery(data, galleryId) { return studentApi.updateCollectionGallery.apply(this, arguments);; },
      updateStudentAttributes(data, rowId) { return studentApi.updateStudentAttributes.apply(this, arguments);; },
      renderRadarChartRaw(statsObj, canvasId, instanceKey, borderColor, bgColor) { return studentApi.renderRadarChartRaw.apply(this, arguments);; },
      updateStatusContainer(data, containerId) { return studentApi.updateStatusContainer.apply(this, arguments);; },
      updatePanel(data, isStudentMode = false) { return studentApi.updatePanel.apply(this, arguments);; },
    });

    const App = {
      ndef: null,

      createModuleContext(extra = {}) {
        return {
          App: this,
          UI,
          DomBridge,
          ModuleBridge,
          currentState,
          batchState,
          quizSession,
          radarChartInstances,
          CONSTANTS,
          TYPE_INFO,
          CONTENT_PROFILES,
          APP_CONFIG,
          db,
          auth,
          storage,
          ...extra
        };
      },

      registerModule(name, moduleDef = {}) {
        return ModuleBridge.register(name, moduleDef);
      },

      onModuleHook(hookName, handler) {
        return ModuleBridge.on(hookName, handler);
      },

      getRegisteredModules() {
        return ModuleBridge.list();
      },

      // --- Auth helpers (P0: move admin login to Firebase Auth + Rules) ---
      async ensureStudentAuth() { return authApi.ensureStudentAuth.apply(this, arguments);; },
      async isCurrentUserAdmin() { return authApi.isCurrentUserAdmin.apply(this, arguments);; },
      renderAdminDiagnostics() { return authApi.renderAdminDiagnostics.apply(this, arguments);; },
      toggleAdminDiagPanel(forceOpen = null) {
        const wrap = document.getElementById('adminDiagInlineWrap');
        if (!wrap) return;
        const shouldOpen = forceOpen == null ? wrap.classList.contains('hidden') : Boolean(forceOpen);
        wrap.classList.toggle('hidden', !shouldOpen);
        if (shouldOpen) {
          this.renderAdminDiagnostics();
        }
      },

      async refreshAdminDiagnostics() {
        try {
          const ok = await this.isCurrentUserAdmin();
          currentState.isAdmin = ok;
          UI.toast(ok ? '管理員權限檢查：已通過' : '管理員權限檢查：未通過');
        } catch (e) {
          console.error('[auth] refreshAdminDiagnostics failed:', e);
          UI.alert(`重新檢查失敗：${e?.message || e}`, '診斷失敗');
        }
      },

      // --- Token helpers (方案三：base62 + hash + active=false) ---
      // --- Token helpers (方案三：base62 + hash + active=false) ---
      getTokenFromHash(hashStr = window.location.hash) {
        try {
          const h = String(hashStr || '').trim();
          if (!h) return null;
          const hs = h.startsWith('#') ? h.slice(1) : h;
          const qs = hs.startsWith('?') ? hs.slice(1) : hs;
          const sp = new URLSearchParams(qs);
          const t = sp.get('t');
          return t ? String(t).trim() : null;
        } catch (_) { return null; }
      },

      normalizeSerial(raw) {
        const digits = String(raw == null ? '' : raw).replace(/[^0-9]/g, '');
        if (!digits) return null;
        return digits.padStart(3, '0');
      },

      // UID 標準化：移除掃描槍常見的冒號/空白，統一大寫
      normalizeUid(raw) {
        return String(raw == null ? '' : raw).trim().toUpperCase().replace(/:/g, '').replace(/\s+/g, '');
      },

      
      validateEvolutionTree() {
        const paths = CONSTANTS.MEDIA?.DRAGON_PATHS || {};
        const missing = ELEMENT_KEYS.filter(k => !(paths[k] && Array.isArray(paths[k].stages) && paths[k].stages.length >= 3));
        if (missing.length) console.warn('[evolution-tree] 缺少完整進化路線:', missing);
        else console.info('[evolution-tree] 五行屬性進化路線已完整覆蓋。');
        return missing;
      },

      // --- Student access gate (Token required) ---
      lockStudentAccess(message) {
        currentState.currentTokenValidated = false;
        currentState.currentToken = null;
        currentState.currentUid = null;
        currentState.studentData = null;
        currentState.studentLocked = true;

        const overlay = document.getElementById('studentLockOverlay');
        const msgEl = document.getElementById('studentLockMsg');
        const panelEl = document.getElementById('studentLockPanel');
        const titleEl = document.getElementById('studentLockTitle');
        const msg = message || '請使用已註冊的 NFC 卡片進入學生面板。';
        const isInfo = /驗證中|讀取中|感應中|載入中/.test(msg);
        if (msgEl) msgEl.textContent = msg;
        if (panelEl) {
          panelEl.style.borderColor = isInfo ? 'var(--cyan)' : 'var(--danger)';
          panelEl.style.boxShadow = isInfo ? '0 0 26px rgba(0,229,255,0.22)' : '0 0 26px rgba(255,0,85,0.22)';
        }
        if (titleEl) {
          titleEl.textContent = isInfo ? 'CARD CHECKING' : '請先感應學生卡';
          titleEl.style.color = isInfo ? 'var(--cyan)' : 'var(--danger)';
        }
        if (overlay) overlay.classList.remove('hidden');
        this.resetSessionIdleTimer();
      },

      unlockStudentAccess() {
        currentState.studentLocked = false;
        const overlay = document.getElementById('studentLockOverlay');
        if (overlay) overlay.classList.add('hidden');
        this.resetSessionIdleTimer();
      },

      buildStudentUrlFromToken(token) {
        const t = encodeURIComponent(String(token || '').trim());
        return window.location.origin + window.location.pathname + "?view=student#t=" + t;
      },

      generateBase62Token(len = 16) {
        const alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        const n = Math.max(8, Math.min(32, Number(len) || 16));
        let out = "";
        try {
          const bytes = new Uint8Array(n);
          (crypto && crypto.getRandomValues) ? crypto.getRandomValues(bytes) : bytes.forEach((_, i) => bytes[i] = Math.floor(Math.random() * 256));
          for (let i = 0; i < n; i++) out += alphabet[bytes[i] % 62];
          return out;
        } catch (_) {
          for (let i = 0; i < n; i++) out += alphabet[Math.floor(Math.random() * 62)];
          return out;
        }
      },

      async resolveSerialFromToken(token, requireActive = true) {
        const tok = String(token || '').trim();
        if (!tok) return null;
        try {
          const tSnap = await getDoc(doc(db, TOKEN_COLLECTION, tok));
          if (!tSnap.exists()) return null;
          const d = tSnap.data() || {};
          if (requireActive && d.active === false) return null;
          return this.normalizeSerial(d.serial);
        } catch (e) {
          console.warn('[token] resolve failed:', e);
          return null;
        }
      },

      async getActiveTokenForSerial(serial) {
        const s = this.normalizeSerial(serial);
        if (!s) return null;

        // 先用目前畫面已知 token，避免只靠查詢 tag_tokens 才能同步。
        if (currentState.currentToken) {
          const curSerial = this.normalizeSerial(currentState.currentUid || currentState.studentData?.card_seq || currentState.studentData?.serial);
          if (curSerial && curSerial === s) return currentState.currentToken;
        }

        // 再看 students/{serial} 是否已記錄 active_token（可避開 tag_tokens 查詢失敗造成的不同步）。
        try {
          const sSnap = await getDoc(doc(db, COLLECTION_NAME, s));
          if (sSnap.exists()) {
            const sd = sSnap.data() || {};
            const hinted = String(sd.active_token || sd.page_token || sd.token || '').trim();
            if (hinted) return hinted;
          }
        } catch (e) {
          console.warn('[token] read student token hint failed:', e);
        }

        // 最後才查 tag_tokens。
        try {
          const q = query(collection(db, TOKEN_COLLECTION), where('serial', '==', s), where('active', '==', true), limit(1));
          const qs = await getDocs(q);
          if (qs && !qs.empty) return qs.docs[0].id;
        } catch (e) {
          console.warn('[token] active token query failed:', e);
        }
        return null;
      },

      dedupeLogs(logs = []) {
        const seen = new Set();
        return (Array.isArray(logs) ? logs : []).filter(item => {
          if (!item || typeof item !== 'object') return false;
          const key = `${Number(item.timestamp) || 0}|${String(item.action_type || '')}|${String(item.detail || '')}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        }).sort((a, b) => (Number(a.timestamp) || 0) - (Number(b.timestamp) || 0));
      },

      dedupeCollection(items = []) {
        const seen = new Set();
        return (Array.isArray(items) ? items : []).filter(item => {
          if (!item || typeof item !== 'object') return false;
          const key = `${String(item.type || '')}|${Number(item.timestamp) || 0}|${String(item.name || '')}|${String(item.path || item.element || item.requiredAttr || '')}|${String(item.id || item.hiddenEggId || '')}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        }).sort((a, b) => (Number(a.timestamp) || 0) - (Number(b.timestamp) || 0));
      },

      mergeStudentRecords(primary = {}, secondary = {}, serial = null) {
        const base = this.applyDataMigration(JSON.parse(JSON.stringify(primary || {})));
        const other = this.applyDataMigration(JSON.parse(JSON.stringify(secondary || {})));
        const merged = { ...other, ...base };
        const s = this.normalizeSerial(serial || base.card_seq || base.serial || other.card_seq || other.serial);

        merged.uid = base.uid || other.uid || null;
        merged.card_seq = s || base.card_seq || other.card_seq || null;
        merged.serial = s || base.serial || other.serial || null;
        merged.class_name = base.class_name || other.class_name || '';
        merged.name = base.name || other.name || '';
        merged.seat_number = base.seat_number || other.seat_number || '匿名';
        merged.totalXP = Math.max(Number(base.totalXP) || 0, Number(other.totalXP) || 0);
        merged.coins = Math.max(Number(base.coins) || 0, Number(other.coins) || 0);
        merged.lap = Math.max(Number(base.lap) || 1, Number(other.lap) || 1);
        merged.trainerRankIndex = Math.max(Number(base.trainerRankIndex) || 0, Number(other.trainerRankIndex) || 0);
        merged.best_rate = Math.min(Number(base.best_rate) || 99, Number(other.best_rate) || 99);
        if (!Number.isFinite(merged.best_rate) || merged.best_rate === 99) merged.best_rate = this.getRateFromRankIndex(merged.trainerRankIndex);
        merged.last_practice_time = Math.max(Number(base.last_practice_time) || 0, Number(other.last_practice_time) || 0);
        merged.last_battle_time = Math.max(Number(base.last_battle_time) || 0, Number(other.last_battle_time) || 0);
        merged.dragon_stage = Math.max(Number(base.dragon_stage) || -1, Number(other.dragon_stage) || -1);
        merged.dragon_path = base.dragon_path || other.dragon_path || null;
        const baseProfile = primary && primary.content_profile_id ? primary.content_profile_id : null;
        const otherProfile = secondary && secondary.content_profile_id ? secondary.content_profile_id : null;
        merged.content_profile_id = baseProfile || otherProfile || 'shanhai';
        merged.ui_variant = (primary && primary.ui_variant) || (secondary && secondary.ui_variant) || (merged.content_profile_id === 'cat' ? 'muslim_friendly' : 'default');
        merged.profile_flags = Object.assign({}, secondary?.profile_flags || {}, primary?.profile_flags || {});
        merged.attributes = {};
        merged.streaks = {};
        merged.attr_event_counts = {};
        merged.attribute_first_gain_order = { metal: null, wood: null, water: null, fire: null, earth: null };
        merged.debuffs = {};
        ELEMENT_KEYS.forEach(k => {
          merged.attributes[k] = Math.max(Number(base.attributes?.[k]) || 0, Number(other.attributes?.[k]) || 0);
          merged.streaks[k] = Math.max(Number(base.streaks?.[k]) || 0, Number(other.streaks?.[k]) || 0);
          merged.attr_event_counts[k] = Math.max(Number(base.attr_event_counts?.[k]) || 0, Number(other.attr_event_counts?.[k]) || 0);
          const orders = [Number(base.attribute_first_gain_order?.[k]), Number(other.attribute_first_gain_order?.[k])].filter(v => Number.isFinite(v) && v > 0);
          merged.attribute_first_gain_order[k] = orders.length ? Math.min(...orders) : null;
        });
        ['Poison','Frozen','Paralyzed','Confusion'].forEach(k => {
          merged.debuffs[k] = Math.max(Number(base.debuffs?.[k]) || 0, Number(other.debuffs?.[k]) || 0);
        });
        merged.debuffs_timestamp = Math.max(Number(base.debuffs_timestamp) || 0, Number(other.debuffs_timestamp) || 0) || null;
        merged.collection = this.dedupeCollection([...(other.collection || []), ...(base.collection || [])]);
        merged.logs = this.dedupeLogs([...(other.logs || []), ...(base.logs || [])]);
        merged.hidden_eggs = this.dedupeCollection([...(other.hidden_eggs || []), ...(base.hidden_eggs || [])]);
        merged.active_hidden_egg_id = base.active_hidden_egg_id || other.active_hidden_egg_id || '';
        merged.active_hidden_egg = base.active_hidden_egg || other.active_hidden_egg || null;
        if (!merged.active_hidden_egg && merged.active_hidden_egg_id) {
          merged.active_hidden_egg = merged.hidden_eggs.find(item => String(item.hiddenEggId || item.id || '') === String(merged.active_hidden_egg_id))
            || merged.collection.find(item => item && item.type === 'hidden_egg' && String(item.hiddenEggId || item.id || '') === String(merged.active_hidden_egg_id))
            || null;
        }
        ensureAttributeFirstGainOrder(merged);
        return this.applyDataMigration(merged);
      },

      async syncStudentMirrorForSerial(serial, preferredData = null) {
        const s = this.normalizeSerial(serial);
        if (!s) return preferredData ? this.applyDataMigration(preferredData) : null;
        const studentRef = doc(db, COLLECTION_NAME, s);
        const token = await this.getActiveTokenForSerial(s);
        let studentSnapData = preferredData ? this.applyDataMigration(JSON.parse(JSON.stringify(preferredData))) : null;
        if (!studentSnapData) {
          const snap = await getDoc(studentRef);
          if (!snap.exists()) return null;
          studentSnapData = this.applyDataMigration(JSON.parse(JSON.stringify(snap.data() || {})));
        }
        let pageData = null;
        if (token) {
          const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, token));
          if (pageSnap.exists()) pageData = pageSnap.data() || null;
        }
        const merged = this.mergeStudentRecords(studentSnapData, pageData || {}, s);
        if (token) {
          merged.active_token = token;
          merged.page_token = token;
        }
        await setDoc(studentRef, merged, { merge: true });
        if (token) await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...merged, card_seq: s, serial: s, active_token: token, page_token: token }, { merge: true });
        return merged;
      },

      getBuiltInShopItems() {
        const profile = getContentProfile(currentState.studentData);
        const alias = profile.builtInShop || {};
        return [
          { id: 'antidote', name: alias.antidote?.name || '💊 萬靈藥', desc: alias.antidote?.desc || '清除所有負面狀態', cost: 10, borderColor: 'var(--color-grass)', effectType: 'antidote', quantity: null, active: true, builtIn: true },
          { id: 'evo_stone', name: alias.evo_stone?.name || '✨ 各系進化石', desc: alias.evo_stone?.desc || '指定屬性直接 +30 XP', cost: 20, borderColor: 'var(--color-fire)', effectType: 'evo_stone', quantity: null, active: true, builtIn: true },
          { id: 'wonder_stone', name: alias.wonder_stone?.name || '🌟 進化奇石', desc: alias.wonder_stone?.desc || '指定屬性素材 +1', cost: 50, borderColor: 'var(--color-fairy)', effectType: 'wonder_stone', quantity: null, active: true, builtIn: true },
          { id: 'azure_kirin_egg', name: '🌊 碧瀾麒麟蛋', desc: '水屬性隱藏異獸蛋；沿用原本經驗累積與進化節奏，最終可轉化為碧瀾麒麟（★100）', cost: 100, borderColor: 'var(--color-water)', effectType: 'hidden_egg', hiddenEggId: 'azure_kirin', quantity: null, active: true, builtIn: true },
          { id: 'marshmallow_physical', name: '🍡 烤棉花糖(實體)', desc: '需在老師面前購買才能獲得（否則不算數）', cost: 50, borderColor: 'var(--color-electric)', effectType: 'physical_reward', quantity: null, active: true, builtIn: true }
        ];
      },

      getShopEffectLabel(effectType) {
        const alias = (getContentProfile(currentState.studentData).builtInShop || {});
        const map = { antidote: alias.antidote?.name || '萬靈藥', evo_stone: alias.evo_stone?.name || '進化石', wonder_stone: alias.wonder_stone?.name || '進化奇石', physical_reward: '實體兌換品', hidden_egg: alias.hidden_egg?.name || '特殊異獸蛋' };
        return map[effectType] || effectType || '自訂商品';
      },

      getShopButtonHtml(item) {
        const cost = Number(item.cost) || 0;
        const qty = (item.quantity === null || item.quantity === undefined || item.quantity === '') ? null : Math.max(0, Number(item.quantity) || 0);
        const soldOut = qty !== null && qty <= 0;
        const inactive = item.active === false;
        const borderColor = (soldOut || inactive) ? '#666' : (item.borderColor || 'var(--color-electric)');
        const extra = item.effectType === 'hidden_egg' && item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId]
          ? `<br/><span style="font-size:0.68em; color:var(--legendary-gold); font-family:'Noto Sans TC';">${CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].desc}</span>`
          : '';
        const statusLabel = inactive ? '未上架' : (qty === null ? '不限量' : (soldOut ? '售罄' : `剩餘 ${qty}`));
        const statusColor = inactive ? 'var(--text-muted)' : (soldOut ? '#999' : (item.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--cyan)'));
        return `<button class="btn shop-item" onclick="App.handleShopPurchase('${item.id}', ${cost}, ${item.builtIn ? 'true' : 'false'})" ${soldOut || inactive ? 'disabled' : ''} style="text-align:left; border-color:${borderColor}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.55' : '1'};">
          ${String(item.name || '未命名商品')} (${cost} 🪙)<br/><span style="font-size:0.7em; color:${soldOut || inactive ? '#999' : 'var(--text-muted)'}; font-family:'Noto Sans TC';">${String(item.desc || '—')}</span>${extra}
          <div class="tech-font" style="margin-top:6px; font-size:0.72em; color:${statusColor};">${statusLabel}</div>
        </button>`;
      },

      async renderShopItems() {
        const container = document.getElementById('shopItemsContainer');
        if (!container) return;
        let items = this.getBuiltInShopItems();
        try {
          const snap = await getDocs(collection(db, SHOP_COLLECTION));
          snap.forEach(d => {
            const data = d.data() || {};
            items.push({ id: d.id, builtIn: false, name: data.name || '未命名商品', desc: data.desc || '', cost: Number(data.cost) || 0, quantity: data.quantity ?? 0, active: data.active !== false, effectType: data.effectType || 'physical_reward', hiddenEggId: data.hiddenEggId || '', borderColor: data.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--color-electric)' });
          });
        } catch (e) {
          console.warn('[shop] load catalog failed:', e);
        }
        items = items.filter(item => item.builtIn || item.active !== false);
        items.sort((a, b) => {
          const aq = (a.quantity === null || a.quantity === undefined || a.quantity === '') ? Infinity : Number(a.quantity);
          const bq = (b.quantity === null || b.quantity === undefined || b.quantity === '') ? Infinity : Number(b.quantity);
          const aSold = Number.isFinite(aq) && aq <= 0 ? 1 : 0;
          const bSold = Number.isFinite(bq) && bq <= 0 ? 1 : 0;
          return aSold - bSold || (Number(a.cost) || 0) - (Number(b.cost) || 0);
        });
        container.innerHTML = items.map(item => this.getShopButtonHtml(item)).join('') || `<div style="color:var(--text-muted); text-align:center;">目前沒有上架商品</div>`;
      },

      populateHiddenEggSelect() {
        const sel = document.getElementById('shopAdminHiddenEgg');
        if (!sel) return;
        const current = sel.value;
        sel.innerHTML = `<option value="">— 非異獸蛋商品可忽略 —</option>` + Object.values(CONSTANTS.HIDDEN_EGGS).map(item => `<option value="${item.id}">${item.name} / ${CONSTANTS.ATTRIBUTES[item.requiredAttr]?.name || item.requiredAttr} / ★${item.points}</option>`).join('');
        if (current) sel.value = current;
      },

      updateShopAdminFormState() {
        const effect = document.getElementById('shopAdminEffect');
        const egg = document.getElementById('shopAdminHiddenEgg');
        const hint = document.getElementById('shopAdminHint');
        const qty = document.getElementById('shopAdminQty');
        const isHiddenEgg = effect && effect.value === 'hidden_egg';
        if (egg) {
          egg.disabled = !isHiddenEgg;
          egg.style.opacity = isHiddenEgg ? '1' : '0.6';
        }
        if (qty && !qty.value && !currentState.editingShopProductId) qty.value = '1';
        if (hint) {
          hint.textContent = isHiddenEgg
            ? '特殊異獸蛋已實裝；請選擇蛋種，並填入可販售數量。學生購買後會先進入孵化紀錄，完成養成才會轉成隱藏積分。'
            : '一般商品可直接上架。若數量設為 0，學生商店會顯示灰色「售罄」。';
        }
      },

      resetShopAdminForm() {
        ['shopAdminName','shopAdminCost','shopAdminDesc'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
        const qtyEl = document.getElementById('shopAdminQty'); if (qtyEl) qtyEl.value = '1';
        const effect = document.getElementById('shopAdminEffect');
        if (effect) effect.value = 'antidote';
        const active = document.getElementById('shopAdminActive');
        if (active) active.checked = true;
        const egg = document.getElementById('shopAdminHiddenEgg');
        if (egg) egg.value = '';
        currentState.editingShopProductId = null;
        this.updateShopAdminFormState();
      },

      resetShopGiftForm() {
        const seq = document.getElementById('shopGiftTargetSeq'); if (seq) seq.value = '';
        const note = document.getElementById('shopGiftNote'); if (note) note.value = '';
        const attr = document.getElementById('shopGiftAttrSelect'); if (attr) attr.value = 'metal';
        const info = document.getElementById('shopGiftTargetInfo');
        if (info) info.innerHTML = '請先輸入卡序，確認要送禮的學生。';
      },

      setShopAdminTab(tab = 'catalog') {
        currentState.shopAdminTab = tab;
        const catalogPane = document.getElementById('shopAdminCatalogPane');
        const giftPane = document.getElementById('shopAdminGiftPane');
        const btnCatalog = document.getElementById('shopAdminTabBtnCatalog');
        const btnGift = document.getElementById('shopAdminTabBtnGift');
        if (catalogPane) catalogPane.classList.toggle('hidden', tab !== 'catalog');
        if (giftPane) giftPane.classList.toggle('hidden', tab !== 'gift');
        if (btnCatalog) {
          btnCatalog.classList.toggle('btn-solid', tab === 'catalog');
          btnCatalog.style.background = tab === 'catalog' ? 'var(--legendary-gold)' : 'transparent';
          btnCatalog.style.color = tab === 'catalog' ? '#000' : 'var(--legendary-gold)';
          btnCatalog.style.borderColor = 'var(--legendary-gold)';
        }
        if (btnGift) {
          btnGift.classList.toggle('btn-solid', tab === 'gift');
          btnGift.style.background = tab === 'gift' ? 'var(--cyan)' : 'transparent';
          btnGift.style.color = tab === 'gift' ? '#041018' : 'var(--cyan)';
          btnGift.style.borderColor = 'var(--cyan)';
        }
      },

      getAdminGiftableShopItems() {
        const builtIns = this.getBuiltInShopItems().map(item => ({ ...item, sourceId: `builtin:${item.id}` }));
        return builtIns;
      },

      async loadShopGiftOptions(preferredId = '') {
        const sel = document.getElementById('shopGiftItemSelect');
        const list = document.getElementById('shopGiftCatalogList');
        if (!sel || !list) return;
        sel.innerHTML = '<option value="">載入中...</option>';
        list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>';
        let items = this.getAdminGiftableShopItems();
        try {
          const snap = await getDocs(collection(db, SHOP_COLLECTION));
          snap.forEach(d => {
            const row = d.data() || {};
            items.push({ id: d.id, sourceId: d.id, builtIn: false, name: row.name || '未命名商品', desc: row.desc || '', cost: Number(row.cost) || 0, quantity: Math.max(0, Number(row.quantity) || 0), active: row.active !== false, effectType: row.effectType || 'physical_reward', hiddenEggId: row.hiddenEggId || '', borderColor: row.effectType === 'hidden_egg' ? 'var(--legendary-gold)' : 'var(--color-electric)' });
          });
        } catch (e) {
          console.warn('[shop gift] load options failed:', e);
        }
        items.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
        const optionHtml = ['<option value="">請選擇要贈送的物品</option>'].concat(items.map(item => {
          const qtyText = item.builtIn ? '內建' : `庫存 ${Math.max(0, Number(item.quantity) || 0)}`;
          const stateText = item.builtIn ? '老師直接發放' : (item.active === false ? '未上架' : ((Number(item.quantity) || 0) <= 0 ? '售罄' : '可贈送'));
          return `<option value="${item.sourceId}">${String(item.name || '未命名商品')}｜${this.getShopEffectLabel(item.effectType)}｜${qtyText}｜${stateText}</option>`;
        }));
        sel.innerHTML = optionHtml.join('');
        if (preferredId) sel.value = preferredId;
        list.innerHTML = items.map(item => {
          const soldOut = !item.builtIn && (Math.max(0, Number(item.quantity) || 0) <= 0);
          const inactive = !item.builtIn && item.active === false;
          const border = soldOut || inactive ? '#666' : (item.borderColor || 'var(--cyan)');
          const state = item.builtIn ? '內建商品 / 老師可直接贈送' : `${inactive ? '未上架' : (soldOut ? '售罄' : '可贈送')} / 庫存 ${Math.max(0, Number(item.quantity) || 0)}`;
          return `<button class="btn" onclick="App.pickShopGiftItem('${item.sourceId}')" style="text-align:left; border-color:${border}; color:${soldOut || inactive ? '#999' : '#fff'}; opacity:${soldOut || inactive ? '0.62' : '1'};">
            <div style="font-weight:bold; color:${soldOut || inactive ? '#bbb' : 'var(--legendary-gold)'}; font-family:'Noto Sans TC';">${String(item.name || '未命名商品')}</div>
            <div style="font-size:0.76em; color:${soldOut || inactive ? '#999' : '#ccc'}; margin-top:4px; font-family:'Noto Sans TC';">${this.getShopEffectLabel(item.effectType)} / ${state}</div>
            <div style="font-size:0.72em; color:var(--text-muted); margin-top:4px; font-family:'Noto Sans TC';">${String(item.desc || '—')}</div>
          </button>`;
        }).join('') || '<div style="color:var(--text-muted); text-align:center;">目前沒有可贈送的商品</div>';
      },

      pickShopGiftItem(sourceId) {
        const sel = document.getElementById('shopGiftItemSelect');
        if (sel) sel.value = sourceId;
        UI.toast('已選擇贈禮物品');
      },

      fillShopGiftCurrentStudent() {
        const serial = this.normalizeSerial(currentState.studentData?.card_seq || currentState.studentData?.serial || currentState.currentUid);
        const input = document.getElementById('shopGiftTargetSeq');
        if (!serial || !input) { UI.toast('目前尚未載入學生資料'); return; }
        input.value = serial;
        this.lookupShopGiftTarget();
      },

      async lookupShopGiftTarget() {
        const input = document.getElementById('shopGiftTargetSeq');
        const info = document.getElementById('shopGiftTargetInfo');
        const serial = this.normalizeSerial(input?.value || '');
        if (!serial) {
          if (info) info.innerHTML = '<span style="color:var(--danger);">請先輸入正確卡序。</span>';
          return;
        }
        if (info) info.innerHTML = '查詢中...';
        try {
          const snap = await getDoc(doc(db, COLLECTION_NAME, serial));
          if (!snap.exists()) {
            if (info) info.innerHTML = `<span style="color:var(--danger);">查無卡序 ${serial}，請先確認學生資料已建檔。</span>`;
            return;
          }
          const d = this.applyDataMigration(JSON.parse(JSON.stringify(snap.data() || {})));
          const profileName = isCatProfile(d) ? '貓咪版' : '山海版';
          if (info) info.innerHTML = `<div style="color:var(--legendary-gold); font-weight:bold;">${d.name || '未命名學生'}｜卡序 ${serial}</div><div style="margin-top:4px; color:#ddd;">${d.class_name || '未分班'} / ${profileName} / 總能量 ${Number(d.totalXP) || 0} / 金幣 ${Number(d.coins) || 0}</div>`;
        } catch (e) {
          console.error(e);
          if (info) info.innerHTML = '<span style="color:var(--danger);">查詢失敗，請稍後再試。</span>';
        }
      },

      async getShopGiftItemMeta(sourceId) {
        if (!sourceId) return null;
        if (sourceId.startsWith('builtin:')) {
          const builtId = sourceId.split(':')[1] || '';
          const item = this.getBuiltInShopItems().find(x => x.id === builtId);
          return item ? { ...item, sourceId, builtIn: true } : null;
        }
        const snap = await getDoc(doc(db, SHOP_COLLECTION, sourceId));
        if (!snap.exists()) return null;
        const d = snap.data() || {};
        return { id: sourceId, sourceId, builtIn: false, ...d, cost: Number(d.cost) || 0, quantity: Math.max(0, Number(d.quantity) || 0), active: d.active !== false };
      },

      async applyAdminGiftEffect(data, itemMeta, targetSerial, selectedAttr = 'metal', note = '') {
        const next = this.applyDataMigration(JSON.parse(JSON.stringify(data || {})));
        next.logs = Array.isArray(next.logs) ? next.logs : [];
        next.collection = Array.isArray(next.collection) ? next.collection : [];
        next.hidden_eggs = Array.isArray(next.hidden_eggs) ? next.hidden_eggs : [];
        const attr = ['metal','wood','water','fire','earth'].includes(selectedAttr) ? selectedAttr : (getDominantElementFromData(next) || 'metal');
        const noteSuffix = note ? ` / 備註：${note}` : '';

        if (itemMeta.effectType === 'physical_reward') {
          next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '實體兌換品'} 已指定發送${noteSuffix}` });
          await this.saveToDB(next, targetSerial);
          return { applied: true };
        }
        if (itemMeta.effectType === 'antidote') {
          next.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
          next.debuffs_timestamp = null;
          next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '萬靈藥'}，已清除異常狀態${noteSuffix}` });
          await this.saveToDB(next, targetSerial);
          return { applied: true };
        }
        if (itemMeta.effectType === 'evo_stone') {
          next.totalXP = Number(next.totalXP) || 0;
          next.totalXP += 30;
          addAttributeXP(next, attr, 30);
          const evolved = this.processEvolution(next);
          evolved.logs = Array.isArray(evolved.logs) ? evolved.logs : [];
          evolved.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化石'}（${CONSTANTS.ATTRIBUTES[attr]?.name || attr} +30 XP）${noteSuffix}` });
          await this.saveToDB(evolved, targetSerial);
          return { applied: true };
        }
        if (itemMeta.effectType === 'wonder_stone') {
          next.collection.push({ type: 'material', element: attr, name: `${CONSTANTS.ATTRIBUTES[attr]?.name || attr}系素材`, img: CONSTANTS.MEDIA.PLACEHOLDER_SVG, stats: { ...(next.attributes || {}) }, timestamp: Date.now() });
          next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '進化奇石'}（${CONSTANTS.ATTRIBUTES[attr]?.name || attr}系素材）${noteSuffix}` });
          await this.saveToDB(next, targetSerial);
          return { applied: true };
        }
        if (itemMeta.effectType === 'hidden_egg') {
          const eggMeta = CONSTANTS.HIDDEN_EGGS[itemMeta.hiddenEggId || ''];
          if (!eggMeta) { UI.alert('此特殊異獸蛋尚未設定完成。', '商品設定錯誤'); return { applied: false }; }
          const eggRecord = { type: 'hidden_egg', id: `${eggMeta.id}_${Date.now()}`, hiddenEggId: eggMeta.id, name: eggMeta.name, beastName: eggMeta.beastName || '', img: eggMeta.img, forms: eggMeta.forms || null, requiredAttr: eggMeta.requiredAttr, points: eggMeta.points, status: 'incubating', stats: { ...(next.attributes || {}) }, timestamp: Date.now() };
          next.hidden_eggs.push(eggRecord);
          next.collection.push({ ...eggRecord });
          if (!String(next.active_hidden_egg_id || '').trim()) {
            next.active_hidden_egg_id = eggMeta.id;
            next.active_hidden_egg = { ...eggRecord, status: 'active', activatedAt: Date.now() };
          }
          next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${eggMeta.name}（需求屬性：${CONSTANTS.ATTRIBUTES[eggMeta.requiredAttr]?.name || eggMeta.requiredAttr}）${noteSuffix}` });
          await this.saveToDB(next, targetSerial);
          return { applied: true };
        }
        next.logs.push({ timestamp: Date.now(), action_type: 'shop_admin_gift', detail: `[教師贈禮] ${itemMeta.name || '商城物品'}${noteSuffix}` });
        await this.saveToDB(next, targetSerial);
        return { applied: true };
      },

      async sendShopGift() {
        const targetInput = document.getElementById('shopGiftTargetSeq');
        const itemSel = document.getElementById('shopGiftItemSelect');
        const attrSel = document.getElementById('shopGiftAttrSelect');
        const noteEl = document.getElementById('shopGiftNote');
        const targetSerial = this.normalizeSerial(targetInput?.value || '');
        const sourceId = itemSel?.value || '';
        const selectedAttr = attrSel?.value || 'metal';
        const note = (noteEl?.value || '').trim();
        if (!targetSerial) { UI.toast('請先輸入指定卡序'); return; }
        if (!sourceId) { UI.toast('請先選擇要贈送的物品'); return; }
        try {
          const targetSnap = await getDoc(doc(db, COLLECTION_NAME, targetSerial));
          if (!targetSnap.exists()) { UI.alert('找不到指定卡序的學生資料。', '贈禮失敗'); return; }
          const itemMeta = await this.getShopGiftItemMeta(sourceId);
          if (!itemMeta) { UI.alert('找不到此商城物品，請重新整理後再試。', '贈禮失敗'); await this.loadShopGiftOptions(); return; }
          if (!itemMeta.builtIn) {
            if (itemMeta.active === false) { UI.alert('此商品目前未上架，請先確認是否仍要保留在商城。', '贈禮失敗'); return; }
            if ((Number(itemMeta.quantity) || 0) <= 0) { UI.alert('此商品目前已售罄。', '贈禮失敗'); await this.loadShopGiftOptions(sourceId); return; }
          }
          const targetData = this.applyDataMigration(JSON.parse(JSON.stringify(targetSnap.data() || {})));
          const ok = await UI.confirm(`確定要將「${itemMeta.name || '商城物品'}」送給 ${targetData.name || '這位學生'}（卡序 ${targetSerial}）嗎？`, '確認送出贈禮');
          if (!ok) return;
          const result = await this.applyAdminGiftEffect(targetData, itemMeta, targetSerial, selectedAttr, note);
          if (!result || !result.applied) return;
          if (!itemMeta.builtIn) {
            try {
              const itemRef = doc(db, SHOP_COLLECTION, sourceId);
              const latest = await getDoc(itemRef);
              if (latest.exists()) {
                const latestQ = Math.max(0, Number(latest.data().quantity) || 0);
                await updateDoc(itemRef, { quantity: Math.max(0, latestQ - 1), updatedAt: Date.now() });
              }
            } catch (e) {
              console.warn('[shop gift] quantity update failed:', e);
            }
          }
          await this.loadShopAdminList();
          await this.loadShopGiftOptions(sourceId);
          await this.renderShopItems();
          await this.lookupShopGiftTarget();
          UI.toast(`已送出：${itemMeta.name || '商城物品'}`);
        } catch (e) {
          console.error(e);
          UI.alert(`贈禮失敗：${e.message || e}`, '贈禮失敗');
        }
      },

      async openShopAdmin() {
        this.populateHiddenEggSelect();
        this.resetShopAdminForm();
        this.resetShopGiftForm();
        const effect = document.getElementById('shopAdminEffect');
        if (effect && !effect.dataset.boundChange) {
          effect.addEventListener('change', () => this.updateShopAdminFormState());
          effect.dataset.boundChange = '1';
        }
        await this.loadShopAdminList();
        await this.loadShopGiftOptions();
        this.updateShopAdminFormState();
        this.setShopAdminTab('catalog');
        UI.showModal('shopAdminModal');
      },

      async loadShopAdminList() {
        const list = document.getElementById('shopAdminList');
        if (!list) return;
        list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入中...</div>';
        try {
          const snap = await getDocs(collection(db, SHOP_COLLECTION));
          if (snap.empty) { list.innerHTML = '<div style="color:var(--text-muted); text-align:center;">目前沒有自訂商品。</div>'; return; }
          const rows = [];
          snap.forEach(d => rows.push({ id: d.id, ...(d.data() || {}) }));
          rows.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
          list.innerHTML = rows.map(item => {
            const soldOut = Math.max(0, Number(item.quantity) || 0) <= 0;
            const hiddenMeta = item.hiddenEggId && CONSTANTS.HIDDEN_EGGS[item.hiddenEggId] ? ` / ${CONSTANTS.HIDDEN_EGGS[item.hiddenEggId].name}` : '';
            return `<div style="background:rgba(0,0,0,0.45); border:1px solid ${soldOut ? '#666' : 'var(--legendary-gold)'}; border-radius:8px; padding:10px;">
              <div style="display:flex; justify-content:space-between; gap:10px; align-items:flex-start;">
                <div style="flex:1;">
                  <div style="color:${soldOut ? '#aaa' : 'var(--legendary-gold)'}; font-weight:bold; font-family:'Noto Sans TC';">${item.name || '未命名商品'}</div>
                  <div style="font-size:0.78em; color:#ccc; margin-top:4px; font-family:'Noto Sans TC';">${this.getShopEffectLabel(item.effectType)}${hiddenMeta} / ${Number(item.cost) || 0} 🪙 / 庫存 ${Math.max(0, Number(item.quantity) || 0)} / ${item.active === false ? '未上架' : (soldOut ? '售罄' : '上架中')}</div>
                  <div style="font-size:0.74em; color:var(--text-muted); margin-top:4px; font-family:'Noto Sans TC';">${item.desc || '—'}</div>
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
                  <button class="btn" onclick="App.pickShopGiftItem('${item.id}'); App.setShopAdminTab('gift')" style="padding:4px 8px; border-color:var(--legendary-gold); color:var(--legendary-gold);">贈送</button>
                  <button class="btn" onclick="App.editShopProduct('${item.id}')" style="padding:4px 8px; border-color:var(--cyan); color:var(--cyan);">編輯</button>
                  <button class="btn" onclick="App.deleteShopProduct('${item.id}')" style="padding:4px 8px; border-color:var(--danger); color:var(--danger);">刪除</button>
                </div>
              </div>
            </div>`;
          }).join('');
        } catch (e) {
          console.error(e);
          list.innerHTML = '<div style="color:var(--danger); text-align:center;">商品讀取失敗</div>';
        }
      },

      async editShopProduct(productId) {
        try {
          const snap = await getDoc(doc(db, SHOP_COLLECTION, productId));
          if (!snap.exists()) { UI.toast('商品不存在'); return; }
          const d = snap.data() || {};
          document.getElementById('shopAdminName').value = d.name || '';
          document.getElementById('shopAdminCost').value = Number(d.cost) || 0;
          document.getElementById('shopAdminDesc').value = d.desc || '';
          document.getElementById('shopAdminEffect').value = d.effectType || 'antidote';
          document.getElementById('shopAdminQty').value = Math.max(0, Number(d.quantity) || 0);
          document.getElementById('shopAdminHiddenEgg').value = d.hiddenEggId || '';
          document.getElementById('shopAdminActive').checked = d.active !== false;
          currentState.editingShopProductId = productId;
          this.updateShopAdminFormState();
          UI.showModal('shopAdminModal');
        } catch (e) {
          console.error(e);
          UI.toast('商品讀取失敗');
        }
      },

      async saveShopProduct() {
        const name = (document.getElementById('shopAdminName').value || '').trim();
        const cost = Math.max(0, Number(document.getElementById('shopAdminCost').value) || 0);
        const rawDesc = (document.getElementById('shopAdminDesc').value || '').trim();
        const effectType = document.getElementById('shopAdminEffect').value;
        const quantity = Math.max(0, Number(document.getElementById('shopAdminQty').value) || 0);
        const hiddenEggId = effectType === 'hidden_egg' ? (document.getElementById('shopAdminHiddenEgg').value || '') : '';
        const active = !!document.getElementById('shopAdminActive').checked;
        if (!name) { UI.toast('請輸入商品名稱'); return; }
        if (!currentState.editingShopProductId && quantity <= 0) { UI.toast('新增商品請填入數量（至少 1），否則會直接顯示為售罄'); return; }
        if (effectType === 'hidden_egg' && !hiddenEggId) { UI.toast('請選擇特殊異獸蛋'); return; }
        const eggMeta = effectType === 'hidden_egg' ? CONSTANTS.HIDDEN_EGGS[hiddenEggId || ''] : null;
        const desc = rawDesc || (eggMeta ? eggMeta.desc : '');
        const payload = { name, cost, desc, effectType, quantity, hiddenEggId, active, updatedAt: Date.now(), createdAt: Date.now() };
        try {
          if (currentState.editingShopProductId) {
            const ref = doc(db, SHOP_COLLECTION, currentState.editingShopProductId);
            const old = await getDoc(ref);
            payload.createdAt = old.exists() ? (old.data().createdAt || Date.now()) : Date.now();
            await setDoc(ref, payload, { merge: true });
          } else {
            const id = `custom_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
            await setDoc(doc(db, SHOP_COLLECTION, id), payload, { merge: false });
          }
          this.resetShopAdminForm();
          await this.loadShopAdminList();
          await this.renderShopItems();
          if (quantity <= 0) UI.alert(`商品已儲存：${name}
目前數量為 0，學生端會顯示為灰色「售罄」。`, '商品已儲存');
          else UI.toast(`商品已儲存：${name}`);
        } catch (e) {
          console.error(e);
          UI.toast(`商品儲存失敗：${e.message || e}`);
        }
      },

      async deleteShopProduct(productId) {
        const ok = await UI.confirm('確定要刪除此商品嗎？售出紀錄不會被刪除。', '刪除商品');
        if (!ok) return;
        try {
          await deleteDoc(doc(db, SHOP_COLLECTION, productId));
          if (currentState.editingShopProductId === productId) this.resetShopAdminForm();
          await this.loadShopAdminList();
          UI.toast('商品已刪除');
        } catch (e) {
          console.error(e);
          UI.toast('商品刪除失敗');
        }
      },

      resetGameplayState(data) {
        const next = this.applyDataMigration(JSON.parse(JSON.stringify(data || {})));
        next.totalXP = 0;
        next.coins = 0;
        next.last_practice_time = 0;
        next.last_battle_time = 0;
        next.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
        next.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
        next.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
        next.attribute_first_gain_order = { metal: null, wood: null, water: null, fire: null, earth: null };
        next.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
        next.debuffs_timestamp = null;
        next.dragon_stage = -1;
        next.dragon_path = null;
        next.collection = [];
        next.hidden_eggs = [];
        next.logs = [...(Array.isArray(next.logs) ? next.logs.slice(-20) : []), { timestamp: Date.now(), action_type: 'system', detail: '[批次調整] 遊戲進度已重置（保留 UID / TOKEN / 卡序 / 姓名）' }];
        next.trainerRankIndex = 0;
        next.best_rate = this.getRateFromRankIndex(next.trainerRankIndex || 0);
        return next;
      },

      openBulkProgressModal() {
        const result = document.getElementById('bulkProgressResult');
        if (result) result.innerText = '可批次調整年級、階級與遊戲進度，或只修復學生頁同步。';
        UI.showModal('bulkProgressModal');
      },

      getBulkSerialRange() {
        const start = this.normalizeSerial(document.getElementById('bulkStartSerial').value);
        const end = this.normalizeSerial(document.getElementById('bulkEndSerial').value);
        if (!start || !end) return null;
        return [start, end].sort();
      },

      async bulkRepairStudentPages() {
        const range = this.getBulkSerialRange();
        if (!range) { UI.toast('請輸入有效的起訖卡序'); return; }
        const [start, end] = range;
        const result = document.getElementById('bulkProgressResult');
        if (result) result.innerText = '修復同步中...';
        try {
          const snap = await getDocs(collection(db, COLLECTION_NAME));
          const targets = [];
          snap.forEach(d => {
            const sid = this.normalizeSerial(d.id);
            if (sid && sid >= start && sid <= end) targets.push(sid);
          });
          let repaired = 0;
          for (const sid of targets) {
            await this.syncStudentMirrorForSerial(sid);
            repaired += 1;
          }
          if (result) result.innerText = `已修復 ${repaired} 筆學生頁同步（卡序 ${start} ~ ${end}）。`;
          UI.toast(`已修復 ${repaired} 筆同步`);
        } catch (e) {
          console.error(e);
          if (result) result.innerText = `修復失敗：${e.message || e}`;
          UI.toast('修復失敗');
        }
      },

      async bulkUpdateProgressAndGrade() {
        const range = this.getBulkSerialRange();
        if (!range) { UI.toast('請輸入有效的起訖卡序'); return; }
        const [start, end] = range;
        const newGrade = document.getElementById('bulkGradeSelect').value || '';
        const newRank = document.getElementById('bulkRankSelect').value;
        const shouldReset = !!document.getElementById('bulkResetProgress').checked;
        const result = document.getElementById('bulkProgressResult');
        if (result) result.innerText = '批次更新中...';
        try {
          const snap = await getDocs(collection(db, COLLECTION_NAME));
          const docs = [];
          snap.forEach(d => {
            const sid = this.normalizeSerial(d.id);
            if (sid && sid >= start && sid <= end) docs.push({ id: sid, data: d.data() || {} });
          });
          let updated = 0;
          for (const row of docs) {
            let data = this.applyDataMigration(JSON.parse(JSON.stringify(row.data || {})));
            if (shouldReset) data = this.resetGameplayState(data);
            if (newGrade) data.class_name = newGrade;
            if (newRank !== '') data.trainerRankIndex = Number(newRank);
            data.best_rate = Math.min(Number(data.best_rate) || 99, this.getRateFromRankIndex(data.trainerRankIndex));
            data.logs = Array.isArray(data.logs) ? data.logs : [];
            data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: `[批次調整] 年級=${newGrade || '不變'} / 階級=${newRank === '' ? '不變' : (CONSTANTS.TRAINER_RANKS[Number(newRank)] || newRank)} / 進度重置=${shouldReset ? '是' : '否'}` });
            const merged = await this.syncStudentMirrorForSerial(row.id, data);
            if (currentState.currentUid && this.normalizeSerial(currentState.currentUid) === row.id) currentState.studentData = merged || data;
            updated += 1;
          }
          if (result) result.innerText = `已更新 ${updated} 筆資料（卡序 ${start} ~ ${end}）。`;
          UI.toast(`已更新 ${updated} 筆資料`);
        } catch (e) {
          console.error(e);
          if (result) result.innerText = `批次調整失敗：${e.message || e}`;
          UI.toast('批次調整失敗');
        }
      },
      async tryAutoEnterAdmin() { return authApi.tryAutoEnterAdmin.apply(this, arguments);; },
      async logoutAdmin() { return authApi.logoutAdmin.apply(this, arguments);; },
      bindSessionActivityWatchers() { return authApi.bindSessionActivityWatchers.apply(this, arguments);; },
      getSessionIdleMode() { return authApi.getSessionIdleMode.apply(this, arguments);; },
      async handleIdleTimeout(mode) { return authApi.handleIdleTimeout.apply(this, arguments);; },
      resetSessionIdleTimer() { return authApi.resetSessionIdleTimer.apply(this, arguments);; },
      async generateUniqueName() {
        const usedNames = new Set();
        try {
          const snapshot = await getDocs(collection(db, COLLECTION_NAME));
          snapshot.forEach(doc => {
            if (doc.data().name) usedNames.add(doc.data().name);
          });
        } catch (error) {
          console.warn("無法取得全校名單權限", error);
        }

        const codes = CONSTANTS.ANONYMOUS_CODES || ["星塵", "光年", "矩陣"]; 
        
        if (usedNames.size === 0) {
          const picked = codes[Math.floor(Math.random() * codes.length)];
          return `匿名學員-${picked}_${Math.floor(Math.random()*1000)}`;
        }

        const available = codes.filter(code => !usedNames.has(`匿名學員-${code}`));
        if (available.length === 0) return `匿名學員-極限_${Math.floor(Math.random()*1000)}`; 
        const picked = available[Math.floor(Math.random() * available.length)];
        return `匿名學員-${picked}`;
      },

      async studentRerollName() {
         let data = currentState.studentData;
         if (!data) return;

         const isFree = (data.free_rename_available === true);
         const cost = isFree ? 0 : 1;

         const currentCoins = Number(data.coins) || 0;
         if (cost > 0 && currentCoins < cost) { 
            UI.alert(`餘額不足！需要 ${cost} 🪙 才能改名喔。`, "操作失敗"); 
            return; 
         }

         const confirmMsg = cost === 0
           ? "首次改名免費！確定要重新抽取代號嗎？\n(舊代號將被釋放回系統)"
           : "確定要消耗 1 🪙 重新抽取代號嗎？\n(舊代號將被釋放回系統)";
         const isConfirmed = await UI.confirm(confirmMsg, "基因重組確認");
         if (!isConfirmed) return;

         this.executeStudentRename();
      },

      async executeStudentRename() {
         let data = JSON.parse(JSON.stringify(currentState.studentData));

         const isFree = (data.free_rename_available === true);
         const cost = isFree ? 0 : 1;
         if (cost > 0 && (Number(data.coins) || 0) < cost) return;

         try {
           UI.toast("⏳ 基因重組中，請稍候...");

           const codes = CONSTANTS.ANONYMOUS_CODES || ["星塵", "光年", "矩陣"];
           const picked = codes[Math.floor(Math.random() * codes.length)];
           const newName = `匿名學員-${picked}_${Math.floor(Math.random()*1000)}`;

           if (cost > 0) data.coins -= cost;
           data.name = newName;
           if (isFree) data.free_rename_available = false;
           data.logs.push({ timestamp: Date.now(), action_type: "system", detail: cost > 0 ? `[商城] 消耗 1 🪙 重新抽取代號：${newName}` : `[商城] 首次改名免費：${newName}` });

           const savedAfterRename = await this.saveToDB(data);
           const latest = this.applyDataMigration(JSON.parse(JSON.stringify(savedAfterRename || data)));
           currentState.studentData = latest;
           if (typeof this.refreshStudentIdentityLabels === 'function') this.refreshStudentIdentityLabels(latest);
           try { UI.updatePanel(latest, currentState.viewMode === 'student'); } catch (_) {}
           UI.toast(`✨ 改名成功！新代號為：${newName}`);
         } catch (error) {
           console.error("改名異常:", error);
           UI.alert("改名失敗，請檢查網路狀態或稍後再試。", "錯誤");
         }
      },

      async rollRegistrationName() {
        const display = document.getElementById('regRandomNameDisplay');
        display.innerText = "運算比對中...";
        const newName = await this.generateUniqueName();
        display.innerText = newName;
        currentState.tempRegName = newName;
        
        document.getElementById('submitRegAndWriteBtn').disabled = false;
        document.getElementById('submitRegBtn').disabled = false;
      },

      async registerNewStudent(autoWriteNfc = false) {
        const cGrade = document.getElementById('regGrade').value;
        const cName = currentState.tempRegName;
        const cSeqRaw = (document.getElementById('regCardSeq') && document.getElementById('regCardSeq').value) ? document.getElementById('regCardSeq').value.trim() : '';

        if(!cName) { UI.toast('請先點擊按鈕抽取代號！'); return; }
        if(!currentState.currentCardUid) { UI.toast('卡片 UID 遺失，請重新感應卡片。'); return; }
        if(!cSeqRaw) { UI.toast('請輸入卡序！'); return; }

        const cardSeqDigits = (cSeqRaw || '').replace(/[^0-9]/g, '');
        if(!cardSeqDigits) { UI.toast('卡序格式錯誤'); return; }
        const cardSeqStr = cardSeqDigits.padStart(3, '0');

        // 卡序作為主鍵：不可重複
        const seqRef = doc(db, COLLECTION_NAME, cardSeqStr);
        const seqSnap = await getDoc(seqRef);
        if (seqSnap.exists()) { UI.alert(`卡序 #${cardSeqStr} 已被使用，請確認是否輸入錯誤或改用補辦流程。`, '卡序衝突'); return; }

        // 同一張卡片（UID）不可重複註冊（僅供管理追蹤與補辦用）
        const cardRef = doc(db, 'cards', this.normalizeUid(currentState.currentCardUid));
        const cardSnap = await getDoc(cardRef);
        if (cardSnap.exists()) { UI.alert(`此卡片已綁定卡序 #${cardSnap.data().serial || cardSnap.data().card_seq || '未知'}` , '註冊衝突'); return; }

        const token = this.generateBase62Token(16);
        const newData = { uid: this.normalizeUid(currentState.currentCardUid), card_seq: cardSeqStr, class_name: cGrade, seat_number: "匿名", name: cName, totalXP: 0, coins: 0, free_rename_available: true, lap: 1, trainerRankIndex: 0, best_rate: 5, last_practice_time: 0, display_team: [], status: 'Healthy', status_timestamp: null, debuffs: { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 }, debuffs_timestamp: null, attributes: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, streaks: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, attr_event_counts: { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 }, attribute_first_gain_order: { metal: null, wood: null, water: null, fire: null, earth: null }, dragon_stage: -1, dragon_path: null, collection: [], logs: [{ timestamp: Date.now(), action_type: "registration", points_added: 0, detail: "匿名晶片初始化完成" }], content_profile_id: 'shanhai', ui_variant: 'default', profile_flags: { hide_fantasy: false, use_cat_theme: false, use_safe_random_label: false }, guide_mode: 'baize', guide_mode_locked: true, active_token: token, page_token: token };

        try { 
          await setDoc(seqRef, newData);
          await setDoc(cardRef, { serial: cardSeqStr, createdAt: Date.now(), active: true });
          await setDoc(doc(db, TOKEN_COLLECTION, token), { serial: cardSeqStr, active: true, issuedAt: Date.now(), issuedBy: (auth.currentUser ? auth.currentUser.uid : null) });
          await setDoc(seqRef, { active_token: token, page_token: token }, { merge: true });
          // 方案A：同步建立學生端資料（student_pages/{token}），學生端不再需要讀取 tag_tokens/students
          await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...newData, serial: cardSeqStr }, { merge: false });
          currentState.currentToken = token; 
          UI.hideModal('regModal'); 

          if (autoWriteNfc) {
              if (!('NDEFReader' in window)) {
                  UI.alert(`裝置不支援 Web NFC，已完成純資料綁定。(卡序 #${cardSeqStr})`, "通知");
              } else {
                  UI.toast("⏳ 請將卡片再次貼近手機背面以寫入網址...");
                  try {
                      if (this.stopWebNfc) this.stopWebNfc();
                      const ndef = new NDEFReader();
                      const stuUrl = this.buildStudentUrlFromToken(token);
                      await ndef.write({ records: [{ recordType: "url", data: stuUrl }] });
                      UI.toast(`✅ 綁定與專屬網址寫入完成！(卡序 #${cardSeqStr})`);
                  } catch (e) {
                      console.error(e);
                      UI.alert(`寫入 NFC 失敗，但資料已成功建檔。(卡序 #${cardSeqStr})\n您可事後於面板重新手動寫入。`, "寫入異常");
                  }
              }
          } else {
              UI.toast(`✅ 匿名初始化綁定成功！(卡序 #${cardSeqStr})`); 
          }

          this.enterScanMode('read'); 
          this.loadStudentData(cardSeqStr, 'admin'); 
        } catch (e) { 
          console.error(e); 
          const code = (e && e.code) ? String(e.code) : '';
          const msg = (e && e.message) ? String(e.message) : String(e);
          // Firestore: collection 會在「成功寫入第一筆 document」時自動出現
          // 所以這裡失敗最常見原因就是 rules 擋寫入（permission-denied）
          if (code === 'permission-denied' || /permission|insufficient/i.test(msg)) {
            UI.alert(
              `Firestore 權限不足（permission-denied）。

請檢查 Firestore Rules 是否允許寫入：
- ${COLLECTION_NAME}/{卡序}
- cards/{UID}
- ${TOKEN_COLLECTION}/{token}

原始錯誤：${msg}`,
              'DB WRITE FAILED'
            );
          } else {
            UI.alert(`資料寫入失敗：
${msg}`, 'DB WRITE FAILED');
          }
          UI.toast('DB WRITE FAILED'); 
        }
      },
      escapeBaizeText(text = '') {
        return String(text || '')
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
      },

      getCatGuideAvatar() {
        return 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FA%20Sagacious%20Cat_800x800.webp?alt=media&token=58e2a846-e249-4741-ac54-b8ad501e6d69&v=20260308';
      },

      getGuideMode(data = null) {
        const src = data || currentState.studentData || {};
        const query = new URLSearchParams(window.location.search);
        const qg = String(query.get('guide') || '').trim().toLowerCase();
        const explicitGuideMode = String(src?.guide_mode || src?.assistant_mode || '').trim().toLowerCase();
        const locked = src?.guide_mode_locked !== false;
        const contentProfileId = String(src?.content_profile_id || '').trim().toLowerCase();
        const uiVariant = String(src?.ui_variant || '').trim().toLowerCase();

        // 最高優先：網址明確指定 guide 角色（僅供測試/覆蓋）
        if (qg === 'cat' || qg === 'sage_cat') return 'cat';
        if (qg === 'baize' || qg === 'shanhai') return 'baize';

        // 真實來源：老師或資料庫明確寫入的 guide_mode
        if (explicitGuideMode === 'cat' || explicitGuideMode === 'sage_cat') return 'cat';
        if (explicitGuideMode === 'baize' || explicitGuideMode === 'shanhai') return 'baize';

        // 若未鎖定，才允許跟內容模式同步推論
        if (!locked) {
          if (contentProfileId === 'cat' || uiVariant === 'muslim_friendly') return 'cat';
          if (contentProfileId === 'shanhai' || uiVariant === 'default') return 'baize';
        }

        // 舊資料回補：優先看明確的內容模式，不再讀多個旗標猜測
        if (contentProfileId === 'cat' || uiVariant === 'muslim_friendly') return 'cat';
        if (contentProfileId === 'shanhai' || uiVariant === 'default') return 'baize';

        // 安全預設：沒有明確設定時，一律走智者貓咪
        return 'cat';
      },


      getBaizeGuideConfig(data = null) {
        const src = data || currentState.studentData || {};
        const flags = getProfileFlags(src);
        if (flags.hide_ai_guide === true || flags.hide_baize === true) {
          return { enabled: false };
        }
        const guideMode = this.getGuideMode(src);
        if (guideMode === 'cat') {
          return {
            enabled: true,
            key: 'cat',
            persona: 'cat',
            assistantName: '智者貓咪',
            sectionTitle: '🐾 智者貓咪',
            sectionDesc: '若你對照護、自然、科學或任務中的疑問有困惑，可向智者貓咪請教。牠只會一步步引導你思考，不會直接給答案。',
            buttonLabel: '請教智者貓咪',
            modalTitle: '🐾 智者貓咪',
            modalDesc: '智者貓咪會用溫和的方式陪你梳理想法，不直接給標準答案。若遇到重要問題，仍請再向老師確認。',
            suggestionText: '建議提問：例如「小貓為什麼喜歡追光點？」、「我這題卡住了，可以提醒我先想哪一步？」',
            placeholder: '請輸入你想請教智者貓咪的問題…',
            welcomeText: '嗨，年輕的照護員。我是智者貓咪。若你對自然、科學或任務卡關了，可以先告訴我你已經想到哪一步，我陪你慢慢整理。',
            statusWaiting: '[ 等待請教 ]',
            statusReady: '[ 可向智者貓咪請教 ]',
            statusThinking: '[ 智者貓咪正在整理鬍鬚與思路… ]',
            statusDone: '[ 智者貓咪已回應 ]',
            statusFail: '[ 智者貓咪去打盹了 ]',
            emptyToast: '請先輸入想請教智者貓咪的問題',
            overLimitAlert: '問題請控制在 300 字以內，讓智者貓咪更容易聚焦引導你。',
            unauthenticatedReply: '你目前尚未完成學生驗證，請重新感應學生卡後再請教智者貓咪。',
            notDeployedReply: '尚未部署 askBaize 後端函式，請先到 Firebase Functions 完成部署。',
            genericReply: '智者貓咪暫時沒有回應，請稍後再試。',
            avatarSrc: this.getCatGuideAvatar()
          };
        }
        return {
          enabled: true,
          key: 'baize',
          persona: 'baize',
          assistantName: '白澤',
          sectionTitle: '🦄 白澤',
          sectionDesc: '若你對自然、科學或任務中的疑問有困惑，可向白澤請示。白澤只會引導你思考，不會直接給答案。',
          buttonLabel: '請示白澤',
          modalTitle: '🦄 白澤靈諭',
          modalDesc: '白澤會以引導方式協助思考，不直接提供標準答案。若遇到重要問題，仍請再向老師確認。',
          suggestionText: '建議提問：例如「為什麼月亮會有圓缺？」、「我這題卡住了，可以提醒我先想哪一步？」',
          placeholder: '請輸入你想請示白澤的問題…',
          welcomeText: '年輕的守護員，吾乃白澤。若你對自然萬物、科學現象或任務關卡有所疑惑，可先說說你已經想到哪一步，吾再循序引你探究。',
          statusWaiting: '[ 等待請教 ]',
          statusReady: '[ 可向白澤請示 ]',
          statusThinking: '[ 白澤正在推演萬物之理… ]',
          statusDone: '[ 白澤已回應 ]',
          statusFail: '[ 白澤靈力不足 ]',
          emptyToast: '請先輸入想請示白澤的問題',
          overLimitAlert: '問題請控制在 300 字以內，讓白澤更容易聚焦引導你。',
          unauthenticatedReply: '你目前尚未完成學生驗證，請重新感應學生卡後再請示白澤。',
          notDeployedReply: '尚未部署 askBaize 後端函式，請先到 Firebase Functions 完成部署。',
          genericReply: '白澤暫時沒有回應，請稍後再試。',
          avatarSrc: 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBaize%2FBaize_800x800.webp?alt=media&token=e2a96804-1c49-4374-a83a-96d34c5b2e92&v=20260308'
        };
      },

      refreshBaizeUi(data = null) {
        const guide = this.getBaizeGuideConfig(data);
        const section = document.getElementById('stuBaizeSection');
        if (!section) return guide;
        if (!guide.enabled) {
          section.style.display = 'none';
          if (!document.getElementById('baizeModal')?.classList.contains('hidden')) this.closeBaizeModal();
          return guide;
        }
        section.style.display = '';
        const avatar = document.getElementById('baizeGuideAvatar');
        if (avatar) {
          avatar.style.opacity = '1';
          avatar.onload = () => { avatar.style.opacity = '1'; };
          avatar.src = guide.avatarSrc || '';
          avatar.alt = guide.assistantName || '智慧引導夥伴';
          avatar.onerror = () => {
            avatar.onerror = null;
            avatar.src = guide.key === 'cat'
              ? 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2Fcats%2FA%20Sagacious%20Cat_800x800.webp?alt=media&token=58e2a846-e249-4741-ac54-b8ad501e6d69&v=20260308c'
              : 'https://firebasestorage.googleapis.com/v0/b/project-shan-hai.firebasestorage.app/o/images%2Fmonster%20pictures%2FBaize%2FBaize_800x800.webp?alt=media&token=e2a96804-1c49-4374-a83a-96d34c5b2e92&v=20260308c';
            avatar.style.opacity = '1';
          };
          if (avatar.complete && avatar.naturalWidth > 0) avatar.style.opacity = '1';
        }
        const titleEl = document.getElementById('baizeGuideTitle');
        if (titleEl) titleEl.textContent = guide.sectionTitle;
        const descEl = document.getElementById('baizeGuideDesc');
        if (descEl) descEl.textContent = guide.sectionDesc;
        const btn = document.getElementById('baizeGuideOpenBtn');
        if (btn) btn.textContent = guide.buttonLabel;
        const modalTitle = document.getElementById('baizeModalTitle');
        if (modalTitle) modalTitle.textContent = guide.modalTitle;
        const modalDesc = document.getElementById('baizeModalDesc');
        if (modalDesc) modalDesc.textContent = guide.modalDesc;
        const suggestion = document.getElementById('baizeSuggestionText');
        if (suggestion) suggestion.textContent = guide.suggestionText;
        const input = document.getElementById('baizeInput');
        if (input) input.placeholder = guide.placeholder;
        const status = document.getElementById('baizeStatusText');
        if (status && !currentState.baizeSending) status.textContent = guide.statusWaiting || '[ 等待請教 ]';
        const sendBtn = document.getElementById('baizeSendBtn');
        if (sendBtn) sendBtn.textContent = guide.key === 'cat' ? '送出請教' : '送出請示';
        const modalEl = document.getElementById('baizeModalContent');
        if (modalEl) modalEl.setAttribute('data-guide-mode', guide.key || 'cat');
        return guide;
      },

      ensureBaizeHistory() {
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        const guideKey = guide.enabled ? guide.key : 'hidden';
        if (currentState.baizeGuideKey !== guideKey || !Array.isArray(currentState.baizeHistory) || currentState.baizeHistory.length === 0) {
          currentState.baizeHistory = guide.enabled ? [{ role: 'assistant', text: guide.welcomeText }] : [];
          currentState.baizeGuideKey = guideKey;
        }
        return currentState.baizeHistory;
      },

      renderBaizeHistory() {
        const historyEl = document.getElementById('baizeChatHistory');
        if (!historyEl) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        const history = this.ensureBaizeHistory();
        historyEl.innerHTML = history.map((entry) => {
          const isUser = entry.role === 'user';
          const name = isUser ? '你' : guide.assistantName;
          const bubbleStyle = isUser
            ? 'background:rgba(255,255,255,0.12); color:#fff; border-radius:14px 14px 4px 14px; margin-left:auto; border:1px solid rgba(255,255,255,0.08);'
            : 'background:rgba(0,229,255,0.12); color:#d8fbff; border-radius:14px 14px 14px 4px; margin-right:auto; border:1px solid rgba(0,229,255,0.18);';
          const safeText = this.escapeBaizeText(entry.text).replace(/\n/g, '<br>');
          return `
            <div style="display:flex; ${isUser ? 'justify-content:flex-end;' : 'justify-content:flex-start;'} margin-bottom:10px;">
              <div style="max-width:84%; padding:10px 12px; line-height:1.6; font-size:0.92em; ${bubbleStyle}">
                <div class="tech-font" style="font-size:0.7em; margin-bottom:4px; opacity:0.78;">${name}</div>
                <div>${safeText}</div>
              </div>
            </div>`;
        }).join('');
        historyEl.scrollTop = historyEl.scrollHeight;
      },

      setBaizeStatus(text = null) {
        const el = document.getElementById('baizeStatusText');
        if (!el) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        el.textContent = text || guide.statusWaiting || '[ 等待請教 ]';
      },

      bindBaizeUi() {
        if (currentState.baizeBound) return;
        this.refreshBaizeUi(currentState.studentData);
        this.ensureBaizeHistory();
        this.renderBaizeHistory();
        this.setBaizeStatus();
        const input = document.getElementById('baizeInput');
        if (input) {
          input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              this.sendBaizeMessage();
            }
          });
        }
        currentState.baizeBound = true;
      },
      openBaizeModal() {
        const guide = this.refreshBaizeUi(currentState.studentData);
        if (!guide.enabled) return;
        this.ensureBaizeHistory();
        this.renderBaizeHistory();
        this.setBaizeStatus(guide.statusReady);
        UI.showModal('baizeModal');
        const input = document.getElementById('baizeInput');
        if (input) setTimeout(() => input.focus(), 30);
      },

      closeBaizeModal() {
        UI.hideModal('baizeModal');
        this.setBaizeStatus();
      },

      async askBaizeViaServer(message) {
        await this.ensureStudentAuth();
        const callable = httpsCallable(functions, 'askBaize');
        const student = currentState.studentData || {};
        const guide = this.getBaizeGuideConfig(student);
        const guideMode = this.getGuideMode(student);
        const result = await callable({
          message,
          profileMode: guideMode === 'cat' ? 'cat' : 'shanhai',
          aiGuideMode: guideMode === 'cat' ? 'sage_cat' : 'baize',
          meta: {
            cardSeq: student.card_seq || student.serial || null,
            className: student.class_name || null,
            contentProfileId: student.content_profile_id || null,
            guidePersona: guide.persona || 'baize',
            source: 'student_baize'
          }
        });
        return result?.data || {};
      },

      async sendBaizeMessage() {
        if (currentState.baizeSending) return;
        const input = document.getElementById('baizeInput');
        if (!input) return;
        const guide = this.getBaizeGuideConfig(currentState.studentData);
        const message = String(input.value || '').trim();
        if (!message) {
          UI.toast(guide.emptyToast || '請先輸入問題');
          return;
        }
        if (message.length > 300) {
          UI.alert(guide.overLimitAlert || '提問請控制在 300 字以內。', '提問過長');
          return;
        }

        currentState.baizeSending = true;
        const sendBtn = document.getElementById('baizeSendBtn');
        if (sendBtn) sendBtn.disabled = true;
        this.ensureBaizeHistory().push({ role: 'user', text: message });
        this.renderBaizeHistory();
        input.value = '';
        this.setBaizeStatus(guide.statusThinking);

        try {
          const data = await this.askBaizeViaServer(message);
          const reply = String(data?.reply || '').trim() || '先回頭看看題目裡最明確的線索，試著說出你已經知道的部分，我們再往下一步。';
          this.ensureBaizeHistory().push({ role: 'assistant', text: reply });
          this.renderBaizeHistory();
          this.setBaizeStatus(guide.statusDone);
        } catch (e) {
          console.error('[askBaizeViaServer] failed:', e);
          const code = String(e?.code || e?.message || '');
          let friendly = guide.genericReply || '目前暫時沒有回應，請稍後再試。';
          if (code.includes('unauthenticated')) {
            friendly = guide.unauthenticatedReply || friendly;
          } else if (code.includes('not-found')) {
            friendly = guide.notDeployedReply || friendly;
          } else if (code.includes('internal')) {
            friendly = guide.genericReply || friendly;
          }
          this.ensureBaizeHistory().push({ role: 'assistant', text: friendly });
          this.renderBaizeHistory();
          this.setBaizeStatus(guide.statusFail);
        } finally {
          currentState.baizeSending = false;
          if (sendBtn) sendBtn.disabled = false;
          if (input) setTimeout(() => input.focus(), 30);
        }
      },

      async init() {
        const runInitPhase = async (label, fn) => {
          __setBootStatus(label, '執行中');
          try {
            return await fn();
          } catch (e) {
            __showBootFailure(e, label);
            throw e;
          }
        };

        await runInitPhase('beforeInit', async () => {
          await ModuleBridge.run('beforeInit', this.createModuleContext({ phase: 'beforeInit' }));
        });
        await runInitPhase('UI.initActionGrid', async () => {
          UI.initActionGrid();
        });
        await runInitPhase('setupEventListeners', async () => {
          this.setupEventListeners();
        });
        await runInitPhase('bindBaizeUi', async () => {
          this.bindBaizeUi();
        });
        await runInitPhase('renderAdminDiagnostics', async () => {
          this.renderAdminDiagnostics();
        });
        await runInitPhase('bindSessionActivityWatchers', async () => {
          this.bindSessionActivityWatchers();
        });

        await runInitPhase('onAuthStateChanged', async () => {
          onAuthStateChanged(auth, async (user) => {
            try {
              currentState.authUser = user || null;

              const urlParams = new URLSearchParams(window.location.search);
              const isStudentView = (urlParams.get('view') === 'student');
              if (isStudentView) return;

              if (user) {
                const ok = await this.isCurrentUserAdmin();
                currentState.isAdmin = ok;
                await ModuleBridge.run('afterAuth', this.createModuleContext({ phase: 'afterAuth', user, isAdmin: ok }));
                if (ok) {
                  UI.hide('loginView'); UI.show('dashboardView');
                  await this.openRequestedAdminPanel();
                } else {
                  UI.hide('dashboardView');
                  UI.show('loginView');
                }
                this.resetSessionIdleTimer();
              } else {
                currentState.isAdmin = false;
                currentState.adminDiag = {
                  build: BUILD_TAG,
                  projectId: firebaseConfig.projectId,
                  email: '', uid: '', claimAdmin: '未檢查', allowlist: '未檢查', final: '否',
                  lastError: '', checkedAt: new Date().toLocaleString('zh-TW'), summary: '尚未登入，無法驗證管理員權限'
                };
                this.renderAdminDiagnostics();
                this.resetSessionIdleTimer();
              }
            } catch (error) {
              console.error('[auth-state] callback failed', error);
              __setBootStatus('auth-state-error', error?.message || '登入狀態處理失敗');
              currentState.isAdmin = false;
              try {
                UI.hide('dashboardView');
                UI.show('loginView');
                this.renderAdminDiagnostics();
              } catch (_) {}
            }
          });
        });

        await runInitPhase('checkRoute', async () => {
          await this.checkRoute();
          await ModuleBridge.run('afterRoute', this.createModuleContext({ phase: 'afterRoute', viewMode: currentState.viewMode }));
        });

        setInterval(() => {
          try {
            UI.updateDailyQuestTimer();
          } catch (e) {
            console.warn('[timer] updateDailyQuestTimer failed:', e);
          }
        }, 60000);

        try {
            if (currentState.viewMode === 'admin') onSnapshot(collection(db, COLLECTION_NAME), { includeMetadataChanges: true }, (snapshot) => {
              snapshot.docChanges().forEach((change) => {
                const docId = change.doc.id;
                const newData = change.doc.data();
                if (change.type === "modified") {
                  const oldData = currentState.previousStudentsData[docId];
                  if (oldData && !change.doc.metadata.hasPendingWrites) {
                    const xpDiff = (Number(newData.totalXP) || 0) - (Number(oldData.totalXP) || 0);
                    const dashboardViewEl = document.getElementById('dashboardView');
                    const adminViewEl = document.getElementById('adminView');
                    const isLoggedInAdmin = (!!dashboardViewEl && !dashboardViewEl.classList.contains('hidden')) || (!!adminViewEl && !adminViewEl.classList.contains('hidden'));
                    const lastLog = (newData.logs && newData.logs.length > 0) ? newData.logs[newData.logs.length - 1] : null;
                    const isLegitTeacherAction = lastLog && 
                                                 ['batch_action', 'add_xp', 'prop_action', 'shop'].includes(lastLog.action_type) && 
                                                 (Date.now() - lastLog.timestamp < 30000);
                    if (xpDiff > 2 && isLoggedInAdmin && !isLegitTeacherAction) {
                        UI.showHackerAlert(newData, xpDiff);
                    }
                  }
                }
                currentState.previousStudentsData[docId] = newData;
              });
            });
        } catch(e) { console.warn("Firebase onSnapshot 初始化遇到問題", e); }

        const laSelect = document.getElementById('laSelectId');
        if (laSelect) {
           laSelect.innerHTML = '';
           (CONSTANTS.LEGENDARIES || []).forEach(leg => {
              laSelect.innerHTML += `<option value="${leg.id}">${leg.name}</option>`;
           });

           laSelect.addEventListener('change', () => __updateLegendarySelectPreview('laSelectId', 'laPreviewImg', 'laPreviewName'));
           __updateLegendarySelectPreview('laSelectId', 'laPreviewImg', 'laPreviewName');
        }

        const typeSelect = document.getElementById('btSetType');
        if(typeSelect) {
           for(let [key, info] of Object.entries(TYPE_INFO)) typeSelect.innerHTML += `<option value="${key}">${info.name}系</option>`;
        }
        const bossSelect = document.getElementById('btSetBoss');
        if (bossSelect) {
           bossSelect.innerHTML = '';
           (CONSTANTS.LEGENDARIES || []).forEach(leg => bossSelect.innerHTML += `<option value="${leg.id}">${leg.name}</option>`);

           bossSelect.addEventListener('change', () => __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName'));
           __updateLegendarySelectPreview('btSetBoss', 'btBossPreviewImg', 'btBossPreviewName');
        }

        await runInitPhase('afterInit', async () => {
          await ModuleBridge.run('afterInit', this.createModuleContext({ phase: 'afterInit' }));
        });
        ModuleBridge.markReady(this.createModuleContext({ phase: 'ready' }));
        __bootState.ready = true;
        __setBootStatus('ready', '初始化完成');
      },

      async checkRoute() {
        const urlParams = new URLSearchParams(window.location.search);
        const tokenParam = this.getTokenFromHash();
        const isStudentView = (urlParams.get('view') === 'student');

        if (isStudentView) {
          UI.hide('loginView'); UI.hide('dashboardView'); UI.hide('adminView'); UI.show('studentView');
          currentState.viewMode = 'student';
          UI.hide('viewerModeBadge'); UI.hide('exitPreviewBtn');

          // Default: locked until a valid active token resolves to a serial.
          this.lockStudentAccess('請使用已註冊的 NFC 卡片進入學生面板。');

          try {
            await this.ensureStudentAuth();
          } catch (e) {
            console.error(e);
            UI.alert(
              `學生模式需要啟用 Firebase Authentication 的『匿名登入 (Anonymous)』，否則將無法寫入加分/對戰/兌換等資料。

請到 Firebase Console → Authentication → Sign-in method 開啟 Anonymous。`,
              "需要啟用匿名登入"
            );
          }

          // 方案三：學生端必須有 token（Hash #t=...），不再接受 serial/uid 直接進入。
          if (!tokenParam) {
            this.lockStudentAccess('此連結缺少有效的卡片驗證（Token）。\n\n請重新感應已註冊的 NFC 卡片，或請老師協助（卡片補發 / 卡序查詢）。');
            return;
          }

          // 方案 A：學生端不直接讀取 tag_tokens（避免 Rules 開放敏感對照表）
          // 直接以 token 作為 student_pages/{token} 的文件 ID；是否有效由 Firestore Rules 透過 tag_tokens.active 判斷
          currentState.currentToken = tokenParam;
          currentState.currentTokenValidated = true;

          // 保持鎖定狀態，直到 student_pages 成功讀到資料才解鎖
          this.lockStudentAccess('卡片驗證中...');

          this.loadStudentData(tokenParam, 'student');
        } else {
          currentState.viewMode = 'admin';
          UI.show('loginView');
          const emailEl = document.getElementById('adminEmail');
          const pwdEl = document.getElementById('adminPassword');
          if (emailEl) emailEl.focus();
          else if (pwdEl) pwdEl.focus();

          // Auto-enter if session exists and is authorized admin
          // (onAuthStateChanged may fire after checkRoute; both paths are safe)
          if (auth.currentUser) this.tryAutoEnterAdmin();
          this.resetSessionIdleTimer();
        }
      },

      setupEventListeners() {
        // @phase9-split:auth-bind
        this.bindAuthControls();

        const usbInput = document.getElementById('usbScannerInput');
        if (usbInput) usbInput.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
            const uid = usbInput.value.trim().toUpperCase();
            usbInput.value = '';
            if(uid) this.handleCardScan(uid);
            setTimeout(() => {
              try { usbInput.focus(); } catch (_) {}
            }, 100);
          }
        });

        document.addEventListener('click', (e) => {
          const loginViewEl = document.getElementById('loginView');
          const battleArenaEl = document.getElementById('battleArenaModal');
          const adminViewEl = document.getElementById('adminView');
          const batchModeViewEl = document.getElementById('batchModeView');
          const loginHidden = !!loginViewEl?.classList?.contains('hidden');
          const battleHidden = !!battleArenaEl?.classList?.contains('hidden');
          const adminVisible = adminViewEl ? !adminViewEl.classList.contains('hidden') : false;
          const batchVisible = batchModeViewEl ? !batchModeViewEl.classList.contains('hidden') : false;
          if (loginHidden && battleHidden) {
             if(e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'SELECT') {
                 if ((adminVisible || batchVisible) && usbInput) {
                     try { usbInput.focus(); } catch (_) {}
                 }
             }
          }
        });

        const scanNfcBtn = document.getElementById('scanNfcBtn');
        if (scanNfcBtn) scanNfcBtn.addEventListener('click', () => {
          if (!('NDEFReader' in window)) { UI.alert("裝置不支援 Web NFC。", "硬體錯誤"); return; }
          this.startWebNfc(true);
        });

        const csBtn = document.getElementById('cardSeqSearchBtn');
        if (csBtn) csBtn.addEventListener('click', () => this.lookupByCardSeq());
        const csInput = document.getElementById('cardSeqInput');
        if (csInput) csInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') this.lookupByCardSeq(); });

        const submitRegBtn = document.getElementById('submitRegBtn');
        if (submitRegBtn) submitRegBtn.addEventListener('click', () => this.registerNewStudent(false));
        const submitRegAndWriteBtn = document.getElementById('submitRegAndWriteBtn');
        if (submitRegAndWriteBtn) submitRegAndWriteBtn.addEventListener('click', () => this.registerNewStudent(true));
        
        const cancelActionBtn = document.getElementById('cancelActionBtn');
        if (cancelActionBtn && !cancelActionBtn.dataset.boundCancelAction) {
          cancelActionBtn.dataset.boundCancelAction = '1';
          cancelActionBtn.addEventListener('click', () => { UI.hideModal('previewPanel'); currentState.pendingAction = null; });
        }
        const confirmActionBtn = document.getElementById('confirmActionBtn');
        if (confirmActionBtn && !confirmActionBtn.dataset.boundConfirmAction) {
          confirmActionBtn.dataset.boundConfirmAction = '1';
          confirmActionBtn.addEventListener('click', async () => { await this.commitAction(); });
        }
        
        const writeNfcLinkBtn = document.getElementById('writeNfcLinkBtn');
        if (writeNfcLinkBtn) writeNfcLinkBtn.addEventListener('click', async () => {
          if (!('NDEFReader' in window)) { UI.alert("裝置不支援 Web NFC。", "硬體錯誤"); return; }
          if (!window.isSecureContext) { UI.alert("Web NFC 需要在 HTTPS 安全環境下使用。", "硬體錯誤"); return; }
          if (!currentState.currentUid) { UI.toast("❌ 無法取得當前卡序！"); return; }
          const adminViewEl = document.getElementById('adminView');
          const batchModeViewEl = document.getElementById('batchModeView');
          const shouldRestart = (!!adminViewEl && !adminViewEl.classList.contains('hidden')) || (!!batchModeViewEl && !batchModeViewEl.classList.contains('hidden'));
          try {
            // 避免 scan() 與 write() 同時占用 NFC 造成失敗
            if (this.stopWebNfc) this.stopWebNfc();

            const serial = currentState.currentUid;
            let token = currentState.currentToken;
            if (!token && currentState.isAdmin) token = await this.getActiveTokenForSerial(serial);
            if (!token && currentState.isAdmin) {
              token = this.generateBase62Token(16);
              await setDoc(doc(db, TOKEN_COLLECTION, token), { serial: serial, active: true, issuedAt: Date.now(), issuedBy: (auth.currentUser ? auth.currentUser.uid : null) });
              await setDoc(doc(db, COLLECTION_NAME, serial), { active_token: token, page_token: token }, { merge: true });
            }
            if (!token) { UI.alert("找不到可用的 Token，請先完成註冊或使用補發流程。", "無法寫入"); return; }
            currentState.currentToken = token;

            const ndef = new NDEFReader();
            const stuUrl = this.buildStudentUrlFromToken(token);
            await ndef.write({ records: [{ recordType: "url", data: stuUrl }] });
            UI.toast("✅ 專屬面板網址已成功寫入 NFC 卡片！");
          } catch (error) {
            console.error(error);
            UI.alert(`寫入失敗: ${(error && error.message) ? error.message : error}`, "寫入異常");
          } finally {
            // 若老師仍在掃描流程中，安靜地重啟掃描
            if (shouldRestart) {
              try { await this.startWebNfc(false); } catch (_) {}
            }
          }
        });

        const supportWriteBtn = document.getElementById('writeSupportZoneNfcBtn');
        if (supportWriteBtn) {
          supportWriteBtn.addEventListener('click', async () => {
            await this.writeSupportZoneLinkToNfc();
          });
        }

        const supportUrlDisplay = document.getElementById('supportZoneUrlDisplay');
        if (supportUrlDisplay) supportUrlDisplay.value = this.buildSupportZoneUrl();

        const scienceWriteBtn = document.getElementById('writeScienceZoneNfcBtn');
        if (scienceWriteBtn) {
          scienceWriteBtn.addEventListener('click', async () => {
            await this.writeScienceZoneLinkToNfc();
          });
        }

        const scienceUrlDisplay = document.getElementById('scienceZoneUrlDisplay');
        if (scienceUrlDisplay) scienceUrlDisplay.value = this.buildScienceZoneUrl();

        const secretPropTriggerEl = document.getElementById('secretPropTrigger');
        if (secretPropTriggerEl) {
          let secretClickCount = 0;
          let secretClickTimer = null;
          secretPropTriggerEl.addEventListener('click', () => {
            if(currentState.viewMode !== 'student') return;
            secretClickCount++;
            clearTimeout(secretClickTimer);
            if (secretClickCount >= 3) {
              secretClickCount = 0;
              App.startStudentPropScan();
            } else {
              secretClickTimer = setTimeout(() => { secretClickCount = 0; }, 1000);
            }
          });
        }

const openShopBtn = document.getElementById('openShopBtn');
        if (openShopBtn) {
           openShopBtn.addEventListener('click', () => {
             this.openShop();
           });
        }

const openCardForgeBtn = document.getElementById('openCardForgeBtn');
        if (openCardForgeBtn) {
           openCardForgeBtn.setAttribute('type', 'button');
           if (!openCardForgeBtn.dataset.boundCardForgeOpen) {
             openCardForgeBtn.dataset.boundCardForgeOpen = '1';
             openCardForgeBtn.addEventListener('click', (evt) => {
               try {
                 if (window.forceOpenCardForge) {
                   window.forceOpenCardForge(evt);
                   return;
                 }
                 if (this.openCardForge) {
                   this.openCardForge();
                 }
               } catch (e) {
                 console.error('[card forge] button click failed:', e);
                 try { UI.alert(`加分框開啟失敗：${e?.message || e}`, '系統通知'); } catch (_) {}
               }
             });
           }
        }
const openDebuffBtn = document.getElementById('openDebuffBtn');
        if (openDebuffBtn && !openDebuffBtn.dataset.boundOpenDebuff) {
           openDebuffBtn.dataset.boundOpenDebuff = '1';
           openDebuffBtn.addEventListener('click', () => {
              UI.showModal('debuffModal');
           });
        }
        this.populateHiddenEggSelect();
},
      stopWebNfc() {
        try {
          if (this.nfcAbortController) {
            this.nfcAbortController.abort();
            this.nfcAbortController = null;
          }
        } catch (e) {}
      },

      getRequestedAdminPanel() {
        const urlParams = new URLSearchParams(window.location.search);
        const panel = String(urlParams.get('panel') || '').trim();
        return panel || null;
      },

      buildSupportZoneUrl() {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('panel', 'support-zone');
        return url.toString();
      },

      buildScienceZoneUrl() {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('panel', 'science-zone');
        return url.toString();
      },

      async openRequestedAdminPanel() {
        const panel = this.getRequestedAdminPanel();
        if (!panel || !currentState.isAdmin || currentState.pendingAdminPanelOpened) return;
        currentState.pendingAdminPanelOpened = true;
        if (panel === 'support-zone') {
          await this.openSupportZone();
          return;
        }
        if (panel === 'science-zone') {
          await this.openScienceZone();
        }
      },

      async startWebNfc(showToast = true) {
        if (!('NDEFReader' in window)) {
          if (showToast) UI.alert("裝置不支援 Web NFC。", "硬體錯誤");
          return false;
        }
        if (!window.isSecureContext) {
          if (showToast) UI.alert("Web NFC 需要在 HTTPS 安全環境下使用。", "硬體錯誤");
          return false;
        }
        try {
          if (!this.ndef) {
            this.ndef = new NDEFReader();
            this.ndef.addEventListener("reading", (event) => {
              const serialNumber = event.serialNumber;
              currentState.lastNfcSerialNumber = serialNumber ? String(serialNumber).replace(/:/g, '').toUpperCase() : null;

              // 優先：從 NDEF URL record 解析 serial（新制）或 uid（舊制）
              let key = null;
              try {
                const recs = event.message && event.message.records ? event.message.records : [];
                for (const rec of recs) {
                  if (!rec) continue;
                  if (rec.recordType !== "url" && rec.recordType !== "text") continue;

                  let urlStr = null;
                  if (typeof rec.data === "string") urlStr = rec.data;
                  else if (rec.data) {
                    try { urlStr = new TextDecoder().decode(rec.data); } catch (_) {}
                  }
                  if (!urlStr) continue;

                  const u = new URL(urlStr, window.location.href);
                  const serial = u.searchParams.get("serial");
                  const uid = u.searchParams.get("uid");
                  let token = null;
                  try {
                    const hs = (u.hash || '').startsWith('#') ? (u.hash || '').slice(1) : (u.hash || '');
                    const qs = hs.startsWith('?') ? hs.slice(1) : hs;
                    const hp = new URLSearchParams(qs);
                    token = hp.get('t');
                  } catch (_) {}
                  if (token) { key = 'T:' + token; break; }
                  if (serial) { key = serial; break; }
                  if (uid) { key = uid; break; }
                }
              } catch (_) {}

              // 若 URL record 沒帶 serial/uid，才退回使用 serialNumber（卡片 UID）
              if (!key && serialNumber) {
                key = serialNumber.replace(/:/g, "");
              }

              if (key) this.handleCardScan(String(key));
            });
            this.ndef.addEventListener("readingerror", () => {
              UI.toast("❌ NFC 讀取失敗，請重試貼卡。");
            });
          }

          // 重新啟動掃描：避免重複 scan() 造成 InvalidStateError
          this.stopWebNfc();
          this.nfcAbortController = new AbortController();
          await this.ndef.scan({ signal: this.nfcAbortController.signal });

          if (showToast) UI.toast("📡 NFC 感應已就緒...");
          return true;
        } catch (error) {
          console.error(error);
          const msg = (error && error.message) ? error.message : String(error);
          if (showToast) UI.alert(`NFC 啟動失敗: ${msg}`, "硬體錯誤");
          return false;
        }
      },


      enterScanMode(intention) {
        currentState.scanIntention = intention;
        UI.hide('dashboardView'); UI.show('adminView'); UI.hide('adminStudentPanel');
        const titleEl = document.getElementById('scanModeTitle');
        const hintEl = document.getElementById('scanHintText');
        if (intention === 'register') {
          titleEl.innerText = "AWAITING NEW NTAG..."; titleEl.style.color = "var(--color-water)"; hintEl.innerText = "(請感應未註冊卡片以綁定)";
        } else {
          titleEl.innerText = "等待卡片感應中..."; titleEl.style.color = "var(--cyan)"; hintEl.innerText = "掃描槍 / 手動輸入已就緒";
        }
        if (intention === 'register') { UI.hide('cardSeqSearchGroup'); } else { UI.show('cardSeqSearchGroup'); }
        const cs = document.getElementById('cardSeqInput'); if (cs) cs.value = '';
        const usbScannerInput = document.getElementById('usbScannerInput');
        if (usbScannerInput) {
          try { usbScannerInput.focus(); } catch (_) {}
        }
        this.startWebNfc(false);
      },

      async lookupByCardSeq() {
        const inputEl = document.getElementById('cardSeqInput');
        const raw = (inputEl && inputEl.value ? String(inputEl.value) : '').trim();
        if (!raw) { UI.toast('請輸入卡序'); return; }

        const seqDigits = (raw || '').replace(/[^0-9]/g, '');
        if (!seqDigits) { UI.toast('卡序格式錯誤'); return; }
        const seqStr = seqDigits.padStart(3, '0');

        UI.toast('查詢中...');
        try {
          const docSnap = await getDoc(doc(db, COLLECTION_NAME, seqStr));
          if (!docSnap.exists()) { UI.alert('查無此卡序，請確認是否已註冊。', '查詢失敗'); return; }

          currentState.scanIntention = 'read';
          this.loadStudentData(seqStr, 'admin');
          UI.toast(`✅ 已定位卡序 #${seqStr}`);
        } catch (e) {
          console.error(e);
          UI.alert('查詢時發生錯誤，請檢查網路狀態或稍後再試。', '錯誤');
        }
      },



      async simulateScan() {
        UI.alert('測試模式入口已移除；請改用實際卡片、NFC 或卡序查詢進行操作。', '測試模式已停用');
      },



      

      // --- Preview helpers (測試模式預覽用) ---
      buildPreviewStudentData(cardSeqStr) {
        const serial = this.normalizeSerial(cardSeqStr) || String(cardSeqStr || '1000');
        const now = Date.now();
        return {
          uid: `PREVIEW_${serial}`,
          card_seq: serial,
          class_name: '五年級',
          seat_number: '01',
          name: '預覽訓練家',
          totalXP: 85,
          coins: 320,
          free_rename_available: true,
          lap: 1,
          trainerRankIndex: 0,
          best_rate: 5,
          last_practice_time: now - 2 * 60 * 60 * 1000,
          display_team: [],
          status: 'Healthy',
          status_timestamp: null,
          debuffs: { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 },
          debuffs_timestamp: null,
          attributes: { metal: 18, wood: 32, water: 24, fire: 40, earth: 12 },
          streaks: { metal: 1, wood: 2, water: 1, fire: 3, earth: 0 },
          attr_event_counts: { metal: 3, wood: 5, water: 4, fire: 7, earth: 2 },
          dragon_stage: 1,           // 1=成長期（便於看見較完整 UI）
          dragon_path: 'fire',
          collection: [],
          logs: [
            { timestamp: now - 24 * 60 * 60 * 1000, action_type: 'registration', points_added: 0, detail: '預覽帳號建立' },
            { timestamp: now - 3 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 20, detail: '練習加分 (火)' },
            { timestamp: now - 2 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 15, detail: '練習加分 (木)' },
            { timestamp: now - 1 * 60 * 60 * 1000, action_type: 'add_xp', points_added: 25, detail: '練習加分 (水)' }
          ],
          content_profile_id: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'cat' : 'shanhai',
          ui_variant: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'muslim_friendly' : 'default',
          guide_mode: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? 'cat' : 'baize',
          guide_mode_locked: true,
          profile_flags: (new URLSearchParams(window.location.search).get('profile') === 'cat') ? { hide_fantasy: true, use_cat_theme: true, use_safe_random_label: true } : { hide_fantasy: false, use_cat_theme: false, use_safe_random_label: false }
        };
      },

      async seedPreviewStudent(cardSeqStr) {
        const serial = this.normalizeSerial(cardSeqStr) || String(cardSeqStr || '1000');

        // 若已存在真實資料，就不要覆蓋
        try {
          const ref = doc(db, COLLECTION_NAME, serial);
          const snap = await getDoc(ref);
          if (snap.exists()) return;
        } catch (e) {
          // 讀取被 rules 擋住也沒關係：後面會直接用本機假資料讓畫面可預覽
        }

        const sample = this.buildPreviewStudentData(serial);

        // 優先嘗試寫入 Firestore（方便你預覽「真實 onSnapshot 流程」）
        try {
          await setDoc(doc(db, COLLECTION_NAME, serial), sample, { merge: false });
        } catch (e) {
          console.warn('preview seed write failed:', e);
          // fallback：至少讓畫面能看到「真實長相」
          currentState.currentUid = serial;
          currentState.studentData = sample;
          UI.updatePanel(sample, true);
          UI.toast('⚠️ 預覽資料無法寫入/讀取 Firestore，已使用本機假資料顯示（請檢查 Rules / 登入狀態）。');
        }
      },


// --- Account Management (卡序查詢 / 卡片補發) --- (卡序查詢 / 卡片補發) ---
      openAccountMgmt() {
        if (!currentState.isAdmin) { UI.alert('需要老師帳號登入後才能使用。', '權限不足'); return; }
        this.setAccountMgmtTab('lookup');
        currentState.reissueDraft = null;
        const m1 = document.getElementById('amLookupMsg'); if (m1) m1.textContent = '';
        const m2 = document.getElementById('amReissueMsg'); if (m2) m2.textContent = '';
        const info = document.getElementById('amReissueInfo'); 
        if (info) info.innerHTML = '<span style="color:var(--text-muted);">請先輸入卡序並載入學生資料。</span>';
        const btn = document.getElementById('amReissueStartBtn');
        if (btn) { btn.disabled = true; btn.style.opacity = 0.6; }
        UI.showModal('accountMgmtModal');
        const inp = document.getElementById('amSerialLookupInput');
        if (inp) { inp.value = ''; setTimeout(() => inp.focus(), 50); }
      },

      setAccountMgmtTab(tab) {
        const lookup = document.getElementById('amLookupPane');
        const reissue = document.getElementById('amReissuePane');
        if (!lookup || !reissue) return;
        if (tab === 'reissue') { lookup.classList.add('hidden'); reissue.classList.remove('hidden'); }
        else { reissue.classList.add('hidden'); lookup.classList.remove('hidden'); }
      },

      async amLookupSerial() {
        const msg = document.getElementById('amLookupMsg');
        const raw = (document.getElementById('amSerialLookupInput')?.value || '').trim();
        const seq = this.normalizeSerial(raw);
        if (!seq) { if (msg) msg.textContent = '⚠️ 請輸入正確卡序'; return; }
        if (msg) msg.textContent = '查詢中...';
        try {
          const sSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
          if (!sSnap.exists()) { if (msg) msg.textContent = '❌ 查無此卡序（尚未註冊）'; return; }
          if (msg) msg.textContent = '✅ 已找到，正在開啟...';
          UI.hideModal('accountMgmtModal');
          this.enterScanMode('read');
          this.loadStudentData(seq, 'admin');
        } catch (e) {
          console.error(e);
          if (msg) msg.textContent = '❌ 查詢失敗，請稍後重試';
        }
      },

      async amLoadReissue() {
        const raw = (document.getElementById('amReissueSerialInput')?.value || '').trim();
        const seq = this.normalizeSerial(raw);
        const msg = document.getElementById('amReissueMsg');
        const info = document.getElementById('amReissueInfo');
        const btn = document.getElementById('amReissueStartBtn');
        if (!seq) { if (msg) msg.textContent = '⚠️ 請輸入正確卡序'; return; }
        if (msg) msg.textContent = '查詢中...';
        try {
          const sSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
          if (!sSnap.exists()) { 
            if (msg) msg.textContent = '❌ 查無此卡序（尚未註冊）'; 
            if (btn) { btn.disabled = true; btn.style.opacity = 0.6; }
            return; 
          }
          const data = sSnap.data() || {};
          const oldUid = data.uid ? this.normalizeUid(data.uid) : null;
          const oldToken = await this.getActiveTokenForSerial(seq);
          currentState.reissueDraft = { serial: seq, oldUid: oldUid, oldToken: oldToken };

          if (info) {
            info.innerHTML = `
              <div><b>卡序：</b>#${seq}</div>
              <div><b>學生：</b>${(data.name || '未命名')}</div>
              <div><b>班級：</b>${(data.class_name || '-')}</div>
              <div><b>目前UID：</b>${oldUid ? oldUid : '<span style="color:var(--text-muted);">（未記錄）</span>'}</div>
              <div><b>目前Token：</b>${oldToken ? oldToken : '<span style="color:var(--text-muted);">（未建立）</span>'}</div>
              <div style="margin-top:6px; font-size:0.85em; color:var(--text-muted);">補發會停用舊卡（舊UID/舊Token 失效），資料不變。</div>
            `;
          }
          if (btn) { btn.disabled = false; btn.style.opacity = 1; }
          if (msg) msg.textContent = '✅ 已載入，請點「一鍵補發」並感應新卡';
        } catch (e) {
          console.error(e);
          if (msg) msg.textContent = '❌ 載入失敗，請稍後重試';
          if (btn) { btn.disabled = true; btn.style.opacity = 0.6; }
        }
      },

      async amStartReissue() {
        const msg = document.getElementById('amReissueMsg');
        const draft = currentState.reissueDraft;
        if (!draft || !draft.serial) { if (msg) msg.textContent = '⚠️ 請先載入學生資料'; return; }
        currentState.reissueState = { ...draft };
        currentState.scanIntention = 'reissue';
        if (msg) msg.textContent = '📡 請感應「新卡」以完成補發...';
        try {
          await this.startWebNfc(true);
        } catch (_) {}
      },

      async executeReissue(serial, oldToken, oldUid, newUid) {
        const seq = this.normalizeSerial(serial);
        const msg = document.getElementById('amReissueMsg');
        if (!seq) { UI.alert('卡序格式錯誤', '補發失敗'); return; }
        if (!currentState.isAdmin) { UI.alert('需要老師登入後才能補發。', '權限不足'); return; }

        if (msg) msg.textContent = '⏳ 補發處理中...';
        const newToken = this.generateBase62Token(16);
        const now = Date.now();
        const normOldUid = oldUid ? this.normalizeUid(oldUid) : null;
        const normNewUid = newUid ? this.normalizeUid(newUid) : null;

        try {
          const batch = writeBatch(db);

          // 新 token
          batch.set(doc(db, TOKEN_COLLECTION, newToken), { 
            serial: seq, active: true, issuedAt: now, issuedBy: (auth.currentUser ? auth.currentUser.uid : null),
            replacedToken: oldToken || null
          });

          // 舊 token 停用
          if (oldToken) {
            batch.set(doc(db, TOKEN_COLLECTION, oldToken), { active: false, revokedAt: now, replacedBy: newToken }, { merge: true });
          }

          // 更新學生 UID（若可取得）
          if (normNewUid) {
            batch.set(doc(db, COLLECTION_NAME, seq), { uid: normNewUid, active_token: newToken, page_token: newToken }, { merge: true });
            batch.set(doc(db, 'cards', normNewUid), { serial: seq, createdAt: now, active: true, replacedUid: normOldUid || null }, { merge: true });
          }

          // 無論是否換 UID，都更新學生主檔目前有效 token
          batch.set(doc(db, COLLECTION_NAME, seq), { active_token: newToken, page_token: newToken }, { merge: true });

          // 舊 UID 停用
          if (normOldUid && (!normNewUid || normOldUid !== normNewUid)) {
            batch.set(doc(db, 'cards', normOldUid), { active: false, revokedAt: now, replacedBy: (normNewUid ? normNewUid : null) }, { merge: true });
          }

          await batch.commit();
          currentState.currentToken = newToken;

          // 方案A：以新 token 建立 student_pages/{token}（複製 students/{卡序}）
          try {
            const stuSnap = await getDoc(doc(db, COLLECTION_NAME, seq));
            if (stuSnap.exists()) {
              const sd0 = stuSnap.data() || {};
              const sd = this.applyDataMigration(JSON.parse(JSON.stringify(sd0)));
              const serialDigits = String(sd.card_seq || sd.serial || seq || '').replace(/[^0-9]/g, '');
              const serial = serialDigits ? serialDigits.padStart(3, '0') : String(seq);
              sd.card_seq = serial;
              sd.serial = serial;
              await setDoc(doc(db, STUDENT_PAGE_COLLECTION, newToken), sd, { merge: false });
            }
          } catch (e) {
            console.warn('[student_pages] seed on reissue failed:', e?.message || e);
          }


          // 嘗試寫入 NFC
          let writeOk = false;
          let stuUrl = this.buildStudentUrlFromToken(newToken);
          try {
            if (!('NDEFReader' in window)) throw new Error('裝置不支援 Web NFC');
            if (!window.isSecureContext) throw new Error('Web NFC 需要 HTTPS');
            if (this.stopWebNfc) this.stopWebNfc();
            const ndef = new NDEFReader();
            await ndef.write({ records: [{ recordType: "url", data: stuUrl }] });
            writeOk = true;
          } catch (e) {
            console.warn('[reissue] nfc write failed:', e);
          }

          currentState.scanIntention = 'read';
          currentState.reissueState = null;
          currentState.reissueDraft = null;

          if (writeOk) {
            if (msg) msg.textContent = '✅ 補發完成（已寫入新卡）';
            UI.toast(`✅ 補發完成：卡序 #${seq}`);
          } else {
            const tips = `寫入 NFC 失敗，但補發資料已完成。\n請改用其他工具手動寫入以下網址：\n${stuUrl}`;
            UI.alert(tips, '寫入異常');
            if (msg) msg.textContent = '⚠️ 補發完成，但寫入失敗（需手動寫入）';
          }

          UI.hideModal('accountMgmtModal');
          this.enterScanMode('read');
          this.loadStudentData(seq, 'admin');
        } catch (e) {
          console.error(e);
          currentState.scanIntention = 'read';
          if (msg) msg.textContent = '❌ 補發失敗，請稍後重試';
          UI.alert('補發寫入資料庫失敗，請檢查權限/網路/規則設定。', '補發失敗');
        }
      },


      getProfilePayloadFromForm() {
        const profileId = document.getElementById('profileSelect')?.value || 'shanhai';
        const uiVariant = document.getElementById('profileVariantSelect')?.value || (profileId === 'cat' ? 'muslim_friendly' : 'default');
        const guideMode = document.getElementById('guideModeSelect')?.value || (profileId === 'cat' ? 'cat' : 'baize');
        const guideModeLocked = document.getElementById('guideModeLocked')?.checked !== false;
        return {
          content_profile_id: profileId,
          ui_variant: uiVariant,
          guide_mode: guideMode,
          guide_mode_locked: guideModeLocked,
          profile_flags: {
            hide_fantasy: !!document.getElementById('flagHideFantasy')?.checked,
            use_cat_theme: !!document.getElementById('flagUseCatTheme')?.checked,
            use_safe_random_label: !!document.getElementById('flagSafeRandom')?.checked
          }
        };
      },

      async applyCurrentStudentProfile() {
        const serial = this.normalizeSerial(currentState.currentUid || currentState.studentData?.card_seq);
        if (!serial) return UI.toast('請先讀取學生資料');
        const payload = this.getProfilePayloadFromForm();
        try {
          await setDoc(doc(db, COLLECTION_NAME, serial), payload, { merge: true });
          const token = await this.getActiveTokenForSerial(serial);
          if (token) await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...payload, card_seq: serial, serial }, { merge: true });
          const merged = Object.assign({}, currentState.studentData || {}, payload, { card_seq: serial, serial });
          currentState.studentData = this.applyDataMigration(merged);
          UI.updatePanel(currentState.studentData, currentState.viewMode === 'student');
          UI.toast(`✅ 已套用${payload.content_profile_id === 'cat' ? '貓咪版' : '山海版'}顯示設定`);
        } catch (e) {
          console.error(e);
          UI.alert('寫入顯示設定失敗：' + (e.message || e), '設定失敗');
        }
      },

      quickApplyCatProfile() {
        const sel = document.getElementById('profileSelect'); if (sel) sel.value = 'cat';
        const variant = document.getElementById('profileVariantSelect'); if (variant) variant.value = 'muslim_friendly';
        const guideSel = document.getElementById('guideModeSelect'); if (guideSel) guideSel.value = 'cat';
        const guideLocked = document.getElementById('guideModeLocked'); if (guideLocked) guideLocked.checked = true;
        const f1 = document.getElementById('flagHideFantasy'); if (f1) f1.checked = true;
        const f2 = document.getElementById('flagUseCatTheme'); if (f2) f2.checked = true;
        const f3 = document.getElementById('flagSafeRandom'); if (f3) f3.checked = true;
      },

      quickApplyShanhaiProfile() {
        const sel = document.getElementById('profileSelect'); if (sel) sel.value = 'shanhai';
        const variant = document.getElementById('profileVariantSelect'); if (variant) variant.value = 'default';
        const guideSel = document.getElementById('guideModeSelect'); if (guideSel) guideSel.value = 'baize';
        const guideLocked = document.getElementById('guideModeLocked'); if (guideLocked) guideLocked.checked = true;
        const f1 = document.getElementById('flagHideFantasy'); if (f1) f1.checked = false;
        const f2 = document.getElementById('flagUseCatTheme'); if (f2) f2.checked = false;
        const f3 = document.getElementById('flagSafeRandom'); if (f3) f3.checked = false;
      },

      backToDashboard() {
        if(currentState.unsubscribe) { currentState.unsubscribe(); currentState.unsubscribe = null; }
        UI.hide('adminView'); UI.hide('viewerModeBadge'); UI.hide('exitPreviewBtn'); UI.show('dashboardView');
      },

      // --- 訓練家階級（取代原本 LAP 顯示/優惠）---
// 規則：
// - 計算進化型態時：包含全息投影(isHologram)；排除 dead_dragon
// - 異獸以 type==='legendary' 計算
computeTrainerProgress(data) {
  const col = Array.isArray(data?.collection) ? data.collection : [];
  const stage = Number(data?.dragon_stage);
  const stageIdx = Number.isFinite(stage) ? stage : -1;

  // 只計入可展示/有效的龍獸結算紀錄（type==='dragon'），排除死亡/全息
  const dragonItems = col.filter(i =>
    i && typeof i === 'object' &&
    i.type === 'dragon' &&
    !(i.isHologram === true || i.isHologram === "true")
  );

  const dragonMilestones = dragonItems.length;
  const uniquePaths = new Set(dragonItems.map(i => String(i.path || i.element || '')).filter(Boolean)).size;
  const legendaryCount = col.filter(i => i && typeof i === 'object' && i.type === 'legendary').length;

  // 階級判定（可依需求再調整）
  let rankIndex = 0;
  if (legendaryCount >= 1 && stageIdx >= 2) rankIndex = 7;          // 龍獸大師
  else if (legendaryCount >= 1) rankIndex = 6;                      // 傳說召喚師
  else if (stageIdx >= 2 && dragonMilestones >= 3) rankIndex = 5;    // 宗師（完成破殼→成長→成年）
  else if (stageIdx >= 2) rankIndex = 4;                            // 領主（成年期）
  else if (stageIdx >= 1) rankIndex = 3;                            // 守護者（成長期）
  else if (stageIdx >= 0) rankIndex = 2;                            // 試煉者（破殼期）
  else if ((Number(data?.totalXP) || 0) > 0) rankIndex = 1;          // 進階學徒（開始累積能量）
  else rankIndex = 0;                                               // 新手學徒

  const rankName = (CONSTANTS.TRAINER_RANKS && CONSTANTS.TRAINER_RANKS[rankIndex]) ? CONSTANTS.TRAINER_RANKS[rankIndex] : '新手學徒';
  return { dragonMilestones, uniquePaths, legendaryCount, rankIndex, rankName };
},

getRateFromRankIndex(rankIndex) {
  const idx = Number.isFinite(Number(rankIndex)) ? Number(rankIndex) : 0;
  const v = CONSTANTS.TRAINER_RATE_BY_RANK?.[idx];
  return Number(v) || 5;
},

// 兼容舊資料：把舊 lap 對應到原本的匯率（避免既有學生優惠被意外削弱）
getRateFromLap(lap) {
  const L = Number(lap) || 1;
  return (L === 2) ? 4 : (L === 3) ? 3 : (L >= 4) ? 2 : 5;
},

applyDataMigration(data) {
        if (!data.debuffs) {
          data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
          if (data.status && data.status !== 'Healthy' && data.debuffs[data.status] !== undefined) data.debuffs[data.status] = 1;
          data.status = 'Healthy'; 
        }
        
        if (!data.attributes || data.attributes.electric !== undefined) data.attributes = { metal: Number(data.attributes?.metal)||0, wood: Number(data.attributes?.wood)||0, water: Number(data.attributes?.water)||0, fire: Number(data.attributes?.fire)||0, earth: Number(data.attributes?.earth)||0 };
        if (!data.streaks || data.streaks.electric !== undefined) data.streaks = { metal: Number(data.streaks?.metal)||0, wood: Number(data.streaks?.wood)||0, water: Number(data.streaks?.water)||0, fire: Number(data.streaks?.fire)||0, earth: Number(data.streaks?.earth)||0 };
        data.content_profile_id = data.content_profile_id || 'shanhai';
        data.ui_variant = data.ui_variant || (data.content_profile_id === 'cat' ? 'muslim_friendly' : 'default');
        data.profile_flags = Object.assign({ hide_fantasy: data.content_profile_id === 'cat', use_cat_theme: data.content_profile_id === 'cat', use_safe_random_label: data.content_profile_id === 'cat' }, data.profile_flags || {});
        if (!data.guide_mode) {
          if (data.content_profile_id === 'cat' || data.ui_variant === 'muslim_friendly') data.guide_mode = 'cat';
          else if (data.content_profile_id === 'shanhai' || data.ui_variant === 'default') data.guide_mode = 'baize';
          else data.guide_mode = 'cat';
        }
        if (typeof data.guide_mode_locked !== 'boolean') data.guide_mode_locked = true;
        // 累積「各屬性加分事件次數」：用於學生面板「龍蛋的成長旅程」（不掉階、從創立起累積）
        if (!data.attr_event_counts) {
          data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
          // best-effort：若舊資料尚未有此欄位，嘗試從既有 logs 回推（若 logs 曾被截斷，則以可取得的部分為準）
          try {
            if (Array.isArray(data.logs)) {
              const xpTypes = new Set(['add_xp','batch_action','prop_action','quest']);
              const nameToKey = (rawName) => {
                const n = String(rawName || '')
                  .replace(/[\s\[\]【】()（）]/g, '')
                  .replace(/[⚙️🌳💧🔥🪨]/g, '');
                if (!n) return null;
                if (n.includes('金') || n.includes('鋼')) return 'metal';
                if (n.includes('木') || n.includes('草') || n.includes('葉')) return 'wood';
                if (n.includes('水')) return 'water';
                if (n.includes('火')) return 'fire';
                if (n.includes('土') || n.includes('地')) return 'earth';
                return null;
              };
              data.logs.forEach((log) => {
                if (!log || !xpTypes.has(log.action_type)) return;
                const d = String(log.detail || '');
                const m = d.match(/\(([^)]+)\)\s*$/); // 例：(火) / (太陽)
                if (!m) return;
                const k = nameToKey(m[1]);
                if (k && data.attr_event_counts[k] != null) data.attr_event_counts[k] += 1;
              });
            }
          } catch (e) {}
        } else {
          // 補齊缺漏 key
          const base = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
          data.attr_event_counts = Object.assign(base, data.attr_event_counts);
        }

        ensureAttributeFirstGainOrder(data);
        
        data.coins = Number(data.coins) || 0;
        data.totalXP = Number(data.totalXP) || 0;
        data.lap = Number(data.lap) || 1;

        // 訓練家階級（不掉階）：若資料缺漏則補上，並以已達成的最高階級為準
data.trainerRankIndex = Number(data.trainerRankIndex);
if (!Number.isFinite(data.trainerRankIndex)) data.trainerRankIndex = 0;
data.best_rate = Number(data.best_rate);
if (!Number.isFinite(data.best_rate)) data.best_rate = 99; // 先給大值，後續再取 min()
if (data.collection && data.collection.length > 0) {
          data.collection = data.collection.map(item => {
            // 舊版資料：曾以字串存入封存項目（避免再顯示舊版圖源/名稱）
            if (typeof item === 'string') {
              return { type: 'legacy', legacy: item, timestamp: Date.now() };
            }
            return item;
          });
        }
        if (data.last_practice_time === undefined) data.last_practice_time = 0;
        if (data.display_team === undefined) data.display_team = [];
        if (!data.logs) data.logs = [];
        if (!Array.isArray(data.reward_events)) data.reward_events = [];
        if (!Array.isArray(data.reward_settled_ids)) data.reward_settled_ids = [];
        if (!Array.isArray(data.hidden_eggs)) data.hidden_eggs = [];
        data.active_hidden_egg_id = data.active_hidden_egg_id || '';
        if (!data.active_hidden_egg && data.active_hidden_egg_id) {
          const activeFromHidden = data.hidden_eggs.find(item => String(item.hiddenEggId || item.id || '') === String(data.active_hidden_egg_id));
          const activeFromCollection = Array.isArray(data.collection) ? data.collection.find(item => item && item.type === 'hidden_egg' && String(item.hiddenEggId || item.id || '') === String(data.active_hidden_egg_id)) : null;
          data.active_hidden_egg = activeFromHidden || activeFromCollection || null;
        }
// 依目前收藏計算階級；並保留「舊 lap」的最佳優惠，避免既有學生優惠被意外削弱
const prog = this.computeTrainerProgress(data);
data.trainerRankIndex = Math.max(data.trainerRankIndex, prog.rankIndex);
const rateFromRank = this.getRateFromRankIndex(data.trainerRankIndex);
const rateFromLap = this.getRateFromLap(data.lap);
data.best_rate = Math.min(data.best_rate, rateFromRank, rateFromLap);
if (!Number.isFinite(data.best_rate) || data.best_rate === 99) data.best_rate = rateFromRank;
        return data;
      },

      async handleCardScan(uid) {
        if (Date.now() - batchState.lastScanTime < 800) return;
        batchState.lastScanTime = Date.now();

        // Token (T:) 需保留大小寫（base62）
        let rawKey = String(uid || '').trim();
        const isTokenKey = rawKey.length >= 2 && rawKey[1] === ':' && (rawKey[0] === 'T' || rawKey[0] === 't');
        if (isTokenKey) {
          rawKey = 'T:' + rawKey.slice(2).trim(); // prefix 統一，但 token 內容保留
        } else {
          rawKey = rawKey.toUpperCase().replace(/:/g, '').replace(/\s+/g, '');
        }
        if (!rawKey) return;
        UI.toast(`UID DETECTED: ${rawKey}`);

        const resolveSerialFromKey = async (key) => {
          const kRaw = String(key || '').trim();
          if (!kRaw) return null;

          const isTok = kRaw.length >= 2 && kRaw[1] === ':' && (kRaw[0] === 'T' || kRaw[0] === 't');
          const k = isTok ? ('T:' + kRaw.slice(2).trim()) : kRaw.toUpperCase();

          // Token URL (#t=xxxx) → serial（token 需保留大小寫）
          if (isTok) {
            const tok = kRaw.slice(2).trim();
            const serial = await this.resolveSerialFromToken(tok, /*requireActive*/ true);
            if (serial) {
              currentState.currentToken = tok;
              return serial;
            }

            // Token 解析失敗時（常見：規則/索引尚未就緒或 token doc 尚未建立）
            // 老師端可退回使用 NFC UID 對照表 /cards/{uid} 來找回卡序，避免卡住
            if (currentState.isAdmin && currentState.lastNfcSerialNumber) {
              try {
                const uidKey = this.normalizeUid(currentState.lastNfcSerialNumber);
                const cSnap = await getDoc(doc(db, 'cards', uidKey));
                if (cSnap.exists()) {
                  const cd = cSnap.data() || {};
                  if (cd.active === false) return null;
                  const sRaw = cd.serial || cd.card_seq;
                  const sd = (sRaw == null) ? '' : String(sRaw).replace(/[^0-9]/g, '');
                  if (sd) {
                    UI.toast('⚠️ Token 無效，已改用 UID 對照查詢');
                    return sd.padStart(3, '0');
                  }
                }
              } catch (e) {}
            }

            return null; // inactive / not found
          }

          const digits = k.replace(/[^0-9]/g, '');
          const isPureDigits = !!digits && digits.length === k.length;
          if (isPureDigits) return digits.padStart(3, '0');

          // Admin fallback: UID -> serial via /cards/{uid}
          if (currentState.isAdmin) {
            try {
              const uidKey = this.normalizeUid(k);
              const cSnap = await getDoc(doc(db, 'cards', uidKey));
              if (cSnap.exists()) {
                const cd = cSnap.data() || {};
                if (cd.active === false) return null; // 補發後的舊卡直接拒絕
                const sRaw = cd.serial || cd.card_seq;
                const sd = (sRaw == null) ? '' : String(sRaw).replace(/[^0-9]/g, '');
                if (sd) return sd.padStart(3, '0');
              }
            } catch (e) {}
          }
          return null;
        };

        if (currentState.scanIntention === 'student_prop') {
           const actionSnap = await getDoc(doc(db, "action_cards", rawKey));
           if (actionSnap.exists()) {
               this.executeStudentPropAction(actionSnap.data());
               return;
           }

           const serial = await resolveSerialFromKey(rawKey);
           if (serial) {
             const stuSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
             if (stuSnap.exists()) {
               UI.toast(`🔄 切換至學生：${stuSnap.data().name}`);
               window.history.replaceState(null, '', `?view=student&serial=${serial}`);
               this.loadStudentData(serial, 'student');
               return;
             }
           }

           UI.toast("❌ 未知的卡片！");
           return;
        }

        if (currentState.scanIntention === 'forge') {
           if (!currentState.pendingForgeData) return UI.alert("鑄造資料遺失，請重新操作。", "系統異常");
           try { 
               await setDoc(doc(db, "action_cards", rawKey), currentState.pendingForgeData); 
               UI.hideModal('cardForgeModal'); 
               UI.toast('✅ 道具卡鑄造綁定成功！'); 
               this.backToDashboard(); 
           } catch(e) { UI.alert("寫入資料庫失敗！", "鑄造失敗"); }
           return;
        }

        if (currentState.scanIntention === 'support-batch') {
           const serial = await resolveSerialFromKey(rawKey);
           if (serial) {
             await this.handleSupportBatchScan(serial);
             return;
           }
           UI.toast("❌ 無法辨識此學習扶助卡片");
           return;
        }

        if (currentState.scanIntention === 'science-batch') {
           const serial = await resolveSerialFromKey(rawKey);
           if (serial) {
             await this.handleScienceBatchScan(serial);
             return;
           }
           UI.toast("❌ 無法辨識此科展團隊卡片");
           return;
        }

        if (currentState.scanIntention === 'batch') {
           // ✅ Batch 模式「任何一次掃描」都視為活動：重置 10 秒倒數（避免掃描過程被倒數關閉）
           // 這樣老師連續感應貼紙/道具卡時，不需要反覆重開批量模式
           this.startBatchTimer();
           const actionSnap = await getDoc(doc(db, "action_cards", rawKey));
           if (actionSnap.exists()) {
               if (!batchState.activeStudentUid) { UI.toast("⚠️ 請先感應學生卡！"); return; }
               await this.executeBatchAction(actionSnap.data()); return;
           }

           const serial = await resolveSerialFromKey(rawKey);
           if (serial) {
             const stuSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
             if (stuSnap.exists()) { await this.setBatchStudent(serial, stuSnap.data()); return; }
           }

           UI.toast("❌ 未知的卡片！"); 
           return;
        }

        if (currentState.scanIntention === 'register') {
          // 若掃到的是已寫入 URL 的學生卡（Token/卡序），代表該卡可能已被使用
          if (rawKey.startsWith('T:')) {
            const serial = await resolveSerialFromKey(rawKey);
            if (serial) UI.alert(`此卡已綁定卡序 #${serial}（Token 模式）`, '註冊衝突');
            else UI.alert('偵測到已寫入網址的卡片（可能為舊卡/停用卡），請改用空白新卡。', '註冊衝突');
            return;
          }
          // 若掃到的是已寫入 URL 的學生卡，Web NFC 可能回傳卡序（純數字）
          const digits = rawKey.replace(/[^0-9]/g, '');
          const isPureDigits = !!digits && digits.length === rawKey.length;
          if (isPureDigits) {
            const serial = digits.padStart(3, '0');
            const stuSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
            if (stuSnap.exists()) {
              UI.alert(`此卡序 #${serial} 已綁定給：${stuSnap.data().name}`, "註冊衝突");
            } else {
              UI.alert(`偵測到卡序 #${serial}，但資料庫尚未建檔。
請改用空白卡片(UID)進行註冊。`, "註冊異常");
            }
            return;
          }

          // 一般狀況：rawKey 為 UID
          const cardRef = doc(db, 'cards', this.normalizeUid(rawKey));
          const cardSnap = await getDoc(cardRef);
          if (cardSnap.exists()) {
            const s = cardSnap.data().serial || cardSnap.data().card_seq || '未知';
            UI.alert(`此卡片已綁定卡序 #${s}`, "註冊衝突");
            return;
          }

          currentState.currentCardUid = this.normalizeUid(rawKey);
          document.getElementById('regUidDisplay').innerText = this.normalizeUid(rawKey);
          UI.showModal('regModal');
          const cs = document.getElementById('regCardSeq');
          if (cs) { cs.value = ''; cs.focus(); }
          return;
        }

        
        if (currentState.scanIntention === 'reissue') {
          const st = currentState.reissueState;
          if (!st || !st.serial) { UI.alert('補發狀態遺失，請回到帳號管理重新操作。', '系統異常'); return; }

          const newUid = currentState.lastNfcSerialNumber || null;
          if (st.oldUid && newUid && String(st.oldUid).toUpperCase() === String(newUid).toUpperCase()) {
            UI.alert('偵測到同一張舊卡，請改用「新卡」進行補發。', '補發失敗');
            return;
          }

          await this.executeReissue(st.serial, st.oldToken || null, st.oldUid || null, newUid);
          return;
        }

// Default: read mode (admin scan)
        const serial = await resolveSerialFromKey(rawKey);
        if (!serial) { 
          UI.alert('資料庫中查無此卡片紀錄，或此卡已被停用（補發後舊卡失效）。', '查無檔案');
          return;
        }

        const docRef = doc(db, COLLECTION_NAME, serial);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) { 
          this.loadStudentData(serial, 'admin'); 
        } else { 
          UI.alert('資料庫中查無此卡片紀錄，或此卡已被停用（補發後舊卡失效）。', '查無檔案'); 
        }
      },
      setCardForgeMode(mode) { return teacherActionsApi.setCardForgeMode.apply(this, arguments); },

      initCardForgePresets() { return teacherActionsApi.initCardForgePresets.apply(this, arguments); },

      applyForgeXpPreset() { return teacherActionsApi.applyForgeXpPreset.apply(this, arguments); },

      ensureTeacherTargetData(data) { return teacherActionsApi.ensureTeacherTargetData.apply(this, arguments); },

      openCardForge() { return teacherActionsApi.openCardForge.apply(this, arguments); },
      startCardForge() { return teacherActionsApi.startCardForge.apply(this, arguments); },
      cancelCardForge() { return teacherActionsApi.cancelCardForge.apply(this, arguments); },
      enterBatchMode() { return batchApi.enterBatchMode.apply(this, arguments); },
      exitBatchMode() { return batchApi.exitBatchMode.apply(this, arguments); },
      setBatchStudent() { return batchApi.setBatchStudent.apply(this, arguments); },
      startBatchTimer() { return batchApi.startBatchTimer.apply(this, arguments); },
      endBatchSession() { return batchApi.endBatchSession.apply(this, arguments); },
      resetBatchState() { return batchApi.resetBatchState.apply(this, arguments); },
      persistBatchStudentData() { return batchApi.persistBatchStudentData.apply(this, arguments); },
      executeBatchAction() { return batchApi.executeBatchAction.apply(this, arguments); },

      async startStudentPropScan() {
         currentState.scanIntention = 'student_prop';
         const ok = await this.startWebNfc(true);
         if (ok) UI.toast("🔮 巡堂道具模式已啟動，請直接感應道具卡！");
      },

      async executeStudentPropAction(action) {
         if (!currentState.studentData) return;
         let data = JSON.parse(JSON.stringify(currentState.studentData)); 

         // Debuff card: stacks negative status (student prop scan)
         if (action && (action.type === 'debuff' || action.debuffKey)) {
           const debuffKey = action.debuffKey || action.statusKey || action.debuff || 'Poison';
           const stacksRaw = parseInt(action.stacks);
           const stacks = Math.max(1, Math.min(5, Number.isFinite(stacksRaw) ? stacksRaw : 1));
           if (!data.debuffs) data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
           data.debuffs[debuffKey] = (data.debuffs[debuffKey] || 0) + stacks;
           data.debuffs_timestamp = Date.now();
           const info = CONSTANTS.DEBUFF_INFO[debuffKey] || { name: debuffKey, color: 'var(--danger)' };
           data.logs.push({ timestamp: Date.now(), action_type: "prop_debuff", points_added: 0, detail: `[巡堂狀態] ${action.name} -> ${info.name} +${stacks}` });
           if (await this.checkDeathTrigger(data, debuffKey)) { return; }
           await this.saveToDB(data);
           UI.toast(`⚠️ [${action.name}] 已疊加：${info.name} +${stacks}`);
           return;
         }
         let actualAttr = action.attr; 
         let actualVal = action.val;
         
         if (data.debuffs?.Confusion > 0) { const keys = Object.keys(CONSTANTS.ATTRIBUTES); actualAttr = keys[Math.floor(Math.random() * keys.length)]; }
         if (data.debuffs?.Poison > 0) actualVal = Math.floor(actualVal / Math.pow(2, data.debuffs.Poison)); 
         
         data.totalXP += actualVal; if(data.totalXP < 0) data.totalXP = 0; 
         if (actualAttr !== 'random') addAttributeXP(data, actualAttr, action.val);
        if (!data.attr_event_counts) data.attr_event_counts = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
        if (actualAttr && data.attr_event_counts[actualAttr] != null) data.attr_event_counts[actualAttr] = (Number(data.attr_event_counts[actualAttr]) || 0) + 1;

         
         data.logs.push({ timestamp: Date.now(), action_type: "prop_action", points_added: actualVal, detail: `[巡堂道具] ${action.name} -> +${actualVal}XP (${CONSTANTS.ATTRIBUTES[actualAttr]?.name || '特殊'})` });
         data = this.processEvolution(data);
         
         await this.saveToDB(data);
         
         const uiColor = CONSTANTS.ATTRIBUTES[actualAttr] ? CONSTANTS.ATTRIBUTES[actualAttr].color : 'var(--cyan)';
         UI.toast(`🌟 [${action.name}] 觸發成功！ +${actualVal} XP`);
         
         const panel = document.querySelector('#studentView .tech-panel');
         if(panel) {
             const oldBoxShadow = panel.style.boxShadow;
             const oldBorderColor = panel.style.borderColor;
             panel.style.boxShadow = `0 0 50px ${uiColor}`;
             panel.style.borderColor = uiColor;
             setTimeout(() => {
                 panel.style.boxShadow = oldBoxShadow;
                 panel.style.borderColor = oldBorderColor;
             }, 800);
         }
      },
      loadStudentData(uid, mode) { return studentApi.loadStudentData.apply(this, arguments);; },
      checkDebuffRecovery(data) { return studentApi.checkDebuffRecovery.apply(this, arguments);; },
      refreshStudentRewardPanel(dataObj = null, forceStudentPanel = false) { return studentApi.refreshStudentRewardPanel.apply(this, arguments);; },
      async showRanking() {
        UI.showModal('rankingModal');
        const tbody = document.getElementById('rankingTableBody');
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">載入榜單中...</td></tr>';

        try {
          const snapshot = await getDocs(collection(db, COLLECTION_NAME));
          let students = [];
          snapshot.forEach(doc => { students.push(this.applyDataMigration(doc.data())); });

          students.sort((a, b) => { 
             const aProg = this.computeTrainerProgress(a);
             const bProg = this.computeTrainerProgress(b);
             const aRank = Math.max(Number(a.trainerRankIndex)||0, aProg.rankIndex);
             const bRank = Math.max(Number(b.trainerRankIndex)||0, bProg.rankIndex);
             if (bRank !== aRank) return bRank - aRank;
             const aLegPts = (a.collection||[]).filter(i=>i.type==='legendary').reduce((s,i)=>s+(i.points||0), 0);
             const bLegPts = (b.collection||[]).filter(i=>i.type==='legendary').reduce((s,i)=>s+(i.points||0), 0);
             if (bLegPts !== aLegPts) return bLegPts - aLegPts;
             return b.totalXP - a.totalXP; 
          });
          students = students.slice(0, 30);

          tbody.innerHTML = '';
          if(students.length === 0) { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">目前尚無資料</td></tr>'; return; }

          const isUnsafeUrl = (u) => {
            const s = String(u || '');
            if (!s) return false;
            if (s.startsWith('data:')) return false;
            if (!/^https?:\/\//i.test(s)) return false;
            return !/firebasestorage\.googleapis\.com\/v0\/b\//i.test(s);
          };
          const safeImg = (u) => (isUnsafeUrl(u) ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : (u || CONSTANTS.MEDIA.PLACEHOLDER_SVG));

          students.forEach((st, idx) => {
            let rankClass = ''; if (idx === 0) rankClass = 'rank-1'; else if (idx === 1) rankClass = 'rank-2'; else if (idx === 2) rankClass = 'rank-3';

            const prog = this.computeTrainerProgress(st);
            const rankIdx = Math.max(Number(st.trainerRankIndex)||0, prog.rankIndex);
            const rankName = CONSTANTS.TRAINER_RANKS[rankIdx] || '新手學徒';

            const col = Array.isArray(st.collection) ? st.collection : [];

            let displayItems = [];
            if (Array.isArray(st.display_team) && st.display_team.length > 0) {
               displayItems = st.display_team
                 .map(v => col[Number(v)])
                 .filter(i => i && !(i.isHologram === true || i.isHologram === "true") && i.type !== 'dead_dragon' && (i.type === 'dragon' || i.type === 'legendary'));
            }
            if (displayItems.length === 0) {
               displayItems = col
                 .filter(i => i && !(i.isHologram === true || i.isHologram === "true") && i.type !== 'dead_dragon' && (i.type === 'dragon' || i.type === 'legendary'))
                 .slice(-5);
            }

            let collectionHtml = '<div style="display:flex; gap:5px; flex-wrap:wrap;">';
            const escAttr = (v) => String(v || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
            const isHttp = (v) => /^https?:\/\//i.test(String(v || ''));
            if (displayItems.length > 0) {
               displayItems.forEach(item => {
                 const title = escAttr(item?.name || '');
                 if(item.type === 'legendary') {
                    const url = isHttp(item.img) ? safeImg(item.img) : CONSTANTS.MEDIA.PLACEHOLDER_SVG;
                    const assetKey = (!isHttp(item.img) && (item.img || item.img_file)) ? escAttr(item.img || item.img_file) : (item.img_file ? escAttr(item.img_file) : '');
                    collectionHtml += `<img src="${url}" ${assetKey ? `data-asset="${assetKey}"` : ''} style="width:35px; height:35px; object-fit:contain; filter:drop-shadow(0 0 3px var(--legendary-gold)); border:1px solid var(--legendary-gold); border-radius:5px; background:rgba(255,183,0,0.1);" title="${title || '稀有異獸'}">`;
                 } else if (item.type === 'dragon') {
                    const info = CONSTANTS.ATTRIBUTES[item.element] || { color: 'var(--cyan)', name: '?' };
                    const url = isHttp(item.img) ? safeImg(item.img) : CONSTANTS.MEDIA.PLACEHOLDER_SVG;
                    const assetKey = (!isHttp(item.img) && (item.img || item.img_file)) ? escAttr(item.img || item.img_file) : (item.img_file ? escAttr(item.img_file) : '');
                    collectionHtml += `<img src="${url}" ${assetKey ? `data-asset="${assetKey}"` : ''} style="width:35px; height:35px; object-fit:contain; filter:drop-shadow(0 0 2px ${info.color}); border:1px solid rgba(255,255,255,0.2); border-radius:5px; background:rgba(0,0,0,0.5);" title="${title || (info.name + '系龍獸')}">`;
                 }
               });
            } else { collectionHtml += '<span style="color:#555; font-size:0.8em;">無展示資料</span>'; }
            collectionHtml += '</div>';

            const legPts = (col||[]).filter(i=>i.type==='legendary').reduce((s,i)=>s+(i.points||0), 0);

            tbody.innerHTML += `
              <tr>
                <td class="${rankClass}">#${idx + 1}</td>
                <td>
                  <div style="font-weight:bold; font-family:'Noto Sans TC'; font-size:1.1em;">${st.name}</div>
                  <div class="tech-font" style="font-size:0.75em; color:var(--text-muted);">${st.class_name}</div>
                </td>
                <td class="tech-font">
                  <span class="badge" style="border-color:var(--cyan); color:var(--cyan); margin-bottom:4px; display:inline-block;">${rankName}</span><br>
                  ${legPts > 0 ? `<span style="color:var(--legendary-gold); font-size:0.85em;">★ ${legPts} pts</span><br>` : ''}
                  <span style="font-size:0.85em; color:#ccc;">${st.totalXP} 點總能量</span>
                </td>
                <td>${collectionHtml}</td>
              </tr>
            `;
          });
          // 讓排行榜中的封存圖示也能用 Storage downloadURL 正確顯示
          hydrateStorageImages(tbody);
        } catch (e) { console.error(e); tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red;">讀取失敗</td></tr>'; }
      },

      prepareAction(attr, baseVal, desc) { return teacherActionsApi.prepareAction.apply(this, arguments); },
      prepareActionFromButton(buttonEl) { return teacherActionsApi.prepareActionFromButton.apply(this, arguments); },

      async commitAction() { return teacherActionsApi.commitAction.apply(this, arguments); },

      processEvolution(data) {
        data.totalXP = Number(data.totalXP) || 0;
        data.coins = Number(data.coins) || 0;
        data.lap = Number(data.lap) || 1;

        // 五行屬性初始化（兼容舊資料）
        if (!data.attributes) data.attributes = {};
        if (!data.streaks) data.streaks = {};
        for (const k of ELEMENT_KEYS) {
          data.attributes[k] = Number(data.attributes[k]) || 0;
          data.streaks[k] = Number(data.streaks[k]) || 0;
        }

        // 龍獸成長：每滿 100 XP 進行一次階段升級（Frozen 會阻擋升級）
        while (data.totalXP >= 100) {
          if (data.debuffs?.Frozen > 0) {
            data.logs.push({ timestamp: Date.now(), action_type: 'system', detail: '因【冰凍】影響無法成長升級。' });
            break;
          }

          const overflowXP = data.totalXP - 100;
          const maxEl = getDominantElementFromData(data);

          // 初始化階段
          let stageIdx = Number(data.dragon_stage);
          if (!Number.isFinite(stageIdx)) stageIdx = -1;
          const beforeStage = stageIdx;

          // ★ 新規則：
          // - 每滿 100 XP 更換一次型態/圖片
          // - 但只有「已成年(2) 且再次滿 100」才會：
          //   1) 把最終型態封存到收藏區
          //   2) 重置為新的初始龍蛋
          const isAdultFull = stageIdx >= 2;

          // 進化階段推進（成年期滿載不在這裡變更 stage，而是在後面重置）
          if (stageIdx < 0) {
            // 第一次滿 100：決定破殼方向（依當下最高屬性）
            data.dragon_path = maxEl;      // 以屬性作為路線 key
            data.dragon_stage = 0;         // 0=破殼期
          } else if (stageIdx < 2) {
            data.dragon_stage = stageIdx + 1; // 1=成長期, 2=成年期
          } else {
            data.dragon_stage = 2; // 已成年：維持成年期，等「滿載」結算後才重置新蛋
          }

          const afterStage = Number(data.dragon_stage);
          const didStageChange = afterStage !== beforeStage;

          // 訓練家階級 / 兌幣比例（沿用舊系統）
          const prog = this.computeTrainerProgress(data);
          const storedRank = Number(data.trainerRankIndex);
          const rankIdx = Math.max(Number.isFinite(storedRank) ? storedRank : 0, prog.rankIndex);
          data.trainerRankIndex = rankIdx;

          const rateFromRank = this.getRateFromRankIndex(rankIdx);
          const rateFromLap = this.getRateFromLap(data.lap);
          data.best_rate = Number(data.best_rate);
          if (!Number.isFinite(data.best_rate)) data.best_rate = 99;
          data.best_rate = Math.min(data.best_rate, rateFromRank, rateFromLap);

          let rate = Math.min(rateFromRank, data.best_rate);
          if (data.debuffs?.Paralyzed > 0) rate *= Math.pow(2, data.debuffs.Paralyzed);
          const coinsEarned = Math.floor(100 / rate);

          data.coins += coinsEarned;

          const vis = getDragonVisual(data);
          if (!data.collection) data.collection = [];

          // 封存規則：
          // - 破殼期/成長期：進化當下封存
          // - 成年期：改為「成年期滿載」才封存最終型態
          if (didStageChange && afterStage !== 2) {
            data.collection.push({
              type: 'dragon',
              element: maxEl,
              path: data.dragon_path,
              stage: data.dragon_stage,
              name: vis.name,
              img_file: vis.file,
              img: '',
              stats: { ...data.attributes },
              timestamp: Date.now()
            });
          }

          if (didStageChange && afterStage === 2 && Array.isArray(data.hidden_eggs) && data.hidden_eggs.length > 0) {
            const remainingEggs = [];
            for (const egg of data.hidden_eggs) {
              const eggMeta = CONSTANTS.HIDDEN_EGGS[egg.hiddenEggId || egg.id] || egg;
              if (eggMeta && eggMeta.requiredAttr === maxEl) {
                data.collection = Array.isArray(data.collection) ? data.collection : [];
                data.collection = data.collection.filter(item => !(item.type === 'hidden_egg' && String(item.id || item.hiddenEggId || '') === String(egg.id || egg.hiddenEggId || '')));
                const legendaryName = eggMeta.beastName || String(eggMeta.name || '').replace(/蛋$/, '');
                const legendaryImg = eggMeta.legendaryImg || (eggMeta.forms && eggMeta.forms.adult) || eggMeta.img;
                data.collection.push({ type: 'legendary', name: legendaryName, img: legendaryImg, points: Number(eggMeta.points) || 0, hiddenEggId: eggMeta.id || egg.hiddenEggId || '', element: maxEl, timestamp: Date.now() });
                if (String(data.active_hidden_egg_id || '') === String(eggMeta.id || egg.hiddenEggId || '')) {
                  data.active_hidden_egg_id = '';
                  data.active_hidden_egg = null;
                }
                data.logs.push({ timestamp: Date.now(), action_type: 'legendary', detail: `[特殊異獸蛋] ${eggMeta.name} 養成完成，轉化為隱藏異獸 ${legendaryName}（★${Number(eggMeta.points) || 0}）` });
              } else {
                remainingEggs.push(egg);
              }
            }
            data.hidden_eggs = remainingEggs;
          }

          if (isAdultFull) {
            // 成年期滿載：封存最終型態異獸 → 取得新蛋（重置）
            data.collection.push({
              type: 'dragon',
              element: maxEl,
              path: data.dragon_path,
              stage: 2,
              name: vis.name,
              img_file: vis.file,
              img: '',
              stats: { ...data.attributes },
              timestamp: Date.now(),
              isFinal: true
            });

            // 重置成新的初始龍蛋
            data.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
            data.streaks = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
            data.attr_event_counts = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
            data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
            data.debuffs_timestamp = null;

            data.dragon_stage = -1;
            data.dragon_path = null;

            data.logs.push({ timestamp: Date.now(), action_type: 'evolution', detail: `成年期滿載：${vis.name} 已封存，獲得新的初始龍蛋 (+${coinsEarned}🪙)` });

            // 新蛋從 0 開始（避免 overflow 造成新蛋一出現就帶著 XP 但屬性已被重置）
            data.totalXP = 0;
          } else {
            data.logs.push({ timestamp: Date.now(), action_type: 'evolution', detail: `成長：${vis.name} (+${coinsEarned}🪙)` });
            data.totalXP = overflowXP;
          }
        }

        return data;
      },

      
      // --- 商城（兌換）---
      // 修正：允許先打開商城（例如剛切換學生、資料尚未 onSnapshot 回來時），並在資料到位後自動解鎖按鈕
      async openShop() {
        const coinsEl = document.getElementById('shopCoins');
        UI.showModal('shopModal');
        const hasStudent = !!currentState.studentData;
        if (coinsEl) coinsEl.innerText = hasStudent ? (currentState.studentData.coins || 0) : '...';
        await this.renderShopItems();
        if (!hasStudent) {
          if (currentState.currentUid) UI.toast('⏳ 學生資料載入中…');
          else UI.alert('請先掃描學生卡或查詢卡序，載入學生資料後才能兌換。', '需要學生資料');
        }
      },

      async applyShopEffect(data, itemMeta, cost) {
        if (itemMeta.effectType === 'physical_reward') {
          const ok = await UI.confirm(`${itemMeta.name || '實體商品'}
需要在老師面前購買才能獲得，否則不算數。

請確認你正在老師面前購買？`, '實體獎勵確認');
          if (!ok) return { applied: false };
          data.coins -= cost;
          data.collection = Array.isArray(data.collection) ? data.collection : [];
          const voucherTs = Date.now();
          const voucher = {
            type: 'voucher',
            voucherId: `voucher_${String(itemMeta.id || 'item').replace(/[^a-zA-Z0-9_-]/g, '')}_${voucherTs}`,
            itemId: String(itemMeta.id || ''),
            name: itemMeta.name || '實體商品兌換憑證',
            desc: itemMeta.desc || '請向老師出示此憑證兌換實體物品。',
            img: itemMeta.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG,
            status: 'active',
            purchasedAt: voucherTs,
            redeemedAt: null,
            redeemedBy: null,
            stats: { ...(data.attributes || {}) },
            timestamp: voucherTs
          };
          data.collection.push(voucher);
          data.logs.push({ timestamp: voucherTs, action_type: 'shop', detail: `購買${itemMeta.name || '實體商品'}（已建立兌換憑證）` });
          const saved = await this.saveToDB(data);
          if (!saved) { UI.alert('購買已送出，但憑證建立失敗，請通知老師確認。', '系統通知'); return { applied: false }; }
          UI.hideModal('shopModal');
          UI.alert(`已建立「${itemMeta.name || '實體商品'}」的購買憑證，請到收藏區出示給老師兌現。`, '已建立憑證');
          return { applied: true };
        }
        if (itemMeta.effectType === 'antidote') {
          data.coins -= cost;
          data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 };
          data.debuffs_timestamp = null;
          data.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `購買${itemMeta.name || '萬靈藥'}` });
          await this.saveToDB(data);
          UI.hideModal('shopModal');
          return { applied: true };
        }
        if (itemMeta.effectType === 'evo_stone') {
          UI.hideModal('shopModal');
          document.getElementById('attrSelectTitle').innerText = '選擇目標屬性';
          UI.showModal('attrSelectModal');
          document.getElementById('confirmAttrSelectBtn').onclick = async () => {
            let freshData = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || data)));
            const selectedAttr = document.getElementById('attrSelectDropdown').value;
            if ((Number(freshData.coins) || 0) < cost) { UI.alert('餘額不足！', '交易失敗'); return; }
            freshData.coins -= cost;
            freshData.totalXP += 30;
            addAttributeXP(freshData, selectedAttr, 30);
            freshData.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `${itemMeta.name || '進化石'}（${CONSTANTS.ATTRIBUTES[selectedAttr].name} +30 XP）` });
            freshData = this.processEvolution(freshData);
            await this.saveToDB(freshData);
            UI.hideModal('attrSelectModal');
            UI.toast('交易完成');
            await this.renderShopItems();
          };
          return { applied: true, deferred: true };
        }
        if (itemMeta.effectType === 'wonder_stone') {
          UI.hideModal('shopModal');
          document.getElementById('attrSelectTitle').innerText = '選擇進化目標';
          UI.showModal('attrSelectModal');
          document.getElementById('confirmAttrSelectBtn').onclick = async () => {
            let freshData = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData || data)));
            const selectedAttr = document.getElementById('attrSelectDropdown').value;
            if ((Number(freshData.coins) || 0) < cost) { UI.alert('餘額不足！', '交易失敗'); return; }
            freshData.coins -= cost;
            freshData.collection = Array.isArray(freshData.collection) ? freshData.collection : [];
            freshData.collection.push({ type: 'material', element: selectedAttr, name: `${CONSTANTS.ATTRIBUTES[selectedAttr].name}系素材`, img: CONSTANTS.MEDIA.PLACEHOLDER_SVG, stats: { ...freshData.attributes }, timestamp: Date.now() });
            freshData.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `${itemMeta.name || '進化奇石'}（${CONSTANTS.ATTRIBUTES[selectedAttr].name}系素材）` });
            await this.saveToDB(freshData);
            UI.hideModal('attrSelectModal');
            UI.toast('交易完成');
            await this.renderShopItems();
          };
          return { applied: true, deferred: true };
        }
        if (itemMeta.effectType === 'hidden_egg') {
          const eggMeta = CONSTANTS.HIDDEN_EGGS[itemMeta.hiddenEggId || ''];
          if (!eggMeta) { UI.alert('此特殊異獸蛋尚未設定完成。', '商品設定錯誤'); return { applied: false }; }
          data.coins -= cost;
          data.hidden_eggs = Array.isArray(data.hidden_eggs) ? data.hidden_eggs : [];
          data.collection = Array.isArray(data.collection) ? data.collection : [];
          const eggRecord = { type: 'hidden_egg', id: `${eggMeta.id}_${Date.now()}`, hiddenEggId: eggMeta.id, name: eggMeta.name, beastName: eggMeta.beastName || '', img: eggMeta.img, forms: eggMeta.forms || null, requiredAttr: eggMeta.requiredAttr, points: eggMeta.points, status: 'incubating', stats: { ...data.attributes }, timestamp: Date.now() };
          data.hidden_eggs.push(eggRecord);
          data.collection.push({ ...eggRecord });
          if (!String(data.active_hidden_egg_id || '').trim()) {
            data.active_hidden_egg_id = eggMeta.id;
            data.active_hidden_egg = { ...eggRecord, status: 'active', activatedAt: Date.now() };
          }
          data.logs.push({ timestamp: Date.now(), action_type: 'shop', detail: `購買特殊異獸蛋：${eggMeta.name}（需求屬性：${CONSTANTS.ATTRIBUTES[eggMeta.requiredAttr]?.name || eggMeta.requiredAttr}）` });
          await this.saveToDB(data);
          UI.hideModal('shopModal');
          return { applied: true };
        }
        UI.alert('此商品功能尚未支援。', '商品設定錯誤');
        return { applied: false };
      },

async handleShopPurchase(itemId, cost, isBuiltIn = false) {
        if (!currentState.studentData) { UI.alert('請先掃描學生卡或查詢卡序，載入學生資料後才能兌換。', '需要學生資料'); return; }
        let data = this.applyDataMigration(JSON.parse(JSON.stringify(currentState.studentData)));
        data.coins = Number(data.coins) || 0;
        let itemMeta = null;
        let itemRef = null;

        if (isBuiltIn) {
          itemMeta = this.getBuiltInShopItems().find(x => x.id === itemId);
        } else {
          itemRef = doc(db, SHOP_COLLECTION, itemId);
          const snap = await getDoc(itemRef);
          if (!snap.exists()) { UI.alert('此商品已下架。', '交易失敗'); await this.renderShopItems(); return; }
          const d = snap.data() || {};
          itemMeta = { id: itemId, builtIn: false, ...d, cost: Number(d.cost) || 0, quantity: Math.max(0, Number(d.quantity) || 0) };
          cost = itemMeta.cost;
          if (itemMeta.active === false) { UI.alert('此商品尚未上架。', '交易失敗'); await this.renderShopItems(); return; }
          if (itemMeta.quantity <= 0) { UI.alert('此商品已售罄。', '交易失敗'); await this.renderShopItems(); return; }
        }
        if (!itemMeta) { UI.alert('找不到商品資料。', '交易失敗'); return; }
        if (data.coins < cost) { UI.alert('您目前的金幣餘額不足！', '交易失敗'); return; }

        const effectResult = await this.applyShopEffect(data, itemMeta, cost);
        if (!effectResult || !effectResult.applied) return;

        if (!isBuiltIn && itemRef && !effectResult.deferred) {
          try {
            const latest = await getDoc(itemRef);
            if (latest.exists()) {
              const q = Math.max(0, Number(latest.data().quantity) || 0);
              await updateDoc(itemRef, { quantity: Math.max(0, q - 1), updatedAt: Date.now() });
            }
          } catch (e) {
            console.warn('[shop] quantity update failed:', e);
          }
        }
        if (!effectResult.deferred) {
          UI.toast('交易完成');
          await this.renderShopItems();
        }
      },

      async redeemCollectionVoucher(index) {
        if (!currentState.studentData) return;
        let data = JSON.parse(JSON.stringify(currentState.studentData));
        data.collection = Array.isArray(data.collection) ? data.collection : [];
        const item = data.collection[index];
        if (!item || item.type !== 'voucher') return;
        if (item.status === 'redeemed') return UI.toast('此憑證已兌現');
        const ok = await UI.confirm(`確定將「${item.name || '兌換憑證'}」標記為已兌現嗎？

兌現後，學生收藏區將不再顯示此憑證。`, '老師兌現確認');
        if (!ok) return;
        item.status = 'redeemed';
        item.redeemedAt = Date.now();
        item.redeemedBy = auth.currentUser?.email || auth.currentUser?.uid || 'teacher';
        data.logs = Array.isArray(data.logs) ? data.logs : [];
        data.logs.push({ timestamp: Date.now(), action_type: 'voucher_redeem', detail: `[老師兌現] ${item.name || '兌換憑證'} 已完成領取` });
        const saved = await this.saveToDB(data);
        if (!saved) { UI.alert('兌現失敗，請稍後再試。', '系統通知'); return; }
        currentState.studentData = this.applyDataMigration(saved);
        UI.hideModal('archiveModal');
        UI.updatePanel(currentState.studentData, currentState.viewMode !== 'student');
        UI.toast('已完成兌現');
      },
      checkDeathTrigger(data, triggerStatusKey) { return teacherActionsApi.checkDeathTrigger.apply(this, arguments); },

      async forceDebuff(statusName) { return teacherActionsApi.forceDebuff.apply(this, arguments); },

      async punishHacker() {
        if (!currentState.hackerUid) return; const docRef = doc(db, COLLECTION_NAME, currentState.hackerUid); const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
           let data = docSnap.data(); data.totalXP = 0; for(let k in data.attributes) data.attributes[k] = 0; data.debuffs = { Poison: 0, Frozen: 0, Paralyzed: 0, Confusion: 0 }; data.debuffs_timestamp = null; data.dragon_stage = -1; data.dragon_path = null;
           data.collection.push({ type: `dead_dragon`, cause: 'Poison', stats: {fire:0,electric:0,water:0,psychic:0,dark:0,grass:0,ice:0,fairy:0}, timestamp: Date.now() });
           data.logs.push({timestamp: Date.now(), action_type: 'system', detail: `[防護] 偵測未授權操作，死神制裁經驗歸零！`}); await this.saveToDB(data, currentState.hackerUid); UI.hideModal('hackerAlertModal'); UI.toast('✅ 已制裁。'); currentState.hackerUid = null;
        }
      },

      async rollbackHacker() {
        if (!currentState.hackerUid) return; const oldData = currentState.previousStudentsData[currentState.hackerUid];
        if (oldData) { oldData.logs.push({timestamp: Date.now(), action_type: 'system', detail: `[防護] 已攔截異常經驗。`}); await this.saveToDB(oldData, currentState.hackerUid); UI.hideModal('hackerAlertModal'); UI.toast('🔙 已撤銷。'); currentState.hackerUid = null; }
      },

      resetQuizForm() {
        const formTitle = document.getElementById('qmFormTitle');
        const editId = document.getElementById('qmEditId');
        const saveBtn = document.getElementById('qmSaveBtn');
        const cancelBtn = document.getElementById('qmCancelEditBtn');
        if (formTitle) formTitle.innerText = '[ 新增題目 ]';
        if (editId) editId.value = '';
        if (saveBtn) {
          saveBtn.innerText = '儲存題目';
          saveBtn.setAttribute('onclick', 'App.saveNewQuiz()');
        }
        if (cancelBtn) cancelBtn.classList.add('hidden');
        const grade = document.getElementById('qmGrade');
        const unit = document.getElementById('qmUnit');
        const question = document.getElementById('qmQuestion');
        const opts = [0, 1, 2, 3].map(i => document.getElementById(`qmOpt${i}`));
        if (grade) grade.value = '5上';
        if (unit) unit.value = '';
        if (question) question.value = '';
        opts.forEach(el => { if (el) el.value = ''; });
        const firstRadio = document.querySelector('input[name="qmCorrect"][value="0"]');
        if (firstRadio) firstRadio.checked = true;
      },

      fillQuizForm(quizId, quizData = {}) {
        const formTitle = document.getElementById('qmFormTitle');
        const editId = document.getElementById('qmEditId');
        const saveBtn = document.getElementById('qmSaveBtn');
        const cancelBtn = document.getElementById('qmCancelEditBtn');
        if (formTitle) formTitle.innerText = '[ 修改題目 EDIT ENTRY ]';
        if (editId) editId.value = quizId || '';
        if (saveBtn) {
          saveBtn.innerText = 'UPDATE ENTRY (儲存修改)';
          saveBtn.setAttribute('onclick', 'App.saveEditedQuiz()');
        }
        if (cancelBtn) cancelBtn.classList.remove('hidden');
        const gradeEl = document.getElementById('qmGrade');
        const unitEl = document.getElementById('qmUnit');
        const questionEl = document.getElementById('qmQuestion');
        if (gradeEl) gradeEl.value = quizData.grade || '5上';
        if (unitEl) unitEl.value = quizData.unit || '';
        if (questionEl) questionEl.value = quizData.question || '';
        const options = Array.isArray(quizData.options) ? quizData.options : [];
        for (let i = 0; i < 4; i++) {
          const opt = options[i] || {};
          const input = document.getElementById(`qmOpt${i}`);
          if (input) input.value = opt.text || '';
          const radio = document.querySelector(`input[name="qmCorrect"][value="${i}"]`);
          if (radio) radio.checked = !!opt.isCorrect;
        }
        if (!Array.from(document.querySelectorAll('input[name="qmCorrect"]')).some(r => r.checked)) {
          const firstRadio = document.querySelector('input[name="qmCorrect"][value="0"]');
          if (firstRadio) firstRadio.checked = true;
        }
        const box = document.getElementById('quizManagerModal')?.querySelector('.modal-content');
        if (box) box.scrollTo({ top: 0, behavior: 'smooth' });
      },

      async openEditQuiz(id) {
        try {
          const snap = await getDoc(doc(db, 'quiz_bank', id));
          if (!snap.exists()) {
            UI.toast('找不到題目資料');
            return;
          }
          this.fillQuizForm(id, snap.data());
        } catch (e) {
          console.error(e);
          UI.toast('讀取題目失敗');
        }
      },

      cancelQuizEdit() {
        this.resetQuizForm();
      },

      readQuizFormData() {
        const qGrade = document.getElementById('qmGrade')?.value || '5上';
        const qUnit = document.getElementById('qmUnit')?.value.trim() || '未分類';
        const qText = document.getElementById('qmQuestion')?.value.trim() || '';
        const opts = [0, 1, 2, 3].map(i => (document.getElementById(`qmOpt${i}`)?.value || '').trim());
        const checked = document.querySelector('input[name="qmCorrect"]:checked');
        const correctVal = checked ? String(checked.value) : '0';
        if (!qText || opts.some(v => !v)) {
          UI.toast('請填寫完整題目！');
          return null;
        }
        return {
          grade: qGrade,
          unit: qUnit,
          question: qText,
          options: opts.map((text, idx) => ({ text, isCorrect: correctVal === String(idx) })),
        };
      },

      async importQuizBulk() {
        const textarea = document.getElementById('qmBulkImport');
        const raw = (textarea?.value || '').trim();
        if (!raw) {
          UI.toast('請先貼上題庫內容');
          return;
        }

        const entries = [];
        try {
          if (raw.startsWith('[')) {
            const parsed = JSON.parse(raw);
            if (!Array.isArray(parsed)) throw new Error('JSON 必須是陣列');
            parsed.forEach((item, idx) => {
              const options = Array.isArray(item.options) ? item.options : [];
              if (!item.question || options.length < 4) throw new Error(`第 ${idx + 1} 筆 JSON 格式不完整`);
              let answerIndex = 0;
              if (typeof item.answer === 'number') {
                answerIndex = item.answer >= 1 && item.answer <= 4 ? item.answer - 1 : item.answer;
              }
              const normalizedOptions = options.slice(0, 4).map((opt, optIdx) => {
                if (typeof opt === 'string') return { text: opt.trim(), isCorrect: optIdx === answerIndex };
                return { text: String(opt?.text || '').trim(), isCorrect: !!opt?.isCorrect || optIdx === answerIndex };
              });
              entries.push({
                grade: String(item.grade || '5上').trim(),
                unit: String(item.unit || '未分類').trim(),
                question: String(item.question || '').trim(),
                options: normalizedOptions,
                isActive: item.isActive === true,
              });
            });
          } else {
            const lines = raw.split(/\r?\n/).map(v => v.trim()).filter(Boolean);
            lines.forEach((line, idx) => {
              const cols = line.split('\t');
              if (cols.length < 8) throw new Error(`第 ${idx + 1} 行欄位不足，需 8 欄`);
              const [grade, unit, question, o1, o2, o3, o4, answerRaw] = cols;
              const answer = Number(String(answerRaw).trim());
              if (!(answer >= 1 && answer <= 4)) throw new Error(`第 ${idx + 1} 行正解需填 1-4`);
              entries.push({
                grade: String(grade || '5上').trim(),
                unit: String(unit || '未分類').trim(),
                question: String(question || '').trim(),
                options: [o1, o2, o3, o4].map((txt, optIdx) => ({ text: String(txt || '').trim(), isCorrect: optIdx === answer - 1 })),
                isActive: false,
              });
            });
          }

          const valid = entries.filter(item => item.question && Array.isArray(item.options) && item.options.length === 4 && item.options.every(opt => opt.text));
          if (!valid.length) {
            UI.toast('沒有可匯入的有效題目');
            return;
          }

          for (const item of valid) {
            await addDoc(collection(db, 'quiz_bank'), { ...item, timestamp: Date.now() });
          }
          UI.toast(`✅ 已匯入 ${valid.length} 題`);
          if (textarea) textarea.value = '';
          await this.loadQuizBank();
        } catch (e) {
          console.error(e);
          UI.alert(`匯入失敗：${e.message || e}`, '題庫匯入失敗');
        }
      },

      async exportQuizBank(format = 'json') {
        if (currentState.quizExporting) {
          UI.toast('題庫下載準備中，請稍候...');
          return;
        }
        currentState.quizExporting = true;
        try {
          const snapshot = await getDocs(collection(db, 'quiz_bank'));
          const quizzes = [];
          snapshot.forEach(docSnap => {
            if (docSnap.id !== '_BATTLE_TOWER_BOSS_') quizzes.push({ id: docSnap.id, ...docSnap.data() });
          });
          if (!quizzes.length) {
            UI.toast('題庫為空，無法下載');
            return;
          }
          quizzes.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

          if (String(format).toLowerCase() === 'csv') {
            const rows = [[
              'id', 'grade', 'unit', 'question', 'option1', 'option2', 'option3', 'option4', 'answer', 'isActive', 'timestamp'
            ]];
            quizzes.forEach(q => {
              const options = Array.isArray(q.options) ? q.options : [];
              let answerIndex = options.findIndex(opt => !!opt?.isCorrect);
              if (answerIndex < 0) answerIndex = 0;
              rows.push([
                q.id || '',
                q.grade || '',
                q.unit || '',
                q.question || '',
                options[0]?.text || '',
                options[1]?.text || '',
                options[2]?.text || '',
                options[3]?.text || '',
                String(answerIndex + 1),
                q.isActive === true ? 'true' : 'false',
                q.timestamp || ''
              ]);
            });
            downloadCsvFile(`quiz_bank_${formatLocalDateKey()}.csv`, rows);
          } else {
            const payload = quizzes.map(q => ({
              id: q.id || '',
              grade: q.grade || '',
              unit: q.unit || '',
              question: q.question || '',
              options: Array.isArray(q.options) ? q.options.map(opt => ({
                text: String(opt?.text || ''),
                isCorrect: !!opt?.isCorrect
              })) : [],
              isActive: q.isActive === true,
              timestamp: q.timestamp || null,
              updatedAt: q.updatedAt || null
            }));
            downloadTextFile(`quiz_bank_${formatLocalDateKey()}.json`, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8;');
          }
          UI.toast(`⬇️ 題庫已下載（${String(format).toUpperCase()}）`);
        } catch (e) {
          console.error(e);
          UI.alert(`題庫下載失敗：${e.message || e}`, '題庫下載失敗');
        } finally {
          currentState.quizExporting = false;
        }
      },

      updateQuizSelectionSummary(visibleIds = null) {
        const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
        const counter = document.getElementById('qmSelectedCount');
        if (counter) counter.innerText = `已勾選 ${selectedIds.length} 題`;

        const allCheckbox = document.getElementById('qmSelectAll');
        if (allCheckbox) {
          const visible = Array.isArray(visibleIds) ? visibleIds : [];
          const selectedVisible = visible.filter(id => selectedIds.includes(id)).length;
          allCheckbox.checked = visible.length > 0 && selectedVisible === visible.length;
          allCheckbox.indeterminate = selectedVisible > 0 && selectedVisible < visible.length;
        }
      },

      updateQuizFilterState() {
        const quizzes = Array.isArray(currentState.quizBankCache) ? currentState.quizBankCache : [];
        const gradeSelect = document.getElementById('qmFilterGrade');
        const unitSelect = document.getElementById('qmFilterUnit');
        if (!gradeSelect || !unitSelect) return;

        const gradeOrder = ['1上','1下','2上','2下','3上','3下','4上','4下','5上','5下','6上','6下','學習扶助班'];
        const gradeRank = (g) => {
          const idx = gradeOrder.indexOf(String(g || ''));
          return idx >= 0 ? idx : 999;
        };

        const gradeValue = gradeSelect.value;
        const grades = Array.from(new Set(quizzes.map(q => String(q.grade || '').trim()).filter(Boolean)))
          .sort((a, b) => gradeRank(a) - gradeRank(b) || String(a).localeCompare(String(b), 'zh-Hant'));

        gradeSelect.innerHTML = '<option value="">全部年級</option>' + grades.map(g => `<option value="${g}">${g}</option>`).join('');
        gradeSelect.value = grades.includes(gradeValue) ? gradeValue : '';

        const filteredForUnit = quizzes.filter(q => !gradeSelect.value || String(q.grade || '').trim() === gradeSelect.value);
        const unitValue = unitSelect.value;
        const units = Array.from(new Set(filteredForUnit.map(q => String(q.unit || '未分類').trim() || '未分類')))
          .sort((a, b) => String(a).localeCompare(String(b), 'zh-Hant'));
        unitSelect.innerHTML = '<option value="">全部單元</option>' + units.map(u => `<option value="${u}">${u}</option>`).join('');
        unitSelect.value = units.includes(unitValue) ? unitValue : '';
      },

      getFilteredQuizzes() {
        const quizzes = Array.isArray(currentState.quizBankCache) ? currentState.quizBankCache : [];
        const gradeValue = document.getElementById('qmFilterGrade')?.value || '';
        const unitValue = document.getElementById('qmFilterUnit')?.value || '';
        return quizzes.filter(q => {
          const gradeOk = !gradeValue || String(q.grade || '').trim() === gradeValue;
          const unitOk = !unitValue || String(q.unit || '未分類').trim() === unitValue;
          return gradeOk && unitOk;
        });
      },

      toggleQuizSelection(id, checked) {
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        if (checked) selected.add(id);
        else selected.delete(id);
        currentState.quizSelectedIds = Array.from(selected);
        const visibleIds = this.getFilteredQuizzes().map(q => q.id);
        this.updateQuizSelectionSummary(visibleIds);
      },

      toggleAllQuizSelections(checked) {
        const visibleIds = this.getFilteredQuizzes().map(q => q.id);
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        visibleIds.forEach(id => {
          if (checked) selected.add(id);
          else selected.delete(id);
        });
        currentState.quizSelectedIds = Array.from(selected);
        this.renderQuizBankList();
      },

      renderQuizBankList() {
        const container = document.getElementById('quizListContainer');
        if (!container) return;

        const filtered = this.getFilteredQuizzes();
        const selected = new Set(Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : []);
        const visibleIds = filtered.map(q => q.id);
        const gradeOrder = ['1上','1下','2上','2下','3上','3下','4上','4下','5上','5下','6上','6下','學習扶助班'];
        const gradeRank = (g) => {
          const idx = gradeOrder.indexOf(String(g || ''));
          return idx >= 0 ? idx : 999;
        };

        if (!filtered.length) {
          container.innerHTML = '<div style="text-align:center; color:#555; padding:18px; border:1px dashed #355; border-radius:8px;">目前篩選條件下沒有題目。</div>';
          this.updateQuizSelectionSummary([]);
          return;
        }

        const grouped = {};
        filtered.forEach(q => {
          const grade = String(q.grade || '未分類').trim() || '未分類';
          const unit = String(q.unit || '未分類').trim() || '未分類';
          if (!grouped[grade]) grouped[grade] = {};
          if (!grouped[grade][unit]) grouped[grade][unit] = [];
          grouped[grade][unit].push(q);
        });

        const gradeKeys = Object.keys(grouped).sort((a, b) => gradeRank(a) - gradeRank(b) || String(a).localeCompare(String(b), 'zh-Hant'));
        container.innerHTML = gradeKeys.map(grade => {
          const units = Object.keys(grouped[grade]).sort((a, b) => String(a).localeCompare(String(b), 'zh-Hant'));
          const unitHtml = units.map(unit => {
            const cards = grouped[grade][unit].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0)).map(q => {
              const optionsHtml = Array.isArray(q.options) ? q.options.map((opt, i) => {
                const color = opt.isCorrect ? 'var(--color-grass)' : '#555';
                return `<span style="color:${color}; margin-right:10px; font-size:0.85em; display:inline-block; margin-bottom:4px;">${i + 1}. ${opt.text}</span>`;
              }).join('') : '';
              const activeColor = q.isActive ? 'var(--color-grass)' : '#555';
              const activeText = q.isActive ? '✅ 已派發' : '❌ 未開放';
              return `<div style="background:rgba(0,0,0,0.35); border:1px solid #333; border-radius:6px; padding:10px;">
                <div style="display:flex; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:8px; align-items:flex-start;">
                  <label style="display:flex; align-items:flex-start; gap:8px; flex:1; min-width:180px; color:#fff;">
                    <input type="checkbox" style="width:auto; margin-top:3px;" ${selected.has(q.id) ? 'checked' : ''} onchange="App.toggleQuizSelection('${q.id}', this.checked)" />
                    <span style="line-height:1.65;">${q.question}</span>
                  </label>
                  <button onclick="App.toggleQuizActive('${q.id}', ${q.isActive || false})" style="background:transparent; border:1px dashed ${activeColor}; color:${activeColor}; padding:2px 8px; border-radius:4px; cursor:pointer;">${activeText}</button>
                </div>
                <div style="margin-bottom:10px;">${optionsHtml}</div>
                <div style="text-align:right; display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap;">
                  <button onclick="App.openEditQuiz('${q.id}')" style="background:none; border:1px solid var(--cyan); border-radius:4px; padding:2px 8px; color:var(--cyan); cursor:pointer;">修改</button>
                  <button onclick="App.deleteQuiz('${q.id}')" style="background:none; border:1px solid var(--danger); border-radius:4px; padding:2px 8px; color:var(--danger); cursor:pointer;">刪除</button>
                </div>
              </div>`;
            }).join('');
            return `<div style="background:rgba(0,0,0,0.25); border:1px solid #233; border-radius:8px; padding:12px;">
              <div class="tech-font" style="color:var(--cyan); margin-bottom:10px;">${unit} <span style="color:var(--text-muted); font-size:0.85em;">(${grouped[grade][unit].length} 題)</span></div>
              <div style="display:flex; flex-direction:column; gap:10px;">${cards}</div>
            </div>`;
          }).join('');
          return `<div style="border:1px solid #355; border-radius:10px; padding:12px; background:rgba(0,20,30,0.25);">
            <div class="tech-font" style="color:var(--legendary-gold); margin-bottom:12px; font-size:1.05em;">${grade}</div>
            <div style="display:flex; flex-direction:column; gap:12px;">${unitHtml}</div>
          </div>`;
        }).join('');

        this.updateQuizSelectionSummary(visibleIds);
      },

      async batchSetQuizActive(active) {
        const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
        if (!selectedIds.length) {
          UI.toast('請先勾選要處理的題目');
          return;
        }
        const actionText = active ? '批次佈題' : '批次下架';
        const confirmed = await UI.confirm(`確定要對 ${selectedIds.length} 題執行「${actionText}」嗎？`, actionText);
        if (!confirmed) return;

        try {
          const batch = writeBatch(db);
          selectedIds.forEach(id => batch.update(doc(db, 'quiz_bank', id), { isActive: !!active, updatedAt: Date.now() }));
          await batch.commit();
          UI.toast(`✅ 已完成 ${actionText}`);
          await this.loadQuizBank();
        } catch (e) {
          console.error(e);
          UI.toast(`${actionText}失敗`);
        }
      },

      async batchDeleteSelectedQuizzes() {
        const selectedIds = Array.isArray(currentState.quizSelectedIds) ? currentState.quizSelectedIds : [];
        if (!selectedIds.length) {
          UI.toast('請先勾選要刪除的題目');
          return;
        }
        const confirmed = await UI.confirm(`確定要永久刪除 ${selectedIds.length} 題嗎？\n(此操作無法復原)`, '批次刪除確認');
        if (!confirmed) return;

        try {
          const batch = writeBatch(db);
          selectedIds.forEach(id => batch.delete(doc(db, 'quiz_bank', id)));
          await batch.commit();
          UI.toast(`🗑️ 已刪除 ${selectedIds.length} 題`);
          await this.loadQuizBank();
        } catch (e) {
          console.error(e);
          UI.toast('批次刪除失敗');
        }
      },

      async loadQuizBank() {
        UI.showModal('quizManagerModal');
        this.resetQuizForm();
        const container = document.getElementById('quizListContainer');
        if (container) container.innerHTML = '<div style="text-align:center;">載入中...</div>';
        currentState.quizSelectedIds = [];
        try {
          const snapshot = await getDocs(collection(db, 'quiz_bank'));
          const quizzes = [];
          snapshot.forEach(docSnap => { if (docSnap.id !== '_BATTLE_TOWER_BOSS_') quizzes.push({ id: docSnap.id, ...docSnap.data() }); });
          currentState.quizBankCache = quizzes;
          document.getElementById('qmTotalCount').innerText = quizzes.length;
          if (quizzes.length === 0) {
            if (container) container.innerHTML = '<div style="text-align:center; color:#555;">題庫為空！</div>';
            this.updateQuizFilterState();
            this.updateQuizSelectionSummary([]);
            return;
          }
          quizzes.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          this.updateQuizFilterState();
          this.renderQuizBankList();
        } catch (e) {
          console.error(e);
          currentState.quizBankCache = [];
          if (container) container.innerHTML = '<div style="text-align:center; color:var(--danger);">題庫載入失敗</div>';
          this.updateQuizSelectionSummary([]);
        }
      },

      async saveNewQuiz() {
        const formData = this.readQuizFormData();
        if (!formData) return;
        const newQuiz = { ...formData, isActive: false, timestamp: Date.now() };
        try {
          await addDoc(collection(db, 'quiz_bank'), newQuiz);
          UI.toast('✅ 新增成功！');
          this.resetQuizForm();
          await this.loadQuizBank();
        } catch(e) {
          console.error(e);
          UI.toast('新增失敗');
        }
      },

      async saveEditedQuiz() {
        const editId = document.getElementById('qmEditId')?.value;
        if (!editId) {
          UI.toast('找不到要修改的題目');
          return;
        }
        const formData = this.readQuizFormData();
        if (!formData) return;
        try {
          const oldSnap = await getDoc(doc(db, 'quiz_bank', editId));
          const oldData = oldSnap.exists() ? oldSnap.data() : {};
          await updateDoc(doc(db, 'quiz_bank', editId), {
            ...formData,
            isActive: oldData.isActive === true,
            timestamp: oldData.timestamp || Date.now(),
            updatedAt: Date.now(),
          });
          UI.toast('✏️ 題目已更新');
          this.resetQuizForm();
          await this.loadQuizBank();
        } catch (e) {
          console.error(e);
          UI.toast('修改失敗');
        }
      },

      async deleteQuiz(id) { 
         const isConfirmed = await UI.confirm(`確定要永久刪除這筆資料嗎？
(此操作無法復原)`, "刪除確認");
         if (!isConfirmed) return;
         try { await deleteDoc(doc(db, 'quiz_bank', id)); UI.toast('🗑️ 已刪除'); this.resetQuizForm(); await this.loadQuizBank(); } catch(e) { UI.toast('刪除失敗'); } 
      },
      
      async toggleQuizActive(id, currentStatus) { try { await updateDoc(doc(db, 'quiz_bank', id), { isActive: !currentStatus, updatedAt: Date.now() }); await this.loadQuizBank(); } catch(e) { UI.toast('切換失敗'); } },

      async startDailyQuest() {
        if (currentState.dailyQuestStarting) {
          UI.toast('題庫載入中，請勿重複點擊');
          return;
        }

        const btn = document.getElementById('stuDailyQuestBtn');
        const timerText = document.getElementById('stuDailyQuestTimer');
        const remainingRewardCount = getTodayDailyRemaining(currentState.studentData);
        if (remainingRewardCount <= 0) {
          UI.alert('今日歷練獎勵已滿 10 題，繼續作答也不會再增加金幣與經驗。請等待中午 12:00 重置，避免重複刷題浪費時間。', '今日歷練已達上限');
          UI.updateDailyQuestTimer();
          return;
        }

        const className = String(currentState.studentData?.class_name || '').trim();
        const isSupportClass = /學習扶助/.test(className);
        const gradeMatch = className.match(/[1-6一二三四五六]/);
        if (!isSupportClass && !gradeMatch) { UI.showModal('entityOccupiedModal'); return; }
        const userGrade = isSupportClass ? '學習扶助班' : ({ '一':'1', '二':'2', '三':'3', '四':'4', '五':'5', '六':'6' }[gradeMatch[0]] || gradeMatch[0]);

        currentState.dailyQuestStarting = true;
        if (btn) btn.disabled = true;
        if (timerText) {
          timerText.innerText = '[ 題庫載入中... ] 正在鎖定今日歷練';
          timerText.style.color = 'var(--warning)';
        }

        try {
          const snapshot = await getDocs(collection(db, 'quiz_bank'));
          let gradeMatched = [];
          let fallbackActive = [];
          snapshot.forEach(docSnap => {
            const raw = docSnap.data() || {};
            const q = { id: docSnap.id, ...raw };
            if (!isQuizEnabled(q)) return;
            if (quizMatchesStudentGrade(q, userGrade, isSupportClass)) {
              gradeMatched.push(q);
            } else if (!/學習扶助/.test(String(q.grade || q.class_name || q.gradeName || '').trim())) {
              fallbackActive.push(q);
            }
          });
          let allQ = gradeMatched;
          if (allQ.length < 1 && fallbackActive.length > 0) {
            console.warn('[daily quest] no exact grade match, fallback to active quiz bank');
            allQ = fallbackActive;
          }
          if (allQ.length < 1) { UI.alert('無法載入題庫：目前沒有符合年級且已啟用的題目。', '題庫不足'); UI.updateDailyQuestTimer(); return; }

          // 每次開始每日修練時，先把符合年級且啟用中的題庫隨機洗牌，再抽取「今日尚可獲獎的題數」
          for (let i = allQ.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [allQ[i], allQ[j]] = [allQ[j], allQ[i]];
          }

          // 初始化 session：每日可重複進入，但每日最多獲獎 10 題；本次僅出剩餘可獲獎題數
          quizSession.mode = 'daily';
          quizSession.dailyRemainingAtStart = remainingRewardCount;
          quizSession.questions = allQ.slice(0, Math.max(1, Math.min(10, remainingRewardCount)));
          quizSession.currentIndex = 0;
          quizSession.score = 0;
          quizSession.dailyCoinsEarned = 0;
          quizSession.dailyXpEarned = 0;
          quizSession.dailyData = JSON.parse(JSON.stringify(currentState.studentData || {}));

          // 立刻鎖定 24h 冷卻（避免中途關閉/刷新可重刷）
          quizSession.dailyData.last_practice_time = Date.now();
          quizSession.dailyData.logs = Array.isArray(quizSession.dailyData.logs) ? quizSession.dailyData.logs : [];
          const dailyLabels = getProfileLabels(quizSession.dailyData);
          const dailyLogPrefix = dailyLabels.dailyQuestLogPrefix || (isCatProfile(quizSession.dailyData) ? '後院巡查' : '每日歷練');
          quizSession.dailyData.logs.push({ timestamp: Date.now(), action_type: "quest", detail: `[${dailyLogPrefix}] 開始今日挑戰（本次可獲獎 ${quizSession.questions.length} 題，今日剩餘 ${remainingRewardCount} 題）` });

          const startedData = await this.saveToDB(quizSession.dailyData);
          quizSession.dailyData = this.refreshStudentRewardPanel(startedData || currentState.studentData || quizSession.dailyData, true);
          UI.updateDailyQuestTimer();

          const quizPlayTitleEl = document.getElementById('quizPlayTitle');
          const quizPlayContentEl = document.querySelector('#quizPlayModal .modal-content');
          if (quizPlayTitleEl) {
            quizPlayTitleEl.innerText = isCatProfile(quizSession.dailyData) ? '### 後院巡查' : '### 每日歷練';
            quizPlayTitleEl.style.color = "var(--color-grass)";
          }
          if (quizPlayContentEl) quizPlayContentEl.style.borderColor = "var(--color-grass)";
          UI.hide('quizResultArea');
          UI.show('quizPlayArea');
          UI.showModal('quizPlayModal');
          this.renderQuizQuestion();
        } catch(e) {
          console.error(e);
          UI.toast('無法載入題庫');
          UI.updateDailyQuestTimer();
        } finally {
          currentState.dailyQuestStarting = false;
        }
      },

      renderQuizQuestion() {

        const q = quizSession.questions[quizSession.currentIndex];
        const progressEl = document.getElementById('quizProgress');
        const questionEl = document.getElementById('quizQuestionText');
        const optsArea = document.getElementById('quizOptionsArea');
        if (!q || !questionEl || !optsArea) {
          console.warn('[renderQuizQuestion] missing question or quiz DOM', {
            hasQuestion: !!q,
            hasQuestionEl: !!questionEl,
            hasOptionsEl: !!optsArea
          });
          UI.alert('題目資料或作答面板不存在，請重新開始挑戰。', '無法載入題目');
          UI.hideModal('quizPlayModal');
          return;
        }
        if (progressEl) {
          if (quizSession.mode === 'battle') {
              progressEl.innerText = `只要答錯就會失去今日挑戰機會！請仔細作答。`;
          } else {
              const dailyRemain = Number(quizSession.dailyRemainingAtStart ?? quizSession.questions.length) - Number(quizSession.currentIndex);
              progressEl.innerText = `第 ${quizSession.currentIndex + 1} 題 / 共 ${quizSession.questions.length} 題｜今日剩餘可獲獎 ${Math.max(0, dailyRemain)} 題`; 
          }
        }
        questionEl.innerText = q.question || '（題目遺失）';
        optsArea.innerHTML = '';
        if (Array.isArray(q.options)) {
            q.options.forEach((opt, idx) => { 
                if (quizSession.mode === 'battle') {
                    optsArea.innerHTML += `<button class="btn" style="text-align:left; border-color:#555; color:#fff;" onclick="App.handleBattleQuizAnswer(${!!opt.isCorrect})">${opt.text}</button>`;
                } else {
                    optsArea.innerHTML += `<button class="btn quiz-opt-btn" onclick="App.selectQuizOption(${idx}, ${!!opt.isCorrect})" style="text-align:left; font-family:'Noto Sans TC'; border-color:var(--text-muted); color:#fff; font-size:1em;">${String.fromCharCode(65 + idx)}. ${opt.text}</button>`; 
                }
            });
        }
        if (!optsArea.innerHTML) {
          UI.alert('目前這題沒有可作答選項，請通知老師檢查題庫。', '題目格式異常');
          UI.hideModal('quizPlayModal');
        }
      },

      async selectQuizOption(selectedIndex, isCorrect) {
        const btns = document.querySelectorAll('.quiz-opt-btn');
        btns.forEach(b => { b.disabled = true; });
        const selectedBtn = btns[selectedIndex];
        if (!selectedBtn) {
          UI.alert('找不到對應的作答按鈕，請重新開始本次題目。', '作答失敗');
          return;
        }

        if (isCorrect) {
          selectedBtn.style.background = 'rgba(0,255,153,0.3)';
          selectedBtn.style.borderColor = 'var(--color-grass)';
          quizSession.score++;

          // 每答對一題：改由 Cloud Function settleStudentReward 統一驗證、結算與入帳
          if (quizSession.mode === 'daily') {
            try {
              const baselineData = quizSession.dailyData
                ? JSON.parse(JSON.stringify(quizSession.dailyData))
                : JSON.parse(JSON.stringify(currentState.studentData || {}));
              const q = quizSession.questions[quizSession.currentIndex] || {};
              const serial = this.normalizeSerial(baselineData.card_seq || baselineData.serial || currentState.currentUid || '000') || '000';
              const eventId = buildRewardEventId('daily_correct', [serial, q.id || q.question || quizSession.currentIndex]);
              const settle = await this.settleRewardViaServer('daily_correct', {
                eventId,
                source: 'daily_quiz',
                questionId: q.id || null,
                question: String(q.question || '').slice(0, 80),
                index: quizSession.currentIndex,
                serial
              });

              if (settle?.ok && settle?.student) {
                const latestData = this.refreshStudentRewardPanel(settle.student, true);
                quizSession.dailyData = latestData;
                currentState.studentData = latestData;
                const descEl = document.getElementById('quizResultDesc');

                if (settle.applied) {
                  const rewardCoins = Number(settle?.reward?.coins) || 0;
                  const rewardXp = Number(settle?.reward?.xp) || 0;
                  quizSession.dailyCoinsEarned = (Number(quizSession.dailyCoinsEarned) || 0) + rewardCoins;
                  quizSession.dailyXpEarned = (Number(quizSession.dailyXpEarned) || 0) + rewardXp;
                  if (descEl) descEl.innerHTML = `<span style="color:var(--color-grass)">本題獎勵已成功存入。</span>`;
                } else {
                  if (descEl) {
                    descEl.innerHTML = `<span style="color:var(--warning)">${settle.message || '本題已判定正確，但本次不再增加獎勵。'}</span>`;
                  }
                }
              } else {
                throw new Error(settle?.message || '後端沒有回傳學生資料');
              }
            } catch (e) {
              console.warn('[daily quest] server settlement failed:', e?.message || e);
              const descEl = document.getElementById('quizResultDesc');
              if (descEl) {
                descEl.innerHTML = `<span style="color:var(--danger)">本題作答已判定正確，但後端結算失敗，請勿重複刷題。</span>`;
              }
              UI.alert('獎勵未存入', `本題已判定正確，但後端 settleStudentReward 沒有成功完成結算，所以重新整理後不會保留。

請確認：
1) 前端已部署本版
2) Cloud Function 已部署為 asia-east1 / settleStudentReward
3) 再通知老師協助處理。`);
            }
          }

        } else {
          selectedBtn.style.background = 'rgba(255,0,85,0.3)';
          selectedBtn.style.borderColor = 'var(--danger)';
          const q = quizSession.questions[quizSession.currentIndex];
          let correctIdx = q.options ? q.options.findIndex(o => o.isCorrect) : -1;
          if (correctIdx !== -1) {
            btns[correctIdx].style.borderColor = 'var(--color-grass)';
            btns[correctIdx].style.color = 'var(--color-grass)';
          }
        }

        setTimeout(() => {
          quizSession.currentIndex++;
          if (quizSession.currentIndex < quizSession.questions.length) this.renderQuizQuestion();
          else this.showQuizResult();
        }, 1000);
      },


      async settleRewardViaServer(type, meta = {}) {
        try {
          await this.ensureStudentAuth();
          const token = String(currentState.currentToken || '').trim();
          if (!token) throw new Error('缺少有效學生 token');
          const call = httpsCallable(functions, 'settleStudentReward');
          const response = await call({
            token,
            type: String(type || '').trim(),
            meta: { ...meta, clientBuild: BUILD_TAG }
          });
          const payload = response?.data || {};
          if (payload?.student) {
            const normalized = this.applyDataMigration(JSON.parse(JSON.stringify(payload.student)));
            currentState.studentData = normalized;
            if (quizSession && quizSession.mode === 'daily') quizSession.dailyData = normalized;
          }
          return payload;
        } catch (e) {
          console.error('[settleRewardViaServer] failed:', e);
          throw e;
        }
      },

      buildBattleRewardEventId(studentData = {}, bossKey = 'boss', monKey = 0) {
        const serial = this.normalizeSerial(studentData?.card_seq || studentData?.serial || currentState.currentUid || '000') || '000';
        const anchor = getBattleResetAnchor(studentData || {}, Date.now());
        return buildRewardEventId('boss_win', [serial, bossKey, monKey, anchor]);
      },

      getBattleRewardDisplay(studentData = {}, settle = null) {
        const data = this.applyDataMigration(JSON.parse(JSON.stringify(studentData || {})));
        const labels = getProfileLabels(data);
        const xpUnit = labels.xp || (isCatProfile(data) ? '成長能量' : '進化能量');
        const attrKey = settle?.reward?.attrKey || getDominantElementFromData(data);
        const attrName = settle?.reward?.attrName || (getProfileAttributeInfo(attrKey, data)?.name || attrKey);
        const coins = Number(settle?.reward?.coins);
        const xp = Number(settle?.reward?.xp);
        return {
          xpUnit,
          attrName,
          coins: Number.isFinite(coins) && coins > 0 ? coins : 5,
          xp: Number.isFinite(xp) && xp > 0 ? xp : 5
        };
      },

      async resolveBattleRecordBase(serial, fallbackData = null) {
        const normalizedSerial = this.normalizeSerial(serial || fallbackData?.card_seq || fallbackData?.serial || currentState.currentUid || '');
        if (normalizedSerial) {
          try {
            const synced = await this.syncStudentMirrorForSerial(normalizedSerial);
            if (synced) return this.applyDataMigration(JSON.parse(JSON.stringify(synced)));
          } catch (syncErr) {
            console.warn('[battle] resolve latest record base failed:', syncErr?.message || syncErr);
          }
        }
        return this.applyDataMigration(JSON.parse(JSON.stringify(fallbackData || currentState.studentData || {})));
      },

      buildBattleOutcomeRecord(dataObj = {}, options = {}) {
        const data = this.applyDataMigration(JSON.parse(JSON.stringify(dataObj || {})));
        const now = Number(options.timestamp) || Date.now();
        const isWin = options.isWin === true;
        const settle = options.settle || null;
        const saveStatus = String(options.saveStatus || '').trim() || 'unknown';
        const eventId = String(options.eventId || '').trim();
        const bossKey = String(options.bossKey || currentState.currentBattleBoss?.id || currentState.currentBattleBoss?.legendaryId || currentState.currentBattleBoss?.name || 'boss').trim();
        const monKey = options.monKey == null ? currentState.selectedBattleMonIndex : options.monKey;
        const display = this.getBattleRewardDisplay(data, settle);
        const labels = getProfileLabels(data);
        data.last_battle_time = now;
        data.today_battle_used = true;
        data.today_battle_date = now;
        data.logs = Array.isArray(data.logs) ? data.logs : [];

        let detail = '';
        let summary = '';
        let result = isWin ? 'win' : 'lose';

        if (isWin) {
          if (settle?.ok && settle?.applied) {
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功結算 +${display.coins}🪙 +${display.xp} 點${display.attrName}${display.xpUnit}`;
            summary = `BOSS 討伐成功，已存入 ${display.coins} 金幣與 ${display.xp} 點${display.attrName}${display.xpUnit}`;
            result = 'win_settled';
          } else if (settle?.ok) {
            const msg = String(settle?.message || '本次沒有新增獎勵。').trim();
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功但未新增獎勵：${msg}`;
            summary = `BOSS 討伐成功，但本次沒有新增獎勵。${msg}`;
            result = 'win_no_reward';
          } else {
            const msg = String(settle?.message || options.errorMessage || '獎勵結算失敗，請稍後重整確認是否已入帳。').trim();
            detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 成功但結算失敗：${msg}`;
            summary = `BOSS 討伐成功，但獎勵結算失敗。${msg}`;
            result = 'win_settle_failed';
          }
        } else {
          detail = `[${isCatProfile(data) ? '領域防衛' : '對戰塔'}] 失敗`;
          summary = labels.battleConsume || '討伐失敗，本日挑戰機會已消耗。';
          result = 'lose';
        }

        data.battle_result = result;
        data.battle_summary = summary;
        data.logs.push({
          timestamp: now,
          action_type: 'battle',
          detail,
          battle_result: result,
          battle_save_status: saveStatus,
          reward_event_id: eventId || null,
          boss_id: bossKey || null,
          battle_mon_index: monKey
        });
        return this.processEvolution(data);
      },

      showQuizResult() {
        UI.hide('quizPlayArea');
        UI.show('quizResultArea');

        const maxQ = quizSession.questions.length;
        document.getElementById('quizScoreText').innerText = `${quizSession.score} / ${maxQ}`;

        if (quizSession.mode === 'daily') {
          const earned = Number(quizSession.score) || 0;
          const labels = getProfileLabels(currentState.studentData);
          const xpUnit = labels.xp || (isCatProfile(currentState.studentData) ? '成長能量' : '進化能量');
          const totalCoins = Number(currentState.studentData?.coins) || 0;
          const totalXp = Number(currentState.studentData?.totalXP) || 0;
          const rewardArea = document.getElementById('quizRewardArea');
          const remainingAfter = getTodayDailyRemaining(currentState.studentData);
          document.getElementById('quizResultDesc').innerText =
            fillProfileTemplate(labels.dailyQuestSummary, { earned }) + `
（每日最多 10 題；目前尚可獲得 ${remainingAfter} 題獎勵，歸零後請等待中午 12:00 重置）`;
          document.getElementById('quizScoreText').style.color = earned > 0 ? 'var(--color-grass)' : 'var(--danger)';
          if (rewardArea) {
            rewardArea.innerHTML = `本次獲得：<b>${Number(quizSession.dailyCoinsEarned) || 0}</b> 金幣、<b>${Number(quizSession.dailyXpEarned) || 0}</b> 點${xpUnit}<br>目前持有：<b>${totalCoins}</b> 金幣　｜　目前${xpUnit}：<b>${totalXp}</b>`;
          }
          UI.show('quizRewardArea');
          UI.show('quizCloseBtn');
          UI.updateDailyQuestTimer();
          return;
        }

        // 兼容：若未來有其他模式沿用此流程
        if (quizSession.score === maxQ && maxQ > 0) {
          document.getElementById('quizResultDesc').innerText = "滿分通關！獲得 2 點經驗能量。";
          document.getElementById('quizScoreText').style.color = 'var(--cyan)';
          const sel = document.getElementById('quizRewardAttr'); sel.innerHTML = '';
          for (const [key, info] of Object.entries(CONSTANTS.ATTRIBUTES)) sel.innerHTML += `<option value="${key}">${info.icon} ${info.name} 屬性</option>`;
          UI.show('quizRewardArea');
          UI.hide('quizCloseBtn');
        } else {
          document.getElementById('quizResultDesc').innerText = "修練結束！必須「全數答對」才能獲獎。";
          document.getElementById('quizScoreText').style.color = 'var(--danger)';
          UI.hide('quizRewardArea');
          UI.show('quizCloseBtn');
          this.updatePracticeCooldown();
        }
      },

      async claimQuizReward() {

        const attr = document.getElementById('quizRewardAttr').value; let data = JSON.parse(JSON.stringify(currentState.studentData));
        data.totalXP += 2; addAttributeXP(data, attr, 2); data.last_practice_time = Date.now();
        data.logs.push({ timestamp: Date.now(), action_type: "quest", points_added: 2, detail: `[修練] 滿分獲得 2XP (${CONSTANTS.ATTRIBUTES[attr].name})` });
        
        if (!data.attr_event_counts) data.attr_event_counts = { fire: 0, electric: 0, water: 0, psychic: 0, dark: 0, grass: 0, ice: 0, fairy: 0 };
        if (attr && data.attr_event_counts[attr] != null) data.attr_event_counts[attr] = (Number(data.attr_event_counts[attr]) || 0) + 1;
data = this.processEvolution(data); await this.saveToDB(data); UI.hideModal('quizPlayModal'); UI.toast('🔋 能量注入！'); UI.updateDailyQuestTimer();
      },
      
      async updatePracticeCooldown() {
        let data = JSON.parse(JSON.stringify(currentState.studentData || {}));
        data.last_practice_time = Date.now();
        const savedData = await this.saveToDB(data);
        this.refreshStudentRewardPanel(savedData || currentState.studentData || data, true);
        UI.updateDailyQuestTimer();
      },
      
      buildStudentWritablePayload(dataObj = {}, serial = '', token = '') {
        const src = JSON.parse(JSON.stringify(dataObj || {}));
        const clean = {};
        const fields = [
          'card_seq', 'serial', 'active_token', 'page_token',
          'coins', 'totalXP', 'attributes', 'logs',
          'reward_events', 'reward_settled_ids',
          'updatedAt', 'lastSeenAt',
          'last_practice_time', 'last_battle_time',
          'dailyChallengeProgress', 'battleState',
          'today_battle_used', 'today_quiz_reward_count',
          'today_quiz_reward_date', 'today_battle_date',
          'battle_result', 'battle_summary',
          'daily_reset_override_at', 'battle_reset_override_at',
          'active_hidden_egg_id', 'active_hidden_egg',
          'hidden_eggs', 'collection', 'dragon_stage', 'dragon_path',
          'attribute_gain_order'
        ];
        fields.forEach((key) => {
          if (src[key] !== undefined) clean[key] = src[key];
        });
        if (serial) {
          clean.card_seq = serial;
          clean.serial = serial;
        }
        if (token) {
          clean.active_token = token;
          clean.page_token = token;
        }
        const MAX_LOGS = 200;
        if (Array.isArray(clean.logs) && clean.logs.length > MAX_LOGS) clean.logs = clean.logs.slice(-MAX_LOGS);
        if (!Array.isArray(clean.reward_events)) clean.reward_events = [];
        if (!Array.isArray(clean.reward_settled_ids)) clean.reward_settled_ids = [];
        if (!Array.isArray(clean.hidden_eggs)) clean.hidden_eggs = [];
        if (!Array.isArray(clean.collection)) clean.collection = [];
        if (!clean.attributes || typeof clean.attributes !== 'object') clean.attributes = { metal: 0, wood: 0, water: 0, fire: 0, earth: 0 };
        clean.attributes = {
          metal: Number(clean.attributes?.metal) || 0,
          wood: Number(clean.attributes?.wood) || 0,
          water: Number(clean.attributes?.water) || 0,
          fire: Number(clean.attributes?.fire) || 0,
          earth: Number(clean.attributes?.earth) || 0
        };
        return clean;
      },

      _saveQueues: new Map(),
      async enqueueSerialSave(serial, work) {
        const key = this.normalizeSerial(serial) || String(serial || '');
        const prev = this._saveQueues.get(key) || Promise.resolve();
        const next = prev.catch(() => {}).then(() => work());
        this._saveQueues.set(key, next);
        try {
          return await next;
        } finally {
          if (this._saveQueues.get(key) === next) this._saveQueues.delete(key);
        }
      },

      isFastAdminSaveMode(explicitUid = null) {
        if (currentState.viewMode === 'student') return false;
        if (!explicitUid) return false;
        return ['batch', 'support-batch', 'science-batch'].includes(String(currentState.scanIntention || ''));
      },

      async saveToDB(dataObj, explicitUid = null) {
        const isStudentTokenMode = (currentState.viewMode === 'student' && !!currentState.currentToken);
        if (currentState.viewMode === 'student' && !currentState.currentTokenValidated) { UI.toast('此操作需要有效卡片驗證'); return null; }

        try {
          const payload = this.applyDataMigration(JSON.parse(JSON.stringify(dataObj || {})));
          if (currentState.currentToken) { payload.active_token = currentState.currentToken; payload.page_token = currentState.currentToken; }
          const MAX_LOGS = 200;
          if (Array.isArray(payload.logs) && payload.logs.length > MAX_LOGS) payload.logs = payload.logs.slice(-MAX_LOGS);

          if (isStudentTokenMode) {
            const serial = this.normalizeSerial(payload.card_seq || payload.serial || currentState.currentUid);
            const token = String(currentState.currentToken || '').trim();
            if (serial && token) {
              const writable = this.buildStudentWritablePayload(payload, serial, token);

              // 學生端改以 student_pages/{token} 為正式落地來源，避免主檔 rules 或舊 token 綁定條件
              // 導致整筆獎勵失敗。students/{serial} 改為非阻斷式鏡像同步。
              await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), writable, { merge: true });

              try {
                await setDoc(doc(db, COLLECTION_NAME, serial), writable, { merge: true });
              } catch (mirrorErr) {
                console.warn('[student-save] mirror to students failed, page saved as source of truth:', mirrorErr?.message || mirrorErr);
              }

              const studentSnap = await getDoc(doc(db, COLLECTION_NAME, serial));
              const pageSnap = await getDoc(doc(db, STUDENT_PAGE_COLLECTION, token));
              const merged = this.mergeStudentRecords(
                studentSnap.exists() ? (studentSnap.data() || {}) : {},
                pageSnap.exists() ? (pageSnap.data() || {}) : writable,
                serial
              );
              currentState.studentData = this.applyDataMigration(merged || writable);
              return currentState.studentData;
            }
            if (token) {
              const writable = this.buildStudentWritablePayload(payload, '', token);
              await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), writable, { merge: true });
              currentState.studentData = this.applyDataMigration(writable);
              return currentState.studentData;
            }
            return payload;
          }

          const serial = this.normalizeSerial(explicitUid || payload.card_seq || payload.serial || currentState.currentUid);
          if (!serial) return payload;
          payload.card_seq = serial;
          payload.serial = serial;

          if (this.isFastAdminSaveMode(explicitUid || serial)) {
            return await this.enqueueSerialSave(serial, async () => {
              await setDoc(doc(db, COLLECTION_NAME, serial), payload, { merge: true });
              try {
                const token = String(payload.active_token || payload.page_token || await this.getActiveTokenForSerial(serial) || '').trim();
                if (token) await setDoc(doc(db, STUDENT_PAGE_COLLECTION, token), { ...payload, active_token: token, page_token: token }, { merge: true });
              } catch (mirrorErr) {
                console.warn('[fast-admin-save] mirror failed:', mirrorErr?.message || mirrorErr);
              }
              const local = this.applyDataMigration(JSON.parse(JSON.stringify(payload)));
              if (currentState.currentUid && this.normalizeSerial(currentState.currentUid) === serial) currentState.studentData = local;
              return local;
            });
          }

          await setDoc(doc(db, COLLECTION_NAME, serial), payload, { merge: true });
          const merged = await this.syncStudentMirrorForSerial(serial, payload);
          if (merged && currentState.currentUid && this.normalizeSerial(currentState.currentUid) === serial) currentState.studentData = merged;
          return merged || payload;
        } catch (e) {
          console.error(e);
          UI.toast(`DB SYNC FAILED：${e.message || e}`);
          return null;
        }
      },



async loadLegendaryAdmin() {
         UI.showModal('legendaryAdminModal');
         const listDiv = document.getElementById('laActiveList');
         listDiv.innerHTML = '<div style="color:var(--text-muted); text-align:center;">載入資料中...</div>';
         try {
           const snap = await getDocs(collection(db, 'legendary_bank'));
           let items = []; snap.forEach(doc => items.push({ id: doc.id, ...doc.data() }));
           if (items.length === 0) { listDiv.innerHTML = '<div style="color:#555; text-align:center;">目前無開放任何兌換。</div>'; return; }
           
           listDiv.innerHTML = '';
           items.forEach(item => {
              const legInfo = CONSTANTS.LEGENDARIES.find(l => l.id === item.legendaryId) || {};
              const attrInfo = getProfileAttributeInfo(item.reqAttr, currentState.studentData) || {};
              listDiv.innerHTML += `
                <div style="background:rgba(255,183,0,0.1); border:1px solid var(--legendary-gold); border-radius:6px; padding:10px; display:flex; align-items:center; gap:10px;">
                  <img src="${legInfo.img}" style="width:50px; height:50px; object-fit:contain; filter:drop-shadow(0 0 5px var(--legendary-gold));">
                  <div style="flex:1;">
                    <div style="color:var(--legendary-gold); font-weight:bold; font-family:'Noto Sans TC'; font-size:1.1em;">${item.name} <span class="tech-font" style="font-size:0.7em;">(★ ${item.points})</span></div>
                    <div style="color:#ccc; font-size:0.8em; font-family:'Noto Sans TC'; margin-top:4px;">需求: ${item.reqCount} 隻 ${attrInfo.icon}${(CONSTANTS.DRAGON_NAMES && CONSTANTS.DRAGON_NAMES[item.reqAttr]) ? CONSTANTS.DRAGON_NAMES[item.reqAttr] : (attrInfo.name + '龍獸')}</div>
                  </div>
                  <button onclick="App.deleteLegendary('${item.id}')" style="background:none; border:1px solid var(--danger); color:var(--danger); padding:4px 8px; border-radius:4px; cursor:pointer;">移除</button>
                </div>`;
           });
         } catch(e) { console.error(e); listDiv.innerHTML = '<div style="color:red; text-align:center;">讀取失敗</div>'; }
      },

      async publishLegendary() {
         const legId = document.getElementById('laSelectId').value;
         const points = parseInt(document.getElementById('laPoints').value) || 0;
         const reqAttr = document.getElementById('laReqAttr').value;
         const reqCount = parseInt(document.getElementById('laReqCount').value) || 1;
         
         const legInfo = CONSTANTS.LEGENDARIES.find(l => l.id === legId);
         if(!legInfo) return;
         
         const data = { legendaryId: legId, name: legInfo.name, img: legInfo.img, points: points, reqAttr: reqAttr, reqCount: reqCount, timestamp: Date.now() };
         try {
            await addDoc(collection(db, 'legendary_bank'), data);
            UI.toast('✅ 發布成功！');
            UI.hideModal('legendaryAddModal'); this.loadLegendaryAdmin();
         } catch(e) { UI.alert("發布失敗", "資料庫錯誤"); }
      },

      async deleteLegendary(docId) {
         const isConfirmed = await UI.confirm("確定要將此異獸從兌換列表移除嗎？\n(已兌換的學生不會受影響)", "移除確認");
         if(!isConfirmed) return;
         try { await deleteDoc(doc(db, 'legendary_bank', docId)); UI.toast("已移除"); this.loadLegendaryAdmin(); } catch(e) { UI.alert("移除失敗", "資料庫錯誤"); }
      },

      async loadActiveLegendariesForStudent() {
         const listDiv = document.getElementById('stuLegendaryList');
         const speechDiv = document.getElementById('teacherSpeechText');
         const teacherAvatar = document.getElementById('teacherAvatar');
         if (teacherAvatar) setImgFromFileBaseName(teacherAvatar, 'teacher', { shadowColor: 'rgba(255,183,0,0.55)' });
         try {
           const snap = await getDocs(collection(db, 'legendary_bank'));
           let items = []; snap.forEach(doc => items.push({ id: doc.id, ...doc.data() }));
           const labels = getProfileLabels(currentState.studentData);
           if (items.length === 0) { 
             speechDiv.innerHTML = `<span style="color:#ccc;">${labels.legendaryEmptySpeech || '研究站仍在整理線索，這週暫時沒有發現新的稀有異獸。請繼續培育你的龍獸，等待下一次探索成果吧！'}</span>`;
             listDiv.innerHTML = ''; 
             return; 
           }
           
           let legNames = items.map(i => `<span style="color:var(--legendary-gold); font-weight:bold;">${isCatProfile(currentState.studentData) ? '特殊品種夥伴' : i.name}</span>`).join('、');
           speechDiv.innerHTML = fillProfileTemplate(labels.legendarySpeechPrefix, { names: legNames });

           listDiv.innerHTML = '';
           const stuCol = currentState.studentData.collection || [];
           
           items.forEach(item => {
              let currentCount = stuCol.filter(i => i.type === `${item.reqAttr}_legacy` && !(i.isHologram === true || i.isHologram === "true")).length;
              const isReady = currentCount >= item.reqCount;
              const attrInfo = CONSTANTS.ATTRIBUTES[item.reqAttr] || {};
              const btnHtml = isReady ? 
                `<button class="btn btn-solid" style="background:var(--legendary-gold); padding:5px; font-size:0.8em; color:#000;" onclick="App.exchangeLegendary('${item.id}', '${item.reqAttr}', ${item.reqCount})">${labels.legendaryExchange || '進行交換'}</button>` : 
                `<button class="btn" disabled style="padding:5px; font-size:0.8em;">${labels.legendaryInsufficient || '條件不足'}</button>`;

              listDiv.innerHTML += `
                <div style="background:rgba(0,0,0,0.6); border:1px solid ${isReady?'var(--legendary-gold)':'#333'}; border-radius:6px; padding:10px; display:flex; align-items:center; gap:10px; opacity:${isReady?1:0.6}; transition:0.3s;">
                  <img src="${item.img}" style="width:40px; height:40px; object-fit:contain; filter:drop-shadow(0 0 5px ${isReady?'var(--legendary-gold)':'#555'});">
                  <div style="flex:1;">
                    <div style="color:${isReady?'var(--legendary-gold)':'#aaa'}; font-weight:bold; font-family:'Noto Sans TC'; font-size:0.95em;">${isCatProfile(currentState.studentData) ? '特殊品種夥伴' : item.name}</div>
                    <div style="color:var(--text-muted); font-size:0.7em; font-family:'Noto Sans TC'; margin-top:2px;">${fillProfileTemplate(labels.legendaryRequirement, { current: currentCount, need: item.reqCount, attrName: attrInfo.name })}</div>
                  </div>
                  ${btnHtml}
                </div>`;
           });
         } catch(e) { console.error(e); listDiv.innerHTML = '<div style="color:red; text-align:center;">讀取失敗</div>'; }
      },

      async exchangeLegendary(docId, reqAttrFromUI, reqCountFromUI) {
        try {
          const legRef = doc(db, 'legendary_bank', docId);
          const legSnap = await getDoc(legRef);
          if (!legSnap.exists()) {
            UI.alert('兌換失敗：異獸不存在或已被移除', "兌換失敗");
            return;
          }
          const legData = legSnap.data() || {};
          const reqAttr = legData.reqAttr || reqAttrFromUI;
          const reqCount = Number(legData.reqCount ?? reqCountFromUI) || 0;
          const name = legData.name || '未知異獸';

          if (!reqAttr || reqCount <= 0) {
            UI.alert('兌換失敗：異獸需求資料異常', "系統錯誤");
            return;
          }

          const stuRef = (currentState.viewMode === 'student' && currentState.currentToken)
            ? doc(db, STUDENT_PAGE_COLLECTION, currentState.currentToken)
            : doc(db, COLLECTION_NAME, currentState.currentUid);
          const stuSnap = await getDoc(stuRef);
          if (!stuSnap.exists()) {
            UI.alert('兌換失敗：找不到學生資料', "資料遺失");
            return;
          }
          let data = this.applyDataMigration(stuSnap.data() || {});
          data.collection = data.collection || [];
          data.display_team = data.display_team || [];
          data.logs = data.logs || [];

          const isHolo = v => v === true || v === 'true';

          const owned = data.collection.filter(i => i && i.type === `${reqAttr}_legacy` && !isHolo(i.isHologram)).length;
          if (owned < reqCount) {
            UI.alert(`條件不足：你目前只有 ${owned} 隻 ${reqAttr} 龍獸，需求為 ${reqCount} 隻。`, "條件不符");
            return;
          }

          const isConfirmed = await UI.confirm(`確認要進行基因交換嗎？\n作為材料的 ${reqCount} 隻 ${reqAttr} 龍獸素材將化為全息投影（無法作為排行榜展示），並獲得異獸：${name}`, "基因交換確認");
          if (!isConfirmed) return;

          let foundCount = 0;
          for (let i = 0; i < data.collection.length && foundCount < reqCount; i++) {
            if (data.collection[i]?.type === `${reqAttr}_legacy` && !isHolo(data.collection[i]?.isHologram)) {
              data.collection[i].isHologram = true;
              foundCount++;
            }
          }
          if (foundCount < reqCount) {
            UI.alert('兌換失敗：材料在處理時不足（可能資料剛同步，請重試）', "系統錯誤");
            return;
          }

          data.collection.push({
            type: 'legendary',
            legendaryId: legData.legendaryId || legData.legendaryType || docId,
            name,
            img: legData.img || '',
            points: legData.points || 0,
            timestamp: Date.now()
          });

          data.display_team = (data.display_team || []).filter(idx => data.collection[idx] && !isHolo(data.collection[idx].isHologram));

          data.logs.push({
            timestamp: Date.now(),
            action_type: 'exchange_legendary',
            detail: `兌換異獸：${name}`
          });

          await this.saveToDB(data);

          try {
            const exchanged = Number(legData.exchangedCount || 0) || 0;
            await updateDoc(legRef, { exchangedCount: exchanged + 1 });
          } catch (e) {
            console.warn('[legendary_bank] exchangedCount update failed:', e);
          }

          UI.toast(`✅ 兌換成功：${name}`);
          await this.loadActiveLegendariesForStudent();
        } catch (e) {
          console.error(e);
          UI.alert(`兌換失敗：${e.message || e}`, "系統異常");
        }
      },

      startBattleChallenge() { return battleApi.startBattleChallenge.apply(this, arguments); },
      attackBoss() { return battleApi.startBattleChallenge.apply(this, arguments); },
      selectBattleMon(idx) { return battleApi.selectBattleMon.apply(this, arguments); },
      async confirmBattleSelection() { return battleApi.confirmBattleSelection.apply(this, arguments); },
      async handleBattleQuizAnswer(isCorrect) { return battleApi.handleBattleQuizAnswer.apply(this, arguments); },
      prepareBattleArena() { return battleApi.prepareBattleArena.apply(this, arguments); },
      rollDice() { return battleApi.rollDice.apply(this, arguments); },
      showBattleSettlement() { return battleApi.showBattleSettlement.apply(this, arguments); },
      backToBattleResult() { return battleApi.backToBattleResult.apply(this, arguments); },
      closeBattleArenaAndRefresh() { return battleApi.closeBattleArenaAndRefresh.apply(this, arguments); },
      async endBattle(isWin) { return battleApi.endBattle.apply(this, arguments); },
      async checkBattleTowerStatus(studentData) { return battleApi.checkBattleTowerStatus.apply(this, arguments); },
      async updateBattleTowerStatus(studentData) { return battleApi.updateBattleTowerStatus.apply(this, arguments); },
      async resetDailyAndBattleChallenges() { return battleApi.resetDailyAndBattleChallenges.apply(this, arguments); },
      async populateBattleQuizOptions(audienceKey = 'default') { return battleApi.populateBattleQuizOptions.apply(this, arguments); },
      updateBattleTowerAdminAudienceView(rawDoc = {}) { return battleApi.updateBattleTowerAdminAudienceView.apply(this, arguments); },
      async openBattleTowerSetup() { return battleApi.openBattleTowerSetup.apply(this, arguments); },
      async publishBattleBoss() { return battleApi.publishBattleBoss.apply(this, arguments); },
      async clearBattleBoss() { return battleApi.clearBattleBoss.apply(this, arguments); },
      openDisplayTeamEditor() {
        const grid = document.getElementById('dtGrid');
        if (!grid) return;

        const data = currentState.studentData;
        if (!data) return;

        const col = Array.isArray(data.collection) ? data.collection : [];

        let selected = Array.isArray(data.display_team) ? data.display_team.slice() : [];
        selected = selected.map(v => Number(v)).filter(v => Number.isFinite(v));

        // 只保留可展示的項目（dragon / legendary；排除死亡/全息）
        selected = selected.filter(i => {
          if (i < 0 || i >= col.length) return false;
          const it = col[i];
          if (!it) return false;
          if (it.isHologram === true || it.isHologram === "true") return false;
          if (it.type === 'dead_dragon') return false;
          return (it.type === 'dragon' || it.type === 'legendary');
        });

        currentState.tempDisplayTeam = [...new Set(selected)].slice(0, 5);

        const countEl = document.getElementById('dtCountDisplay');
        if (countEl) countEl.innerText = currentState.tempDisplayTeam.length;

        grid.innerHTML = '';
        col.forEach((it, idx) => {
          if (!it) return;
          if (it.isHologram === true || it.isHologram === "true") return;
          if (it.type === 'dead_dragon') return;
          if (it.type !== 'dragon' && it.type !== 'legendary') return;

          let border = 'rgba(255,255,255,0.15)';
          let label = it.name || '龍獸';
          let img = it.img || CONSTANTS.MEDIA.PLACEHOLDER_SVG;

          if (it.type === 'legendary') {
            border = 'var(--legendary-gold)';
            label = `異獸 - ${it.name || '稀有異獸'}`;
          } else if (it.type === 'dragon') {
            const info = CONSTANTS.ATTRIBUTES[it.element] || { color: 'var(--cyan)', name: '?' };
            border = info.color;
            label = it.name || `${info.name}系龍獸`;
          }

          const sel = currentState.tempDisplayTeam.includes(idx);
          const fileBase = it.img_file || '';
          const imgSrc = fileBase ? CONSTANTS.MEDIA.PLACEHOLDER_SVG : img;
          const dataAttr = fileBase ? ('data-asset="' + String(fileBase).replace(/"/g,'&quot;') + '"') : '';
          grid.innerHTML += `
            <div class="team-item-btn ${sel ? 'selected' : ''}" id="dtItem_${idx}" onclick="App.toggleDisplayTeamItem(${idx})" style="border-color:${border};">
              <img src="${imgSrc}" ${dataAttr} alt="${label}">
              <div style="margin-top:6px; font-size:10px; text-align:center; color:${border}; line-height:1.2;">${label}</div>
            </div>`;
        });

        hydrateStorageImages(grid);
        UI.showModal('displayTeamModal');
      },

      toggleDisplayTeamItem(idx) {
        if (!Array.isArray(currentState.tempDisplayTeam)) currentState.tempDisplayTeam = [];
        idx = Number(idx);
        if (!Number.isFinite(idx)) return;

        const el = document.getElementById(`dtItem_${idx}`);
        const i = currentState.tempDisplayTeam.indexOf(idx);

        if (i !== -1) {
          currentState.tempDisplayTeam.splice(i, 1);
          if (el) el.classList.remove('selected');
        } else {
          if (currentState.tempDisplayTeam.length >= 5) return UI.toast("最多只能選 5 隻展示！");
          currentState.tempDisplayTeam.push(idx);
          if (el) el.classList.add('selected');
        }

        const countEl = document.getElementById('dtCountDisplay');
        if (countEl) countEl.innerText = currentState.tempDisplayTeam.length;
      },

      async saveDisplayTeam() {
        if (!currentState.studentData) return;

        let data = JSON.parse(JSON.stringify(currentState.studentData));
        const col = data.collection || [];

        let team = Array.isArray(currentState.tempDisplayTeam) ? currentState.tempDisplayTeam.slice() : [];
        team = team.map(v => Number(v)).filter(v => Number.isFinite(v));
        team = team.filter(idx => idx >= 0 && idx < col.length && col[idx] && !(col[idx].isHologram === true || col[idx].isHologram === "true") && col[idx].type !== 'dead_dragon');
        team = [...new Set(team)].slice(0, 5);

        data.display_team = team;
        data.logs = data.logs || [];
        data.logs.push({ timestamp: Date.now(), action_type: 'display_team', detail: `更新展示隊伍 (${team.length}/5)` });

        await this.saveToDB(data);
        UI.hideModal('displayTeamModal');
        UI.toast('⭐ 展示隊伍已更新');
      }
    };

    // UI 由 Phase 14 façade 於模組掛載完成後統一對外暴露。
    const forceOpenCardForge = createForceOpenCardForgeBridge({
      currentState,
      UI,
      getApp: () => App
    });


    // @phase10-split:mount-teacher-actions
    teacherActionsApi = createTeacherActionsModule({
      CONSTANTS, ELEMENT_KEYS, auth, db, doc, getDoc, buildRewardEventId, applyRewardEventToData, getProfileLabels, addAttributeXP
    });

    // @phase11-split:mount-batch
    batchApi = createBatchModule({
      db, doc, getDoc, COLLECTION_NAME, CONSTANTS, addAttributeXP, getProfileLabels
    });

    // @phase12-split:mount-battle
    battleApi = createBattleModule({
      db, doc, getDoc, getDocs, collection, writeBatch, setDoc, deleteDoc,
      CONSTANTS, TYPE_INFO, COLLECTION_NAME, STUDENT_PAGE_COLLECTION,
      hasBattleAttemptRemaining, buildBattleTeamForStudent, getDragonVisual, splitBattleVisualRef,
      buildCollectionDisplayItem, getProfileAttributeInfo, getBattleMonDiceCount, getBattleStageLabel,
      getBattleMonStage, isDirectVisualSource, hydrateStorageImages, getStudentGradeInfo,
      isQuizEnabled, quizMatchesStudentGrade, isCatProfile, getProfileLabels, normalizeBossDiceCount,
      createBattleDiceFaces, applyProfileStaticTexts, fillProfileTemplate, getBattleResetAnchor,
      formatCountdown, getNextNoonTimestamp, getBattleBossConfigForStudent, getBattleAudienceOptions,
      getBattleBossConfigForAudience, normalizeBattleTowerDoc, getCatBossVisualByType, __updateLegendarySelectPreview
    });


    // @phase13-split:mount-shop-quiz-ranking-content-zones
    shopApi = createShopModule({ SHOP_COLLECTION, COLLECTION_NAME, CONSTANTS, getContentProfile });
    quizApi = createQuizModule({ isQuizEnabled, quizMatchesStudentGrade, getProfileLabels, isCatProfile, buildRewardEventId, formatLocalDateKey });
    rankingApi = createRankingModule({ COLLECTION_NAME, CONSTANTS, hydrateStorageImages });
    contentProfileApi = createContentProfileModule({ COLLECTION_NAME, STUDENT_PAGE_COLLECTION, CONSTANTS });
    zonesApi = createZonesModule({ COLLECTION_NAME, SUPPORT_ZONE_COLLECTION, SCIENCE_ZONE_COLLECTION, CONSTANTS, ELEMENT_KEYS, addAttributeXP, formatLocalDateKey, formatLocalDateTime, downloadCsvFile });

    // @phase9-split:mount-auth-student
    authApi = createAuthModule({
      auth, db, doc, getDoc, signInWithEmailAndPassword, signInAnonymously, signOut,
      UI, currentState, BUILD_TAG, firebaseConfig, __setBootStatus, __bindLoginFallback
    });
    studentApi = createStudentModule({
      db, doc, getDoc, onSnapshot, UI, currentState, radarChartInstances, CONSTANTS,
      COLLECTION_NAME, STUDENT_PAGE_COLLECTION, Chart, App,
      getProfileLabels, getProfileDebuffInfo, getProfileAttributeInfo, getProfileVisual,
      isCatProfile, colorToRgba, setImgFromFileBaseName, buildCollectionDisplayItem,
      hydrateStorageImages, getRadarLabelsForData, applyProfileStaticTexts, syncProfileForm
    });


// @phase14-split:mount-app-facade
const facadeMountReport = mountAppFacade({
  App,
  UI,
  apis: {
    authApi,
    studentApi,
    teacherActionsApi,
    batchApi,
    battleApi,
    shopApi,
    quizApi,
    rankingApi,
    contentProfileApi,
    zonesApi
  },
  debugFlags: DEBUG_FLAGS
});

exposeGlobalFacade({ App, UI });
const globalSurfaceInventory = buildGlobalSurfaceInventory({ App, UI });
attachSurfaceMetadata({ App, UI, inventory: globalSurfaceInventory });
logSurfaceWarnings(globalSurfaceInventory, { debugFlags: DEBUG_FLAGS });
const systemNamespace = buildSystemNamespace({
  APP_CONFIG,
  App,
  UI,
  DomBridge,
  ModuleBridge,
  currentState,
  batchState,
  quizSession,
  radarChartInstances,
  CONSTANTS,
  TYPE_INFO,
  CONTENT_PROFILES,
  db,
  auth,
  storage,
  APP_FACADE_METHODS,
  facadeMountReport,
  globalSurfaceInventory,
  DEBUG_FLAGS,
  DEBUG_MARKERS,
  RUNTIME_ENV,
  clearAssetUrlCache: __clearAssetUrlCache
});

const globalBridgeReport = exposeLegacyGlobals({
  App,
  UI,
  DEBUG_FLAGS,
  RUNTIME_ENV,
  clearAssetUrlCache: __clearAssetUrlCache,
  forceOpenCardForge,
  systemNamespace
});

    const __bootState = {
      stage: 'script-loaded',
      detail: '模組腳本已載入，等待初始化',
      error: '',
      ready: false,
      fallbackLoginBound: false
    };

    // @debug-removable:boot-panel
    const __renderBootStatus = () => {
      const panel = document.getElementById('bootStatusPanel');
      if (!panel) return;
      if (!DEBUG_FLAGS.showBootPanel) {
        panel.style.display = 'none';
        return;
      }
      panel.style.display = '';
      const lines = [];
      lines.push(`啟動階段：${__bootState.stage}`);
      if (__bootState.detail) lines.push(`狀態：${__bootState.detail}`);
      if (__bootState.error) lines.push(`錯誤：${__bootState.error}`);
      if (DEBUG_FLAGS.enableVerboseBootStatus && !__bootState.ready && window.location.protocol === 'file:') {
        lines.push('提醒：若使用分檔/模組版，請改用本機伺服器開啟，不要直接雙擊 HTML。');
      }
      panel.textContent = lines.join('\n');
      panel.style.borderColor = __bootState.error ? 'rgba(255,107,107,0.45)' : 'rgba(0,229,255,0.18)';
      panel.style.color = __bootState.error ? '#ffd6d6' : 'var(--text-muted)';
      panel.style.background = __bootState.error ? 'rgba(66,12,12,0.72)' : 'rgba(7,20,33,0.72)';
    };

    function __setBootStatus(stage, detail = '') {
      __bootState.stage = stage || __bootState.stage;
      if (typeof detail === 'string') __bootState.detail = detail;
      __renderBootStatus();
    }

    function __showBootFailure(error, stage = '') {
      const message = (error && (error.stack || error.message)) ? (error.stack || error.message) : String(error || '未知錯誤');
      __bootState.error = message;
      __setBootStatus(stage || 'failed', '初始化未完成');
      console.error('[boot]', stage || 'failed', error);
    }

    // @debug-removable:fallback-login
    function __bindLoginFallback(appRef) {
      if (!DEBUG_FLAGS.enableFallbackLogin) return false;
      if (__bootState.fallbackLoginBound) return true;
      const btn = document.getElementById('loginBtn');
      const emailInput = document.getElementById('adminEmail');
      const pwdInput = document.getElementById('adminPassword');
      if (!btn || !emailInput || !pwdInput) {
        __setBootStatus('login-controls-missing', '找不到登入欄位，請檢查 loginView DOM');
        return false;
      }

      const enterHandler = (e) => {
        if (e.key === 'Enter') btn.click();
      };
      emailInput.addEventListener('keypress', enterHandler);
      pwdInput.addEventListener('keypress', enterHandler);

      btn.addEventListener('click', async (e) => {
        if (__bootState.ready || btn.dataset.loginBound === 'app') return;
        e.preventDefault();
        const email = String(emailInput.value || '').trim();
        const pwd = String(pwdInput.value || '');
        if (!email || !pwd) {
          UI.alert('系統尚未完成初始化，且目前尚未輸入管理者 Email / 密碼。', '尚未就緒');
          __setBootStatus('fallback-login-blocked', '等待初始化完成，或先檢查上方錯誤訊息');
          return;
        }
        const originalText = btn.innerText;
        btn.disabled = true;
        btn.innerText = 'BOOT RECOVERY...';
        try {
          __setBootStatus('fallback-login', '主程式初始化未完成，改用保底登入流程');
          await signInWithEmailAndPassword(auth, email, pwd);
          try { localStorage.setItem('adminEmail', email); } catch (_) {}
          if (auth.currentUser) {
            try { await auth.currentUser.getIdToken(true); } catch (_) {}
          }
          const ok = appRef && appRef.isCurrentUserAdmin ? await appRef.isCurrentUserAdmin() : false;
          currentState.isAdmin = ok;
          if (!ok) {
            const uid = auth.currentUser?.uid || '(unknown uid)';
            await signOut(auth);
            UI.alert(`此帳號已成功登入，但目前仍未通過管理者驗證。

目前登入 UID：${uid}

請檢查 custom claim 或 /admins/${uid} 是否存在。`, '權限不足');
            __setBootStatus('fallback-login-denied', '帳號已登入，但尚未具備管理權限');
            return;
          }
          UI.hide('loginView');
          UI.show('dashboardView');
          UI.toast('ACCESS GRANTED (RECOVERY MODE)');
          if (appRef && appRef.openRequestedAdminPanel) await appRef.openRequestedAdminPanel();
          if (appRef && appRef.resetSessionIdleTimer) appRef.resetSessionIdleTimer();
          pwdInput.value = '';
          __setBootStatus('fallback-login-success', '已透過保底登入流程進入老師端');
        } catch (err) {
          __showBootFailure(err, 'fallback-login');
          UI.alert(`登入失敗。

目前系統尚未完全初始化，請先查看登入按鈕下方的啟動訊息。`, '登入失敗');
        } finally {
          btn.disabled = false;
          btn.innerText = originalText;
        }
      });

      __bootState.fallbackLoginBound = true;
      __setBootStatus('fallback-login-bound', '已建立登入保底機制');
      return true;
    }

    // @debug-removable:boot-error-capture
    if (DEBUG_FLAGS.captureGlobalBootErrors) {
      window.addEventListener('error', (event) => {
        if (__bootState.ready) return;
        __showBootFailure(event?.error || event?.message || '未知錯誤', `window.error:${event?.filename || 'inline'}`);
      });
      window.addEventListener('unhandledrejection', (event) => {
        if (__bootState.ready) return;
        __showBootFailure(event?.reason || 'Promise rejection', 'unhandledrejection');
      });
    }

    let __shanHaiBootstrapped = false;
    const __bootstrapShanHaiApp = async () => {
      if (__shanHaiBootstrapped) return;
      __shanHaiBootstrapped = true;
      __setBootStatus('bootstrap-start', '準備啟動系統');
      if (DEBUG_FLAGS.enableFallbackLogin) __bindLoginFallback(App);
      if (DEBUG_FLAGS.enableVerboseBootStatus && window.location.protocol === 'file:') {
        __setBootStatus('bootstrap-start', '目前以 file:// 開啟；若是分檔版請改用本機伺服器');
      }
      try {
        await App.init();
      } catch (e) {
        __showBootFailure(e, __bootState.stage || 'bootstrap');
        try {
          UI.alert(`初始化失敗: ${(e && e.message) ? e.message : e}

請先查看登入按鈕下方的啟動訊息，以確認卡在哪個階段。`, '系統通知');
        } catch (_) {}
      }
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', __bootstrapShanHaiApp, { once: true });
    } else {
      __bootstrapShanHaiApp();
    }
    window.addEventListener('load', __bootstrapShanHaiApp, { once: true });