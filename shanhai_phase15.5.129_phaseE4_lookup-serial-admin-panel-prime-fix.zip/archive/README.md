# Archive governance

This directory stores historical inactive variants and backups that are intentionally kept out of the active `js/` workspace.

## Layout

- `archive/variants/js/...`: inactive entry, core, and module variants retained for rollback/forensics
- `archive/backups/js/...`: backup snapshots such as `.bak` and rewritten scratch files

## Rules

1. Do not apply new fixes to archived files first.
2. Canonical runtime files remain under `js/` and are defined by `js/ENTRY_CHAIN_MANIFEST.json` and `js/MODULE_VARIANT_MANIFEST.json`.
3. If a rollback is needed, inspect the manifest entries and then restore deliberately rather than editing archived copies in place.
