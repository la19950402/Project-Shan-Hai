# Phase 15.5.30 - Risk Reduction Phase 6

## 本輪目標
- 不新增全域變數
- 繼續消除 active 主鏈中的高風險 `this.*` 跨模組 helper 依賴
- 保持 canonical active chain，不再新增入口副本

## 已完成
1. battle 模組將以下跨模組 helper 改為 injected deps / local safe wrappers：
   - `normalizeSerial`
   - `applyDataMigration`
   - `saveToDB`
   - `settleRewardViaServer`
   - `buildBattleRewardEventId`
   - `resolveBattleRecordBase`
   - `buildBattleOutcomeRecord`
   - `getBattleRewardDisplay`
   - `refreshStudentRewardPanel`
   - `isCurrentUserAdmin`
2. zones 模組將以下跨模組 helper 改為 injected deps / local safe wrappers：
   - `getRequestedAdminPanel`
   - `startWebNfc`
   - `stopWebNfc`
   - `applyDataMigration`
   - `processEvolution`
   - `saveToDB`
3. shop 模組移除剩餘的 `this.normalizeSerial(...)` 呼叫，改走 module-local `normalizeSerialSafe(...)`。
4. active canonical chain 已統一升級到 `phase15phase6`。

## 仍保留到下一輪
- battle 內部大量 `this.*` 自呼叫（屬於同模組方法鏈）尚未全面消除。
- zones 內部以 `this.*` 進行同模組流程轉接的部分尚未全面改寫。
- 可進一步導入共享 DOM query helper，降低重複的 `document.getElementById(...)`。
